using UnityEngine;
using System;
using System.Linq;
using System.Collections.Generic;

public class QuestManager : MonoBehaviour
{
    public static QuestManager Instance { get; private set; }

    [Tooltip("Catálogo opcional para arrancar quests por ID aunque no se hayan añadido antes.")]
    [SerializeField] private List<QuestData> questCatalog = new();

    // runtime: questId -> RuntimeQuest
    private readonly Dictionary<string, RuntimeQuest> _runtime = new(64);

    // visibilidad por quest (archivada vs visible)
    private readonly Dictionary<string, QuestVisibility> _visibility = new(StringComparer.Ordinal);
    // seguimiento ("seguir" misión en el tracker)
    private readonly HashSet<string> _followed = new(StringComparer.Ordinal);

    // índice: conditionId -> lista de (questId, stepIndex) para completar en O(1)
    private readonly Dictionary<string, List<StepRef>> _conditionIndex = new(64, StringComparer.Ordinal);

    // Quests cuyos requiredItems (consumeOnComplete) ya se han consumido del inventario.
    // Evita volver a consumir un item (p.ej. una poción comprada) cuando una misión ya
    // completada se re-procesa como "auto-completar" al restaurar flags de un save
    // (INC-020: la poción desaparecía tras recargar/completar por una re-consumición
    // no idempotente de ConsumeRequiredItems).
    private readonly HashSet<string> _itemsConsumedForQuest = new(StringComparer.Ordinal);

    // Referencia al inventario para detectar items añadidos
    private Inventory _cachedInventory;
    private bool _isSubscribedToInventory;

    // Referencia al wardrobe para detectar items de wardrobe añadidos
    private WardrobeInventory _cachedWardrobe;
    private bool _isSubscribedToWardrobe;

    // Índice de QuestChainEntries: questId → entry, para evitar FindObjectsByType en hot paths.
    // Se marca dirty al cargar/descargar escena; se reconstruye bajo demanda.
    private readonly Dictionary<string, Game.NPC.Modules.QuestChainEntry> _questChainIndex = new(32, StringComparer.Ordinal);
    private bool _questChainIndexDirty = true;

    // RestoreFromProfileFlags auto-completa quests (paso 5) llamando
    // a CompleteQuest de forma síncrona en plena carga/restauración. Antes eso disparaba
    // OnQuestCompleted igual que una compleción real de gameplay, y los ejecutores de post-action
    // (NPCQuestActionExecutor) reaccionaban lanzando diálogos/moviendo NPCs durante la carga del
    // save. Con este flag, CompleteQuest sigue marcando el estado y archivando la quest con
    // normalidad, pero no dispara el evento público mientras se está restaurando.
    private bool _isRestoringFromProfile;

    // Eventos públicos para UI/lógica externa
    public event Action<string> OnQuestStarted;
    public event Action<string> OnQuestCompleted;
    public event Action<string, int> OnStepCompleted;
    public event Action OnQuestsChanged;
    public event Action<string, QuestVisibility> OnQuestVisibilityChanged;
    public event Action<string, bool> OnQuestFollowChanged;

    #region Unity
    void Awake()
    {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void OnDestroy()
    {
        if (Instance == this)
        {
            Instance = null;
        }
    }

#if UNITY_EDITOR
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    static void ResetStatics()
    {
        Instance = null;
    }
#endif
    
    void Start()
    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log("[QuestManager] Start - Intentando suscribirse al inventario y wardrobe");
#endif
        // Intentar suscribirse al inventario y wardrobe
        TrySubscribeToInventory();
        TrySubscribeToWardrobe();
    }
    
    void OnEnable()
    {
        PlayerService.OnPlayerRegistered += OnPlayerRegistered;
        Game.NPC.PlayerParty.OnMemberJoined += OnPartyMemberJoined;
        UnityEngine.SceneManagement.SceneManager.sceneLoaded   += OnSceneLoaded;
        UnityEngine.SceneManagement.SceneManager.sceneUnloaded += OnSceneUnloaded;
    }

    void OnDisable()
    {
        PlayerService.OnPlayerRegistered -= OnPlayerRegistered;
        Game.NPC.PlayerParty.OnMemberJoined -= OnPartyMemberJoined;
        UnityEngine.SceneManagement.SceneManager.sceneLoaded   -= OnSceneLoaded;
        UnityEngine.SceneManagement.SceneManager.sceneUnloaded -= OnSceneUnloaded;
        UnsubscribeFromInventory();
        UnsubscribeFromWardrobe();
    }

    private void OnSceneLoaded(UnityEngine.SceneManagement.Scene scene, UnityEngine.SceneManagement.LoadSceneMode mode)
        => _questChainIndexDirty = true;

    private void OnSceneUnloaded(UnityEngine.SceneManagement.Scene scene)
        => _questChainIndexDirty = true;
    
    private void OnPlayerRegistered(GameObject player)
    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[QuestManager] OnPlayerRegistered llamado para '{player?.name}'");
#endif
        // Re-intentar suscripción cuando el player está disponible
        TrySubscribeToInventory();
        TrySubscribeToWardrobe();
    }
    #endregion

    #region API básica
    public bool HasQuest(string questId) => _runtime.ContainsKey(questId);

    public QuestState GetState(string questId)
        => _runtime.TryGetValue(questId, out var rq) ? rq.State : QuestState.Inactive;

    public IEnumerable<RuntimeQuest> GetAll() => _runtime.Values;

    /// <summary>
    /// Datos de diseño (QuestData) de una quest por su ID, sin pasar por GetAll()+LINQ. Pensado
    /// para UI que solo necesita el nombre/descripción localizados (p.ej. QuestStartedBannerUI),
    /// no el estado de progreso -- ver INC-199.
    /// </summary>
    public bool TryGetQuestData(string questId, out QuestData data)
    {
        if (_runtime.TryGetValue(questId, out var rq) && rq.Data != null)
        {
            data = rq.Data;
            return true;
        }
        data = null;
        return false;
    }

    public QuestVisibility GetVisibility(string questId)
    {
        if (string.IsNullOrEmpty(questId)) return QuestVisibility.Visible;
        if (_visibility.TryGetValue(questId, out var v)) return v;
        return QuestVisibility.Visible;
    }

    public void SetVisibility(string questId, QuestVisibility state)
    {
        if (string.IsNullOrEmpty(questId)) return;
        if (!_runtime.ContainsKey(questId)) return;

        var current = GetVisibility(questId);
        if (current == state) return;

        _visibility[questId] = state;
        OnQuestVisibilityChanged?.Invoke(questId, state);
        OnQuestsChanged?.Invoke();
    }

    public bool IsFollowed(string questId)
    {
        if (string.IsNullOrEmpty(questId)) return false;
        return _followed.Contains(questId);
    }

    public void SetFollowed(string questId, bool followed)
    {
        if (string.IsNullOrEmpty(questId)) return;
        if (!_runtime.ContainsKey(questId)) return;

        bool changed;
        if (followed)
            changed = _followed.Add(questId);
        else
            changed = _followed.Remove(questId);

        if (changed)
        {
            OnQuestFollowChanged?.Invoke(questId, followed);
            OnQuestsChanged?.Invoke();
        }
    }

    public void AddQuest(QuestData data)
    {
        if (!data || string.IsNullOrEmpty(data.questId) || _runtime.ContainsKey(data.questId)) return;

        var rq = new RuntimeQuest(data);
        _runtime[data.questId] = rq;
        _visibility[data.questId] = QuestVisibility.Visible;
        _followed.Remove(data.questId);
        IndexQuestConditions(rq);
        OnQuestsChanged?.Invoke();
    }

    public void StartQuest(string questId)
    {
        if (!_runtime.TryGetValue(questId, out var rq))
        {
            var data = questCatalog.FirstOrDefault(q => q && q.questId == questId);
            if (!data)
            {
                // FIX (21 sep 2026, Raul: "las misiones no estan empezando" -- este metodo no
                // dejaba NINGUN rastro en consola cuando el questId no estaba en questCatalog, asi
                // que "el grafo llamo a StartQuest pero la mision no aparecio" era indistinguible de
                // "StartQuest ni se llamo" con solo mirar el log. Ahora avisa.
                Debug.LogWarning($"[QuestManager] StartQuest('{questId}') ignorado: no existe ninguna " +
                    "QuestData con ese questId en questCatalog. Revisa que el asset de la mision este " +
                    "arrastrado a la lista questCatalog del QuestManager de la escena.");
                return;
            }

            rq = new RuntimeQuest(data);
            _runtime[questId] = rq;
            _visibility[questId] = QuestVisibility.Visible;
            _followed.Remove(questId);
            IndexQuestConditions(rq);
        }

        if (rq.State == QuestState.Inactive)
        {
            rq.State = QuestState.Active;
            
            // Verificar si el jugador ya tiene items requeridos o miembros en el equipo
            CheckExistingRequirementsForQuest(rq);
            
            OnQuestStarted?.Invoke(questId);
            OnQuestsChanged?.Invoke();
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager] Quest iniciada: '{questId}' ({rq.Data?.displayNameId})");
#endif
        }
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        else
        {
            Debug.Log($"[QuestManager] StartQuest('{questId}') ignorado: ya estaba en estado {rq.State} (no Inactive).");
        }
#endif
    }

    public void CompleteQuest(string questId)
    {
        if (!_runtime.TryGetValue(questId, out var rq)) return;
        if (rq.State == QuestState.Completed) return;

        // Consumir items del inventario si están configurados para ser consumidos
        ConsumeRequiredItems(questId);

        rq.State = QuestState.Completed;
        // no propagar el evento (y sus post-actions) mientras estamos restaurando
        // el estado desde un perfil/save; ver comentario en _isRestoringFromProfile.
        if (!_isRestoringFromProfile)
            OnQuestCompleted?.Invoke(questId);
        ArchiveCompletedQuest(questId);
        OnQuestsChanged?.Invoke();
    }
    
    /// <summary>
    /// Consume los items requeridos de una quest del inventario del jugador.
    /// Solo consume items donde consumeOnComplete = true.
    /// </summary>
    private void ConsumeRequiredItems(string questId)
    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[QuestManager.ConsumeRequiredItems] Iniciando para quest '{questId}'");
#endif

        // Idempotencia: si esta quest ya consumió sus items requeridos anteriormente
        // (p.ej. en una sesión previa), no volver a hacerlo. Sin este guard, una quest
        // que se re-completa por el flujo de auto-completado al restaurar un save
        // (ver RestoreFromProfileFlags, paso 5) vuelve a llamar a ConsumeRequiredItems
        // y consume de nuevo el item del inventario actual, aunque no tenga nada que
        // ver con la partida que se está restaurando (INC-020).
        if (_itemsConsumedForQuest.Contains(questId))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager.ConsumeRequiredItems] Quest '{questId}' ya había consumido sus items requeridos anteriormente, no se repite.");
#endif
            return;
        }

        var questEntry = FindQuestChainEntry(questId);
        if (questEntry == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[QuestManager.ConsumeRequiredItems] No se encontró QuestChainEntry para quest '{questId}'");
#endif
            return;
        }
        
        if (questEntry.requiredItems == null || questEntry.requiredItems.Length == 0)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager.ConsumeRequiredItems] Quest '{questId}' no tiene items requeridos");
#endif
            return;
        }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[QuestManager.ConsumeRequiredItems] Quest '{questId}' tiene {questEntry.requiredItems.Length} items requeridos");
#endif

        // Obtener el inventario del jugador usando PlayerService (consistente con el resto del código)
        if (!PlayerService.TryGetComponent(out Inventory inventory, includeInactive: true, allowSceneLookup: true))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[QuestManager.ConsumeRequiredItems] No se pudo obtener Inventory para consumir items de quest '{questId}'");
#endif
            return;
        }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[QuestManager.ConsumeRequiredItems] Inventario obtenido, procesando items...");
#endif

        foreach (var itemReq in questEntry.requiredItems)
        {
            if (itemReq.item == null)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[QuestManager.ConsumeRequiredItems] Item requerido es null en quest '{questId}'");
#endif
                continue;
            }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager.ConsumeRequiredItems] Procesando item '{itemReq.item.itemId}' - consumeOnComplete={itemReq.consumeOnComplete}");
#endif
            
            if (!itemReq.consumeOnComplete)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[QuestManager.ConsumeRequiredItems] Item '{itemReq.item.itemId}' no está configurado para ser consumido (consumeOnComplete=false)");
#endif
                continue;
            }

            // Verificar que el jugador tiene suficientes items antes de consumir
            int currentCount = inventory.Count(itemReq.item.itemId);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager.ConsumeRequiredItems] Cantidad en inventario de '{itemReq.item.itemId}': {currentCount}/{itemReq.amount}");
#endif
            
            if (currentCount < itemReq.amount)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[QuestManager.ConsumeRequiredItems] El jugador no tiene suficientes '{itemReq.item.itemId}' para consumir ({currentCount}/{itemReq.amount})");
#endif
                continue;
            }

            // Consumir los items usando TryConsume
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager.ConsumeRequiredItems] Intentando consumir {itemReq.amount}x '{itemReq.item.itemId}'...");
#endif
            
            if (inventory.TryConsume(itemReq.item, itemReq.amount, notifyChanges: true))
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[QuestManager.ConsumeRequiredItems] Consumido {itemReq.amount}x '{itemReq.item.itemId}' del inventario al completar quest '{questId}'");
#endif
            }
            else
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[QuestManager.ConsumeRequiredItems] Falló al consumir {itemReq.amount}x '{itemReq.item.itemId}'");
#endif
            }
        }

        // Marcar como procesada para que no vuelva a consumir estos items si la quest
        // se re-completa (auto-completado al restaurar un save, dobles disparos, etc.).
        _itemsConsumedForQuest.Add(questId);

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[QuestManager.ConsumeRequiredItems] Proceso completado para quest '{questId}'");
#endif
    }

    /// <summary>
    /// Fuerza la verificación de miembros del equipo para todas las quests activas.
    /// Útil cuando un NPC se une al party pero el evento no se disparó correctamente.
    /// </summary>
    public void ForceCheckPartyMembersForActiveQuests()
    {
        if (!Game.NPC.PlayerParty.HasInstance)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[QuestManager] ForceCheckPartyMembersForActiveQuests: No hay PlayerParty disponible");
#endif
            return;
        }

        var party = Game.NPC.PlayerParty.Instance;
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[QuestManager] ForceCheckPartyMembersForActiveQuests - Miembros en party: {party.MemberCount}");
#endif
        int totalStepsCompleted = 0;
        foreach (var kv in _runtime)
        {
            if (kv.Value.State != QuestState.Active) continue;
            var rq = kv.Value;
            var questEntry = FindQuestChainEntry(rq.Id);
            if (questEntry != null && questEntry.requiredPartyMembers != null && questEntry.requiredPartyMembers.Length > 0)
            {
                int stepsCompleted = CheckPartyMembersForQuest(rq, party, questEntry.requiredPartyMembers);
                totalStepsCompleted += stepsCompleted;
            }
        }

        if (totalStepsCompleted > 0)
            OnQuestsChanged?.Invoke();
    }

    public void MarkStepDone(string questId, int stepIndex)
    {
        if (!_runtime.TryGetValue(questId, out var rq)) return;
        if (rq.State != QuestState.Active) return;
        if ((uint)stepIndex >= (uint)rq.Steps.Length) return;

        var step = rq.Steps[stepIndex];
        if (step.completed) return;

        step.completed = true;
        OnStepCompleted?.Invoke(questId, stepIndex);

        if (AllStepsCompleted(rq))
        {
            if (ShouldAutoCompleteWhenAllStepsDone(questId))
            {
                // Usar la ruta centralizada para mantener side-effects consistentes
                // (consumo de items, archivado, eventos, etc.).
                CompleteQuest(questId);
                return;
            }

            var questEntry = FindQuestChainEntry(questId);
            var completionMode = questEntry != null ? questEntry.completionMode.ToString() : "Unknown/NoChainEntry";
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager] Quest '{questId}' con todos los pasos completos, sin autocompletado (CompletionMode: {completionMode}).");
#endif
        }

        OnQuestsChanged?.Invoke();
    }

    /// <summary>
    /// Determina si una quest debe auto-completarse al tener todos los pasos listos.
    /// Regla estricta: SOLO auto-completa cuando el modo es AutoCompleteWhenStepsReady.
    /// </summary>
    private bool ShouldAutoCompleteWhenAllStepsDone(string questId)
    {
        var questEntry = FindQuestChainEntry(questId);
        if (questEntry == null)
            return false;

        return questEntry.completionMode == QuestCompletionMode.AutoCompleteWhenStepsReady;
    }

    /// <summary>
    /// Completa un step específico de una quest usando su Condition ID.
    /// Este es el método recomendado para usar desde nodos narrativos.
    /// </summary>
    public void CompleteQuestStepByConditionId(string questId, string stepConditionId)
    {
        if (string.IsNullOrEmpty(questId) || string.IsNullOrEmpty(stepConditionId))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[QuestManager] CompleteQuestStepByConditionId - questId o stepConditionId vacío");
#endif
            return;
        }

        if (!_runtime.TryGetValue(questId, out var rq))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[QuestManager] CompleteQuestStepByConditionId - Quest '{questId}' no existe en runtime");
#endif
            return;
        }

        if (rq.Steps == null || rq.Steps.Length == 0)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[QuestManager] CompleteQuestStepByConditionId - Quest '{questId}' no tiene steps");
#endif
            return;
        }

        // Buscar el step por su conditionId
        int stepIndex = -1;
        for (int i = 0; i < rq.Steps.Length; i++)
        {
            if (rq.Steps[i].conditionId == stepConditionId)
            {
                stepIndex = i;
                break;
            }
        }

        if (stepIndex < 0)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[QuestManager] CompleteQuestStepByConditionId - No se encontró step con conditionId '{stepConditionId}' en quest '{questId}'");
#endif
            return;
        }

        // Usar el método existente para completar el step
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[QuestManager] Completando step '{stepConditionId}' (índice {stepIndex}) en quest '{questId}'");
#endif
        MarkStepDone(questId, stepIndex);
    }

    public bool IsStepCompleted(string questId, int stepIndex)
        => _runtime.TryGetValue(questId, out var rq)
           && (uint)stepIndex < (uint)rq.Steps.Length
           && rq.Steps[stepIndex].completed;

    public bool AreAllStepsCompleted(string questId)
        => _runtime.TryGetValue(questId, out var rq) && AllStepsCompleted(rq);

    /// <summary>
    /// Busca el índice de un step por su conditionId.
    /// Retorna -1 si no se encuentra.
    /// </summary>
    public int FindStepIndexByConditionId(string questId, string conditionId)
    {
        if (string.IsNullOrEmpty(questId) || string.IsNullOrEmpty(conditionId))
            return -1;
        
        if (!_runtime.TryGetValue(questId, out var rq) || rq.Steps == null)
            return -1;
        
        for (int i = 0; i < rq.Steps.Length; i++)
        {
            if (string.Equals(rq.Steps[i].conditionId, conditionId, StringComparison.OrdinalIgnoreCase))
                return i;
        }
        
        return -1;
    }

    public void CompleteByCondition(string conditionId)
    {
        if (string.IsNullOrEmpty(conditionId)) return;
        if (!_conditionIndex.TryGetValue(conditionId, out var list)) return;

        for (int i = 0; i < list.Count; i++)
        {
            var sr = list[i];
            if (GetState(sr.questId) != QuestState.Active) continue;
            MarkStepDone(sr.questId, sr.stepIndex);
        }
    }

    void ArchiveCompletedQuest(string questId)
    {
        if (string.IsNullOrEmpty(questId)) return;
        SetFollowed(questId, false);
        SetVisibility(questId, QuestVisibility.Hidden);
    }
    #endregion

    #region Persistencia vía flags (export/import)
    // Formato de flags:
    //   QUEST_COMPLETED:<questId>
    //   QUEST_ACTIVE:<questId>
    //   QUEST_STEP_DONE:<questId>:<stepIndex>
    //   QUEST_ARCHIVED:<questId>
    //   QUEST_FOLLOWED:<questId>

    private const string Q_COMPLETED = "QUEST_COMPLETED:";
    private const string Q_ACTIVE    = "QUEST_ACTIVE:";
    private const string Q_STEP_DONE = "QUEST_STEP_DONE:";
    private const string Q_ARCHIVED  = "QUEST_ARCHIVED:";
    private const string Q_FOLLOWED  = "QUEST_FOLLOWED:"; // legacy alias
    private const string Q_TRACKED   = "QUEST_TRACKED:";
    private const string Q_ITEMS_CONSUMED = "QUEST_ITEMS_CONSUMED:";

    /// <summary>Reconstruye el estado a partir de flags del perfil.</summary>
    public void RestoreFromProfileFlags(IReadOnlyList<string> flags)
    {
        // ver comentario en _isRestoringFromProfile.
        _isRestoringFromProfile = true;
        try
        {
            RestoreFromProfileFlagsInternal(flags);
        }
        finally
        {
            _isRestoringFromProfile = false;
        }
    }

    private void RestoreFromProfileFlagsInternal(IReadOnlyList<string> flags)
    {
        ResetAllQuests();

        if (flags == null || flags.Count == 0) return;

        var toActive = new HashSet<string>(StringComparer.Ordinal);
        var toArchived = new HashSet<string>(StringComparer.Ordinal);
        var toFollowed = new HashSet<string>(StringComparer.Ordinal);

        // 1) Marcar completadas / recopilar activas
        for (int i = 0; i < flags.Count; i++)
        {
            var f = flags[i];
            if (string.IsNullOrEmpty(f)) continue;

            if (f.StartsWith(Q_COMPLETED, StringComparison.Ordinal))
            {
                var qid = f.Substring(Q_COMPLETED.Length);
                if (string.IsNullOrEmpty(qid)) continue;
                EnsureRuntimeQuest(qid, out var rq);
                if (rq == null)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.LogWarning($"[QuestManager.RestoreFromProfileFlags] Quest '{qid}' no encontrada en catálogo aunque tiene flag QUEST_COMPLETED");
#endif
                    continue;
                }
                rq.State = QuestState.Completed;
                _visibility[qid] = QuestVisibility.Hidden;
                // Marcar todos los pasos como completados si la misión está completada
                if (rq.Steps != null)
                {
                    for (int s = 0; s < rq.Steps.Length; s++)
                        rq.Steps[s].completed = true;
                }
            }
            else if (f.StartsWith(Q_ACTIVE, StringComparison.Ordinal))
            {
                var qid = f.Substring(Q_ACTIVE.Length);
                if (string.IsNullOrEmpty(qid)) continue;
                EnsureRuntimeQuest(qid, out _);
                toActive.Add(qid);
            }
            else if (f.StartsWith(Q_ARCHIVED, StringComparison.Ordinal))
            {
                var qid = f.Substring(Q_ARCHIVED.Length);
                if (string.IsNullOrEmpty(qid)) continue;
                EnsureRuntimeQuest(qid, out _);
                toArchived.Add(qid);
            }
            else if (f.StartsWith(Q_FOLLOWED, StringComparison.Ordinal) || f.StartsWith(Q_TRACKED, StringComparison.Ordinal))
            {
                var prefixLen = f.StartsWith(Q_FOLLOWED, StringComparison.Ordinal) ? Q_FOLLOWED.Length : Q_TRACKED.Length;
                var qid = f.Substring(prefixLen);
                if (string.IsNullOrEmpty(qid)) continue;
                EnsureRuntimeQuest(qid, out _);
                toFollowed.Add(qid);
            }
            else if (f.StartsWith(Q_ITEMS_CONSUMED, StringComparison.Ordinal))
            {
                var qid = f.Substring(Q_ITEMS_CONSUMED.Length);
                if (string.IsNullOrEmpty(qid)) continue;
                // Restaurar el marcador de "items ya consumidos" ANTES del paso 5
                // (auto-completado de quests con todos los pasos hechos) para que
                // ConsumeRequiredItems no vuelva a quitar el item del inventario (INC-020).
                _itemsConsumedForQuest.Add(qid);
            }
        }

        foreach (var qid in toActive)
        {
            if (_runtime.TryGetValue(qid, out var rq) && rq.State != QuestState.Completed)
                rq.State = QuestState.Active;
        }

        // 2) Aplicar visibilidad archivada
        foreach (var qid in toArchived)
        {
            if (_runtime.ContainsKey(qid))
                _visibility[qid] = QuestVisibility.Hidden;
        }

        // 3) Aplicar seguimiento
        _followed.Clear();
        foreach (var qid in toFollowed)
        {
            if (_runtime.ContainsKey(qid))
            {
                _followed.Add(qid);
                // No sobrescribir "Hidden" con "Tracked": si está archivada, mantener Hidden
                if (GetVisibility(qid) != QuestVisibility.Hidden)
                    _visibility[qid] = QuestVisibility.Tracked;
            }
        }

        // 4b) Auto-archivar completadas y limpiar seguimiento
        foreach (var kvp in _runtime)
        {
            if (kvp.Value.State == QuestState.Completed)
            {
                _followed.Remove(kvp.Key);
                _visibility[kvp.Key] = QuestVisibility.Hidden;
            }
        }

        // 4) Marcar pasos completados
        for (int i = 0; i < flags.Count; i++)
        {
            var f = flags[i];
            if (string.IsNullOrEmpty(f)) continue;
            if (!f.StartsWith(Q_STEP_DONE, StringComparison.Ordinal)) continue;

            var rest = f.Substring(Q_STEP_DONE.Length);
            var sep = rest.LastIndexOf(':');
            if (sep <= 0) continue;

            var qid = rest.Substring(0, sep);
            var idxStr = rest.Substring(sep + 1);
            if (!int.TryParse(idxStr, out int stepIdx)) continue;

            EnsureRuntimeQuest(qid, out var rq2);
            if (rq2 == null)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[QuestManager.RestoreFromProfileFlags] Quest '{qid}' no encontrada en catálogo aunque tiene flag QUEST_STEP_DONE");
#endif
                continue;
            }
            if (rq2.State == QuestState.Inactive) rq2.State = QuestState.Active;
            if ((uint)stepIdx < (uint)rq2.Steps.Length)
                rq2.Steps[stepIdx].completed = true;
        }

        // 5) Auto-completar quests activas que ya están con todos los pasos completos
        // (caso típico al cargar save y/o tras cambiar el completionMode en configs).
        var questsReadyToAutoComplete = new List<string>();
        foreach (var kvp in _runtime)
        {
            var rq = kvp.Value;
            if (rq.State != QuestState.Active) continue;
            if (!AllStepsCompleted(rq)) continue;
            if (!ShouldAutoCompleteWhenAllStepsDone(rq.Id)) continue;
            questsReadyToAutoComplete.Add(rq.Id);
        }

        for (int i = 0; i < questsReadyToAutoComplete.Count; i++)
        {
            var questId = questsReadyToAutoComplete[i];
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager] Auto-completando quest '{questId}' tras RestoreFromProfileFlags (steps ya completos).");
#endif
            CompleteQuest(questId);
        }

        OnQuestsChanged?.Invoke();

        // helper local
        void EnsureRuntimeQuest(string questId, out RuntimeQuest rqOut)
        {
            if (!_runtime.TryGetValue(questId, out rqOut))
            {
                var data = questCatalog.FirstOrDefault(q => q && q.questId == questId);
                if (data != null)
                {
                    rqOut = new RuntimeQuest(data);
                    _runtime[questId] = rqOut;
                    IndexQuestConditions(rqOut);
                }
            }
        }
    }

    /// <summary>Vuelca el estado actual a una lista de flags (determinista).</summary>
    public void ExportFlags(List<string> outFlags)
    {
        if (outFlags == null) return;

        foreach (var rq in _runtime.Values)
        {
            var state = rq.State;
            if (state == QuestState.Completed)
            {
                outFlags.Add(Q_COMPLETED + rq.Id);
                if (_itemsConsumedForQuest.Contains(rq.Id))
                    outFlags.Add(Q_ITEMS_CONSUMED + rq.Id);
            }
            else if (state == QuestState.Active)
            {
                outFlags.Add(Q_ACTIVE + rq.Id);
                for (int i = 0; i < rq.Steps.Length; i++)
                    if (rq.Steps[i].completed)
                        outFlags.Add($"{Q_STEP_DONE}{rq.Id}:{i}");
            }

            // Visibilidad: si está archivada, emitir flag incluso cuando esté completada
            var vis = GetVisibility(rq.Id);
            if (vis == QuestVisibility.Hidden)
            {
                outFlags.Add(Q_ARCHIVED + rq.Id);
            }
            else if (IsFollowed(rq.Id) || vis == QuestVisibility.Tracked)
            {
                // Seguimiento: emitir solo si NO está archivada. Evita restaurar archivadas como "tracked".
                outFlags.Add(Q_TRACKED + rq.Id);
            }
        }
    }
    #endregion

    #region Internals
    private static bool AllStepsCompleted(RuntimeQuest rq)
    {
        var steps = rq.Steps;
        for (int i = 0; i < steps.Length; i++)
            if (!steps[i].completed) return false;
        return true;
    }

    private void IndexQuestConditions(RuntimeQuest rq)
    {
        var steps = rq.Steps;
        for (int i = 0; i < steps.Length; i++)
        {
            var cid = steps[i].conditionId;
            if (string.IsNullOrEmpty(cid)) continue;

            if (!_conditionIndex.TryGetValue(cid, out var lst))
            {
                lst = new List<StepRef>(2);
                _conditionIndex[cid] = lst;
            }
            lst.Add(new StepRef(rq.Id, i));
        }
    }

    private readonly struct StepRef
    {
        public readonly string questId;
        public readonly int stepIndex;
        public StepRef(string q, int i) { questId = q; stepIndex = i; }
    }

    // ===== Runtime model =====
    public class RuntimeQuest
    {
        public string Id => Data.questId;
        public QuestData Data { get; }
        public QuestState State { get; set; }
        public QuestStep[] Steps { get; }

        public RuntimeQuest(QuestData data)
        {
            Data = data;
            State = QuestState.Inactive;

            if (data.steps == null || data.steps.Length == 0)
            {
                Steps = Array.Empty<QuestStep>();
                return;
            }

            Steps = new QuestStep[data.steps.Length];
            for (int i = 0; i < data.steps.Length; i++)
            {
                var s = data.steps[i];
                Steps[i] = new QuestStep
                {
                    description = s.description,
                    conditionId = s.conditionId,
                    completed = false
                };
            }
        }
    }
    #endregion

    /// <summary>
    /// Verifica si el jugador ya tiene items requeridos por la quest o miembros en el equipo
    /// y marca automáticamente los pasos correspondientes como completados.
    /// </summary>
    private void CheckExistingRequirementsForQuest(RuntimeQuest rq)
    {
        if (rq == null || rq.Steps == null || rq.Steps.Length == 0)
            return;
        
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[QuestManager] CheckExistingRequirementsForQuest para quest '{rq.Id}'");
#endif
        
        int totalStepsCompleted = 0;
        
        // === Verificar items del inventario normal ===
        if (PlayerService.TryGetComponent(out Inventory inventory, includeInactive: true, allowSceneLookup: true))
        {
            var questEntry = FindQuestChainEntry(rq.Id);
            if (questEntry != null && questEntry.requiredItems != null && questEntry.requiredItems.Length > 0)
            {
                totalStepsCompleted += CheckInventoryItemsForQuest(rq, inventory, questEntry.requiredItems);
            }
        }
        
        // === Verificar items del wardrobe ===
        if (PlayerService.TryGetComponent(out WardrobeInventory wardrobe, includeInactive: true, allowSceneLookup: true))
        {
            var questEntry = FindQuestChainEntry(rq.Id);
            if (questEntry != null && questEntry.requiredWardrobeItems != null && questEntry.requiredWardrobeItems.Length > 0)
            {
                totalStepsCompleted += CheckWardrobeItemsForQuest(rq, wardrobe, questEntry.requiredWardrobeItems);
            }
        }

        // === Verificar miembros del equipo ===
        if (Game.NPC.PlayerParty.HasInstance)
        {
            var questEntry = FindQuestChainEntry(rq.Id);
            if (questEntry != null && questEntry.requiredPartyMembers != null && questEntry.requiredPartyMembers.Length > 0)
            {
                totalStepsCompleted += CheckPartyMembersForQuest(rq, Game.NPC.PlayerParty.Instance, questEntry.requiredPartyMembers);
            }
        }
        
        // Notificar cambios si se completó algún step
        if (totalStepsCompleted > 0)
        {
            OnQuestsChanged?.Invoke();
        }
    }
    
    /// <summary>
    /// Verifica items del inventario para una quest
    /// </summary>
    private int CheckInventoryItemsForQuest(RuntimeQuest rq, Inventory inventory, Game.NPC.Modules.ItemRequirement[] requiredItems)
    {
        int stepsCompleted = 0;
        foreach (var itemReq in requiredItems)
        {
            if (itemReq.item == null) continue;
            string conditionId = itemReq.GetStepConditionId();
            int count = inventory.Count(itemReq.item.itemId);
            if (count < itemReq.amount) continue;
            
            int stepIdx = FindStepIndex(rq, conditionId, itemReq.stepIndex);
            if (stepIdx >= 0 && !rq.Steps[stepIdx].completed)
            {
                MarkStepDone(rq.Id, stepIdx);
                stepsCompleted++;
            }
        }
        return stepsCompleted;
    }
    
    /// <summary>
    /// Verifica items del wardrobe para una quest
    /// </summary>
    private int CheckWardrobeItemsForQuest(RuntimeQuest rq, WardrobeInventory wardrobe, Game.NPC.Modules.WardrobeItemRequirement[] requiredWardrobeItems)
    {
        int stepsCompleted = 0;
        foreach (var wardrobeReq in requiredWardrobeItems)
        {
            if (wardrobeReq.item == null) continue;
            string conditionId = wardrobeReq.GetStepConditionId();
            bool hasItem = wardrobe.TryGetEntry(wardrobeReq.item.Category, wardrobeReq.item.PartName, out _);
            if (!hasItem) continue;
            
            int stepIdx = FindStepIndex(rq, conditionId, wardrobeReq.stepIndex);
            if (stepIdx >= 0 && !rq.Steps[stepIdx].completed)
            {
                MarkStepDone(rq.Id, stepIdx);
                stepsCompleted++;
            }
        }
        return stepsCompleted;
    }

    /// <summary>
    /// Verifica miembros del equipo para una quest
    /// </summary>
    private int CheckPartyMembersForQuest(RuntimeQuest rq, Game.NPC.PlayerParty party, Game.NPC.Modules.PartyMemberRequirement[] requiredMembers)
    {
        int stepsCompleted = 0;
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[QuestManager] CheckPartyMembersForQuest para quest '{rq.Id}': {requiredMembers.Length} requisitos, {party.Members.Count} miembros en el equipo");
#endif

        foreach (var memberReq in requiredMembers)
        {
            if (string.IsNullOrEmpty(memberReq.memberId))
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[QuestManager] PartyMemberRequirement con memberId vacío en quest '{rq.Id}'");
#endif
                continue;
            }

            // Verificar si el miembro está en el equipo
            bool isInParty = party.Members.Any(m => QuestMatchingUtils.IsPartyMemberMatch(m, memberReq.memberId));
            
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager] Buscando miembro '{memberReq.memberId}': {(isInParty ? "ENCONTRADO" : "NO ENCONTRADO")}");
#endif
            
            if (!isInParty) continue;
            
            string conditionId = memberReq.GetStepConditionId();
            int stepIdx = FindStepIndex(rq, conditionId, memberReq.stepIndex);
            
            if (stepIdx >= 0 && !rq.Steps[stepIdx].completed)
            {
                MarkStepDone(rq.Id, stepIdx);
                stepsCompleted++;
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[QuestManager] Step {stepIdx} de quest '{rq.Id}' completado por miembro '{memberReq.memberId}' en el equipo");
#endif
            }
            else if (stepIdx < 0)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[QuestManager] No se encontró step para miembro '{memberReq.memberId}' en quest '{rq.Id}'. conditionId='{conditionId}', stepIndex={memberReq.stepIndex}");
#endif
            }
            else if (stepIdx >= 0 && rq.Steps[stepIdx].completed)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[QuestManager] Step {stepIdx} de quest '{rq.Id}' ya estaba completado para miembro '{memberReq.memberId}'");
#endif
            }
        }
        return stepsCompleted;
    }
    
    /// <summary>
    /// Busca el índice de un step basándose en conditionId o stepIndex
    /// PRIORIDAD: stepIndex > conditionId
    /// </summary>
    private int FindStepIndex(RuntimeQuest rq, string conditionId, int stepIndex)
    {
        // Prioridad 1: Usar stepIndex directamente si es válido
        // No requiere que conditionId sea null, solo que stepIndex sea válido
        if (stepIndex >= 0 && stepIndex < rq.Steps.Length)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager.FindStepIndex] Usando stepIndex directo: {stepIndex} para quest '{rq.Id}'");
#endif
            return stepIndex;
        }
        
        // Prioridad 2: Buscar por conditionId
        if (!string.IsNullOrEmpty(conditionId))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager.FindStepIndex] Buscando por conditionId: '{conditionId}' en quest '{rq.Id}'");
#endif
            for (int i = 0; i < rq.Steps.Length; i++)
            {
                if (rq.Steps[i].conditionId == conditionId)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[QuestManager.FindStepIndex] Encontrado step {i} con conditionId '{conditionId}'");
#endif
                    return i;
                }
            }
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[QuestManager.FindStepIndex] No se encontró step con conditionId '{conditionId}' en quest '{rq.Id}'");
#endif
        }
        
        return -1;
    }
    
    /// <summary>
    /// Reconstruye el índice questId → QuestChainEntry escaneando los NPCs de la escena.
    /// Se llama solo cuando el índice está marcado como dirty (al cargar/descargar escenas).
    /// </summary>
    private void RebuildQuestChainIndex()
    {
        _questChainIndex.Clear();
        var allNpcManagers = FindObjectsByType<Game.NPC.NPCBehaviourManagerV2>();
        if (allNpcManagers == null) { _questChainIndexDirty = false; return; }

        foreach (var npcManager in allNpcManagers)
        {
            if (npcManager == null || npcManager.Configuration?.questConfig?.questChain == null) continue;
            foreach (var entry in npcManager.Configuration.questConfig.questChain)
            {
                if (entry.questData != null && !_questChainIndex.ContainsKey(entry.questData.questId))
                    _questChainIndex[entry.questData.questId] = entry;
            }
        }
        _questChainIndexDirty = false;
    }

    /// <summary>
    /// Busca el QuestChainEntry para un questId usando el índice cacheado (O(1) tras la primera llamada).
    /// </summary>
    private Game.NPC.Modules.QuestChainEntry FindQuestChainEntry(string questId)
    {
        if (_questChainIndexDirty) RebuildQuestChainIndex();
        _questChainIndex.TryGetValue(questId, out var entry);
        return entry;
    }

    /// <summary>
    /// Elimina todas las misiones activas y su progreso. Útil para nueva partida.
    /// </summary>
    public void ResetAllQuests()
    {
        _runtime.Clear();
        _conditionIndex.Clear();
        _visibility.Clear();
        _followed.Clear();
        _itemsConsumedForQuest.Clear();
        OnQuestsChanged?.Invoke();
    }
    
    #region Inventory Item Detection
    
    /// <summary>
    /// Intenta suscribirse al evento OnItemAdded del inventario del jugador.
    /// Se llama automáticamente cuando el jugador está disponible.
    /// </summary>
    private void TrySubscribeToInventory()
    {
        if (!PlayerService.TryGetComponent(out Inventory inventory, includeInactive: true, allowSceneLookup: true))
        {
            return;
        }
        
        bool cachedIsValid = _cachedInventory != null && _cachedInventory;
        if (_isSubscribedToInventory && cachedIsValid && _cachedInventory == inventory)
        {
            return;
        }
        
        if (_isSubscribedToInventory && cachedIsValid && _cachedInventory != inventory)
        {
            _cachedInventory.OnItemAdded -= OnInventoryItemAdded;
        }
        
        _cachedInventory = inventory;
        _cachedInventory.OnItemAdded += OnInventoryItemAdded;
        _isSubscribedToInventory = true;
    }
    
    private void UnsubscribeFromInventory()
    {
        if (!_isSubscribedToInventory || _cachedInventory == null) return;
        _cachedInventory.OnItemAdded -= OnInventoryItemAdded;
        _isSubscribedToInventory = false;
        _cachedInventory = null;
    }
    
    private void OnInventoryItemAdded(ItemData item, int addedAmount, int newTotal)
    {
        if (item == null) return;
        foreach (var kv in _runtime)
        {
            if (kv.Value.State == QuestState.Active)
                CheckItemForQuest(kv.Value, item, newTotal);
        }
    }
    
    private void CheckItemForQuest(RuntimeQuest rq, ItemData item, int currentCount)
    {
        var questEntry = FindQuestChainEntry(rq.Id);
        if (questEntry == null || questEntry.requiredItems == null) return;
        
        foreach (var itemReq in questEntry.requiredItems)
        {
            if (itemReq.item == null || itemReq.item.itemId != item.itemId) continue;
            if (currentCount < itemReq.amount) continue;
            
            int stepIdx = -1;
            string conditionId = itemReq.GetStepConditionId();
            
            if (conditionId == null && itemReq.stepIndex >= 0 && itemReq.stepIndex < rq.Steps.Length)
                stepIdx = itemReq.stepIndex;
            else if (!string.IsNullOrEmpty(conditionId))
            {
                for (int i = 0; i < rq.Steps.Length; i++)
                {
                    if (rq.Steps[i].conditionId == conditionId)
                    {
                        stepIdx = i;
                        break;
                    }
                }
            }
            
            if (stepIdx >= 0 && !rq.Steps[stepIdx].completed)
            {
                MarkStepDone(rq.Id, stepIdx);
            }
        }
    }
    
    #endregion
    
    #region Wardrobe Item Detection
    
    private void TrySubscribeToWardrobe()
    {
        if (!PlayerService.TryGetComponent(out WardrobeInventory wardrobe, includeInactive: true, allowSceneLookup: true))
        {
            return;
        }
        
        bool cachedIsValid = _cachedWardrobe != null && _cachedWardrobe;
        if (_isSubscribedToWardrobe && cachedIsValid && _cachedWardrobe == wardrobe)
        {
            return;
        }
        
        if (_isSubscribedToWardrobe && cachedIsValid && _cachedWardrobe != wardrobe)
        {
            _cachedWardrobe.OnWardrobeChanged -= OnWardrobeChanged;
        }
        
        _cachedWardrobe = wardrobe;
        _cachedWardrobe.OnWardrobeChanged += OnWardrobeChanged;
        _isSubscribedToWardrobe = true;
    }
    
    private void UnsubscribeFromWardrobe()
    {
        if (!_isSubscribedToWardrobe || _cachedWardrobe == null) return;
        _cachedWardrobe.OnWardrobeChanged -= OnWardrobeChanged;
        _isSubscribedToWardrobe = false;
        _cachedWardrobe = null;
    }
    
    private void OnWardrobeChanged()
    {
        foreach (var kv in _runtime)
        {
            if (kv.Value.State == QuestState.Active)
                CheckWardrobeForQuest(kv.Value);
        }
    }
    
    private void CheckWardrobeForQuest(RuntimeQuest rq)
    {
        if (_cachedWardrobe == null) return;
        var questEntry = FindQuestChainEntry(rq.Id);
        if (questEntry == null || questEntry.requiredWardrobeItems == null) return;
        
        foreach (var wardrobeReq in questEntry.requiredWardrobeItems)
        {
            if (wardrobeReq.item == null) continue;
            bool hasItem = _cachedWardrobe.TryGetEntry(wardrobeReq.item.Category, wardrobeReq.item.PartName, out _);
            if (!hasItem) continue;
            
            int stepIdx = -1;
            string conditionId = wardrobeReq.GetStepConditionId();
            
            if (conditionId == null && wardrobeReq.stepIndex >= 0 && wardrobeReq.stepIndex < rq.Steps.Length)
                stepIdx = wardrobeReq.stepIndex;
            else if (!string.IsNullOrEmpty(conditionId))
            {
                for (int i = 0; i < rq.Steps.Length; i++)
                {
                    if (rq.Steps[i].conditionId == conditionId)
                    {
                        stepIdx = i;
                        break;
                    }
                }
            }
            
            if (stepIdx >= 0 && !rq.Steps[stepIdx].completed)
            {
                MarkStepDone(rq.Id, stepIdx);
            }
        }
    }
    
    #endregion

    #region Party Member Detection

    // La comparación de IDs de party member vive en QuestMatchingUtils (Assets/Scripts/Quests/
    // QuestMatchingUtils.cs) — antes estaba duplicada aquí y en NPCQuestConfig.cs de forma
    // literal, con riesgo de que las dos copias divergieran silenciosamente.

    private void OnPartyMemberJoined(Game.NPC.NPCPartyMember member)
    {
        if (member == null) 
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[QuestManager] OnPartyMemberJoined: miembro es null");
#endif
            return;
        }

        // El índice pudo construirse antes de que este NPC existiera (miembro instanciado al
        // unirse): se fuerza un escaneo para que su QuestChainEntry entre en juego.
        _questChainIndexDirty = true;
        
        // Obtener el ID de persistencia del miembro
        string persistenceId = member.NPCManager?.PersistenceId;
        string gameObjectName = member.gameObject.name;
        
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[QuestManager] ===== OnPartyMemberJoined DISPARADO =====");
#endif
        foreach (var kv in _runtime)
        {
            if (kv.Value.State != QuestState.Active) continue;
            var rq = kv.Value;
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager] Verificando quest '{rq.Id}' (Estado: {rq.State})");
#endif
            
            var questEntry = FindQuestChainEntry(rq.Id);
            if (questEntry == null)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[QuestManager] No se encontró QuestChainEntry para quest '{rq.Id}'");
#endif
                continue;
            }
            
            if (questEntry.requiredPartyMembers == null || questEntry.requiredPartyMembers.Length == 0)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[QuestManager] Quest '{rq.Id}' no tiene requiredPartyMembers");
#endif
                continue;
            }
            
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[QuestManager] Quest '{rq.Id}' tiene {questEntry.requiredPartyMembers.Length} requiredPartyMembers");
#endif
            
            for (int i = 0; i < questEntry.requiredPartyMembers.Length; i++)
            {
                var memberReq = questEntry.requiredPartyMembers[i];
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[QuestManager] [{i}] Requisito memberId='{memberReq.memberId}', stepIndex={memberReq.stepIndex}, stepConditionId='{memberReq.stepConditionId}'");
#endif
                
                // Comparar con distintos formatos posibles del ID
                bool matches = QuestMatchingUtils.IsPartyMemberMatch(member, memberReq.memberId);
                if (matches)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[QuestManager] Match encontrado para '{memberReq.memberId}' (persistenceId='{persistenceId}' / gameObject='{gameObjectName}')");
#endif
                }
                else
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[QuestManager] NO match: esperaba '{memberReq.memberId}', recibido persistenceId='{persistenceId}' / gameObject='{gameObjectName}'");
#endif
                }
                
                if (matches)
                {
                    // Si este requisito está marcado como "solo al hablar con el NPC", no lo completamos
                    // aquí (join global e inmediato). Se completará desde NPCQuestConfig.HandleQuestState
                    // cuando el jugador efectivamente hable con el NPC dueño de la cadena.
                    if (memberReq.completeOnlyOnNpcTalk)
                    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[QuestManager] '{memberReq.memberId}' tiene completeOnlyOnNpcTalk=true, se difiere a la interacción con el NPC");
#endif
                        continue;
                    }

                    string conditionId = memberReq.GetStepConditionId();
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[QuestManager] Buscando step con conditionId='{conditionId}', stepIndex={memberReq.stepIndex}");
#endif

                    int stepIdx = FindStepIndex(rq, conditionId, memberReq.stepIndex);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[QuestManager] FindStepIndex devolvió: {stepIdx}");
#endif

                    if (stepIdx >= 0)
                    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[QuestManager] Step encontrado en índice {stepIdx}, completed={rq.Steps[stepIdx].completed}");
#endif
                        
                        if (!rq.Steps[stepIdx].completed)
                        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.Log($"[QuestManager] ¡COMPLETANDO STEP {stepIdx} de quest '{rq.Id}' por miembro '{memberReq.memberId}'!");
#endif
                            MarkStepDone(rq.Id, stepIdx);
                        }
                        else
                        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.Log($"[QuestManager] Step {stepIdx} de quest '{rq.Id}' ya estaba completado para miembro '{memberReq.memberId}'");
#endif
                        }
                    }
                    else
                    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.LogWarning($"[QuestManager] No se encontró step para miembro '{memberReq.memberId}' en quest '{rq.Id}'. conditionId='{conditionId}', stepIndex={memberReq.stepIndex}");
#endif
                    }
                }
            }
        }
        
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[QuestManager] ===== OnPartyMemberJoined FINALIZADO =====");
#endif
    }

    #endregion
}
