using System.Collections.Generic;
using Game.NPC;
using UnityEditor;
using UnityEngine;

/// <summary>
/// Ventana de debug para inspeccionar todos los iconos del minimapa en tiempo real.
/// Muestra: GO, escena, estado de visibilidad, icono, color y quién lo lanzó.
/// Menú: El Sendero → Pruebas y comprobaciones → Minimapa: iconos activos (en Play)
/// </summary>
public class MinimapDebugWindow : EditorWindow
{
    // ── Estilos ──────────────────────────────────────────────────────────────

    static GUIStyle _labelCenter;
    static GUIStyle _labelBold;
    static GUIStyle _rowStyle;

    static readonly Color ColVisible    = new(0.4f, 0.9f, 0.4f, 0.25f);
    static readonly Color ColRegistered = new(0.9f, 0.9f, 0.3f, 0.25f);
    static readonly Color ColHidden     = new(0.5f, 0.5f, 0.5f, 0.15f);

    // ── Estado ───────────────────────────────────────────────────────────────

    Vector2 _scroll;
    bool    _autoRefresh = true;
    double  _lastRefresh;
    bool    _showOnlyVisible;

    readonly List<MarkerInfo> _infos = new();

    struct MarkerInfo
    {
        public MinimapMarker marker;
        public bool          internalVisible;   // flag _visible del componente
        public bool          isVisible;         // IsVisible (incluye GO activo)
        public bool          isRegistered;      // existe en MinimapUIController._entries
        public bool          hasUIIcon;         // la Image de UI existe
        public string        sceneName;
        public string        iconName;
        public string        owner;
        public Vector3       worldPos;
    }

    // ── Apertura ─────────────────────────────────────────────────────────────

    [MenuItem("El Sendero/Pruebas y comprobaciones/Minimapa: iconos activos (en Play)")]
    static void Open() => GetWindow<MinimapDebugWindow>("Minimapa Debug");

    // ── Ciclo ────────────────────────────────────────────────────────────────

    void OnEnable()   => Refresh();
    void OnDisable()  => _infos.Clear();

    void OnInspectorUpdate()
    {
        if (!_autoRefresh || !EditorApplication.isPlaying) return;
        if (EditorApplication.timeSinceStartup - _lastRefresh < 0.5) return;
        Refresh();
    }

    // ── Recolección ──────────────────────────────────────────────────────────

    void Refresh()
    {
        _lastRefresh = EditorApplication.timeSinceStartup;
        _infos.Clear();

        // Markers en escena (incluyendo inactivos para ver los ocultos)
        var all = FindObjectsByType<MinimapMarker>(FindObjectsInactive.Include);

        // Conjunto de los registrados en MinimapUIController
        var registeredSet  = new HashSet<MinimapMarker>();
        var hasUIIconSet   = new HashSet<MinimapMarker>();

        if (MinimapUIController.Instance != null)
        {
            foreach (var e in MinimapUIController.Instance.Editor_GetEntries())
            {
                if (e.marker == null) continue;
                registeredSet.Add(e.marker);
                if (e.hasUIIcon) hasUIIconSet.Add(e.marker);
            }
        }

        foreach (var m in all)
        {
            if (m == null) continue;
            _infos.Add(new MarkerInfo
            {
                marker          = m,
                internalVisible = m.Editor_InternalVisible,
                isVisible       = m.IsVisible,
                isRegistered    = registeredSet.Contains(m),
                hasUIIcon       = hasUIIconSet.Contains(m),
                sceneName       = m.gameObject.scene.name,
                iconName        = m.Icon != null ? m.Icon.name : "(sin icono)",
                owner           = DetectOwner(m),
                worldPos        = m.transform.position,
            });
        }

        // Primero los visibles
        _infos.Sort((a, b) =>
        {
            int va = a.isVisible ? 0 : 1;
            int vb = b.isVisible ? 0 : 1;
            if (va != vb) return va.CompareTo(vb);
            return string.Compare(a.sceneName, b.sceneName, System.StringComparison.Ordinal);
        });

        Repaint();
    }

    // ── GUI ──────────────────────────────────────────────────────────────────

    void OnGUI()
    {
        EnsureStyles();

        DrawToolbar();
        DrawHeaders();

        _scroll = EditorGUILayout.BeginScrollView(_scroll);
        foreach (var info in _infos)
        {
            if (info.marker == null) continue;
            if (_showOnlyVisible && !info.isVisible) continue;
            DrawRow(info);
        }
        EditorGUILayout.EndScrollView();

        DrawLegend();
    }

    void DrawToolbar()
    {
        using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
        {
            if (GUILayout.Button("↺ Refrescar", EditorStyles.toolbarButton, GUILayout.Width(90)))
                Refresh();

            _autoRefresh     = GUILayout.Toggle(_autoRefresh, "Auto (Play)", EditorStyles.toolbarButton, GUILayout.Width(90));
            _showOnlyVisible = GUILayout.Toggle(_showOnlyVisible, "Solo visibles", EditorStyles.toolbarButton, GUILayout.Width(90));

            GUILayout.FlexibleSpace();

            int visCount = 0;
            foreach (var i in _infos) if (i.isVisible) visCount++;
            EditorGUILayout.LabelField(
                $"Total: {_infos.Count}  |  Visibles: {visCount}",
                EditorStyles.miniLabel);
        }
    }

    void DrawHeaders()
    {
        using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
        {
            GUILayout.Label("V", _labelCenter, GUILayout.Width(18));
            GUILayout.Label("R", _labelCenter, GUILayout.Width(18));
            GUILayout.Label("GameObject",    EditorStyles.boldLabel, GUILayout.Width(180));
            GUILayout.Label("Escena",        EditorStyles.boldLabel, GUILayout.Width(100));
            GUILayout.Label("Icono",         EditorStyles.boldLabel, GUILayout.Width(120));
            GUILayout.Label("Color",         EditorStyles.boldLabel, GUILayout.Width(44));
            GUILayout.Label("Posición",      EditorStyles.boldLabel, GUILayout.Width(140));
            GUILayout.Label("Origen",        EditorStyles.boldLabel);
        }
    }

    void DrawRow(in MarkerInfo info)
    {
        Color bg = info.isVisible    ? ColVisible
                 : info.isRegistered ? ColRegistered
                 :                     ColHidden;

        GUI.backgroundColor = bg;
        using (new EditorGUILayout.HorizontalScope(_rowStyle))
        {
            GUI.backgroundColor = Color.white;

            // Visible (el flag interno) / activo como GO
            string vLabel = info.internalVisible
                          ? (info.isVisible ? "●" : "◌")  // flag=true pero GO inactivo
                          : "○";                            // flag=false
            GUILayout.Label(vLabel, _labelCenter, GUILayout.Width(18));

            // Registrado en MinimapUIController
            GUILayout.Label(info.isRegistered ? "✓" : "—", _labelCenter, GUILayout.Width(18));

            // Nombre (click = seleccionar)
            if (GUILayout.Button(info.marker.gameObject.name, EditorStyles.label, GUILayout.Width(180)))
            {
                Selection.activeGameObject = info.marker.gameObject;
                EditorGUIUtility.PingObject(info.marker.gameObject);
            }

            GUILayout.Label(info.sceneName, GUILayout.Width(100));
            GUILayout.Label(info.iconName,  GUILayout.Width(120));

            // Muestra el sprite inline si existe
            if (info.marker.Icon != null)
            {
                var rect = GUILayoutUtility.GetRect(28, 28, GUILayout.Width(44));
                GUI.DrawTexture(rect, info.marker.Icon.texture, ScaleMode.ScaleToFit);
            }
            else
            {
                EditorGUILayout.ColorField(
                    GUIContent.none, info.marker.MarkerColor,
                    false, false, false, GUILayout.Width(44));
            }

            GUILayout.Label(
                $"({info.worldPos.x:F1}, {info.worldPos.y:F1}, {info.worldPos.z:F1})",
                GUILayout.Width(140));

            GUILayout.Label(info.owner);
        }
    }

    void DrawLegend()
    {
        EditorGUILayout.Space(2);
        using (new EditorGUILayout.HorizontalScope())
        {
            DrawSwatch(ColVisible);    GUILayout.Label("● Visible  ", GUILayout.Width(70));
            DrawSwatch(ColRegistered); GUILayout.Label("◌ Reg. pero oculto  ", GUILayout.Width(130));
            DrawSwatch(ColHidden);     GUILayout.Label("○ No visible / no reg.", GUILayout.Width(160));
            GUILayout.FlexibleSpace();
            GUILayout.Label("V = _visible  R = registrado en MinimapUIController",
                EditorStyles.miniLabel);
        }
    }

    static void DrawSwatch(Color c)
    {
        var rect = GUILayoutUtility.GetRect(12, 12, GUILayout.Width(14));
        EditorGUI.DrawRect(rect, c + new Color(0, 0, 0, 0.6f));
    }

    // ── Detección de origen ──────────────────────────────────────────────────

    static string DetectOwner(MinimapMarker marker)
    {
        // QuestObjectiveMarker crea un hijo llamado "_QuestObjMarker"
        if (marker.gameObject.name == "_QuestObjMarker")
        {
            var qom = marker.GetComponentInParent<QuestObjectiveMarker>();
            if (qom != null)
            {
                var so       = new SerializedObject(qom);
                var questId  = so.FindProperty("questId")?.stringValue  ?? "?";
                var stepIdx  = so.FindProperty("stepIndex")?.intValue   ?? -99;
                var afterStep= so.FindProperty("showAfterStep")?.intValue ?? -99;
                return $"QuestObjectiveMarker  quest={questId}  step={stepIdx}  showAfter={afterStep}";
            }
            return "QuestObjectiveMarker (quest desconocida)";
        }

        // NPCQuestIconManager añade MinimapMarker directamente al root del NPC
        var npcMgr = marker.GetComponent<NPCQuestIconManager>()
                  ?? marker.GetComponentInParent<NPCQuestIconManager>();
        if (npcMgr != null)
        {
            // _questConfig es privado sin [SerializeField] — usamos reflection (solo editor)
            var field   = typeof(NPCQuestIconManager).GetField("_questConfig",
                              System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            var config  = field?.GetValue(npcMgr) as UnityEngine.Object;
            string cfgName = config != null ? config.name : npcMgr.gameObject.name;
            return $"NPCQuestIconManager  ({cfgName})";
        }

        // Fallback: listar los componentes que convivan con el marker
        var comps = marker.GetComponents<MonoBehaviour>();
        var names  = new System.Text.StringBuilder();
        foreach (var c in comps)
        {
            if (c == null || c == marker) continue;
            if (names.Length > 0) names.Append(", ");
            names.Append(c.GetType().Name);
        }
        return names.Length > 0
            ? $"Manual  (en GO con: {names})"
            : "Manual / Directo";
    }

    // ── Estilos ──────────────────────────────────────────────────────────────

    void EnsureStyles()
    {
        _labelCenter ??= new GUIStyle(EditorStyles.label)
        {
            alignment = TextAnchor.MiddleCenter,
            fontSize  = 14,
        };
        _labelBold ??= new GUIStyle(EditorStyles.boldLabel);
        _rowStyle  ??= new GUIStyle(EditorStyles.helpBox)
        {
            padding = new RectOffset(2, 2, 1, 1),
            margin  = new RectOffset(0, 0, 1, 0),
        };
    }
}
