// Scripts/World/TeleportService.cs
using System.Collections;
using UnityEngine;
using UnityEngine.AI;
using EasyTransition;

[DisallowMultipleComponent]
[DefaultExecutionOrder(-200)]
public class TeleportService : MonoBehaviour
{
    // ===== Singleton mínimo =====
    private static TeleportService _inst;
    public static TeleportService Inst
    {
        get
        {
            if (_inst != null) return _inst;
            
            // Intentar obtener desde ServiceLocator primero
            if (ServiceLocator.TryGet(out TeleportService service) && service != null)
            {
                _inst = service;
                return _inst;
            }
            
            // Si no está registrado, advertir
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[TeleportService] No se encontró instancia registrada en ServiceLocator.");
#endif
            return null;
        }
    }

    // Nuevos eventos para notificar estado de teleport
    public static event System.Action OnTeleportStarted;
    public static event System.Action OnTeleportCut;     // Momento del movimiento real
    public static event System.Action OnTeleportEnded;   // Fin de transición (o inmediato si no hay transición)

#if UNITY_EDITOR
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    static void ResetStatics()
    {
        _inst = null;
        OnTeleportStarted = null;
        OnTeleportCut = null;
        OnTeleportEnded = null;
        _sTransitionInProgress = false;
    }
#endif

    // Helper para invocar eventos de forma segura y con logging por suscriptor
    private static void InvokeEvent(System.Action evt, string eventName)
    {
        if (evt == null) return;
        foreach (var d in evt.GetInvocationList())
        {
            try { ((System.Action)d).Invoke(); }
            catch (System.Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                ex
#endif
            )
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogError($"[TeleportService] Excepción en suscriptor de {eventName}: {ex.Message}\n{ex.StackTrace}");
#endif
            }
        }
    }

    [Header("Transición (EasyTransition)")]
    [SerializeField] private TransitionSettings teleportTransition; // arrastra p.ej. Fade.asset
    [SerializeField] private float transitionDelay; // 0 por defecto implícito
    [SerializeField] private bool useTransitionByDefault = true;

    // Flag propio para no invocar Transition() cuando ya hay una en curso (el plugin usa el mismo mensaje de error)
    private static bool _sTransitionInProgress;

    // FIX A7 (auditoría 2026-08-07): handlers activos de la transición en curso, guardados a nivel
    // de instancia para poder desuscribirlos desde OnDestroy si el GameObject se destruye a mitad
    // de una transición. TransitionManager es DontDestroyOnLoad/persistente: sin esto, un handler
    // local huérfano seguía suscrito y podía disparar más tarde para una transición de OTRO
    // sistema, moviendo al jugador/compañeros a las coordenadas de este teleport ya obsoleto.
    private UnityEngine.Events.UnityAction _activeCutHandler;
    private UnityEngine.Events.UnityAction _activeEndHandler;

    /// <summary>
    /// Solo se libera en el callback tm.onTransitionEnd; si la escena cambia a mitad de una
    /// transición (evento que nunca llega a dispararse) queda "colgado" en true para siempre,
    /// bloqueando cualquier teleport con fade futuro (cae a "teletransporte inmediato" sin fundido
    /// permanentemente). Llamar desde los puntos de entrada seguros de sesión.
    /// </summary>
    public static void ForceResetTransitionLock() => _sTransitionInProgress = false;

    private void Awake()
    {
        if (_inst != null && _inst != this) { Destroy(gameObject); return; }
        _inst = this;
        ServiceLocator.Register(this);
        //DontDestroyOnLoad(gameObject);
        //Debug.Log($"[TeleportService] Awake in '{name}' | TransitionSettings: {(teleportTransition ? teleportTransition.name : "<null>")}");
    }

    private void OnDestroy()
    {
        if (_inst == this)
        {
            ServiceLocator.Unregister(this);
            _inst = null;
        }

        // FIX A7 (auditoría 2026-08-07): ver comentario de _activeCutHandler/_activeEndHandler.
        var tm = FindTM();
        if (tm != null)
        {
            if (_activeCutHandler != null) tm.onTransitionCutPointReached -= _activeCutHandler;
            if (_activeEndHandler != null) tm.onTransitionEnd -= _activeEndHandler;
        }
        _activeCutHandler = null;
        _activeEndHandler = null;
    }

#if UNITY_EDITOR
    private void OnValidate()
    {
        if (!teleportTransition)
        {
            Debug.LogWarning("[TeleportService] No hay TransitionSettings asignado. El teletransporte usará modo inmediato.", this);
        }
    }
#endif

    // ================== API ESTÁTICA mínima ==================

    /// <summary>Teleporta a un anchor por id.</summary>
    public static void TeleportToAnchor(GameObject player, string anchorId, bool? useTransition = null)
    {
        // FIX C3 (auditoría 2026-08-07): los tres early-return de este método (y de
        // DoTeleportToAnchor, más abajo) retornaban sin emitir OnTeleportEnded. TeleportSystem.
        // TeleportSequence espera ese evento con WaitUntil antes de devolver el control al
        // jugador — si nunca llega, la corrutina se queda colgada para siempre: input bloqueado,
        // GamePhase.Cutscene empujado permanentemente, y además IsTeleporting=true bloquea
        // cualquier teleport futuro. Emitir el evento en cada fallo evita el cuelgue.
        if (!Inst)
        {
            InvokeEvent(OnTeleportEnded, nameof(OnTeleportEnded));
            return;
        }
        var sa = SpawnManager.GetAnchor(anchorId);
        if (!sa)
        {
            // Fallback: el anchor puede estar en una zona inactiva (zoneRoot desactivado)
            // y nunca ha llamado OnEnable para registrarse en AnchorRegistry.
            // Esta búsqueda es costosa pero solo ocurre al iniciar partida, nunca en Update.
            var all = FindObjectsByType<SpawnAnchor>(FindObjectsInactive.Include);
            foreach (var candidate in all)
            {
                if (candidate.anchorId == anchorId) { sa = candidate; break; }
            }
        }
        if (!sa)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[TeleportService] Anchor '{anchorId}' no encontrado.");
#endif
            InvokeEvent(OnTeleportEnded, nameof(OnTeleportEnded));
            return;
        }
        Inst.DoTeleportToAnchor(player, sa.transform, useTransition);
    }

    // ================== API de instancia ==================

    public void DoTeleportToAnchor(GameObject player, Transform anchor, bool? useTransition = null)
    {
        if (!player || !anchor)
        {
            // FIX C3: mismo motivo que arriba — no dejar colgado a quien espera OnTeleportEnded.
            InvokeEvent(OnTeleportEnded, nameof(OnTeleportEnded));
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[TeleportService] Parámetros nulos en TeleportToAnchor.");
#endif
            return;
        }

        // Sincronizar anchor actual (SpawnManager y runtimePreset) si conocemos su id
        var sa = anchor.GetComponentInParent<SpawnAnchor>(includeInactive: true);
        if (sa && !string.IsNullOrEmpty(sa.anchorId))
        {
            SpawnManager.SetCurrentAnchor(sa.anchorId);
        }

        var pos = anchor.position;
        var rot = anchor.rotation;
        
        // Aplicar orientación según faceDoor
        if (sa != null)
        {
            // CONVENCIÓN: El SpawnAnchor se coloca con el eje Z (forward) apuntando
            // hacia donde quieres que mire el jugador POR DEFECTO
            if (sa.faceDoor)
            {
                // faceDoor = true → Invertir la dirección (mirar al lado contrario)
                // Usamos -forward para dar la vuelta 180°
                rot = Quaternion.LookRotation(-anchor.forward, Vector3.up);
            }
            else
            {
                // faceDoor = false (por defecto) → Usar la dirección del anchor tal cual
                // El jugador mira en la dirección del eje Z del anchor
                rot = Quaternion.LookRotation(anchor.forward, Vector3.up);
            }
        }

        // Notificar inicio de teleport
        InvokeEvent(OnTeleportStarted, nameof(OnTeleportStarted));

        // Decidir si podemos hacer transición de forma segura
        bool wantTransition = useTransition ?? useTransitionByDefault;
        var tm = wantTransition ? FindTM() : null;
        bool hasSettings = teleportTransition != null;
        bool pluginBusy = IsPluginTransitionRunning();
        bool canTransition = wantTransition && hasSettings && tm != null && !_sTransitionInProgress && !pluginBusy;

        if (!canTransition && wantTransition)
        {
            if (_sTransitionInProgress)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning("[TeleportService] Una transición ya está en curso (local). Se hace teletransporte inmediato para evitar el error del plugin.");
                #endif
            }
            else if (pluginBusy)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning("[TeleportService] TransitionManager está ocupado con otra transición. Teletransporte inmediato.");
                #endif
            }
            else if (teleportTransition == null)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning("[TeleportService] No hay TransitionSettings asignado. Se hace teletransporte inmediato.");
                #endif
            }
            else if (tm == null)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning("[TeleportService] No se encontró TransitionManager. Se hace teletransporte inmediato.");
                #endif
            }
        }

        if (canTransition) TeleportWithTransition(player, pos, rot, anchor);
        else               MoveNow(player, pos, rot, anchor);
    }

    // ================== Núcleo transición / movimiento ==================
    
    private void TeleportWithTransition(GameObject player, Vector3 worldPos, Quaternion worldRot, Transform anchorForEnv)
    {
        var tm = FindTM(); // ← seguro, no usa Instance()
        if (tm == null || teleportTransition == null)
        {
            // Si el manager aún no está o no tienes settings, teleporta sin fade (no rompe)
            MoveNow(player, worldPos, worldRot, anchorForEnv);
            return;
        }

        if (_sTransitionInProgress)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[TeleportService] Se intentó iniciar una transición mientras otra sigue activa. Ejecutando teletransporte inmediato.");
#endif
            MoveNow(player, worldPos, worldRot, anchorForEnv);
            return;
        }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[TeleportService] Transition OK → Settings='{teleportTransition.name}', Delay={transitionDelay:0.00}, Manager='{tm.name}'");
#endif

        _sTransitionInProgress = true;

        void OnCut()
        {
            MovePlayerSafely(player, worldPos, worldRot);
            TeleportCompanionsToPlayer();
            ApplyEnvironmentForAnchor(anchorForEnv);
            // Notificar corte (momento del movimiento)
            InvokeEvent(OnTeleportCut, nameof(OnTeleportCut));
            tm.onTransitionCutPointReached -= OnCut;
            _activeCutHandler = null;
        }

        void OnEnd()
        {
            _sTransitionInProgress = false;
            // Notificar fin
            InvokeEvent(OnTeleportEnded, nameof(OnTeleportEnded));
            tm.onTransitionEnd -= OnEnd;
            _activeEndHandler = null;
        }

        // FIX A7 (auditoría 2026-08-07): guardar referencia a nivel de instancia (ver OnDestroy).
        _activeCutHandler = OnCut;
        _activeEndHandler = OnEnd;
        tm.onTransitionCutPointReached += _activeCutHandler;
        tm.onTransitionEnd            += _activeEndHandler;

        // OJO: usamos la versión SIN cambio de escena del plugin (la estable)
        tm.Transition(teleportTransition, transitionDelay);

        // FIX (12 sep 2026, reporte de Raúl — "la transición se queda pillada al entrar/salir de
        // interiores, ahora que son cargas aditivas"): _sTransitionInProgress SOLO se libera en el
        // callback tm.onTransitionEnd (ver comentario de ForceResetTransitionLock más arriba). Si
        // ese callback nunca llega a dispararse — p. ej. porque InteriorPortalTrigger descarga en
        // aditivo la propia escena del interior (WillHouse) mientras la corrutina Timer() de
        // TransitionManager sigue en marcha, y esa corrutina (o el propio TransitionManager, o el
        // GameObject de Transition instanciado) acaba destruyéndose por una carrera con esa
        // descarga — el flag se queda "colgado" en true para siempre: todos los teleports con
        // fundido futuros de TODA la sesión caen en silencio a "teletransporte inmediato"
        // (canTransition=false más arriba), y si además el overlay visual de EasyTransition se
        // quedó a mitad de tapar la pantalla, el jugador ve la transición congelada ahí. Antes de
        // este fix, el único punto que liberaba el flag a mano era
        // GameBootService.ResetTransientSessionState() (solo al (re)iniciar partida vía
        // WorldBootstrap) — nada lo recuperaba durante la sesión en curso.
        // Igual que el timeout de cinemática de arranque que ya usa WorldBootstrap
        // (bootCinematicTimeout/WaitForBootCinematicOrTimeout), esta corrutina vive en
        // TeleportService (que sigue vivo mientras la escena de mundo persistente — MainWorld —
        // esté cargada, algo que las cargas/descargas aditivas de interiores nunca tocan) y no
        // depende de que TransitionManager siga vivo para poder actuar.
        StartCoroutine(Co_TransitionWatchdog(tm, teleportTransition));
    }

    /// <summary>
    /// Red de seguridad: si la transición en curso no termina (tm.onTransitionEnd nunca se
    /// dispara) dentro de un margen generoso, fuerza el reset de los flags de "transición en
    /// curso" y desbloquea al jugador — para no dejar la sesión entera sin fundidos futuros (o al
    /// jugador congelado) por una transición que quedó huérfana a causa de una carga/descarga
    /// aditiva de escena. No sustituye investigar la causa raíz si esto llega a dispararse: solo
    /// evita que el síntoma se quede pillado para siempre.
    /// </summary>
    private IEnumerator Co_TransitionWatchdog(TransitionManager tm, TransitionSettings settings)
    {
        float expected = settings.transitionTime;
        if (settings.autoAdjustTransitionTime && settings.transitionSpeed > 0f)
            expected /= settings.transitionSpeed;
        float timeout = expected + settings.destroyTime + 3f; // +3s de colchón de seguridad

        float elapsed = 0f;
        while (_sTransitionInProgress && elapsed < timeout)
        {
            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        if (!_sTransitionInProgress) yield break; // terminó con normalidad, nada que hacer

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.LogWarning($"[TeleportService] Watchdog: la transición no terminó tras {timeout:0.0}s " +
                          "(probable interrupción por carga/descarga aditiva de escena a mitad de la " +
                          "transición). Forzando reset y liberando al jugador.");
#endif

        if (tm != null)
        {
            if (_activeCutHandler != null) tm.onTransitionCutPointReached -= _activeCutHandler;
            if (_activeEndHandler != null) tm.onTransitionEnd -= _activeEndHandler;
            tm.ForceResetTransition();
        }
        _activeCutHandler = null;
        _activeEndHandler = null;
        _sTransitionInProgress = false;

        // Por si el corte (OnCut) nunca llegó a ejecutarse, asegurar que el jugador quedó movido
        // y el entorno aplicado antes de devolver el control — mismo camino que el modo inmediato.
        InvokeEvent(OnTeleportEnded, nameof(OnTeleportEnded));
    }

    private void MoveNow(GameObject player, Vector3 pos, Quaternion rot, Transform anchorForEnv)
    {
        MovePlayerSafely(player, pos, rot);
        TeleportCompanionsToPlayer();
        ApplyEnvironmentForAnchor(anchorForEnv);
        // En modo inmediato, emitir cut y end seguidos
        InvokeEvent(OnTeleportCut, nameof(OnTeleportCut));
        InvokeEvent(OnTeleportEnded, nameof(OnTeleportEnded));
    }

    private void MovePlayerSafely(GameObject player, Vector3 pos, Quaternion rot)
    {
        if (!player) return;

        pos = SitioLibre(player, pos);
        player.transform.SetPositionAndRotation(pos, rot);

        var rb = player.GetComponent<Rigidbody>() ?? player.GetComponentInChildren<Rigidbody>(true);
        if (rb && !rb.isKinematic)
        {
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        var motor = player.GetComponent<Invector.vCharacterController.vThirdPersonMotor>() ?? player.GetComponentInChildren<Invector.vCharacterController.vThirdPersonMotor>(true);
        if (motor != null)
        {
            motor.ForzarEnElSuelo();
        }
    }

    // ── Sitio libre ───────────────────────────────────────────────────────────────────────────

    private static readonly Collider[] s_solapes = new Collider[16];

    /// Si el punto de llegada está ocupado por algo sólido (un ancla que se ha quedado debajo de
    /// unas cajas o de un mueble colocado después), busca alrededor, en el NavMesh, el sitio libre
    /// más cercano. Sin esto el jugador aparece subido encima. Ver INC-1117.
    private static Vector3 SitioLibre(GameObject player, Vector3 pos)
    {
        if (Libre(player, pos)) return pos;
        for (float radio = 0.75f; radio <= 4.5f; radio += 0.75f)
        {
            for (int i = 0; i < 12; i++)
            {
                float ang = i * 30f * Mathf.Deg2Rad;
                Vector3 candidato = pos + new Vector3(Mathf.Cos(ang), 0f, Mathf.Sin(ang)) * radio;
                if (!NavMesh.SamplePosition(candidato, out var hit, 1.5f, NavMesh.AllAreas)) continue;
                if (Mathf.Abs(hit.position.y - pos.y) > 1.5f) continue;
                if (Libre(player, hit.position)) return hit.position;
            }
        }
        return pos;
    }

    /// Cabe el jugador de pie en el punto: una cápsula de su tamaño, levantada un palmo para no
    /// contar el suelo que pisa, no toca nada sólido que no sea él mismo.
    private static bool Libre(GameObject player, Vector3 pie)
    {
        var cap = player.GetComponent<CapsuleCollider>();
        float radio = cap != null ? cap.radius * player.transform.lossyScale.x : 0.3f;
        float alto = cap != null ? cap.height * player.transform.lossyScale.y : 1.8f;
        Vector3 abajo = pie + Vector3.up * (0.35f + radio);
        Vector3 arriba = pie + Vector3.up * Mathf.Max(0.35f + radio, alto - radio);
        int n = Physics.OverlapCapsuleNonAlloc(abajo, arriba, radio, s_solapes, ~0, QueryTriggerInteraction.Ignore);
        for (int i = 0; i < n; i++)
        {
            var c = s_solapes[i];
            if (c == null || c is TerrainCollider) continue;
            if (c.transform.IsChildOf(player.transform)) continue;
            return false;
        }
        return true;
    }

    /// <summary>
    /// Teleporta a todos los compañeros (party members + Will NPC instanciado) cerca del jugador.
    /// Llamado automáticamente después de cada teleport del jugador.
    /// </summary>
    private static void TeleportCompanionsToPlayer()
    {
        // 1. Teleportar party members registrados. Un viaje rápido mueve a todo el grupo aunque
        // haya geometría entre medias, así que se omite la comprobación de alcance. Ver INC-819.
        if (Game.NPC.PlayerParty.HasInstance)
            Game.NPC.PlayerParty.Instance.TeleportAllMembersToPlayer(forzar: true);

        // 2. Teleportar Will NPC instanciado (no está en el party formal)
        ActiveCharacterSwapper.Instance?.TeleportWillNpcToPlayer(forzar: true);
    }

    /// <summary>
    /// Aplica el entorno (interior/exterior) basado en el anchor de destino.
    /// </summary>
    public void ApplyEnvironmentForAnchor(Transform anchor)
    {
        var ec = EnvironmentController.Instance;
        if (!ec) return;

        AnchorEnvironment env = null;
        // includeInactive:true porque el anchor puede estar en una zona todavía inactiva
        if (anchor) env = anchor.GetComponentInParent<AnchorEnvironment>(includeInactive: true);

        if (env && env.isInterior) ec.ApplyInterior(env);
        else                       ec.ApplyExterior();
    }

    // ================== Utilidades ==================
    
    static TransitionManager FindTM()
    {
        if (ServiceLocator.TryGet(out TransitionManager tm) && tm != null)
            return tm;
        
        // Fallback: intentar obtener instancia del plugin
        return TransitionManager.Instance();
    }

    static bool IsPluginTransitionRunning()
    {
        // El plugin EasyTransition crea objetos Transition temporales durante las transiciones
        // Como no es un servicio registrado, verificamos si hay alguna transición activa
        // consultando el estado del TransitionManager
        var tm = FindTM();
        if (tm == null) return false;
        
        // Si el TransitionManager existe y está procesando una transición,
        // lo consideramos ocupado
        return false; // El plugin maneja esto internamente
    }
}
