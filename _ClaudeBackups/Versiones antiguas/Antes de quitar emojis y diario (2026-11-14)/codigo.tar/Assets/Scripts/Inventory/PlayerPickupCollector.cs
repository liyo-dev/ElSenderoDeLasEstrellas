using UnityEngine;
using UnityEngine.Events;

[DisallowMultipleComponent]
public class PlayerPickupCollector : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Inventory inventory;
    [SerializeField] private PlayerHealthSystem healthSystem;
    [SerializeField] private ManaPool manaPool;
    [SerializeField] private SpecialChargeMeter specialChargeMeter;
    [SerializeField] private Animator animator;

    [Header("Animation")]
    [SerializeField] private string drinkPotionAnimationName = "DrinkPotion_NoWeapon";
    [Tooltip("Índice de la capa UpperBody (torso/brazos, sin piernas) donde vive DrinkPotion_NoWeapon.")]
    [SerializeField] private int upperBodyLayer = 1;

    [Header("Settings")]
    [SerializeField] private bool logWarnings;

    [Header("Events")]
    [SerializeField] private UnityEvent<PickupEffectType> onEffectApplied;
    [SerializeField] private UnityEvent onAnyPickup;
    
    // Control de animación de poción
    private Coroutine _drinkPotionCoroutine;
    private bool _isPlayingDrinkAnimation;

    void Awake()
    {
        if (!healthSystem) healthSystem = GetComponentInChildren<PlayerHealthSystem>(true);
        if (!manaPool) manaPool = GetComponentInChildren<ManaPool>(true);
        if (!specialChargeMeter) specialChargeMeter = GetComponentInChildren<SpecialChargeMeter>(true);
        if (!animator) animator = GetComponentInChildren<Animator>(true);

        PlayerService.RegisterComponent(this);
    }

    /// <summary>
    /// Applies a pickup effect. Returns true when the effect modified the player state.
    /// The caller can decide whether the pickup should be consumed when false is returned.
    /// </summary>
    public bool TryCollect(PickupEffect effect, out bool shouldConsume)
    {
        bool changed = effect.effectType switch
        {
            PickupEffectType.Currency => ApplyCurrency(effect),
            PickupEffectType.ManaRestore => ApplyMana(effect),
            PickupEffectType.HealthRestore => ApplyHealth(effect),
            PickupEffectType.SpecialCharge => ApplySpecialCharge(effect),
            PickupEffectType.AddToInventory => ApplyAddToInventory(effect),
            PickupEffectType.UnlockWardrobeItem => ApplyUnlockWardrobeItem(effect),
            PickupEffectType.Revivir => SaludDelGrupo.LevantarConObjeto(Mathf.Clamp01(effect.amount)),
            _ => false
        };

        shouldConsume = changed || effect.consumeEvenIfNoChange;

        if (changed)
        {
            onEffectApplied?.Invoke(effect.effectType);
            onAnyPickup?.Invoke();
        }

        return changed;
    }

    // El inventario es del grupo (GrupoDelJugador), no del cuerpo: se busca a través de
    // PlayerService la primera vez que hace falta. Ver INC-484.
    private bool ResolverInventario()
    {
        if (!inventory) PlayerService.TryGetComponent(out inventory, allowSceneLookup: false);
        return inventory;
    }

    private bool ApplyCurrency(PickupEffect effect)
    {
        if (!ResolverInventario())
        {
            LogMissingComponent(nameof(Inventory));
            return false;
        }

        if (!effect.item)
        {
            if (logWarnings)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning("[PlayerPickupCollector] Currency pickup has no ItemData assigned.");
                #endif
            }
            return false;
        }

        int quantity = effect.GetQuantityOrDefault();
        if (quantity <= 0) return false;

        inventory.Add(effect.item, quantity);
        return true;
    }

    private bool ApplyMana(PickupEffect effect)
    {
        if (!manaPool)
        {
            LogMissingComponent(nameof(ManaPool));
            return false;
        }

        float amount = effect.GetAmountOrFallback();
        if (amount <= 0f) return false;

        float before = manaPool.Current;
        manaPool.Refill(amount);
        bool restored = manaPool.Current > before + Mathf.Epsilon;
        
        // Reproducir animación de beber poción si se restauró maná
        if (restored)
            PlayDrinkPotionAnimation();
        
        return restored;
    }

    private bool ApplyHealth(PickupEffect effect)
    {
        if (!healthSystem)
        {
            LogMissingComponent(nameof(PlayerHealthSystem));
            return false;
        }

        float amount = effect.GetAmountOrFallback();
        if (amount <= 0f) return false;

        bool healed = healthSystem.Heal(amount);
        
        // Reproducir animación de beber poción si se curó
        if (healed)
            PlayDrinkPotionAnimation();
        
        return healed;
    }

    private bool ApplySpecialCharge(PickupEffect effect)
    {
        // La carga de equipo vive en GrupoDelJugador (INC-484/INC-491); se busca al usarla.
        if (!specialChargeMeter) PlayerService.TryGetComponent(out specialChargeMeter, allowSceneLookup: false);
        if (!specialChargeMeter)
        {
            LogMissingComponent(nameof(SpecialChargeMeter));
            return false;
        }

        float amount = effect.GetAmountOrFallback();
        if (amount <= 0f) return false;

        return specialChargeMeter.AddCharge(amount);
    }

    private bool ApplyAddToInventory(PickupEffect effect)
    {
        if (!ResolverInventario())
        {
            LogMissingComponent(nameof(Inventory));
            return false;
        }

        if (!effect.item)
        {
            if (logWarnings)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning("[PlayerPickupCollector] AddToInventory pickup has no ItemData assigned.");
                #endif
            }
            return false;
        }

        int quantity = effect.GetQuantityOrDefault();
        if (quantity <= 0) return false;

        // Inventory.Add ya redirige automáticamente los items de equipamiento con
        // wardrobeUnlock al armario en vez de la bolsa normal (punto único de control),
        // así que este pickup funciona igual sin importar el tipo de item configurado.
        inventory.Add(effect.item, quantity);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[PlayerPickupCollector] ✅ Pickup procesado: {effect.item.displayName} x{quantity}");
#endif

        return true;
    }


    private bool ApplyUnlockWardrobeItem(PickupEffect effect)
    {
        if (effect.item == null || effect.item.wardrobeUnlock == null)
        {
            if (logWarnings)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning("[PlayerPickupCollector] UnlockWardrobeItem pickup has no ItemData or WardrobeItemSO assigned.");
                #endif
            }
            return false;
        }

        var wardrobeItem = effect.item.wardrobeUnlock;

        // Intentar desbloquear el item en el WardrobeService. Esto añadirá el item al wardrobe
        // y mostrará el popup correspondiente (CollectiblePopupQueue) cuando proceda.
        bool unlocked = WardrobeService.UnlockWardrobeItem(wardrobeItem, logWarnings: true);

        // Actualizar la apariencia activa del personaje para reflejar el nuevo item (si procede)
        var activeCharacter = PartyControlManager.Instance.ActiveSlot;
        CharacterAppearanceRegistry.Instance.UpdatePart(activeCharacter, wardrobeItem.Category, wardrobeItem.PartName);

        if (unlocked)
        {
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[PlayerPickupCollector] ✅ Item de equipo '{effect.item.displayName}' desbloqueado y añadido al wardrobe.");
            #endif
        }
        else if (logWarnings)
        {
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[PlayerPickupCollector] Item de equipo '{effect.item.displayName}' ya estaba desbloqueado o no pudo añadirse.");
            #endif
        }

        return unlocked;
    }

    private void LogMissingComponent(string componentName)
    {
        if (!logWarnings) return;
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.LogWarning($"[PlayerPickupCollector] Missing required component '{componentName}' on '{name}'.");
#endif
    }

    private void PlayDrinkPotionAnimation()
    {
        if (animator == null)
        {
            if (logWarnings)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning("[PlayerPickupCollector] No se puede reproducir animación de poción: Animator no encontrado.");
                #endif
            }
            return;
        }

        if (string.IsNullOrEmpty(drinkPotionAnimationName))
        {
            if (logWarnings)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning("[PlayerPickupCollector] No se puede reproducir animación de poción: nombre de animación vacío.");
                #endif
            }
            return;
        }

        // Si ya hay una animación en curso, cancelarla antes de iniciar la nueva
        if (_drinkPotionCoroutine != null)
        {
            StopCoroutine(_drinkPotionCoroutine);
            _drinkPotionCoroutine = null;
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log("[PlayerPickupCollector] Animación anterior de poción cancelada para iniciar nueva");
#endif
        }

        // Si ya está reproduciéndose, no iniciar otra
        if (_isPlayingDrinkAnimation)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log("[PlayerPickupCollector] Animación de poción ya en curso - ignorando nueva solicitud");
#endif
            return;
        }

        // Usar corrutina para dar tiempo al Animator Controller de procesar cambios
        _drinkPotionCoroutine = StartCoroutine(PlayDrinkPotionAnimationCoroutine());
    }

    private System.Collections.IEnumerator PlayDrinkPotionAnimationCoroutine()
    {
        _isPlayingDrinkAnimation = true;

        // DrinkPotion_NoWeapon vive en la UpperBody layer (torso/brazos, AvatarMask sin piernas):
        // a diferencia del viejo enfoque en Base Layer, ya NO hace falta resetear todos los
        // parámetros del animator a 0 para "limpiar" el idle — eso forzaba también IsGrounded,
        // IsSprinting, etc. a valores incorrectos y congelaba las piernas si el jugador cogía la
        // poción en pleno movimiento. Ahora la Base Layer sigue su locomoción normal sin tocarla;
        // solo se activa el peso de la capa superior para el gesto de beber.
        bool hasUpperLayer = animator.layerCount > upperBodyLayer && upperBodyLayer > 0;
        if (hasUpperLayer)
            animator.SetLayerWeight(upperBodyLayer, 1f);

        int playLayer = hasUpperLayer ? upperBodyLayer : 0;
        animator.PlayInFixedTime(drinkPotionAnimationName, playLayer, 0f);

        // Esperar 1 frame para que el Animator Controller procese el cambio antes de leer el clip
        yield return null;

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[PlayerPickupCollector] Animación reproducida: {drinkPotionAnimationName} (layer {playLayer})");
#endif

        // Obtener la duración del clip de animación para esperar hasta que termine
        AnimatorClipInfo[] clipInfo = animator.GetCurrentAnimatorClipInfo(playLayer);
        float animationDuration = 1f; // Duración por defecto

        if (clipInfo != null && clipInfo.Length > 0)
        {
            animationDuration = clipInfo[0].clip.length;
        }

        // Esperar a que la animación termine
        yield return new WaitForSeconds(animationDuration);

        // Soltar la UpperBody layer: el propio estado ya vuelve a UpperIdle al terminar el clip
        // (ver el Animator Controller), pero sin esto el peso de la capa se quedaría en 1 para
        // siempre, dejando los brazos "congelados" en la pose de UpperIdle sobre la locomoción.
        if (hasUpperLayer)
            animator.SetLayerWeight(upperBodyLayer, 0f);

        // Limpiar referencias
        _isPlayingDrinkAnimation = false;
        _drinkPotionCoroutine = null;

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[PlayerPickupCollector] Animación de poción completada - flag limpiado");
#endif
    }
}