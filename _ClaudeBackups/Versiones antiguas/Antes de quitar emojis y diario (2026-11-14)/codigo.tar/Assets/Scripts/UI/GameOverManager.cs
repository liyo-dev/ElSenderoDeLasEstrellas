using UnityEngine;
using UnityEngine.SceneManagement;
using EasyTransition;
using DG.Tweening;
using Core;

/// <summary>
/// Gestiona el Game Over con feedback visual cinematográfico:
/// - Slow motion progresivo (árbitro del tiempo)
/// - Zoom de cámara hacia el jugador
/// - Música de Game Over
/// - La noche de estrellas (NocheDeLaCaida) y la pregunta de continuar en el centro
/// - Al caer el jugador, pregunta: «Continuar» carga el último guardado sin pasar por el menú;
///   «Salir al menú» va al menú principal. Sin partida guardada, va directo al menú. Ver INC-518.
/// </summary>
public class GameOverManager : MonoBehaviour
{
    public static GameOverManager Instance { get; private set; }

    #if UNITY_EDITOR
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    static void ResetStatics()
    {
        Instance = null;
        s_respuestaALaDerrota = null;
    }
    #endif

    private static IRespuestaALaDerrota s_respuestaALaDerrota;

    /// La escena actual responde ella misma a la derrota (ver IRespuestaALaDerrota).
    public static void RegistrarRespuestaALaDerrota(IRespuestaALaDerrota respuesta) => s_respuestaALaDerrota = respuesta;

    public static void QuitarRespuestaALaDerrota(IRespuestaALaDerrota respuesta)
    {
        if (s_respuestaALaDerrota == respuesta) s_respuestaALaDerrota = null;
    }

    [Header("Escenas")]
    [SerializeField] private string mainMenuScene = "MainMenu";

    [Header("Continuar desde el último guardado")]
    [Tooltip("Escena del mundo que se carga al continuar. La misma que carga «Continuar» en el menú principal.")]
    [SerializeField] private string continueScene = "MainWorld";
    [Tooltip("Escena de pantalla de carga que tapa el cambio. La misma que usa el menú principal.")]
    [SerializeField] private string loadingOverlayScene = "LoadingScreen";

    [Header("Transiciones")]
    [SerializeField] private TransitionManager transitionManager;
    [SerializeField] private TransitionSettings mainMenuTransitionSettings;
    [SerializeField] private float transitionStartDelay;

    [Header("Slow Motion")]
    [Tooltip("Escala de tiempo mínima durante el slow-mo")]
    [SerializeField, Range(0.01f, 0.5f)] private float slowMotionScale = 0.15f;
    [Tooltip("Duración para llegar al slow-mo máximo")]
    [SerializeField] private float slowMotionRampDuration = 0.4f;
    [Tooltip("Fallback si no hay referencia al jugador (ej. NotifyGameOver llamado sin contexto): duración fija de espera antes de transicionar")]
    [SerializeField] private float slowMotionHoldDuration = 2.5f;
    [Tooltip("Tope de seguridad, en segundos reales, esperando a que el jugador termine de caer (animación de daño + caída), por si el Animator no llega al estado esperado")]
    [SerializeField] private float topeEsperaCaida = 7f;
    [Tooltip("Pequeña pausa tras aterrizar antes de cortar a la transición de pantalla")]
    [SerializeField] private float landingSettleDelay = 0.3f;

    [Header("Camera Zoom")]
    [Tooltip("¿Hacer zoom hacia el jugador?")]
    [SerializeField] private bool enableCameraZoom = true;
    [Tooltip("Factor de zoom (< 1 = acercar, > 1 = alejar). 0.85 = zoom sutil")]
    [SerializeField, Range(0.5f, 1f)] private float zoomFactor = 0.85f;
    [Tooltip("Duración del zoom")]
    [SerializeField] private float zoomDuration = 2f;

    [Header("Camera Focus")]
    [Tooltip("¿Reencuadrar la cámara para que enfoque al jugador al morir? Sin esto la cámara se queda mirando a lo que estuviera enfocando justo antes (p. ej. un enemigo con lock-on activo)")]
    [SerializeField] private bool enableCameraFocus = true;
    [Tooltip("Ángulo horizontal (yaw) del plano de muerte, relativo a la orientación del jugador")]
    [SerializeField] private float deathShotYawOffset = 150f;
    [Tooltip("Inclinación hacia abajo de la cámara para acompañar la caída al suelo")]
    [SerializeField] private float deathShotPitch = 20f;

    [Header("Noche de la caída")]
    [Tooltip("Segundos que tarda la pantalla en irse a la noche de estrellas antes de preguntar.")]
    [SerializeField] private float segundosDeLaNoche = 2.6f;
    [Tooltip("Grados que rodea la cámara al caído mientras cae la noche.")]
    [SerializeField] private float giroDeLaCamara = 40f;
    [Tooltip("Inclinación final de la cámara, mirando al caído desde arriba.")]
    [SerializeField] private float inclinacionFinal = 32f;

    [Header("Audio")]
    [Tooltip("Evento de audio para Game Over")]
    [SerializeField] private string gameOverAudioEvent = "GameOverMenu";

    private bool _isGameOverActive;
    private Coroutine _gameOverCoroutine;
    private Camera _mainCamera;
    private float _originalFOV;
    private Tween _zoomTween;
    private Tween _camaraLentaTween;
    // Escala que pide ahora la cámara lenta de la muerte (la anima _camaraLentaTween).
    private float _escalaPedida = 1f;
    private vThirdPersonCamera _thirdPersonCamera;
    private PlayerHealthSystem _deadPlayer;
    private NocheDeLaCaida _noche;

    public bool IsShown => _isGameOverActive;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void EnsurePersistentIfPlacedInStartScene()
    {
        try
        {
            if (ServiceLocator.TryGet(out GameOverManager existing) && existing != null)
            {
                if (existing.transform.root != null)
                    DontDestroyOnLoad(existing.transform.root.gameObject);
                else
                    DontDestroyOnLoad(existing.gameObject);
            }
        }
        catch (System.Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            ex
#endif
        )
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[GameOverManager] EnsurePersistentIfPlacedInStartScene failed: {ex}");
#endif
        }
    }

    private void Awake()
    {
        // Debug.Log($"[GameOverManager] Awake - scene='{gameObject.scene.name}'");
        
        if (Instance != null && Instance != this)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[GameOverManager] Destruyendo duplicado");
#endif
            Destroy(gameObject);
            return;
        }

        Instance = this;
        ServiceLocator.Register(this);
        SceneManager.sceneLoaded += HandleSceneLoaded;

        // Siempre persistir entre escenas para evitar perder el GameOverManager
        if (transform.parent == null)
        {
            DontDestroyOnLoad(gameObject);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log("[GameOverManager] Marcado como DontDestroyOnLoad");
#endif
        }
        else
        {
            // Si tiene padre, persistir el root
            DontDestroyOnLoad(transform.root.gameObject);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[GameOverManager] Root '{transform.root.name}' marcado como DontDestroyOnLoad");
#endif
        }
    }

    private void OnDestroy()
    {
        CleanupTweens();
        SceneManager.sceneLoaded -= HandleSceneLoaded;
        if (Instance == this)
        {
            Instance = null;
        }
        ServiceLocator.Unregister(this);
    }

    private void CleanupTweens()
    {
        _zoomTween?.Kill();
        _zoomTween = null;
        SoltarCamaraLenta();
    }

    /// Para la rampa de cámara lenta y suelta su petición al árbitro del tiempo.
    private void SoltarCamaraLenta()
    {
        _camaraLentaTween?.Kill();
        _camaraLentaTween = null;
        TimeScaleArbiterService.Release(this);
    }

    private void HandleSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        // Debug.Log($"[GameOverManager] Scene '{scene.name}' loaded -> reseteando estado");
        ForceResetState();
    }

    public void ForceResetState(string reason = null)
    {
        if (_gameOverCoroutine != null)
        {
            StopCoroutine(_gameOverCoroutine);
            _gameOverCoroutine = null;
        }

        CleanupTweens();
        QuitarLaNoche();
        _isGameOverActive = false;

        // Restaurar FOV si es necesario
        if (_mainCamera != null && _originalFOV > 0)
        {
            _mainCamera.fieldOfView = _originalFOV;
        }

        // Soltar cualquier referencia al jugador muerto (se vuelve a asignar en el próximo Game Over)
        _deadPlayer = null;

        if (!string.IsNullOrEmpty(reason))
        {
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log(reason);
            #endif
        }
    }

    /// <summary>
    /// Inicia la secuencia de Game Over cinematográfica
    /// </summary>
    /// <param name="deadPlayer">
    /// Referencia al PlayerHealthSystem que ha muerto. Se usa para enfocar la cámara en él y
    /// para sincronizar la transición de pantalla con el final real de su animación de caída.
    /// Puede ser null (compatibilidad hacia atrás); en ese caso se usa una espera fija.
    /// </param>
    public void ShowGameOver(PlayerHealthSystem deadPlayer = null)
    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[GameOverManager] ShowGameOver() - _isGameOverActive={_isGameOverActive}");
#endif

        if (_isGameOverActive || _gameOverCoroutine != null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log("[GameOverManager] ShowGameOver() IGNORADO - ya activo");
#endif
            return;
        }

        // Sin referencia al caído, el jugador vigente: sin él no hay plano del caído ni noche que
        // gire a su alrededor, y la cámara se quedaba mirando al enemigo fijado. Ver INC-1150.
        if (deadPlayer == null) PlayerService.TryGetComponent(out deadPlayer);
        _deadPlayer = deadPlayer;
        _gameOverCoroutine = StartCoroutine(GameOverSequence());
    }

    private System.Collections.IEnumerator GameOverSequence()
    {
        _isGameOverActive = true;
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log("[GameOverManager] 💀 Iniciando secuencia de Game Over cinematográfica");
#endif
        
        // DialogueManager.Close() hace Pop de UIMode y de ActionMode.Cinematic si estaban activos.
        DialogueManager.Instance?.Close();
        // Fases de GameState que pueden quedar huérfanas si el jugador murió durante un Interactable,
        // un teleport o cualquier otra secuencia que no llegó a hacer su Pop normal.
        GameState.ForceRemove(GamePhase.Dialogue);
        GameState.ForceRemove(GamePhase.SavePrompt);
        GameState.ForceRemove(GamePhase.Cutscene);
        GameState.ForceRemove(GamePhase.GameOver);
        // Limpiar suppressors de GamepadInputReader (ej. QuestMenuManager que no llegó a cerrar).
        GamepadInputReader.ForceRestoreGameplaySuppression();

        // 1. Fuera todo lo que hay en pantalla: el momento es del caído.
        OcultablesDeCinematica.OcultarTodos(this);

        // 1b. Limpiar el estado de cambio de personaje (destruye el NPC instanciado de Will si
        // lo hubiera). Sin esto, si el jugador moría mientras controlaba a Liam/Estela, el NPC de
        // Will quedaba instanciado y sobrevivía al Game Over; al recargar la partida y volver a
        // cambiar de personaje, ActiveCharacterSwapper podía terminar creando un segundo Will
        // (INC: "de pronto hay dos Will" tras un Game Over).
        ActiveCharacterSwapper.Instance?.ResetState();

        // 1c. Limpiar estado de combate huérfano: si el jugador murió en batalla, nunca se
        // llega a EndBattleById/RestoreAfterBattle/OnBattleWonRestoreMusic (esas rutas son solo
        // para victoria), así que AudioService._battleActive y ActiveCombatRegistry se quedaban
        // "encendidos" para siempre (ambos sobreviven al viaje a MainMenu). Efecto observado:
        // tras morir, volver a cargar partida y entrar en una AmbientZone, la música de zona no
        // sonaba porque AmbientZone.TransitionToZoneMusic ve IsBattleActive/Count>0 y aborta.
        AudioService.Instance?.ForceEndBattleState();
        ActiveCombatRegistry.ClearAll();

        // 2. Reproducir música/SFX de Game Over
        PlayGameOverAudio();

        // 3. Configurar cámara para zoom
        SetupCamera();

        // 3b. Reencuadrar la cámara en el jugador (evita que se quede mirando a lo que fuera que
        // tuviera enfocado justo antes de morir, p. ej. un enemigo con lock-on activo)
        if (enableCameraFocus)
        {
            FocusCameraOnDyingPlayer();
        }

        // 4. Iniciar slow-motion progresivo
        StartSlowMotion();

        // 5. Iniciar zoom de cámara (si está habilitado)
        if (enableCameraZoom && _mainCamera != null)
        {
            StartCameraZoom();
        }

        // 6. Esperar a que el jugador termine de caer al suelo (animación de muerte) antes de
        // cortar a la transición, usando tiempo real porque Time.timeScale está modificado
        yield return WaitForPlayerToLand();

        // 7. Cae la noche: la cámara rodea al caído y la pantalla se va a azul con estrellas.
        yield return NocheDeEstrellas();

        // 8. Fuera la cámara lenta antes de preguntar
        SoltarCamaraLenta();

        // 9. Continuar desde el último guardado o salir al menú
        OfrecerContinuar();

        _gameOverCoroutine = null;
    }

    /// Pregunta si continuar desde el último guardado o salir al menú. Sin nada que continuar (ni
    /// partida guardada ni preset de pruebas), o sin popup, va al menú como siempre.
    private void OfrecerContinuar()
    {
        if (s_respuestaALaDerrota != null && s_respuestaALaDerrota.Responder()) return;

        var popup = PopupDeContinuar();
        if (popup == null || !GameBootService.PuedeContinuar())
        {
            TransitionToMainMenu();
            return;
        }

        var loc = LocalizationManager.Instance;
        string Texto(string clave, string porDefecto) => loc != null ? loc.Get(clave, porDefecto) : porDefecto;

        // Atrás no elige nada: es el botón de defensa, y se suele estar pulsando al morir.
        popup.Show(
            Texto("GAME_OVER_MENSAJE", "Has caído. ¿Continuar desde el último punto de guardado?"),
            onConfirm: ContinuarDesdeElGuardado,
            onCancel: TransitionToMainMenu,
            confirmText: Texto("MainMenu_Continue", "Continuar"),
            cancelText: Texto("UI_SALIR_MENU", "Salir al menú"),
            selectConfirm: true,
            cancelWithBack: false,
            centrado: true);
    }

    /// Carga el último guardado sin pasar por el menú: tapa con la pantalla de carga, descarga el
    /// mundo, deja los sistemas como en el guardado (el mismo «Continuar» del menú) y carga el mundo.
    private void ContinuarDesdeElGuardado()
    {
        SoltarCamaraLenta();
        SceneTransitionLoader.LoadWithOverlay(continueScene, loadingOverlayScene, () =>
        {
            GameBootService.ResetTransientSessionState();
            GameBootService.PrepararContinuar();
        });
    }

    private void PlayGameOverAudio()
    {
        if (AudioService.Instance != null)
        {
            // Detener la música de gameplay/batalla: antes solo se reproducía el SFX de Game Over
            // encima de la música que ya estuviera sonando (ej. la del Golem), quedando las dos
            // mezcladas. Un fade corto evita un corte seco.
            AudioService.Instance.StopMusic(0.3f);

            if (!string.IsNullOrEmpty(gameOverAudioEvent))
            {
                AudioService.Instance.PlaySFX(gameOverAudioEvent);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[GameOverManager] 🔊 Audio '{gameOverAudioEvent}' reproducido");
#endif
            }
        }
    }

    private void SetupCamera()
    {
        _mainCamera = Camera.main;

        if (_mainCamera != null)
        {
            _originalFOV = _mainCamera.fieldOfView;
            _thirdPersonCamera = _mainCamera.GetComponent<vThirdPersonCamera>();
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[GameOverManager] 📷 Cámara configurada - FOV original: {_originalFOV}");
#endif
        }
        else
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[GameOverManager] ⚠️ No se encontró Camera.main");
#endif
        }
    }

    /// La pregunta de continuar. ConfirmationPopupUI se apunta como Instance en su Awake, que no
    /// llega a correr si su objeto empezó apagado en la escena: entonces se busca. Ver INC-1150.
    private static ConfirmationPopupUI PopupDeContinuar()
    {
        if (ConfirmationPopupUI.Instance != null) return ConfirmationPopupUI.Instance;
        var popup = FindAnyObjectByType<ConfirmationPopupUI>(FindObjectsInactive.Include);
        // Se enciende para que corra su Awake (prepara el panel y se apunta como Instance).
        if (popup != null && !popup.gameObject.activeSelf) popup.gameObject.SetActive(true);
        if (popup != null && !popup.isActiveAndEnabled) popup = null;
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.LogWarning(popup != null
            ? "[GameOverManager] ConfirmationPopupUI.Instance era nulo; encontrado apagado en la escena y encendido."
            : "[GameOverManager] No hay ConfirmationPopupUI activo en ninguna escena: sin pregunta de continuar.");
#endif
        return popup;
    }

    /// <summary>
    /// Reencuadra la cámara en el jugador que acaba de morir. Sin esto, el zoom cinematográfico
    /// (StartCameraZoom) solo estrecha el FOV mientras la cámara sigue apuntando a lo que fuera
    /// que tuviera enfocado un instante antes (ej. un enemigo con lock-on de combate todavía
    /// activo), en vez de al jugador cayendo al suelo.
    /// </summary>
    private void FocusCameraOnDyingPlayer()
    {
        if (_thirdPersonCamera == null || _deadPlayer == null) return;

        // Soltar cualquier lock de combate que siguiera activo: si no, el ángulo calculado abajo
        // se ignora y CameraMovement() sigue mirando al enemigo bloqueado.
        _thirdPersonCamera.ClearLockTarget();

        // Plano fijo y deliberado detrás/lateral del jugador, inclinado hacia abajo para
        // acompañar la caída. Se calcula a partir de su orientación actual en vez de depender
        // del ángulo libre que tuviera la cámara justo antes de morir.
        float playerYaw = _deadPlayer.transform.eulerAngles.y;
        _thirdPersonCamera.SetAngles(playerYaw + deathShotYawOffset, deathShotPitch);

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[GameOverManager] 🎥 Cámara enfocada en el jugador (yaw={playerYaw + deathShotYawOffset:F0}°, pitch={deathShotPitch:F0}°)");
#endif
    }

    /// <summary>
    /// Espera a que el jugador termine de caer al suelo (animación de muerte completada) antes
    /// de dar paso a la transición de pantalla. Si no hay referencia al jugador, usa la espera
    /// fija anterior como fallback.
    /// </summary>
    private System.Collections.IEnumerator WaitForPlayerToLand()
    {
        // Dejar que se aprecie el ramp de slow-mo antes de comprobar nada más.
        float elapsed = 0f;
        while (elapsed < slowMotionRampDuration)
        {
            elapsed += Time.unscaledDeltaTime;
            yield return null;
        }

        if (_deadPlayer == null)
        {
            float holdElapsed = 0f;
            while (holdElapsed < slowMotionHoldDuration)
            {
                holdElapsed += Time.unscaledDeltaTime;
                yield return null;
            }
            yield break;
        }

        float safety = 0f;
        while (!_deadPlayer.HasDeathAnimationFinished() && safety < topeEsperaCaida)
        {
            safety += Time.unscaledDeltaTime;
            yield return null;
        }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[GameOverManager] 🧍 Jugador en el suelo (esperado {safety:F2}s tras el ramp) -> transición de pantalla");
#endif

        // Pequeño respiro tras aterrizar antes de cortar a la transición.
        yield return new WaitForSecondsRealtime(landingSettleDelay);
    }

    /// La noche de estrellas (INC-1101): el lienzo justo por debajo del de la pregunta de continuar,
    /// y la cámara girando despacio alrededor del caído hasta mirarle desde arriba.
    private System.Collections.IEnumerator NocheDeEstrellas()
    {
        int orden = 100;
        var popup = PopupDeContinuar();
        var lienzoDelPopup = popup != null ? popup.GetComponentInParent<Canvas>() : null;
        if (lienzoDelPopup != null) orden = lienzoDelPopup.rootCanvas.sortingOrder;
        if (_noche != null) Destroy(_noche.gameObject);
        _noche = NocheDeLaCaida.Crear(transform, orden);
        _noche.Mostrar(segundosDeLaNoche);

        float yaw0 = 0f, pitch0 = deathShotPitch;
        if (_deadPlayer != null) yaw0 = _deadPlayer.transform.eulerAngles.y + deathShotYawOffset;
        float t = 0f;
        while (t < segundosDeLaNoche)
        {
            t += Time.unscaledDeltaTime;
            float k = Mathf.SmoothStep(0f, 1f, t / segundosDeLaNoche);
            if (_thirdPersonCamera != null && _deadPlayer != null)
            {
                // El fijado de combate puede volver a engancharse al enemigo: se suelta cada vez.
                _thirdPersonCamera.ClearLockTarget();
                _thirdPersonCamera.SetAngles(yaw0 + giroDeLaCamara * k, Mathf.Lerp(pitch0, inclinacionFinal, k));
            }
            yield return null;
        }
    }

    private void QuitarLaNoche()
    {
        if (_noche != null) Destroy(_noche.gameObject);
        _noche = null;
        OcultablesDeCinematica.MostrarTodos(this);
    }

    private void StartSlowMotion()
    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[GameOverManager] 🐌 Iniciando slow-mo: {Time.timeScale} -> {slowMotionScale} en {slowMotionRampDuration}s");
#endif
        
        // La rampa pide cada paso al árbitro con esta misma clave: convive con las demás
        // peticiones de tiempo en vez de escribir timeScale a mano.
        _camaraLentaTween?.Kill();
        TimeScaleArbiterService.TryGetRequest(this, out _escalaPedida);
        _camaraLentaTween = DOTween.To(
            () => _escalaPedida,
            x => { _escalaPedida = x; TimeScaleArbiterService.Request(this, x); },
            slowMotionScale,
            slowMotionRampDuration
        ).SetEase(Ease.OutQuad).SetUpdate(true);
    }

    private void StartCameraZoom()
    {
        if (_mainCamera == null) return;

        float targetFOV = _originalFOV * zoomFactor;
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[GameOverManager] 🔍 Iniciando zoom FOV: {_originalFOV} -> {targetFOV} en {zoomDuration}s");
#endif

        _zoomTween?.Kill();
        _zoomTween = DOTween.To(
            () => _mainCamera.fieldOfView,
            x => _mainCamera.fieldOfView = x,
            targetFOV,
            zoomDuration
        ).SetEase(Ease.OutSine).SetUpdate(true);
    }

    private void TransitionToMainMenu()
    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[GameOverManager] 🚪 Transición al menú principal: '{mainMenuScene}'");
#endif

        MainMenuController.RequestInputDebounce();

        var tm = ResolveTransitionManager();
        if (tm != null && mainMenuTransitionSettings != null)
        {
            tm.Transition(mainMenuScene, mainMenuTransitionSettings, transitionStartDelay);
        }
        else
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[GameOverManager] TransitionManager o settings no disponibles, carga directa");
#endif
            SceneManager.LoadScene(mainMenuScene);
        }
    }

    private TransitionManager ResolveTransitionManager()
    {
        if (transitionManager != null) return transitionManager;

        if (ServiceLocator.TryGet(out TransitionManager cached) && cached != null)
        {
            transitionManager = cached;
            return transitionManager;
        }

        try
        {
            transitionManager = TransitionManager.Instance();
            if (transitionManager != null)
            {
                ServiceLocator.Register(transitionManager);
            }
        }
        catch (System.Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            ex
#endif
        )
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[GameOverManager] TransitionManager.Instance() falló: {ex.Message}");
#endif
        }

        return transitionManager;
    }

    /// <summary>
    /// Modo helper para notificar Game Over desde otros scripts de forma segura.
    /// Crea una instancia de emergencia si no existe ninguna.
    /// </summary>
    /// <param name="deadPlayer">
    /// PlayerHealthSystem que ha muerto (opcional). Permite enfocar la cámara en él y
    /// sincronizar la transición con el final real de su animación de caída.
    /// </param>
    public static void NotifyGameOver(PlayerHealthSystem deadPlayer = null)
    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log("[GameOverManager] 💀 NotifyGameOver() llamado");
#endif
        
        if (Instance == null)
        {
            // Intentar buscar en ServiceLocator
            if (ServiceLocator.TryGet(out GameOverManager found) && found != null)
            {
                Instance = found;
            }
            else
            {
                // Buscar directamente incluyendo objetos inactivos
                found = UnityEngine.Object.FindAnyObjectByType<GameOverManager>(FindObjectsInactive.Include);
                
                if (found != null)
                {
                    Instance = found;
                    ServiceLocator.Register(found);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log("[GameOverManager] ✅ Instancia encontrada (estaba inactiva o no registrada)");
#endif
                }
                else
                {
                    // Crear instancia de emergencia
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.LogWarning("[GameOverManager] ⚠️ No se encontró instancia, creando una de emergencia...");
#endif
                    var emergencyGO = new GameObject("[GameOverManager_Emergency]");
                    Instance = emergencyGO.AddComponent<GameOverManager>();
                    DontDestroyOnLoad(emergencyGO);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log("[GameOverManager] ✅ Instancia de emergencia creada");
#endif
                }
            }
        }

        if (Instance == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogError("[GameOverManager] ❌ No se pudo crear/encontrar ninguna instancia.");
#endif
            // Fallback: cargar menú principal directamente
            SceneManager.LoadScene("MainMenu");
            return;
        }

        if (!Instance.gameObject.activeSelf)
            Instance.gameObject.SetActive(true);

        if (!Instance.enabled)
            Instance.enabled = true;

        Instance.ShowGameOver(deadPlayer);
    }

    // ================== LEGACY COMPATIBILITY ==================
    public void HideGameOver(bool resumeTime = true) 
    {
        ForceResetState("HideGameOver llamado");
    }
}
