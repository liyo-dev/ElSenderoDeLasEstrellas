﻿using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using Core.InputGlyphs;
using TMPro;

[DisallowMultipleComponent]
public class MainMenuController : MonoBehaviour
{
    static bool _forceInputDebounce;
    static float _forcedDelay = -1f;

    public static void RequestInputDebounce(float minimumDelay = 0.2f)
    {
        _forceInputDebounce = true;
        _forcedDelay = Mathf.Max(0f, minimumDelay);
    }

    [Header("Refs")]
    private SaveSystem saveSystem;

    [Tooltip("Fila / contenedor de la opción CONTINUAR (con tu Text dentro). Si no hay partida, se oculta.")]
    [SerializeField] private GameObject continueRow;

    [Tooltip("Button de la fila CONTINUAR.")]
    [SerializeField] private Button continueButton;

    [Tooltip("Button de la fila NUEVA PARTIDA.")]
    [SerializeField] private Button newGameButton;

    [Tooltip("Button de la fila AJUSTES.")]
    [SerializeField] private Button settingsButton;

    [Tooltip("Button de la fila CONTROLES.")]
    [SerializeField] private Button controlsButton;

    [Tooltip("Button de la fila SALIR.")]
    [SerializeField] private Button exitButton;

    [Tooltip("Button de la fila LABORATORIO (el LAB de pruebas para testers). Opcional.")]
    [SerializeField] private Button labButton;

    [Tooltip("Escena del LAB que carga el botón LABORATORIO.")]
    [SerializeField] private string escenaDelLab = "Lab";

    [Tooltip("Panel que contiene los botones principales del menú.")]
    [SerializeField] private GameObject buttonPanel;

    [Header("Settings")]
    [SerializeField] private SettingsMenuController settingsMenu;

    [Header("Controls")]
    [SerializeField] private ControlsMenuController controlsMenu;

    [Header("Language Select (primer arranque)")]
    [Tooltip("Panel de selección de idioma. Se muestra una única vez, antes del menú, mientras PlayerSettings.LanguageSelected siga en false. Opcional: si se deja vacío, el menú arranca como hasta ahora sin selector de idioma.")]
    [SerializeField] private LanguageSelectPanel languageSelectPanel;

    [Header("Portada")]
    [Tooltip("Portada del fondo (una por etapa de la historia). Al pulsar Nueva Partida o Continuar, se espera a su animación de salida antes de cargar. Vacío = se busca en la escena.")]
    [SerializeField] private PortadaDelMenu portada;

    [Tooltip("Efecto de salida al comenzar o continuar una partida.")]
    [SerializeField] private EfectoDeComenzarPartida efectoAlComenzar;

    [Header("Scene when continuing")]
    [SerializeField] private string nextSceneContinue = "MainWorld";

    [Header("Scene when starting new game")]
    [SerializeField] private string nextSceneNewGame = "Prologo";

    [Header("Loading Screen")]
    [SerializeField] private string loadingOverlayScene = "LoadingScreen";

    [Header("Fade override (opcional)")]
    [SerializeField] private EasyTransition.TransitionSettings fadeOverride;
    [Min(0f)] public float fadeDelay;

    [Header("UI / Intro (opcional)")]
    [SerializeField] private CanvasGroup rootGroup;          // si está vacío, se añade en Awake
    [SerializeField] private RectTransform[] animatedItems;  // hijos que caen en intro
    [Tooltip("Retraso antes de que aparezca el rootGroup")]
    [Min(0f)] public float rootAppearDelay = 1f;
    [Min(0f)] public float introDelay = 0.05f;
    [Min(0f)] public float introStagger = 0.04f;
    [Min(0f)] public float introDuration = 0.35f;
    public float introYOffset = 40f;
    [Header("Input Debounce")]
    [Tooltip("Activar para ignorar el Submit inicial al entrar al menú.")]
    public bool enableInputDebounce;
    [Min(0f)] public float inputArmDelay = 0.2f;

    private Sequence _introSeq;
    private bool _isLoading;
    private Coroutine _loadRoutine;
    private bool _interactionSuspendedForLoad;
    private bool _inputArmed = true;
    private Coroutine _armRoutine;
    private bool _armSnapshotValid;
    private bool _armSnapshotRaycasts;
    private bool _armSnapshotContinueInteractable;
    private bool _armSnapshotNewInteractable;
    private bool _settingsSnapshotRaycasts;
    private bool _settingsSnapshotInteractable;

    void Awake()
    {
        if (!efectoAlComenzar)
            efectoAlComenzar = GetComponent<EfectoDeComenzarPartida>();
        if (!saveSystem)
            saveSystem = ServiceLocator.Get<SaveSystem>();

        if (!rootGroup)
            rootGroup = gameObject.GetComponent<CanvasGroup>() ?? gameObject.AddComponent<CanvasGroup>();

        // Autowire de botones si faltan referencias
        if (!continueButton && continueRow)
            continueButton = continueRow.GetComponent<Button>();

        if (!newGameButton)
            newGameButton = TryFindNewGameButton();

        if (!settingsButton)
            settingsButton = TryFindSettingsButton();

        if (!controlsButton)
            controlsButton = TryFindControlsButton();

        if (!exitButton)
            exitButton = TryFindExitButton();

        if (!settingsMenu)
            settingsMenu = GetComponentInChildren<SettingsMenuController>(true);

        if (!controlsMenu)
            controlsMenu = GetComponentInChildren<ControlsMenuController>(true);

        if (!languageSelectPanel)
            languageSelectPanel = GetComponentInChildren<LanguageSelectPanel>(true);

        if (!portada)
            portada = FindAnyObjectByType<PortadaDelMenu>();

        if (settingsMenu)
            settingsMenu.Close(silent: true);

        if (controlsMenu)
            controlsMenu.Close(silent: true);

        if (languageSelectPanel)
            languageSelectPanel.Close(silent: true);

        WireButton(continueButton, OnClickContinue, "CONTINUE");
        WireButton(newGameButton, OnClickNewGame, "NEW GAME");
        WireButton(settingsButton, OnClickSettings, "SETTINGS");
        WireButton(controlsButton, OnClickControls, "CONTROLS");
        WireButton(exitButton, OnClickExit, "EXIT");
        if (labButton) WireButton(labButton, OnClickLab, "LAB");
        CrearBotonDeIconosDeMando();

        // Ensure UISelectVisual exists on main menu buttons
        var menuButtons = GetComponentsInChildren<Button>(true);
        foreach (var b in menuButtons)
        {
            if (b == null) continue;
            
            // Visual feedback
            if (!b.GetComponent<UISelectVisual>())
            {
                var v = b.gameObject.AddComponent<UISelectVisual>();
                v.normalColor = Color.white;
                v.highlightColor = new Color(0.95f, 0.9f, 0.7f);
                v.selectedScale = 1.08f;
                v.animDuration = 0.12f;
                v.enablePulse = true;
                v.enableShadowPunch = true;
            }
        }
    }

    void OnEnable()
    {
        // Llegar al MainMenu (por cualquier camino: recién arrancado, pausa → salir al menú,
        // créditos → menú...) es un punto de entrada seguro de sesión: nunca hay legítimamente
        // una cinemática/transición/cámara bloqueada en curso aquí. Aprovechamos para tirar
        // cualquier flag estático de sesión que haya quedado "colgado" de una sesión anterior
        // cortada a mitad de camino, antes de que el jugador pueda volver a cargar partida.
        // Ver GameBootService.ResetTransientSessionState() para el detalle.
        GameBootService.ResetTransientSessionState();

        GameState.Push(GamePhase.MainMenu);

        // Forzar modo UI de forma síncrona: cancela cualquier actualización diferida pendiente
        // que pudiera venir del gameplay anterior y deja refCount=1 para el PopUIMode de OnDisable.
        // Usamos EnsureExists() en vez de leer Instance directamente porque, según nuestra
        // arquitectura, el menú debe poder cargarse desde su propia escena (ej: Play in Editor
        // sobre MainMenu.unity) sin haber pasado antes por Start.unity, que es donde normalmente
        // vive el PlayerInputManager persistente.
        var pim = Core.PlayerInputManager.EnsureExists();
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[MainMenu-Debug] OnEnable — pim={pim != null}, GameState.MainMenu={GameState.Is(GamePhase.MainMenu)}");
#endif
        pim.ForceSyncEnterUIMode();
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        // Log estado del EventSystem
        var es = UnityEngine.EventSystems.EventSystem.current;
        var uiMod = es != null ? es.GetComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>() : null;
        Debug.Log($"[MainMenu-Debug] EventSystem={es?.name ?? "NULL"}, UIInputModule={uiMod != null}, " +
                  $"UIInputModule.enabled={uiMod?.enabled}, rootGroup.blocksRaycasts={rootGroup?.blocksRaycasts}");
#endif

        _isLoading = false; // reset por si vuelves al menú
        UpdateContinueVisibility();

        // Asegurar que los botones (incluidos los del selector de idioma, si toca enseñarlo)
        // tienen UIButtonAudio antes de que nada se seleccione, para que el silenciado de abajo
        // cubra también su posible "blip" de selección inicial.
        EnsureButtonAudio();

        // Silenciar temporalmente los sonidos de UI para evitar el sonido de selección inicial
        UIButtonAudio.MuteAll = true;

        bool needsLanguageSelect = languageSelectPanel != null && !PlayerSettings.LanguageSelected;
        if (needsLanguageSelect)
        {
            // Primer arranque de esta instalación: todavía no hay idioma confirmado. Se enseña
            // el selector sin la animación de entrada del menú (rootGroup a alpha 1 directo) —
            // PlayIntro() se reserva para cuando el jugador ya eligió idioma y aparece el menú
            // real, en ShowLanguageSelectFirst().
            if (rootGroup) rootGroup.alpha = 1f;
            ShowLanguageSelectFirst();
        }
        else
        {
            PlayIntro();
            AutoSelectFirstIfNeeded();
        }

        // Rehabilita los sonidos después de la selección inicial.
        StartCoroutine(EnableUISoundsNextFrame());
        
        // SelfTestButtons eliminado - solo útil en debug profundo
        
        // Armar interacción tras un breve retardo para ignorar el Submit inicial
        bool shouldDebounce = enableInputDebounce || _forceInputDebounce;
        _inputArmed = !shouldDebounce;

        if (_armRoutine != null)
        {
            StopCoroutine(_armRoutine);
            _armRoutine = null;
        }

        if (shouldDebounce)
        {
            float delay = inputArmDelay;
            if (_forceInputDebounce)
            {
                delay = Mathf.Max(delay, _forcedDelay >= 0f ? _forcedDelay : delay);
                _forceInputDebounce = false;
                _forcedDelay = -1f;
            }

            _armRoutine = StartCoroutine(ArmMenuAfterDelay(delay));
        }
    }

    void Start()
    {
        UpdateContinueVisibility();
        AutoSelectFirstIfNeeded();
    }

    void OnDisable()
    {
        Core.PlayerInputManager.Instance?.PopUIMode();
        GameState.Pop(GamePhase.MainMenu);
        
        // Asegurar que los sonidos de UI estén habilitados al salir
        UIButtonAudio.MuteAll = false;

        _introSeq?.Kill(); _introSeq = null;
        if (_armRoutine != null)
        {
            StopCoroutine(_armRoutine);
            _armRoutine = null;
        }
        RestoreArmSnapshot();
        if (_loadRoutine != null)
        {
            StopCoroutine(_loadRoutine);
            _loadRoutine = null;
        }
        if (_interactionSuspendedForLoad)
        {
            RestoreMainMenuInteraction();
            _interactionSuspendedForLoad = false;
        }
        _inputArmed = true;
    }

    // ===== Visibilidad / Selección =========================================
    void UpdateContinueVisibility()
    {
        if (!saveSystem)
            saveSystem = ServiceLocator.Get<SaveSystem>(logIfMissing: false);

        bool isTestMode = GameBootService.IsPresetOverrideActive;

        if (isTestMode)
        {
            // Modo test: el bootPreset actúa como partida cargada → solo Continuar.
            // Nueva Partida se oculta porque no tiene sentido resetear el preset de prueba.
            if (continueRow) continueRow.SetActive(true);
            if (continueButton) continueButton.interactable = true;
            if (newGameButton) newGameButton.gameObject.SetActive(false);
        }
        else
        {
            bool hasSave = saveSystem && saveSystem.HasSave();
            if (continueRow) continueRow.SetActive(hasSave);
            if (continueButton) continueButton.interactable = hasSave;
            if (newGameButton) newGameButton.gameObject.SetActive(true);
        }
    }

    void AutoSelectFirstIfNeeded()
    {
        // Seleccionar el primer botón interactivo disponible
        if (continueRow && continueRow.activeInHierarchy && continueButton && continueButton.interactable)
        {
            continueButton.Select();
        }
        else
        {
            var firstBtn = FindFirstActiveButton();
            if (firstBtn) firstBtn.Select();
        }
    }
    
    private System.Collections.IEnumerator EnableUISoundsNextFrame()
    {
        // Mantiene el silencio hasta después del Invoke inicial de MenuNavigator.
        yield return new WaitForSeconds(0.1f);
        yield return null;
        UIButtonAudio.MuteAll = false;
    }
    
    /// <summary>
    /// Asegura que todos los botones del menú tengan UIButtonAudio para los sonidos de navegación
    /// OPTIMIZACIÓN: Solo se ejecuta una vez, cachea el resultado
    /// </summary>
    private bool _audioComponentsEnsured = false;
    
    private void EnsureButtonAudio()
    {
        // Optimización: solo ejecutar una vez
        if (_audioComponentsEnsured) return;
        
        var buttonsRoot = buttonPanel ? buttonPanel : rootGroup ? rootGroup.gameObject : gameObject;
        var menuButtons = new System.Collections.Generic.HashSet<Button>(buttonsRoot.GetComponentsInChildren<Button>(true));
        var languageButtons = languageSelectPanel
            ? languageSelectPanel.GetComponentsInChildren<Button>(true)
            : System.Array.Empty<Button>();
        menuButtons.UnionWith(languageButtons);
        foreach (var b in menuButtons)
        {
            if (b == null) continue;
            
            // Añade el audio de navegación al botón.
            var audioComp = b.GetComponent<UIButtonAudio>();
            if (audioComp == null)
            {
                audioComp = b.gameObject.AddComponent<UIButtonAudio>();
            }
            
            // Habilita la navegación y reserva el click para los handlers que no reproducen sonido.
            audioComp.SetPlayHoverSound(true);
            bool handlerPlaysSound = b == continueButton || b == newGameButton
                || b == settingsButton || b == controlsButton || b == exitButton || (labButton && b == labButton)
                || System.Array.IndexOf(languageButtons, b) >= 0;
            for (int i = 0; i < b.onClick.GetPersistentEventCount(); i++)
            {
                if (b.onClick.GetPersistentTarget(i) != this) continue;
                string method = b.onClick.GetPersistentMethodName(i);
                handlerPlaysSound |= method == nameof(OnClickContinue) || method == nameof(OnClickNewGame)
                    || method == nameof(OnClickSettings) || method == nameof(OnClickControls)
                    || method == nameof(OnClickExit) || method == nameof(OnClickLab);
            }
            audioComp.SetPlayClickSound(!handlerPlaysSound);
        }
        
        _audioComponentsEnsured = true;
        
    }

    // ===== Intro (CanvasGroup en cada item) =================================
    void PlayIntro()
    {
        if (!rootGroup) return;

        rootGroup.alpha = 0f;
        _introSeq?.Kill();
        _introSeq = DOTween.Sequence().AppendInterval(introDelay);

        if (animatedItems != null && animatedItems.Length > 0)
        {
            foreach (var item in animatedItems)
            {
                if (!item) continue;

                var cg = item.GetComponent<CanvasGroup>();
                if (!cg) cg = item.gameObject.AddComponent<CanvasGroup>();

                var startPos = item.anchoredPosition;
                item.anchoredPosition = startPos + new Vector2(0f, -introYOffset);
                cg.alpha = 0f;

                _introSeq.AppendCallback(() =>
                {
                    item.DOAnchorPos(startPos, introDuration).SetEase(Ease.OutCubic);
                    cg.DOFade(1f, introDuration);
                });

                _introSeq.AppendInterval(introStagger);
            }
        }

        // Hacer que el rootGroup aparezca tras un retardo configurable
        _introSeq.Insert(rootAppearDelay, rootGroup.DOFade(1f, introDuration));
    }

    // ===== Acciones de menú =================================================
    public void OnClickContinue()
    {
        if (_isLoading || !_inputArmed)
        {
            if (!_inputArmed)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log("[MainMenu] Ignorando Continue mientras el menú arma la entrada.");
                #endif
            }
            return;
        }
        _isLoading = true;
        
        // SFX de confirmación
        if (!efectoAlComenzar)
            AudioService.Instance?.PlaySFX("UI_Submit");

        if (!saveSystem)
            saveSystem = ServiceLocator.Get<SaveSystem>(logIfMissing: false);

        // El mismo «Continuar» que usa la pantalla de Game Over: ver GameBootService.PrepararContinuar.
        if (!GameBootService.PrepararContinuar(saveSystem))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[MainMenu] CONTINUE pulsado sin save disponible → usando preset por defecto");
#endif
        }

        LoadContinueScene();
    }

    public void OnClickNewGame()
    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log("[MainMenu] ========== NUEVA PARTIDA SOLICITADA ==========");
#endif

        if (_isLoading || !_inputArmed)
        {
            if (!_inputArmed)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log("[MainMenu] Ignorando New Game mientras el menú arma la entrada.");
                #endif
            }
            return;
        }

        if (!saveSystem)
            saveSystem = ServiceLocator.Get<SaveSystem>(logIfMissing: false);

        // Si hay una partida guardada (y no estamos en modo preset de testeo, que no toca el
        // save), pedir confirmación antes de borrarla. Reutilizamos el mismo popup que ya se usa
        // para "salir al menú principal" (ConfirmationPopupUI), solo cambia el texto.
        bool forcePreset = GameBootService.IsPresetOverrideActive;
        bool hasSave = saveSystem != null && saveSystem.HasSave();

        if (!forcePreset && hasSave)
        {
            var popup = ConfirmationPopupUI.Instance;
            if (popup != null)
            {
                string msg = LocalizationManager.Instance != null
                    ? LocalizationManager.Instance.Get("CONFIRM_NEW_GAME", "Se borrarán los datos de la partida actual. ¿Quieres continuar?")
                    : "Se borrarán los datos de la partida actual. ¿Quieres continuar?";
                popup.Show(msg, onConfirm: ProceedWithNewGame);
                return;
            }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[MainMenu] Había que mostrar el popup de confirmación pero ConfirmationPopupUI.Instance es NULL (¿Start.unity no está cargada?). Se procede sin confirmar.");
#endif
        }

        ProceedWithNewGame();
    }

    void ProceedWithNewGame()
    {
        if (_isLoading) return;
        _isLoading = true;

        // SFX de confirmación
        if (!efectoAlComenzar)
            AudioService.Instance?.PlaySFX("UI_Submit");

        bool forcePreset = GameBootService.IsPresetOverrideActive;

        if (forcePreset)
        {
            // MODO TESTING: El preset de testeo controla TODO - no hace falta resetear ni borrar saves
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log("[MainMenu] NEW GAME en modo preset/test → Save NO se borra, bootPreset tiene control absoluto");
#endif
        }
        else
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log("[MainMenu] NEW GAME → Reseteando perfil y borrando save");
#endif

            if (GameBootService.IsAvailable)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log("[MainMenu] Llamando a GameBootService.NewGameReset()...");
#endif
                GameBootService.NewGameReset();
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log("[MainMenu] GameBootService.NewGameReset() completado");
#endif
            }
            else
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning("[MainMenu] GameBootService no esta listo; se borra el save directamente.");
#endif
                if (saveSystem != null)
                {
                    bool ok = saveSystem.Delete();
                    if (!ok)
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.LogWarning("[MainMenu] SaveSystem.Delete() devolvio false (algun fichero no se pudo borrar).");
                        #endif
                    }
                }
            }

            // FIX: una Nueva Partida real arranca MainWorld directamente en la cinemática del sueño
            // inicial (la del prólogo), que pone su propia música vía PlaySequenceMusic()
            // cuando el grafo narrativo lanza su señal de entrada. Ese lanzamiento ocurre en Start()/
            // más adelante, pero AudioService.OnSceneLoaded (suscrito a SceneManager.sceneLoaded) se
            // dispara ANTES, así que sin esto la música de mundo de MainWorld arranca sola un instante
            // y enseguida se corta a la de la secuencia — el "doble arranque" que se oía mal. No se
            // aplica en modo preset/test (forcePreset) porque ese bootPreset puede no arrancar con
            // esta cinemática, y silenciar ahí dejaría MainWorld sin música alguna.
            AudioService.MuteNextBaseSceneMusic = true;
        }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log("[MainMenu] Cargando escena de Nueva Partida...");
#endif
        LoadNewGameScene();
    }

    /// <summary>
    /// Enseña el selector de idioma de primer arranque tapando el menú normal, reutilizando
    /// exactamente la misma coreografía de suspensión/restauración que OnClickSettings/
    /// OnClickControls (SuspendMainMenuInteraction, buttonPanel oculto, re-armado de input al
    /// volver). Solo se llama desde OnEnable cuando PlayerSettings.LanguageSelected es false.
    /// </summary>
    void ShowLanguageSelectFirst()
    {
        if (buttonPanel != null)
            buttonPanel.SetActive(false);

        SuspendMainMenuInteraction();

        languageSelectPanel.Show(() =>
        {
            RestoreMainMenuInteraction();

            if (buttonPanel != null)
                buttonPanel.SetActive(true);

            // El jugador ya eligió idioma: ahora sí toca la animación de entrada normal del
            // menú, como si acabara de aparecer (mismo efecto que un arranque sin selector).
            PlayIntro();

            RestartArmAfterSettingsClose();
            StartCoroutine(RestoreSelectionNextFrame(null));
        });
    }

    public void OnClickSettings()
    {
        if (_isLoading || !_inputArmed) return;
        // SFX de confirmación
        AudioService.Instance?.PlaySFX("UI_Submit");
        
        if (!settingsMenu)
            settingsMenu = GetComponentInChildren<SettingsMenuController>(true);

        // Fallback: obtener desde el ServiceLocator si no se encuentra como hijo
        if (!settingsMenu)
        {
            settingsMenu = ServiceLocator.Get<SettingsMenuController>(false);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[MainMenu] OnClickSettings fallback ServiceLocator -> {(settingsMenu != null ? settingsMenu.name : "<null>")}");
#endif
        }

        if (settingsMenu != null)
        {
            if (buttonPanel != null)
                buttonPanel.SetActive(false);

            var initial = settingsMenu.GetDefaultSelection();
            SuspendMainMenuInteraction();
            settingsMenu.Show(initial, () =>
            {
                RestoreMainMenuInteraction();

                if (buttonPanel != null)
                    buttonPanel.SetActive(true);

                LogMenuState("OnClickSettings-AfterReopen");

                RestartArmAfterSettingsClose();

                // Restaurar la selección en el siguiente frame: debe volver al botón que abrió
                // Ajustes, no al primero de la lista.
                StartCoroutine(RestoreSelectionNextFrame(settingsButton ? settingsButton.gameObject : null));
            });

            if (initial != null)
            {
                var selectable = initial.GetComponent<Selectable>();
                if (selectable != null)
                    selectable.Select();
            }
        }
        else
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[MainMenu] No se encontró SettingsMenuController en la jerarquía ni en la escena.");
#endif
        }
    }

    public void OnClickControls()
    {
        if (_isLoading || !_inputArmed) return;
        // SFX de confirmación
        AudioService.Instance?.PlaySFX("UI_Submit");

        if (!controlsMenu)
            controlsMenu = GetComponentInChildren<ControlsMenuController>(true);

        // Fallback: obtener desde el ServiceLocator si no se encuentra como hijo (mismo patrón que OnClickSettings)
        if (!controlsMenu)
        {
            controlsMenu = ServiceLocator.Get<ControlsMenuController>(false);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[MainMenu] OnClickControls fallback ServiceLocator -> {(controlsMenu != null ? controlsMenu.name : "<null>")}");
#endif
        }

        if (controlsMenu != null)
        {
            if (buttonPanel != null)
                buttonPanel.SetActive(false);

            SuspendMainMenuInteraction();
            LogMenuState("OnClickControls-BeforeShow");
            controlsMenu.Show(() =>
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log("[MainMenu-Debug] Controls onClosed callback INVOCADO");
#endif
                RestoreMainMenuInteraction();

                if (buttonPanel != null)
                    buttonPanel.SetActive(true);
                else
                {
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.LogWarning("[MainMenu-Debug] buttonPanel es NULL en el callback de cierre de Controles");
                    #endif
                }

                LogMenuState("OnClickControls-AfterReopen");

                RestartArmAfterSettingsClose();

                // Restaurar la selección en el siguiente frame: debe volver al botón que abrió
                // Controles, no al primero de la lista.
                StartCoroutine(RestoreSelectionNextFrame(controlsButton ? controlsButton.gameObject : null));
            });
        }
        else
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[MainMenu] No se encontró ControlsMenuController en la jerarquía ni en la escena.");
#endif
        }
    }

    void RestartArmAfterSettingsClose()
    {
        _inputArmed = false;

        if (_armRoutine != null)
        {
            StopCoroutine(_armRoutine);
            _armRoutine = null;
        }

        float delay = Mathf.Max(0.01f, inputArmDelay);
        _armRoutine = StartCoroutine(ArmMenuAfterDelay(delay));
    }

    /// <summary>
    /// LABORATORIO: carga el LAB de pruebas. No toca la partida guardada (el LAB no guarda), así
    /// que no pide confirmación como NUEVA PARTIDA.
    /// </summary>
    public void OnClickLab()
    {
        if (_isLoading || !_inputArmed) return;
        if (string.IsNullOrEmpty(escenaDelLab)) return;
        _isLoading = true;
        if (!efectoAlComenzar)
            AudioService.Instance?.PlaySFX("UI_Submit");
        LoadTargetScene(escenaDelLab, labButton);
    }

    // ── Iconos de mando (pruebas) ────────────────────────────────────────
    // Fila «Mando: …» que fuerza los iconos de mando (Automático / Nintendo / PlayStation / Xbox).
    // Sirve para probar con mandos que llegan al juego disfrazados por apps como Switch 2 Connect,
    // DS4Windows o Steam Input. Solo en el Editor y en builds de desarrollo. Ver InputGlyphService.
    Button _iconosDeMandoButton;
    TMP_Text _iconosDeMandoTexto;

    static readonly InputGlyphDeviceFamily?[] CicloDeIconosDeMando =
    {
        null, InputGlyphDeviceFamily.Switch, InputGlyphDeviceFamily.PlayStation, InputGlyphDeviceFamily.Xbox,
    };

    void CrearBotonDeIconosDeMando()
    {
        if (!Debug.isDebugBuild || _iconosDeMandoButton) return;
        var plantilla = labButton ? labButton : exitButton;
        if (!plantilla) return;

        var copia = Instantiate(plantilla.gameObject, plantilla.transform.parent);
        copia.name = "BotonIconosDeMando";
        copia.transform.SetSiblingIndex(plantilla.transform.GetSiblingIndex() + 1);

        // El texto lo pone esta fila, no la tabla de idiomas.
        foreach (var localizado in copia.GetComponentsInChildren<LocalizedText>(true))
            Destroy(localizado);

        _iconosDeMandoButton = copia.GetComponent<Button>();
        _iconosDeMandoButton.onClick = new Button.ButtonClickedEvent();
        _iconosDeMandoButton.onClick.AddListener(OnClickIconosDeMando);
        _iconosDeMandoTexto = copia.GetComponentInChildren<TMP_Text>(true);
        RefrescarTextoDeIconosDeMando();
    }

    public void OnClickIconosDeMando()
    {
        if (_isLoading || !_inputArmed) return;
        int actual = System.Array.IndexOf(CicloDeIconosDeMando, InputGlyphService.ForcedGamepadFamily);
        var siguiente = CicloDeIconosDeMando[(actual + 1) % CicloDeIconosDeMando.Length];
        InputGlyphService.SetForcedGamepadFamily(siguiente);
        RefrescarTextoDeIconosDeMando();
    }

    void RefrescarTextoDeIconosDeMando()
    {
        if (!_iconosDeMandoTexto) return;
        _iconosDeMandoTexto.text = InputGlyphService.ForcedGamepadFamily switch
        {
            InputGlyphDeviceFamily.Switch => "Mando: Nintendo",
            InputGlyphDeviceFamily.PlayStation => "Mando: PlayStation",
            InputGlyphDeviceFamily.Xbox => "Mando: Xbox",
            _ => "Mando: Automático",
        };
    }

    public void OnClickExit()
    {
        if (_isLoading || !_inputArmed)
        {
            if (!_inputArmed)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log("[MainMenu] Ignorando Exit mientras el menú arma la entrada.");
                #endif
            }
            return;
        }

        // SFX de confirmación
        AudioService.Instance?.PlaySFX("UI_Submit");

        Application.Quit();
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif
    }

    // ===== Carga de escenas diferenciada ===================================
    void LoadContinueScene()
    {
        if (string.IsNullOrEmpty(nextSceneContinue))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogError("[MainMenu] nextSceneContinue no está configurado.");
#endif
            _isLoading = false;
            return;
        }

        LoadTargetScene(nextSceneContinue, continueButton);
    }

    void LoadNewGameScene()
    {
        if (string.IsNullOrEmpty(nextSceneNewGame))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogError("[MainMenu] nextSceneNewGame no está configurado.");
#endif
            _isLoading = false;
            return;
        }

        LoadTargetScene(nextSceneNewGame, newGameButton);
    }

    void LoadTargetScene(string sceneName, Button boton)
    {
        // La portada puede tener animación de salida (Will se levanta del banco): se carga al acabar.
        float espera = portada ? portada.ReproducirSalida() : 0f;
        if (efectoAlComenzar)
        {
            if (_armRoutine != null)
            {
                StopCoroutine(_armRoutine);
                _armRoutine = null;
                RestoreArmSnapshot();
            }
            _introSeq?.Kill(true);
            SuspendMainMenuInteraction();
            _interactionSuspendedForLoad = true;
            _loadRoutine = StartCoroutine(LoadTargetSceneWithEffect(sceneName, boton, espera));
            return;
        }
        if (espera > 0f)
        {
            _loadRoutine = StartCoroutine(LoadTargetSceneAfter(sceneName, espera));
            return;
        }
        LoadTargetSceneNow(sceneName);
    }

    System.Collections.IEnumerator LoadTargetSceneWithEffect(string sceneName, Button boton, float espera)
    {
        yield return efectoAlComenzar.Reproducir(boton, espera);
        _loadRoutine = null;
        if (efectoAlComenzar && efectoAlComenzar.isActiveAndEnabled)
            LoadTargetSceneNow(sceneName);
    }

    System.Collections.IEnumerator LoadTargetSceneAfter(string sceneName, float seconds)
    {
        yield return new WaitForSecondsRealtime(seconds);
        LoadTargetSceneNow(sceneName);
    }

    void LoadTargetSceneNow(string sceneName)
    {
        bool useOverlay = !string.IsNullOrEmpty(loadingOverlayScene);

        if (useOverlay)
        {
            if (fadeOverride != null)
                SceneTransitionLoader.LoadWithOverlay(sceneName, loadingOverlayScene, fadeOverride, fadeDelay);
            else
                SceneTransitionLoader.LoadWithOverlay(sceneName, loadingOverlayScene);
        }
        else
        {
            if (fadeOverride != null)
                SceneTransitionLoader.Load(sceneName, fadeOverride, fadeDelay);
            else
                SceneTransitionLoader.Load(sceneName);
        }
    }

    System.Collections.IEnumerator RestoreSelectionNextFrame(GameObject previous)
    {
        UIButtonAudio.MuteAll = true;
        // Espera la selección de MenuNavigator al reactivar el panel antes de restaurar el foco.
        yield return new WaitForSeconds(0.1f);
        yield return null;

        // Si no tenemos selección previa, usar el primer botón activo visible
        if (previous == null)
        {
            var fallback = FindFirstActiveButton();
            if (fallback != null) previous = fallback.gameObject;
        }

        // Re-aplicar selección usando EventSystem
        if (previous != null)
        {
            var sel = previous.GetComponent<Selectable>();
            if (sel != null) sel.Select();
        }
        UIButtonAudio.MuteAll = false;
    }

    // ===== Debug (temporal — investigando "el menú desaparece tras Controles") =====
    void LogMenuState(string tag)
    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        var es = UnityEngine.EventSystems.EventSystem.current;
        Debug.Log($"[MainMenu-Debug] {tag} — buttonPanel.activeSelf={(buttonPanel ? buttonPanel.activeSelf.ToString() : "NULL")}, " +
                  $"buttonPanel.activeInHierarchy={(buttonPanel ? buttonPanel.activeInHierarchy.ToString() : "NULL")}, " +
                  $"rootGroup.alpha={(rootGroup ? rootGroup.alpha.ToString("F2") : "NULL")}, " +
                  $"rootGroup.interactable={(rootGroup ? rootGroup.interactable.ToString() : "NULL")}, " +
                  $"rootGroup.blocksRaycasts={(rootGroup ? rootGroup.blocksRaycasts.ToString() : "NULL")}, " +
                  $"rootGroup.GO.activeInHierarchy={(rootGroup ? rootGroup.gameObject.activeInHierarchy.ToString() : "NULL")}, " +
                  $"EventSystem.selected={(es != null && es.currentSelectedGameObject != null ? es.currentSelectedGameObject.name : "NULL")}, " +
                  $"MainMenuController.GO.activeInHierarchy={gameObject.activeInHierarchy}");
#endif
    }

    // ===== Utilidades =======================================================
    void WireButton(Button btn, UnityEngine.Events.UnityAction action, string label)
    {
        if (!btn)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[MainMenu] Botón {label} no asignado/encontrado.");
#endif
            return;
        }

        btn.onClick.RemoveListener(action);
        btn.onClick.AddListener(action);

        if (!btn.interactable)
        {
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[MainMenu] Botón {label} no está interactable.");
            #endif
        }

        if (!btn.gameObject.activeInHierarchy)
        {
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[MainMenu] Botón {label} está inactivo en jerarquía.");
            #endif
        }
    }

    Button TryFindNewGameButton()
    {
        // Busca en hijos un botón cuyo nombre sugiera "New Game"
        var all = GetComponentsInChildren<Button>(true);
        foreach (var b in all)
        {
            var n = b.gameObject.name.ToLowerInvariant();
            if (n.Contains("new") || n.Contains("nueva") || n.Contains("newgame") || n.Contains("nueva_partida"))
                return b;
        }
        return null;
    }

    Button TryFindSettingsButton()
    {
        var all = GetComponentsInChildren<Button>(true);
        foreach (var b in all)
        {
            var n = b.gameObject.name.ToLowerInvariant();
            if (n.Contains("setting") || n.Contains("ajuste") || n.Contains("config"))
                return b;
        }
        return null;
    }

    Button TryFindControlsButton()
    {
        var all = GetComponentsInChildren<Button>(true);
        foreach (var b in all)
        {
            var n = b.gameObject.name.ToLowerInvariant();
            if (n.Contains("control"))
                return b;
        }
        return null;
    }

    Button TryFindExitButton()
    {
        // Busca en hijos un botón cuyo nombre sugiera "Salir/Exit/Quit"
        var all = GetComponentsInChildren<Button>(true);
        foreach (var b in all)
        {
            var n = b.gameObject.name.ToLowerInvariant();
            if (n.Contains("salir") || n.Contains("exit") || n.Contains("quit"))
                return b;
        }
        return null;
    }

    Button FindFirstActiveButton()
    {
        var all = GetComponentsInChildren<Button>(true);
        foreach (var b in all)
        {
            if (b.gameObject.activeInHierarchy && b.interactable)
                return b;
        }
        return null;
    }

    // SelfTestButtons eliminado - solo útil para debug profundo
    // Si necesitas debuggear botones, reactiva temporalmente este método

    void CaptureArmSnapshot()
    {
        if (rootGroup != null)
        {
            _armSnapshotRaycasts = rootGroup.blocksRaycasts;
            rootGroup.blocksRaycasts = false;
        }

        if (continueButton)
        {
            _armSnapshotContinueInteractable = continueButton.interactable;
            continueButton.interactable = false;
        }

        // Solo manipular newGameButton si está visible (en modo test está oculto)
        if (newGameButton && newGameButton.gameObject.activeInHierarchy)
        {
            _armSnapshotNewInteractable = newGameButton.interactable;
            newGameButton.interactable = false;
        }

        _armSnapshotValid = true;
    }

    void RestoreArmSnapshot()
    {
        if (!_armSnapshotValid) return;

        if (rootGroup != null)
            rootGroup.blocksRaycasts = _armSnapshotRaycasts;

        if (continueButton)
            continueButton.interactable = _armSnapshotContinueInteractable;

        // Solo restaurar newGameButton si está visible
        if (newGameButton && newGameButton.gameObject.activeInHierarchy)
            newGameButton.interactable = _armSnapshotNewInteractable;

        _armSnapshotValid = false;
    }

    void SuspendMainMenuInteraction()
    {
        if (rootGroup != null)
        {
            _settingsSnapshotRaycasts = rootGroup.blocksRaycasts;
            _settingsSnapshotInteractable = rootGroup.interactable;
            rootGroup.blocksRaycasts = false;
            rootGroup.interactable = false;
        }
    }

    void RestoreMainMenuInteraction()
    {
        if (rootGroup != null)
        {
            rootGroup.blocksRaycasts = _settingsSnapshotRaycasts;
            rootGroup.interactable = _settingsSnapshotInteractable;
        }
    }

    System.Collections.IEnumerator ArmMenuAfterDelay(float delay)
    {
        CaptureArmSnapshot();

        try
        {
            float t = 0f;
            while (t < delay)
            {
                t += Time.unscaledDeltaTime;
                yield return null;
            }
        }
        finally
        {
            RestoreArmSnapshot();
            _inputArmed = true;
            _armRoutine = null;
        }
    }
}
