using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using DG.Tweening;

public enum PresentacionDeTexto { Bocadillo, Subtitulo, SubtituloGrande }

/// Texto cinematográfico paginado, como bocadillo o subtítulo. Vive en la UI de Start.
public class SpeechBubbleUI : MonoBehaviour
{
    PresentacionDeTexto _presentacion;
    CanvasGroup _grupoBocadillo, _grupoSubtitulo;
    RectTransform _rectBocadillo, _rectSubtitulo, _canvasSubtitulo;
    TextMeshProUGUI _textoBocadillo, _textoSubtitulo, _nombreSubtitulo;
    public static SpeechBubbleUI Instance { get; private set; }

#if UNITY_EDITOR
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    static void ResetStatics() { Instance = null; }
#endif

    [Header("Referencias UI")]
    [SerializeField] CanvasGroup _rootGroup;
    [SerializeField] RectTransform _bubbleRect;
    [SerializeField] TextMeshProUGUI _label;
    [SerializeField] RectTransform _parentCanvasRect;

    [Header("Sprites")]
    [Tooltip("Sprite del bocadillo antiguo (elipse blanca del atlas). Solo se usa si el arte " +
             "generado está desactivado.")]
    [SerializeField] Sprite _defaultSprite;
    [Tooltip("Sprite de énfasis del atlas (burbuja explosiva). Solo se usa si el arte generado " +
             "está desactivado.")]
    [SerializeField] Sprite _emphasisSprite;

    [Header("Arte del bocadillo (dibujado por código)")]
    [Tooltip("El bocadillo se dibuja por código: papel cálido con el borde dibujado a mano, " +
             "cola propia y sombra proyectada. Desactívalo para volver al sprite del prefab.")]
    [SerializeField] bool _usarArteGenerado = true;
    [Tooltip("Color del papel del bocadillo.")]
    [SerializeField] Color _colorPapel = new Color(0.965f, 0.914f, 0.82f, 1f);
    [Tooltip("Color del borde dibujado alrededor del papel.")]
    [SerializeField] Color _colorBorde = new Color(0.38f, 0.30f, 0.23f, 1f);
    [Tooltip("Grosor del borde, en píxeles de lienzo. A 0 el bocadillo queda sin contorno.")]
    [SerializeField, Min(0f)] float _grosorBorde = 3f;
    [Tooltip("Radio de las esquinas del papel, en píxeles de lienzo.")]
    [SerializeField, Min(2f)] float _radioEsquina = 26f;
    [Tooltip("Margen entre el texto y el borde del papel, en píxeles de lienzo.")]
    [SerializeField, Min(0f)] float _margenTexto = 14f;
    [Tooltip("Cola del bocadillo: ancho y alto, en píxeles de lienzo. A 0 de alto, no hay cola.")]
    [SerializeField] Vector2 _cola = new Vector2(52f, 26f);
    [Tooltip("Irregularidad del borde: a 0 el papel es un rectángulo perfecto; a 2-3 parece " +
             "dibujado a mano.")]
    [SerializeField, Min(0f)] float _desdibujo = 1.6f;
    [Tooltip("Color del texto dentro del papel.")]
    [SerializeField] Color _colorTexto = new Color(0.14f, 0.12f, 0.10f, 1f);
    [Tooltip("Sombra proyectada: color, alcance del difuminado, desplazamiento y opacidad.")]
    [SerializeField] Color _colorSombra = new Color(0.10f, 0.08f, 0.06f, 1f);
    [Tooltip("Hasta dónde llega la sombra alrededor del papel, en píxeles de lienzo.")]
    [SerializeField, Min(0f)] float _radioSombra = 9f;
    [SerializeField] Vector2 _sombraDesplazamiento = new Vector2(2f, -6f);
    [SerializeField, Range(0f, 0.6f)] float _sombraOpacidad = 0.3f;
    [Tooltip("Tamaño del texto, en proporción del alto del lienzo (0,036 = 39 px a 1080).")]
    [SerializeField, Range(0.015f, 0.06f)] float _tamanoTextoDelCanvas = 0.036f;
    [Tooltip("Ancho mínimo del papel, en múltiplos del tamaño de letra: el texto corto no baja de aquí.")]
    [SerializeField, Min(4f)] float _anchoMinimoEnLetras = 9f;
    [Tooltip("Ancho máximo del papel, en múltiplos del tamaño de letra, antes de partir el texto en líneas.")]
    [SerializeField, Min(8f)] float _anchoMaximoEnLetras = 20f;

    [Header("Animación")]
    [SerializeField] float _fadeInDuration  = 0.15f;
    [SerializeField] float _fadeOutDuration = 0.15f;
    [SerializeField] float _popInDuration   = 0.35f;
    [SerializeField] float _popOutDuration  = 0.18f;

    [Header("Tamaño")]
    [Tooltip("Ancho mínimo del bocadillo en píxeles de canvas. Aumenta si el texto se corta por los lados.")]
    [SerializeField] float _bubbleMinWidth = 420f;
    [Tooltip("Ancho máximo del bocadillo en píxeles de canvas antes de partir el texto en varias líneas. BUGFIX (Agosto 2026): antes el bocadillo solo tenía un ancho MÍNIMO y nunca crecía con el texto real, así que cualquier línea más larga que ese mínimo se salía por los lados en todas las secuencias (ver captura del bug). Ahora el ancho se calcula a partir del texto real en Show(), entre este máximo y _bubbleMinWidth. El ALTO no se toca aquí — lo calcula solo el ContentSizeFitter/VerticalLayoutGroup del hijo \"Bubble\" en el prefab (ver Show()).\nAJUSTE (Agosto 2026, 2ª pasada): min/max bajados de 560/900 a 420/620. Con los valores viejos, cualquier frase de longitud media cabía en una sola línea muy ancha y el bocadillo salía como un óvalo aplastado y alargado; y las frases cortas se estiraban igual hasta el mínimo de 560, con el mismo efecto. Con el ancho máximo más bajo, el texto envuelve antes en 2-3 líneas más cortas y el bocadillo crece en vertical en su lugar — se ve más redondo y las líneas quedan más parejas entre sí (ayuda también a que el bloque de texto centrado se perciba realmente centrado, en vez de una única línea larga pegada a los bordes).")]
    [SerializeField] float _bubbleMaxWidth = 620f;
    [Tooltip("Margen interno horizontal del texto (izquierda y derecha).")]
    [SerializeField] float _labelHorizontalMargin = 44f;

    [Header("Páginas (INC-435)")]
    [Tooltip("Máximo de líneas por bocadillo. Regla de Raúl (25 sep 2026): «los textos de los " +
             "bocadillos no pueden ser de más de tres líneas; si es así hay que paginar la frase en " +
             "TODO EL JUEGO». Una frase que ocupa más se parte en páginas que salen una detrás de otra " +
             "en el mismo bocadillo, cortando por el final de una frase siempre que se pueda.")]
    [SerializeField, Min(1)] int _maxLineas = 3;
    [Tooltip("Caracteres por segundo de lectura cómoda. Ninguna página dura menos de lo que se tarda " +
             "en leerla, aunque quien llama pida menos tiempo: en prologo/peras, líneas de 130 " +
             "caracteres salían 3 s y no daba tiempo a leerlas.")]
    [SerializeField, Min(1f)] float _caracteresPorSegundo = 15f;
    [Tooltip("Ninguna página dura menos que esto.")]
    [SerializeField, Min(0.5f)] float _lecturaMinima = 1.6f;

    [Tooltip("Caracteres hablados por segundo para estimar el habla sin voz.")]
    [SerializeField, Min(1f)] float _caracteresHabladosPorSegundo = 14f;

    [Header("Posición")]
    [SerializeField] Vector3 _worldOffset = new Vector3(0f, 2.2f, 0f);

    [Header("Fijo en pantalla (quien habla no está a la vista)")]
    [Tooltip("Dónde se queda el bocadillo cuando se muestra fijo en pantalla, en proporción del " +
             "canvas (0,0 abajo a la izquierda; 1,1 arriba a la derecha). En este modo el bocadillo " +
             "no tiene pico y lleva encima el nombre de quien habla: pegado al papel si es una frase de " +
             "alguien fuera de cuadro, o al final de una fila de circulitos si se pide a propósito " +
             "(una voz a distancia).")]
    [SerializeField] Vector2 _posicionFija = new Vector2(0f, 0.70f);
    [Tooltip("Separación del borde de la pantalla, en píxeles de canvas.")]
    [SerializeField] float _margenFijo = 40f;
    [SerializeField] Color _colorNombre = new Color(1f, 0.85f, 0.35f);
    [Tooltip("Color del contorno de los circulitos (y del bocadillo sin pico con el arte antiguo).")]
    [SerializeField] Color _colorContornoADistancia = new Color(0.08f, 0.08f, 0.1f, 1f);

    [Header("Voz fuera de escena (quien habla no está en el plano)")]
    [Tooltip("Diámetro del medallón con la cara de quien habla, en proporción del tamaño de letra del bocadillo.")]
    [SerializeField, Min(1f)] float _medallonPorLetra = 2.4f;
    [Tooltip("Cuánto sube y baja el bocadillo en su vaivén, en píxeles de canvas.")]
    [SerializeField, Min(0f)] float _vaivenVertical = 6f;
    [Tooltip("Cuánto se mece de lado a lado, en píxeles de canvas.")]
    [SerializeField, Min(0f)] float _vaivenLateral = 3f;
    [Tooltip("Cuánto se inclina al mecerse, en grados.")]
    [SerializeField, Min(0f)] float _vaivenGiro = 1.2f;
    [Tooltip("Ciclos por segundo del vaivén.")]
    [SerializeField, Min(0.01f)] float _vaivenFrecuencia = 0.45f;

    Image _bubbleImage;
    Camera _cam;
    Transform _target;
    float _factorDeTalla = 1f; // TallaDeNino del que habla: el bocadillo baja con la cabeza de un niño
    bool _isShowing;
    // Cada Show() abre un turno nuevo: quien lo abrió puede cerrar SOLO el suyo (Hide(turno)) y
    // saber si otro le ha quitado el bocadillo. Ver INC-613.
    int _turno;

    /// Turno del bocadillo en pantalla (o del último que se mostró).
    public int Turno => _turno;
    /// Hay un bocadillo en pantalla (aunque sea saliendo).
    public bool Mostrando => _isShowing;

    /// <summary>Posición del bocadillo cuando es fijo en pantalla (proporción 0..1 del canvas).</summary>
    public Vector2 PosicionFija
    {
        get => _posicionFija;
        set => _posicionFija = value;
    }
    Coroutine _autoHideRoutine;
    // Callback pendiente del Show() en curso — solo relevante mientras _autoHideRoutine != null.
    // Guardado aparte (además del parámetro local que ya recibe la propia corrutina AutoHide) para
    // que SkipCurrent() pueda invocarlo desde fuera sin depender de la corrutina.
    Action _pendingOnComplete;

    // Offset por llamada, para cuando el punto de anclaje ya está a la altura que toca (una marca
    // de posición colocada a mano, en vez de la cabeza de un personaje) y sumar el offset de
    // siempre lo dejaría demasiado alto. Null = usar '_worldOffset' de siempre, sin cambiar nada
    // del comportamiento existente. Ver SayBeat.overrideBubbleOffset (17 sep 2026).
    Vector3? _offsetOverride;

    // Oculto temporalmente porque hay un menú (pausa, equipo, tienda...) abierto encima.
    bool _hiddenByMenu;

    // Fijo en pantalla en vez de seguir al personaje, con su nombre encima (ver Show()).
    bool _fijoEnPantalla;
    // El nombre del modo fijo cuelga de una fila de circulitos (voz a distancia) en vez de ir
    // pegado al papel.
    bool _conCirculitos;
    TextMeshProUGUI _nombre;

    // Voz de alguien que no está en el plano (tras una ventana, al otro lado de una puerta): el
    // bocadillo va anclado al sitio de donde sale la voz, sin cola, con la cara de quien habla en
    // un medallón y un vaivén suave. Ver Show(fueraDeEscena).
    bool _fueraDeEscena;
    float _faseDelVaiven;
    string _ultimoHablanteFuera;
    RectTransform _medallon;
    Image _caraDelMedallon;

    // Estilo «a distancia» del modo fijo: cuerpo sin pico y circulitos hasta el nombre.
    static readonly (Vector2 centro, float diametro)[] Circulitos =
    {
        (new Vector2(46f, 20f), 24f),
        (new Vector2(30f, 46f), 16f),
        (new Vector2(21f, 66f), 10f),
    };
    const float AlturaNombre = 78f;
    Sprite _spriteSinPico;
    Sprite _spriteCirculito;
    readonly List<Image> _circulitos = new();
    VerticalLayoutGroup _layout;
    RectOffset _paddingConPico;

    // Arte generado por código (papel con borde dibujado a mano).
    // El bocadillo se pinta como un campo de distancia y se cachea por tamaño: cada
    // medida distinta que aparezca en el juego se dibuja una sola vez.
    readonly Dictionary<long, Sprite> _spritesGenerados = new();
    readonly List<Texture2D> _texturasGeneradas = new();
    float[] _ruido;                 // tabla de ruido para el borde irregular
    const int LadoRuido = 32;
    float _tamanoTextoOriginal;     // tamaño de letra del prefab, para el arte antiguo
    const float SolapeCola = 8f;    // la cola entra este tramo en el papel: sin costura
    const int TopeDeSpritesGenerados = 64;   // texturas de papel vivas a la vez
    const float PasoDeAncho = 8f;    // el ancho se redondea: menos medidas distintas

    // Caché de componentes de animación: evita GetComponentInChildren repetido
    readonly Dictionary<Transform, Animator> _animatorCache = new();
    readonly Dictionary<Transform, NPCSimpleAnimator> _npcAnimCache = new();
    readonly Dictionary<Transform, PlayerDialogueAnimator> _playerAnimCache = new();

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    void Awake()
    {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(transform.root.gameObject);

        _cam = Camera.main;
        _bubbleImage = _bubbleRect.GetComponent<Image>();
        _layout = _bubbleRect.GetComponent<VerticalLayoutGroup>();
        if (_layout != null)
            _paddingConPico = new RectOffset(_layout.padding.left, _layout.padding.right,
                                             _layout.padding.top, _layout.padding.bottom);

        // Migración: si la posición fija guardada en la escena o prefab estaba por debajo de 0.6f
        // (el antiguo 0.42f quedaba en pleno centro tapando el gameplay y a los enemigos),
        // se eleva al 0.70f para situarse limpiamente en el tercio superior.
        if (_posicionFija.y < 0.6f)
            _posicionFija.y = 0.70f;

        if (_parentCanvasRect == null)
            _parentCanvasRect = GetComponentInParent<Canvas>()?.GetComponent<RectTransform>();

        _rootGroup.alpha = 0f;
        _rootGroup.blocksRaycasts = false;
        _bubbleRect.localScale = Vector3.zero;
        _grupoBocadillo = _rootGroup;
        _rectBocadillo = _bubbleRect;
        _textoBocadillo = _label;

        PrepararRuido();
        if (_label != null) _tamanoTextoOriginal = _label.fontSize;
    }

    /// Tabla de ruido con la que se irregulariza el borde del papel. Se genera una vez
    /// con semilla fija: el bocadillo se ve igual en todas las partidas.
    void PrepararRuido()
    {
        _ruido = new float[LadoRuido * LadoRuido];
        var aleatorio = new System.Random(20261022);
        for (int i = 0; i < _ruido.Length; i++)
            _ruido[i] = (float)(aleatorio.NextDouble() * 2.0 - 1.0);
    }

    void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
        // Mismo sistema que ya usan BossHealthBar/MinimapController: ocultarse mientras
        // hay un menú abierto (pausa incluida) y restaurarse al cerrar el último.
        MenuManager.MenuOpened += OnMenuOpened;
        MenuManager.MenuClosed += OnMenuClosed;
        Canvas.willRenderCanvases += ColocarBocadillo;
    }

    void OnDisable()
    {
        Hide();
        _rootGroup.DOKill();
        _bubbleRect.DOKill();
        _rootGroup.alpha = 0f;
        _pendingOnComplete = null;
        SenalesDeHabla.Para(_target);
        SceneManager.sceneLoaded -= OnSceneLoaded;
        MenuManager.MenuOpened -= OnMenuOpened;
        MenuManager.MenuClosed -= OnMenuClosed;
        Canvas.willRenderCanvases -= ColocarBocadillo;
    }

    void OnSceneLoaded(Scene s, LoadSceneMode m) => _cam = Camera.main;

    void OnDestroy()
    {
        if (Instance != this) return;
        Instance = null;
        SceneManager.sceneLoaded -= OnSceneLoaded;
        _rootGroup?.DOKill();
        _bubbleRect?.DOKill();
        _grupoBocadillo?.DOKill();
        _rectBocadillo?.DOKill();
        _grupoSubtitulo?.DOKill();
        _rectSubtitulo?.DOKill();
        if (_canvasSubtitulo != null) Destroy(_canvasSubtitulo.gameObject);
        DestruirSprite(_spriteSinPico);
        DestruirSprite(_spriteCirculito);
        foreach (var s in _spritesGenerados.Values) if (s != null) Destroy(s);
        foreach (var t in _texturasGeneradas) if (t != null) Destroy(t);
        _spritesGenerados.Clear();
        _texturasGeneradas.Clear();
    }

    static void DestruirSprite(Sprite s)
    {
        if (s == null) return;
        if (s.texture != null) Destroy(s.texture);
        Destroy(s);
    }

    /// Coloca el bocadillo justo antes de dibujar el canvas, cuando todas las cámaras ya se han
    /// movido en su LateUpdate. No va en un LateUpdate propio: el orden entre LateUpdates no está
    /// garantizado y, si se colocase antes que la cámara, iría un fotograma por detrás y temblaría
    /// al andar. Ver INC-541.
    void ColocarBocadillo()
    {
        if (_presentacion != PresentacionDeTexto.Bocadillo)
        {
            if (_isShowing) ColocarSubtitulo();
            return;
        }
        if (!_isShowing || _parentCanvasRect == null) return;

        if (_fijoEnPantalla)
        {
            Rect canvas = _parentCanvasRect.rect;
            var fija = new Vector2(
                canvas.xMin + canvas.width * _posicionFija.x + _bubbleRect.rect.width * 0.5f + _margenFijo,
                canvas.yMin + canvas.height * _posicionFija.y);
            _bubbleRect.anchoredPosition = ClampToCanvas(fija + Vaiven());
            return;
        }

        if (_target == null || _cam == null) return;

        Vector3 offset = _offsetOverride ?? _worldOffset * _factorDeTalla;
        Vector3 screenPos = _cam.WorldToScreenPoint(_target.position + offset);
        if (screenPos.z < 0f) return;

        if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
                _parentCanvasRect, screenPos, null, out Vector2 local))
            _bubbleRect.anchoredPosition = ClampToCanvas(local + Vaiven());
    }

    /// Desplazamiento del vaivén de la voz fuera de escena (y su inclinación); cero en los demás
    /// bocadillos. Lento y pequeño: se nota que flota, no que tiembla.
    Vector2 Vaiven()
    {
        if (!_fueraDeEscena) return Vector2.zero;
        float t = Time.unscaledTime * _vaivenFrecuencia * Mathf.PI * 2f + _faseDelVaiven;
        _bubbleRect.localRotation = Quaternion.Euler(0f, 0f, Mathf.Sin(t * 0.7f + 1.3f) * _vaivenGiro);
        return new Vector2(Mathf.Sin(t * 0.5f) * _vaivenLateral, Mathf.Sin(t) * _vaivenVertical);
    }

    /// FIX (17 sep 2026, Raúl: "los bocadillos se cortan por arriba" -- prólogo, planos
    /// cerrados). Antes esta posición se aplicaba sin límites: con poco
    /// headroom (un CloseUp, por ejemplo) la cabeza del personaje queda cerca del borde superior
    /// de la pantalla, y el bocadillo -- que crece HACIA ARRIBA desde el punto de anclaje, con el
    /// pico apuntando hacia abajo a la cabeza -- se salía por encima del canvas. Nunca se había
    /// visto porque las secuencias antiguas (Discusión Ventana, Despertar de la Estrella) siempre
    /// enmarcan con más aire por encima; el prólogo es el primer sitio que pide planos cerrados de
    /// verdad con este sistema. Se calcula el margen a partir del tamaño real del bocadillo (que ya
    /// cambia con el texto, ver Show()) y de su propio pivote, así que funciona igual sin importar
    /// si el pivote está abajo (como parece, por el pico) o en cualquier otro punto.
    const float MargenSobreLaFranja = 12f;

    Vector2 ClampToCanvas(Vector2 local)
    {
        if (_parentCanvasRect == null || _bubbleRect == null) return local;

        Rect canvasRect = _parentCanvasRect.rect;
        float halfWidth    = _bubbleRect.rect.width * 0.5f;
        float bottomMargin = _bubbleRect.rect.height * _bubbleRect.pivot.y;
        float extraArriba  = !(_fijoEnPantalla || _fueraDeEscena) || _nombre == null || !_nombre.gameObject.activeSelf ? 0f
                           : _conCirculitos ? 60f : _nombre.fontSize * 1.4f;
        float topMargin    = _bubbleRect.rect.height * (1f - _bubbleRect.pivot.y) + extraArriba;

        float sobraDelMedallon = _fueraDeEscena && _medallon != null && _medallon.gameObject.activeSelf
            ? _medallon.sizeDelta.x * 0.5f : 0f;
        float minX = canvasRect.xMin + halfWidth + sobraDelMedallon;
        float maxX = canvasRect.xMax - halfWidth;
        // Con bandas de cine, el bocadillo se queda dentro de la imagen, entre las dos franjas.
        float franja = 0f;
        if (HayBandasDeCine)
        {
            var bandas = BandasDeCineUI.Instance;
            franja = Mathf.Max(bandas.AlturaVisible, bandas.AlturaObjetivo) * canvasRect.height + MargenSobreLaFranja;
        }
        float minY = canvasRect.yMin + bottomMargin + sobraDelMedallon + franja;
        float maxY = canvasRect.yMax - topMargin - franja;

        // Si el bocadillo es más grande que el propio canvas (no debería pasar nunca, pero por si
        // acaso) min > max invertiría el clamp -- se deja sin tocar ese eje en vez de forzarlo.
        if (minX <= maxX) local.x = Mathf.Clamp(local.x, minX, maxX);
        if (minY <= maxY) local.y = Mathf.Clamp(local.y, minY, maxY);
        return local;
    }

    // ── API pública ───────────────────────────────────────────────────────────

    [ContextMenu("TEST Show (Player)")]
    void TestShow()
    {
        var player = GameObject.FindWithTag("Player");
        Show(player != null ? player.transform : transform, "¡Otra vez ese sueño...!", 4f);
    }

    [ContextMenu("TEST Hide")]
    void TestHide() => Hide();

    /// <summary>
    /// Muestra una línea con la presentación elegida y mantiene el habla de <paramref name="target"/>.
    /// </summary>
    /// <param name="animTrigger">Trigger del Animator del personaje a disparar mientras habla.</param>
    /// <param name="emphasis">Si true, usa el sprite de énfasis (ej: burbuja explosiva).</param>
    /// <param name="speakerName">
    /// Nombre que aparece encima del subtítulo o del bocadillo fijo. El bocadillo anclado
    /// identifica al personaje con su pico; el subtítulo grande no muestra nombre.
    /// </param>
    /// <param name="worldOffset">
    /// Sustituye, solo para esta llamada, el offset vertical de siempre (_worldOffset, 2,2 m).
    /// Null (por defecto) = comportamiento de siempre. Pensado para SayBeat.markName (17 sep
    /// 2026): una marca de posición ya colocada a la altura que toca no debería tener que
    /// enterrarse 2,2 m bajo el suelo solo para compensar el offset pensado para cabezas de
    /// personaje.
    /// </param>
    /// <param name="fijoEnPantalla">
    /// En vez de seguir al personaje, el bocadillo se queda quieto en un lado de la pantalla
    /// (_posicionFija), sin pico y con una fila de circulitos que sube hasta el nombre de quien
    /// habla (speakerName): se lee como una voz que llega de alguien que no está a la vista. Para
    /// comentarios durante el juego (Eldran guiando un combate, INC-480 e INC-534). En cinemáticas
    /// se deja en false: ahí el pico señala al que habla.
    /// </param>
    /// Un Subtitulo sin bandas de cine se enseña como bocadillo de habla (ver el principio del
    /// método), nunca con los circulitos.
    /// Devuelve el turno de este bocadillo (ver Hide(int)).
    public int Show(Transform target, string text, float duration = 0f,
                     Action onComplete = null, string animTrigger = null, bool emphasis = false,
                     string speakerName = null, Vector3? worldOffset = null,
                     bool fijoEnPantalla = false,
                     PresentacionDeTexto presentacion = PresentacionDeTexto.Bocadillo,
                     Color colorDelNombre = default,
                     bool fueraDeEscena = false, Sprite retrato = null)
    {
        // Una frase se ve de dos maneras: en bocadillo o en cinemática. El subtítulo vive en la
        // banda de cine de abajo; sin bandas (una frase del juego de alguien lejos o fuera de
        // cuadro, o un guion horneado sin ellas) sale en un bocadillo de habla, el mismo papel que
        // los de encima de la cabeza: con su cola sobre quien habla si está en el encuadre y, si
        // no, quieto en un lado de la pantalla con el nombre pegado encima. Los circulitos hasta
        // el nombre son solo para quien pide fijoEnPantalla a propósito.
        // Una voz fuera de escena es la excepción: va en bocadillo aunque la cinemática esté en
        // modo cine, porque el subtítulo no diría de dónde sale la voz. Se ancla a ese sitio (si no
        // se ve en el plano, se queda fija en pantalla) y lleva la cara de quien habla.
        bool conCirculitos = fijoEnPantalla;
        if (fueraDeEscena)
        {
            presentacion = PresentacionDeTexto.Bocadillo;
            fijoEnPantalla = target == null || !SeVeEnPantalla(target, worldOffset);
            conCirculitos = false;
        }
        else if (presentacion == PresentacionDeTexto.Subtitulo && !HayBandasDeCine)
        {
            presentacion = PresentacionDeTexto.Bocadillo;
            fijoEnPantalla = !SeVeEnPantalla(target, worldOffset);
            conCirculitos = false;
        }
        CambiarPresentacion(presentacion, speakerName, colorDelNombre);
        if (_autoHideRoutine != null) { StopCoroutine(_autoHideRoutine); _autoHideRoutine = null; }
        _turno++;

        SenalesDeHabla.Para(_target);
        _target = target;
        _factorDeTalla = TallaDeNino.FactorDe(target);
        _offsetOverride = worldOffset;
        _isShowing = true;
        _fijoEnPantalla = fijoEnPantalla;
        _conCirculitos = fijoEnPantalla && conCirculitos;
        _fueraDeEscena = fueraDeEscena;
        if (fueraDeEscena)
        {
            // La fase cambia con quien habla: las páginas de una misma frase siguen el mismo vaivén.
            string hablante = retrato != null ? retrato.name : speakerName ?? string.Empty;
            if (hablante != _ultimoHablanteFuera) _faseDelVaiven = UnityEngine.Random.value * Mathf.PI * 2f;
            _ultimoHablanteFuera = hablante;
        }
        else
        {
            _ultimoHablanteFuera = null;
            _bubbleRect.localRotation = Quaternion.identity;
        }
        if (presentacion == PresentacionDeTexto.Bocadillo)
        {
            // La voz fuera de escena lleva siempre el nombre: no hay cola que diga quién habla.
            PonerNombre(fijoEnPantalla || fueraDeEscena ? speakerName : null, colorDelNombre);
            PonerEstiloFijo(fijoEnPantalla);
        }
        PonerMedallon(fueraDeEscena ? retrato : null);
        bool conCola = !fijoEnPantalla && !fueraDeEscena;
        // Frases de más de _maxLineas líneas: páginas (INC-435). La medición aplica el estilo
        // del papel por su cuenta; después se deja con cola o sin ella según el modo.
        List<string> paginas = Paginar(text, presentacion);
        if (paginas.Count == 0) paginas.Add(text ?? string.Empty);
        string primera = paginas[0];
        if (presentacion == PresentacionDeTexto.Bocadillo) AplicarEstilo(conCola);
        // Los mismos iconos que los diálogos: «presiona <sprite name="interactable_x">» sin esto
        // salía como «?» en el bocadillo (INC-468).
        Core.InputGlyphs.InputGlyphService.UsarIconos(_label);
        _label.text = primera;

        GameplayEventLog.Log("Dialogo", !string.IsNullOrEmpty(speakerName) ? speakerName : target != null ? target.name : null);

        // Centrado forzado siempre (horizontal Y vertical): no depender solo del valor por
        // defecto del prefab, que podría cambiar sin querer en una variante o en una edición
        // futura del prefab. El bocadillo de cómic siempre debe leerse centrado.
        _label.alignment = TextAlignmentOptions.Center;

        // Margen horizontal para que el texto no roque los bordes del bocadillo
        _label.margin = presentacion == PresentacionDeTexto.Bocadillo
            ? new Vector4(MargenHorizontal, _label.margin.y, MargenHorizontal, _label.margin.w)
            : Vector4.zero;

        // BUGFIX (Agosto 2026): el bocadillo solo tenía un ancho MÍNIMO fijo (_bubbleMinWidth) y
        // nunca se adaptaba al texto real, así que cualquier línea más larga que ese mínimo se
        // salía por los lados — pasaba en todas las secuencias, no era un caso puntual. Ahora se
        // mide el ancho que ocuparía el texto en una sola línea (GetPreferredValues) y el
        // bocadillo crece hasta el máximo para acomodarlo antes de partir el texto en
        // varias líneas (word wrap).
        //
        // OJO — el ALTO no se toca aquí a mano. El GameObject "Bubble" (padre de _label, ver
        // prefab SpeechBubbleUI/Bubble) tiene un VerticalLayoutGroup + ContentSizeFitter con
        // m_VerticalFit=PreferredSize: el alto SIEMPRE lo calcula ese sistema a partir del
        // preferredHeight del texto ya envuelto. El padding del layout lo pone AplicarEstilo()
        // según el arte activo (con el papel dibujado por código, el hueco es el de la sombra
        // proyectada más el borde más el margen del texto, y abajo el de la cola).
        if (_bubbleRect != null && _label != null)
        {
            _label.textWrappingMode = TextWrappingModes.Normal;

            AjustarAncho(primera);
        }

        if (_bubbleImage != null && presentacion == PresentacionDeTexto.Bocadillo)
        {
            if (_usarArteGenerado)
            {
                // El papel se dibuja a la medida exacta del bocadillo: sin deformarlo.
                AplicarSpriteGenerado(conCola);
            }
            else
            {
                Sprite sprite = !conCola ? SpriteSinPico()
                              : emphasis && _emphasisSprite != null ? _emphasisSprite : _defaultSprite;
                if (sprite != null) _bubbleImage.sprite = sprite;
            }
        }
        // Animación del personaje: preferir el wrapper de alto nivel para respetar el state machine
        if (!string.IsNullOrEmpty(animTrigger) && target != null)
        {
            var npcAnim = GetCachedNPCAnimator(target);
            if (npcAnim != null)
            {
                npcAnim.PlaySocialGesture(animTrigger);
            }
            else
            {
                var playerAnim = GetCachedPlayerAnimator(target);
                if (playerAnim != null)
                    playerAnim.PlayGesture(animTrigger);
                else
                {
                    var anim = GetCachedAnimator(target);
                    if (anim != null) anim.Play(animTrigger);
                }
            }
        }

        // Pop-in: escala desde 0 con rebote + fade
        _rootGroup.DOKill();
        _bubbleRect.DOKill();

        _rootGroup.alpha = 0f;
        _bubbleRect.localScale = presentacion == PresentacionDeTexto.Bocadillo ? Vector3.zero
            : Vector3.one * (presentacion == PresentacionDeTexto.SubtituloGrande ? 1.15f : 1f);

        _rootGroup.DOFade(1f, presentacion == PresentacionDeTexto.Bocadillo ? _fadeInDuration : 0.12f).SetUpdate(true);
        _bubbleRect.DOScale(Vector3.one, presentacion == PresentacionDeTexto.Bocadillo ? _popInDuration : 0.15f)
                   .SetEase(presentacion == PresentacionDeTexto.Bocadillo ? Ease.OutBack : Ease.OutQuad)
                   .SetUpdate(true);

        _pendingOnComplete = onComplete;
        if (paginas.Count > 1)
            _autoHideRoutine = StartCoroutine(Co_Paginas(paginas, duration, onComplete));
        else
        {
            float tiempo = duration > 0f ? Mathf.Max(duration, TiempoDeLectura(primera)) : 0f;
            EmpezarHablaDePagina(primera, tiempo);
            if (duration > 0f) _autoHideRoutine = StartCoroutine(AutoHide(tiempo, onComplete));
        }
        return _turno;
    }

    /// Cuánto tiene que estar en pantalla una página para poder leerla (INC-435).
    public float TiempoDeLectura(string pagina)
        => Mathf.Max(_lecturaMinima, 0.6f + (pagina?.Length ?? 0) / Mathf.Max(1f, _caracteresPorSegundo));

    /// Parte el texto con la fuente y ancho reales de su presentación: como máximo _maxLineas
    /// en bocadillo o dos en subtítulo. Corta por frases y, si no caben, por palabras.
    /// Show y SayBeat comparten esta medición para temporizar cada página.
    /// Si el texto contiene saltos de línea explícitos (\n), se respeta como una unidad:
    /// no se pagina, se muestra completo en un solo bocadillo (el alto crece con el texto).
    public List<string> Paginar(string text, PresentacionDeTexto presentacion = PresentacionDeTexto.Bocadillo)
    {
        var paginas = new List<string>();
        if (string.IsNullOrWhiteSpace(text) || _label == null || _bubbleRect == null)
        {
            if (!string.IsNullOrWhiteSpace(text)) paginas.Add(text.Trim());
            return paginas;
        }
        text = text.Trim();

        // Si el texto trae saltos de línea explícitos, no se pagina: va entero en un bocadillo.
        // Así se respetan los diálogos escritos con \n y no se cortan con voces.
        if (text.Contains("\n"))
        {
            paginas.Add(text);
            return paginas;
        }

        TextMeshProUGUI medida = _textoBocadillo;
        int lineas = _maxLineas;
        float ancho;
        float anchoGuardado = _rectBocadillo.sizeDelta.x;
        if (presentacion != PresentacionDeTexto.Bocadillo)
        {
            CrearSubtitulo();
            medida = _textoSubtitulo;
            medida.fontSize = TamanoDeSubtitulo(presentacion);
            ancho = AnchoCanvasSubtitulo * 0.75f;
            lineas = 2;
        }
        else
        {
            // Se mide con el mismo estilo con el que se va a pintar. Si no, la primera frase
            // de la sesión se mide con la letra y el hueco que trae el prefab y sale con otro
            // tamaño que las siguientes.
            AplicarEstilo(true);
            medida.alignment = TextAlignmentOptions.Center;
            medida.textWrappingMode = TextWrappingModes.Normal;
            medida.margin = new Vector4(MargenHorizontal, medida.margin.y, MargenHorizontal, medida.margin.w);
            float preferido = AnchoEnUnaLinea(medida, text);
            Vector2 tamano = _rectBocadillo.sizeDelta;
            tamano.x = AnchoDelBocadillo(preferido);
            _rectBocadillo.sizeDelta = tamano;
            LayoutRebuilder.ForceRebuildLayoutImmediate(_rectBocadillo);
            ancho = medida.rectTransform.rect.width - medida.margin.x - medida.margin.z;
        }
        if (ancho < 50f) ancho = AnchoMaximo - MargenTotalHorizontal;
        float altoMaximo = medida.GetPreferredValues(RenglonesDePrueba(lineas), ancho, 0f).y + 0.5f;
        bool Cabe(string s) => medida.GetPreferredValues(s, ancho, 0f).y <= altoMaximo;

        if (Cabe(text))
        {
            paginas.Add(text);
        }
        else
        {
            string actual = "";
            foreach (string frase in Frases(text))
            {
                string junto = actual.Length == 0 ? frase : actual + " " + frase;
                if (Cabe(junto)) { actual = junto; continue; }
                if (actual.Length > 0) { paginas.Add(actual); actual = ""; }
                if (Cabe(frase)) { actual = frase; continue; }

                // Una frase que sola ya pasa de las líneas: por palabras.
                foreach (string palabra in frase.Split(' '))
                {
                    if (palabra.Length == 0) continue;
                    string prueba = actual.Length == 0 ? palabra : actual + " " + palabra;
                    if (actual.Length > 0 && !Cabe(prueba)) { paginas.Add(actual); actual = palabra; }
                    else actual = prueba;
                }
            }
            if (actual.Length > 0) paginas.Add(actual);
        }

        if (presentacion == PresentacionDeTexto.Bocadillo)
        {
            Vector2 tamano = _rectBocadillo.sizeDelta;
            tamano.x = anchoGuardado;
            _rectBocadillo.sizeDelta = tamano;
        }
        return paginas;
    }

    /// Ancho que ocupa un texto en una sola línea. TMP mide mal con ancho 0: envuelve el texto
    /// a cero píxeles y devuelve el ancho de una sola letra, así que el papel se quedaba siempre
    /// en su mínimo y las frases se partían en trozos de dos palabras. Se mide sin ajuste de
    /// línea y se deja la etiqueta como estaba.
    static float AnchoEnUnaLinea(TextMeshProUGUI etiqueta, string texto)
    {
        if (etiqueta == null || string.IsNullOrEmpty(texto)) return 0f;
        TextWrappingModes modo = etiqueta.textWrappingMode;
        etiqueta.textWrappingMode = TextWrappingModes.NoWrap;
        float ancho = etiqueta.GetPreferredValues(texto, 0f, 0f).x;
        etiqueta.textWrappingMode = modo;
        return ancho;
    }

    static string RenglonesDePrueba(int n)
    {
        var sb = new System.Text.StringBuilder("Ágj");
        for (int i = 1; i < n; i++) sb.Append("\nÁgj");
        return sb.ToString();
    }

    /// Frases de un texto, con su puntuación final pegada («¿Qué?», «Vale...», «¡Ya!»).
    static List<string> Frases(string text)
    {
        var frases = new List<string>();
        var sb = new System.Text.StringBuilder();
        for (int i = 0; i < text.Length; i++)
        {
            char c = text[i];
            sb.Append(c);
            bool fin = c == '.' || c == '!' || c == '?' || c == '…' || c == '\n';
            bool siguienteEsEspacio = i + 1 >= text.Length || char.IsWhiteSpace(text[i + 1]);
            if (fin && siguienteEsEspacio)
            {
                string f = sb.ToString().Trim();
                if (f.Length > 0) frases.Add(f);
                sb.Clear();
            }
        }
        string resto = sb.ToString().Trim();
        if (resto.Length > 0) frases.Add(resto);
        return frases;
    }

    /// Distancia desde el borde superior del rectángulo hasta el borde superior del papel:
    /// con el arte generado es el hueco de la sombra más el borde; con el sprite antiguo,
    /// el padding del prefab.
    float DesplazamientoDelPapel => _usarArteGenerado
        ? MargenDeSombra + _grosorBorde
        : (_paddingConPico != null ? _paddingConPico.top : 0f);

    /// Quien habla está dentro del encuadre: su bocadillo puede señalarle con la cola.
    bool SeVeEnPantalla(Transform target, Vector3? worldOffset)
    {
        if (target == null) return false;
        if (_cam == null) _cam = Camera.main;
        if (_cam == null) return false;
        Vector3 cabeza = target.position + (worldOffset ?? _worldOffset * TallaDeNino.FactorDe(target));
        Vector3 v = _cam.WorldToViewportPoint(cabeza);
        // Algo de margen por arriba: en un plano cerrado la cabeza roza el borde y el bocadillo
        // se ajusta dentro del lienzo (ClampToCanvas).
        return v.z > 0f && v.x > 0f && v.x < 1f && v.y > 0f && v.y < 1.15f;
    }

    /// Nombre de quien habla encima del bocadillo. Solo en el modo fijo en pantalla: siguiendo al
    /// personaje, el pico ya dice quién es. No cuenta como línea del bocadillo (va fuera del layout).
    /// Con circulitos va al final de la fila; sin ellos, pegado al borde de arriba del papel. Su
    /// tamaño sigue al del texto del bocadillo.
    void PonerNombre(string nombre, Color color)
    {
        if (string.IsNullOrEmpty(nombre))
        {
            if (_nombre != null) _nombre.gameObject.SetActive(false);
            return;
        }

        if (_nombre == null)
        {
            var go = new GameObject("Nombre", typeof(RectTransform));
            go.transform.SetParent(_bubbleRect, false);
            go.AddComponent<LayoutElement>().ignoreLayout = true;
            var rt = (RectTransform)go.transform;
            rt.anchorMin = rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 0f);

            _nombre = go.AddComponent<TextMeshProUGUI>();
            _nombre.font = _textoBocadillo.font;
            _nombre.fontStyle = FontStyles.Bold;
            _nombre.alignment = TextAlignmentOptions.BottomLeft;
            _nombre.textWrappingMode = TextWrappingModes.NoWrap;
            _nombre.raycastTarget = false;
            var sombra = go.AddComponent<Shadow>();
            sombra.effectColor = new Color(0f, 0f, 0f, 0.8f);
            sombra.effectDistance = new Vector2(2f, -2f);
        }

        float tamano = (_usarArteGenerado ? TamanoDeTextoDelBocadillo : _tamanoTextoOriginal) * 0.8f;
        _nombre.fontSize = tamano;
        _nombre.rectTransform.sizeDelta = new Vector2(600f, tamano * 1.4f);
        _nombre.rectTransform.anchoredPosition = _conCirculitos
            ? new Vector2(4f, AlturaNombre - DesplazamientoDelPapel)
            : new Vector2(DesplazamientoDelPapel + _radioEsquina * 0.5f, 4f - DesplazamientoDelPapel);
        _nombre.color = color.a > 0f ? color : _colorNombre;
        _nombre.text = nombre;
        _nombre.gameObject.SetActive(true);
    }

    /// Medallón con la cara de quien habla, en la esquina de abajo a la izquierda del papel, donde
    /// iría la cola: la voz fuera de escena no tiene a quién señalar. Sin retrato no sale (basta
    /// el nombre).
    void PonerMedallon(Sprite retrato)
    {
        if (retrato == null)
        {
            if (_medallon != null && _medallon.gameObject.activeSelf) _medallon.gameObject.SetActive(false);
            return;
        }
        if (_medallon == null) CrearMedallon();

        float letra = _usarArteGenerado ? TamanoDeTextoDelBocadillo : _tamanoTextoOriginal;
        float diametro = Mathf.Clamp(letra * _medallonPorLetra, 56f, 120f);
        _medallon.sizeDelta = new Vector2(diametro, diametro);
        _medallon.anchoredPosition = new Vector2(DesplazamientoDelPapel + diametro * 0.12f,
                                                 DesplazamientoDelPapel + diametro * 0.08f);
        _medallon.SetAsLastSibling();
        _caraDelMedallon.sprite = retrato;
        if (!_medallon.gameObject.activeSelf) _medallon.gameObject.SetActive(true);
    }

    void CrearMedallon()
    {
        var go = new GameObject("Medallon", typeof(RectTransform));
        go.transform.SetParent(_bubbleRect, false);
        go.AddComponent<LayoutElement>().ignoreLayout = true;
        _medallon = (RectTransform)go.transform;
        _medallon.anchorMin = _medallon.anchorMax = Vector2.zero;
        _medallon.pivot = new Vector2(0.5f, 0.5f);
        var fondo = go.AddComponent<Image>();
        fondo.sprite = SpriteCirculito();
        fondo.raycastTarget = false;
        go.AddComponent<Mask>().showMaskGraphic = true;

        var cara = new GameObject("Cara", typeof(RectTransform));
        cara.transform.SetParent(_medallon, false);
        var rtCara = (RectTransform)cara.transform;
        rtCara.anchorMin = new Vector2(0.08f, 0.08f);
        rtCara.anchorMax = new Vector2(0.92f, 0.92f);
        rtCara.offsetMin = rtCara.offsetMax = Vector2.zero;
        _caraDelMedallon = cara.AddComponent<Image>();
        _caraDelMedallon.preserveAspect = true;
        _caraDelMedallon.raycastTarget = false;
    }

    /// Cuerpo sin pico (el relleno de abajo reservado al pico se iguala al de arriba) y, si se han
    /// pedido (_conCirculitos), los circulitos que llevan al nombre. Con fijo = false deja el
    /// bocadillo con pico de siempre. El padding solo se toca con el arte antiguo: con el papel
    /// dibujado por código el hueco lo calcula AplicarEstilo().
    void PonerEstiloFijo(bool fijo)
    {
        if (!_usarArteGenerado && _layout != null && _paddingConPico != null)
        {
            int arriba = _paddingConPico.top;
            _layout.padding = fijo
                ? new RectOffset(_paddingConPico.left, _paddingConPico.right, arriba + 6, arriba + 6)
                : new RectOffset(_paddingConPico.left, _paddingConPico.right, arriba, _paddingConPico.bottom);
        }

        bool circulitos = fijo && _conCirculitos;
        if (circulitos && _circulitos.Count == 0)
        {
            float subida = DesplazamientoDelPapel;
            foreach (var (centro, diametro) in Circulitos)
            {
                var go = new GameObject("Circulito", typeof(RectTransform));
                go.transform.SetParent(_bubbleRect, false);
                go.AddComponent<LayoutElement>().ignoreLayout = true;
                var rt = (RectTransform)go.transform;
                rt.anchorMin = rt.anchorMax = new Vector2(0f, 1f);
                rt.pivot = new Vector2(0.5f, 0.5f);
                rt.anchoredPosition = new Vector2(centro.x, centro.y - subida);
                rt.sizeDelta = new Vector2(diametro, diametro);
                var img = go.AddComponent<Image>();
                img.sprite = SpriteCirculito();
                img.raycastTarget = false;
                _circulitos.Add(img);
            }
        }
        foreach (var c in _circulitos)
            if (c != null && c.gameObject.activeSelf != circulitos) c.gameObject.SetActive(circulitos);
    }

    /// Rectángulo redondeado blanco con contorno, en 9-slice: el bocadillo sin pico.
    Sprite SpriteSinPico()
    {
        if (_spriteSinPico != null) return _spriteSinPico;
        const int lado = 128, radio = 44, borde = 48;
        var tex = PintarRedondeado(lado, lado, radio, 3.5f);
        _spriteSinPico = Sprite.Create(tex, new Rect(0, 0, lado, lado), new Vector2(0.5f, 0.5f), 100f,
                                       0, SpriteMeshType.FullRect, new Vector4(borde, borde, borde, borde));
        _spriteSinPico.name = "BocadilloSinPico";
        return _spriteSinPico;
    }

    Sprite SpriteCirculito()
    {
        if (_spriteCirculito != null) return _spriteCirculito;
        const int lado = 64;
        var tex = PintarRedondeado(lado, lado, lado * 0.5f, 5f);
        _spriteCirculito = Sprite.Create(tex, new Rect(0, 0, lado, lado), new Vector2(0.5f, 0.5f), 100f);
        _spriteCirculito.name = "Circulito";
        return _spriteCirculito;
    }

    /// Relleno blanco con contorno de _colorContornoADistancia, con los bordes suavizados.
    Texture2D PintarRedondeado(int ancho, int alto, float radio, float grosor)
    {
        var tex = new Texture2D(ancho, alto, TextureFormat.RGBA32, false)
        {
            wrapMode = TextureWrapMode.Clamp,
            filterMode = FilterMode.Bilinear,
            name = "BocadilloADistancia",
        };
        var px = new Color32[ancho * alto];
        Color contorno = _colorContornoADistancia;
        for (int y = 0; y < alto; y++)
        for (int x = 0; x < ancho; x++)
        {
            // Distancia con signo al borde del rectángulo redondeado (negativa dentro).
            float qx = Mathf.Abs(x + 0.5f - ancho * 0.5f) - (ancho * 0.5f - radio);
            float qy = Mathf.Abs(y + 0.5f - alto * 0.5f) - (alto * 0.5f - radio);
            float d = new Vector2(Mathf.Max(qx, 0f), Mathf.Max(qy, 0f)).magnitude
                      + Mathf.Min(Mathf.Max(qx, qy), 0f) - radio;
            float fuera = Mathf.Clamp01(d + 0.5f);                // 1 = fuera del todo
            float relleno = Mathf.Clamp01(-(d + grosor) + 0.5f);   // 1 = dentro del contorno
            Color c = Color.Lerp(contorno, Color.white, relleno);
            c.a = Mathf.Max((1f - fuera) * contorno.a, relleno);
            px[y * ancho + x] = c;
        }
        tex.SetPixels32(px);
        tex.Apply(false, true);
        return tex;
    }

    // ── Arte del bocadillo dibujado por código ─────────────────────────────────

    /// Margen horizontal del texto: con el arte generado lo aporta el papel, no la etiqueta.
    float MargenHorizontal => _usarArteGenerado ? 0f : _labelHorizontalMargin;

    /// Hueco horizontal total que el texto necesita dentro del bocadillo: el margen de la
    /// etiqueta más el padding del layout (con el papel generado, solo el padding).
    float MargenTotalHorizontal => MargenHorizontal * 2f
                                 + (_layout != null ? _layout.padding.left + _layout.padding.right : 0f);

    /// Rango de ancho del bocadillo según el arte activo.
    float AnchoMinimo => _usarArteGenerado
        ? TamanoDeTextoDelBocadillo * _anchoMinimoEnLetras : _bubbleMinWidth;
    float AnchoMaximo => _usarArteGenerado
        ? TamanoDeTextoDelBocadillo * _anchoMaximoEnLetras : _bubbleMaxWidth;

    /// Ancho del bocadillo para un texto: el que ocuparía en una línea, entre el mínimo y
    /// el máximo. Con el papel dibujado por código se redondea hacia arriba a un paso fijo, para que
    /// haya pocas medidas distintas y el papel no se repinte por cada frase.
    float AnchoDelBocadillo(float anchoDelTexto)
    {
        float ancho = Mathf.Clamp(anchoDelTexto + MargenTotalHorizontal, AnchoMinimo, AnchoMaximo);
        if (_usarArteGenerado) ancho = Mathf.Ceil(ancho / PasoDeAncho) * PasoDeAncho;
        return ancho;
    }

    /// Hueco que hay que dejar alrededor del papel para que quepa la sombra proyectada.
    float MargenDeSombra => _radioSombra
                          + Mathf.Max(Mathf.Abs(_sombraDesplazamiento.x), Mathf.Abs(_sombraDesplazamiento.y));

    /// Alto del lienzo donde vive el bocadillo (1080 si todavía no se ha medido).
    float AlturaDelCanvas => _parentCanvasRect != null && _parentCanvasRect.rect.height > 50f
        ? _parentCanvasRect.rect.height
        : 1080f;

    /// Tamaño de letra del bocadillo, proporcional al alto del lienzo: se lee igual en cualquier
    /// resolución, como los subtítulos, y crece con la pantalla en vez de quedarse en un valor fijo.
    float TamanoDeTextoDelBocadillo => Mathf.Clamp(AlturaDelCanvas * _tamanoTextoDelCanvas, 22f, 64f);

    /// Prepara el estilo según el arte activo: el padding del layout lo marca el papel
    /// (borde + margen del texto, y la cola por debajo) y la imagen pasa a "simple",
    /// porque el bocadillo dibujado por código no se trocea.
    void AplicarEstilo(bool conCola)
    {
        // Solo el texto del BOCADILLO, nunca _label: Paginar() llama aquí para medir frases de
        // bocadillo aunque la presentación activa sea un subtítulo, y entonces _label era el texto
        // del subtítulo y se quedaba con la letra oscura del papel (subtítulos en negro).
        if (_textoBocadillo == null) return;

        if (!_usarArteGenerado)
        {
            if (_layout != null && _paddingConPico != null) _layout.padding = _paddingConPico;
            _textoBocadillo.margin = new Vector4(_labelHorizontalMargin, _textoBocadillo.margin.y,
                                        _labelHorizontalMargin, _textoBocadillo.margin.w);
            _textoBocadillo.fontSize = _tamanoTextoOriginal;
            if (_bubbleImage != null) _bubbleImage.type = Image.Type.Sliced;
            return;
        }

        // Padding = hueco de la sombra + borde del papel + margen del texto (+ la cola).
        int margen = Mathf.RoundToInt(MargenDeSombra + _grosorBorde
                                      + Mathf.Max(_margenTexto, TamanoDeTextoDelBocadillo * 0.6f));
        int abajo = margen + (conCola ? Mathf.RoundToInt(_cola.y) : 0);
        if (_layout != null) _layout.padding = new RectOffset(margen, margen, margen, abajo);

        _textoBocadillo.margin = new Vector4(0f, _textoBocadillo.margin.y, 0f, _textoBocadillo.margin.w);
        _textoBocadillo.fontSize = TamanoDeTextoDelBocadillo;
        _textoBocadillo.color = _colorTexto;
        if (_bubbleImage != null) _bubbleImage.type = Image.Type.Simple;
    }

    /// El papel del bocadillo dibujado por código, a la medida exacta del rectángulo:
    /// como la imagen es "simple" (no troceada), la textura tiene que coincidir con el
    /// tamaño del bocadillo o se deformaría.
    void AplicarSpriteGenerado(bool conCola)
    {
        if (_bubbleImage == null || _bubbleRect == null) return;
        Sprite sprite = SpriteGenerado(_bubbleRect.rect.size, conCola);
        if (sprite != null) _bubbleImage.sprite = sprite;
    }

    /// El bocadillo del tamaño pedido, dibujado por código y cacheado por medidas:
    /// cada ancho/alto distinto que aparezca en el juego se pinta una sola vez.
    Sprite SpriteGenerado(Vector2 tamano, bool conCola)
    {
        int ancho = Mathf.Max(16, Mathf.RoundToInt(tamano.x));
        int alto = Mathf.Max(16, Mathf.RoundToInt(tamano.y));
        long clave = ((long)ancho << 33) | ((long)alto << 1) | (conCola ? 1L : 0L);
        if (_spritesGenerados.TryGetValue(clave, out Sprite sprite) && sprite != null) return sprite;

        // Tope de memoria: cada medida distinta es una textura. Cuando se llena, se
        // empieza de cero (las medidas que vuelven a salir se vuelven a pintar).
        if (_spritesGenerados.Count >= TopeDeSpritesGenerados)
        {
            foreach (var s in _spritesGenerados.Values) if (s != null) Destroy(s);
            foreach (var t in _texturasGeneradas) if (t != null) Destroy(t);
            _spritesGenerados.Clear();
            _texturasGeneradas.Clear();
        }

        var tex = PintarBocadillo(ancho, alto, conCola);
        sprite = Sprite.Create(tex, new Rect(0, 0, ancho, alto), new Vector2(0.5f, 0.5f), 100f);
        sprite.name = conCola ? "BocadilloPapel" : "BocadilloPapelSinCola";
        _spritesGenerados[clave] = sprite;
        _texturasGeneradas.Add(tex);
        return sprite;
    }

    /// Pinta el papel: rectángulo redondeado con borde difuso, cola y sombra proyectada,
    /// todo sobre un campo de distancia. La cola entra en el papel para que el borde no
    /// se corte con ella.
    Texture2D PintarBocadillo(int ancho, int alto, bool conCola)
    {
        var tex = new Texture2D(ancho, alto, TextureFormat.RGBA32, false)
        {
            wrapMode = TextureWrapMode.Clamp,
            filterMode = FilterMode.Bilinear,
            name = "BocadilloPapel",
        };
        var px = new Color32[ancho * alto];

        float borde = Mathf.Max(0f, _grosorBorde);
        // El papel vive dentro del hueco que necesita la sombra proyectada.
        float margen = MargenDeSombra;
        float anchoPapel = Mathf.Max(4f, ancho - 2f * margen);
        float altoPapel = Mathf.Max(4f, alto - 2f * margen - (conCola ? _cola.y : 0f));

        float x0 = margen, x1 = margen + anchoPapel;
        float y1 = alto - margen;             // la textura crece hacia arriba
        float y0 = y1 - altoPapel;
        float cx = (x0 + x1) * 0.5f, cy = (y0 + y1) * 0.5f;
        float hw = anchoPapel * 0.5f, hh = altoPapel * 0.5f;
        float radio = Mathf.Min(_radioEsquina, Mathf.Min(hw, hh));

        // La cola asoma por debajo del papel; su base se mete dentro para no dejar costura.
        float colaPunta = conCola ? margen : -1000f;
        float colaBase = y0 + (conCola ? SolapeCola : 0f);
        float colaIzq = cx - _cola.x * 0.5f, colaDer = cx + _cola.x * 0.5f;

        for (int y = 0; y < alto; y++)
        for (int x = 0; x < ancho; x++)
        {
            float fx = x + 0.5f, fy = y + 0.5f;
            float d = DistanciaPapel(fx, fy, cx, cy, hw, hh, radio,
                                     colaIzq, colaDer, colaBase, colaPunta, conCola);

            // La sombra es el mismo papel desplazado: su opacidad sale de lo lejos que
            // está de la forma, así que sale difusa sin necesidad de difuminar nada.
            float ds = DistanciaPapel(fx - _sombraDesplazamiento.x, fy - _sombraDesplazamiento.y,
                                      cx, cy, hw, hh, radio,
                                      colaIzq, colaDer, colaBase, colaPunta, conCola);
            float aSombra = Mathf.Clamp01((_radioSombra - ds) / Mathf.Max(0.001f, _radioSombra));
            aSombra *= aSombra * _sombraOpacidad;

            // Relleno dentro del papel; el borde es un halo que se desvanece hacia fuera.
            float aRelleno = Mathf.Clamp01(0.5f - d);
            float aBorde = borde > 0.01f ? Mathf.Clamp01((borde - d) / borde) : 0f;
            float aPapel = Mathf.Max(aRelleno, aBorde);
            Color c = Color.Lerp(_colorBorde, _colorPapel, aRelleno);

            // La sombra va detrás del papel.
            Color final = Color.Lerp(_colorSombra, c, aPapel);
            float alfa = aPapel + aSombra * (1f - aPapel);
            px[y * ancho + x] = new Color(final.r, final.g, final.b, alfa);
        }

        tex.SetPixels32(px);
        tex.Apply(false, true);
        return tex;
    }

    /// Distancia con signo al papel (cuerpo redondeado + cola), con el borde irregular.
    float DistanciaPapel(float fx, float fy, float cx, float cy, float hw, float hh, float radio,
                         float colaIzq, float colaDer, float colaBase, float colaPunta, bool conCola)
    {
        float d = DistanciaRectRedondeado(fx, fy, cx, cy, hw, hh, radio);
        if (conCola)
        {
            float dt = DistanciaTriangulo(fx, fy,
                new Vector2(colaIzq, colaBase), new Vector2(cx, colaPunta),
                new Vector2(colaDer, colaBase));
            d = Mathf.Min(d, dt);
        }
        return d + Desdibujo(fx, fy);
    }

    /// Distancia con signo a un rectángulo redondeado (negativa dentro).
    static float DistanciaRectRedondeado(float x, float y, float cx, float cy,
                                          float hw, float hh, float r)
    {
        float qx = Mathf.Abs(x - cx) - (hw - r);
        float qy = Mathf.Abs(y - cy) - (hh - r);
        float dx = Mathf.Max(qx, 0f), dy = Mathf.Max(qy, 0f);
        float fuera = Mathf.Sqrt(dx * dx + dy * dy);
        float dentro = Mathf.Min(Mathf.Max(qx, qy), 0f);
        return fuera + dentro - r;
    }

    /// Distancia con signo aproximada a un triángulo (intersección de tres medios
    /// planos): basta para pintar la cola.
    static float DistanciaTriangulo(float x, float y, Vector2 a, Vector2 b, Vector2 c)
    {
        float area = (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
        float signo = area >= 0f ? 1f : -1f;
        float h1 = signo * DistanciaMediaPlano(x, y, a, b);
        float h2 = signo * DistanciaMediaPlano(x, y, b, c);
        float h3 = signo * DistanciaMediaPlano(x, y, c, a);
        return -Mathf.Min(h1, Mathf.Min(h2, h3));
    }

    static float DistanciaMediaPlano(float x, float y, Vector2 p, Vector2 q)
    {
        float ex = q.x - p.x, ey = q.y - p.y;
        float largo = Mathf.Sqrt(ex * ex + ey * ey);
        if (largo < 0.0001f) return 0f;
        return (ex * (y - p.y) - ey * (x - p.x)) / largo;
    }

    /// Irregularidad del borde: el papel no es un rectángulo de plástico.
    float Desdibujo(float x, float y)
    {
        if (_desdibujo <= 0f || _ruido == null) return 0f;
        return MuestraRuido(x * 0.055f, y * 0.055f) * _desdibujo;
    }

    float MuestraRuido(float x, float y)
    {
        int x0 = Mathf.FloorToInt(x), y0 = Mathf.FloorToInt(y);
        float fx = x - x0, fy = y - y0;
        fx = fx * fx * (3f - 2f * fx);
        fy = fy * fy * (3f - 2f * fy);
        int m = LadoRuido - 1;
        float v00 = _ruido[(y0 & m) * LadoRuido + (x0 & m)];
        float v10 = _ruido[(y0 & m) * LadoRuido + ((x0 + 1) & m)];
        float v01 = _ruido[((y0 + 1) & m) * LadoRuido + (x0 & m)];
        float v11 = _ruido[((y0 + 1) & m) * LadoRuido + ((x0 + 1) & m)];
        return Mathf.Lerp(Mathf.Lerp(v00, v10, fx), Mathf.Lerp(v01, v11, fx), fy);
    }

    // La presentación cambia las referencias visuales; el ciclo de habla y cierre es compartido.
    void CambiarPresentacion(PresentacionDeTexto presentacion, string nombre, Color color)
    {
        _rootGroup.DOKill();
        _bubbleRect.DOKill();
        _rootGroup.alpha = 0f;
        _presentacion = presentacion;
        if (presentacion == PresentacionDeTexto.Bocadillo)
        {
            _rootGroup = _grupoBocadillo;
            _bubbleRect = _rectBocadillo;
            _label = _textoBocadillo;
            return;
        }
        CrearSubtitulo();
        _rootGroup = _grupoSubtitulo;
        _bubbleRect = _rectSubtitulo;
        _label = _textoSubtitulo;
        _label.fontSize = TamanoDeSubtitulo(presentacion);
        _nombreSubtitulo.fontSize = TamanoDeSubtitulo(PresentacionDeTexto.Subtitulo) * 0.75f;
        _nombreSubtitulo.text = presentacion == PresentacionDeTexto.SubtituloGrande ? string.Empty : nombre;
        _nombreSubtitulo.color = color.a > 0f ? color : new Color(0.91f, 0.91f, 0.91f);
        ColocarSubtitulo();
    }

    float AlturaCanvasSubtitulo => _canvasSubtitulo != null && _canvasSubtitulo.rect.height > 50f
        ? _canvasSubtitulo.rect.height
        : (_parentCanvasRect != null && _parentCanvasRect.rect.height > 50f ? _parentCanvasRect.rect.height : 1080f);

    float AnchoCanvasSubtitulo => _canvasSubtitulo != null && _canvasSubtitulo.rect.width > 50f
        ? _canvasSubtitulo.rect.width
        : (_parentCanvasRect != null && _parentCanvasRect.rect.width > 50f ? _parentCanvasRect.rect.width : 1920f);

    void CrearSubtitulo()
    {
        if (_grupoSubtitulo != null) return;
        var go = new GameObject("Subtitulos", typeof(RectTransform), typeof(Canvas));
        go.transform.SetParent(_parentCanvasRect, false);
        var canvas = go.GetComponent<Canvas>();
        canvas.overrideSorting = true;
        canvas.sortingOrder = 9997;
        _canvasSubtitulo = (RectTransform)go.transform;
        _canvasSubtitulo.anchorMin = Vector2.zero;
        _canvasSubtitulo.anchorMax = Vector2.one;
        _canvasSubtitulo.offsetMin = _canvasSubtitulo.offsetMax = Vector2.zero;
        Canvas.ForceUpdateCanvases();
        var panel = new GameObject("Linea", typeof(RectTransform), typeof(CanvasGroup));
        panel.transform.SetParent(go.transform, false);
        _rectSubtitulo = (RectTransform)panel.transform;
        _grupoSubtitulo = panel.GetComponent<CanvasGroup>();
        _grupoSubtitulo.alpha = 0f;
        _grupoSubtitulo.blocksRaycasts = false;
        _grupoSubtitulo.interactable = false;
        // Los grupos del HUD no ocultan el texto de la cinemática.
        _grupoSubtitulo.ignoreParentGroups = true;
        _textoSubtitulo = CrearTextoDeSubtitulo("Texto", _rectSubtitulo);
        _nombreSubtitulo = CrearTextoDeSubtitulo("Hablante", _rectSubtitulo);
        _nombreSubtitulo.fontSize = _textoBocadillo.fontSize * 0.75f;
        _nombreSubtitulo.fontStyle = FontStyles.Bold;
        _nombreSubtitulo.textWrappingMode = TextWrappingModes.NoWrap;
    }

    TextMeshProUGUI CrearTextoDeSubtitulo(string nombre, RectTransform padre)
    {
        var go = new GameObject(nombre, typeof(RectTransform), typeof(TextMeshProUGUI));
        go.transform.SetParent(padre, false);
        var texto = go.GetComponent<TextMeshProUGUI>();
        texto.font = _textoBocadillo.font;
        texto.fontSize = _textoBocadillo.fontSize;
        texto.color = Color.white;
        texto.alignment = TextAlignmentOptions.Center;
        texto.textWrappingMode = TextWrappingModes.Normal;
        texto.raycastTarget = false;
        texto.outlineColor = new Color32(0, 0, 0, 255);
        texto.outlineWidth = 0.22f;
        return texto;
    }

    float TamanoDeSubtitulo(PresentacionDeTexto presentacion)
    {
        float altura = BandasDeCineUI.Instance != null && BandasDeCineUI.Instance.AlturaObjetivo > 0f
            ? BandasDeCineUI.Instance.AlturaObjetivo : 0.13f;
        float altoCanvas = AlturaCanvasSubtitulo;
        float normal = Mathf.Clamp((altoCanvas * altura - 16f) / 3.4f, 18f, 26f);
        return normal * (presentacion == PresentacionDeTexto.SubtituloGrande ? 1.8f : 1f);
    }

    /// Las bandas de cine están puestas o entrando: el subtítulo tiene dónde ir.
    static bool HayBandasDeCine
    {
        get
        {
            var bandas = BandasDeCineUI.Instance;
            return bandas != null && (bandas.AlturaVisible > 0.02f || bandas.AlturaObjetivo > 0.02f);
        }
    }

    /// Alto de la banda de abajo en la que va el subtítulo (tanto por uno de la pantalla). Si las
    /// bandas se retiran con la frase aún en pantalla, la frase se queda donde estaba la banda.
    float _altoDeBanda = 0.13f;

    void ColocarSubtitulo()
    {
        if (_canvasSubtitulo == null || _rectSubtitulo == null || _textoSubtitulo == null || _nombreSubtitulo == null) return;
        bool grande = _presentacion == PresentacionDeTexto.SubtituloGrande;
        if (HayBandasDeCine)
            _altoDeBanda = Mathf.Max(BandasDeCineUI.Instance.AlturaVisible, BandasDeCineUI.Instance.AlturaObjetivo);
        float altoCanvas = AlturaCanvasSubtitulo;
        float anchoCanvas = AnchoCanvasSubtitulo;
        float anchoMax = anchoCanvas * 0.75f;

        bool tieneNombre = !string.IsNullOrEmpty(_nombreSubtitulo.text) && !grande;

        string txt = _textoSubtitulo.text ?? string.Empty;
        Vector2 tamTexto = !string.IsNullOrEmpty(txt) ? _textoSubtitulo.GetPreferredValues(txt, anchoMax, 0f) : Vector2.zero;
        float altoTexto = Mathf.Max(_textoSubtitulo.fontSize * 1.15f, tamTexto.y);

        float altoNombre = tieneNombre
            ? Mathf.Max(_nombreSubtitulo.fontSize * 1.15f, _nombreSubtitulo.GetPreferredValues(_nombreSubtitulo.text, anchoMax, 0f).y)
            : 0f;

        float espaciado = tieneNombre ? 4f : 0f;
        float paddingY = 6f;
        float altoTotal = altoTexto + altoNombre + espaciado + (paddingY * 2f);

        float altoBanda = altoCanvas * _altoDeBanda;

        _rectSubtitulo.anchorMin = _rectSubtitulo.anchorMax = new Vector2(0.5f, grande ? 0.5f : 0f);
        _rectSubtitulo.pivot = new Vector2(0.5f, grande ? 0.5f : 0f);

        // Sin fondo propio: el subtítulo grande va en el centro y el normal, centrado en la banda
        // de cine de abajo, que ya es negra.
        _rectSubtitulo.sizeDelta = new Vector2(anchoMax, altoTotal);
        _rectSubtitulo.anchoredPosition = grande
            ? Vector2.zero
            : new Vector2(0f, Mathf.Max(4f, (altoBanda - altoTotal) * 0.5f));

        float anchoContenido = anchoMax;

        // 1. Texto de diálogo en la parte inferior
        _textoSubtitulo.rectTransform.anchorMin = _textoSubtitulo.rectTransform.anchorMax = new Vector2(0.5f, 0f);
        _textoSubtitulo.rectTransform.pivot = new Vector2(0.5f, 0f);
        _textoSubtitulo.rectTransform.anchoredPosition = new Vector2(0f, paddingY);
        _textoSubtitulo.rectTransform.sizeDelta = new Vector2(anchoContenido, altoTexto);
        _textoSubtitulo.alignment = TextAlignmentOptions.Center;

        // 2. Nombre del hablante sobre el texto
        _nombreSubtitulo.gameObject.SetActive(tieneNombre);
        if (tieneNombre)
        {
            _nombreSubtitulo.rectTransform.anchorMin = _nombreSubtitulo.rectTransform.anchorMax = new Vector2(0.5f, 0f);
            _nombreSubtitulo.rectTransform.pivot = new Vector2(0.5f, 0f);
            _nombreSubtitulo.rectTransform.anchoredPosition = new Vector2(0f, paddingY + altoTexto + espaciado);
            _nombreSubtitulo.rectTransform.sizeDelta = new Vector2(anchoContenido, altoNombre);
            _nombreSubtitulo.alignment = TextAlignmentOptions.Center;
        }
    }

    /// El ancho del bocadillo para un texto: el que ocuparía en una línea, entre el mínimo y el
    /// máximo (ver el comentario largo de Show()). El alto lo recalcula el layout del prefab.
    void AjustarAncho(string texto)
    {
        if (_presentacion != PresentacionDeTexto.Bocadillo) { ColocarSubtitulo(); return; }
        float bubbleWidth = AnchoDelBocadillo(AnchoEnUnaLinea(_label, texto));

        Vector2 sd = _bubbleRect.sizeDelta;
        sd.x = bubbleWidth;
        _bubbleRect.sizeDelta = sd;

        LayoutRebuilder.ForceRebuildLayoutImmediate(_bubbleRect);
    }

    /// Las páginas de una frase larga, una detrás de otra en el mismo bocadillo: cambia el texto
    /// con un pequeño rebote (no se cierra y se vuelve a abrir). El tiempo total se reparte según
    /// lo largo de cada página, y ninguna dura menos de lo que se tarda en leerla. Sin duración
    /// (duration <= 0, el bocadillo lo cierra quien lo abrió) las páginas pasan solas a ritmo de
    /// lectura y la última se queda.
    IEnumerator Co_Paginas(List<string> paginas, float duration, Action onComplete)
    {
        int total = 0;
        foreach (var p in paginas) total += Mathf.Max(1, p.Length);

        for (int i = 0; i < paginas.Count; i++)
        {
            if (i > 0)
            {
                _label.text = paginas[i];
                AjustarAncho(paginas[i]);
                // La página nueva puede ocupar otra altura: el papel se repinta a su medida.
                if (_usarArteGenerado) AplicarSpriteGenerado(!_fijoEnPantalla);
                _bubbleRect.DOKill();
                _bubbleRect.localScale = Vector3.one;
                if (_presentacion == PresentacionDeTexto.Bocadillo)
                    _bubbleRect.DOPunchScale(Vector3.one * 0.06f, 0.2f, 6, 0.6f).SetUpdate(true);
            }

            bool ultima = i == paginas.Count - 1;
            float reparto = duration > 0f ? duration * Mathf.Max(1, paginas[i].Length) / total : 0f;
            float tiempo = Mathf.Max(reparto, TiempoDeLectura(paginas[i]));
            EmpezarHablaDePagina(paginas[i], ultima && duration <= 0f ? 0f : tiempo);
            if (ultima && duration <= 0f) { _autoHideRoutine = null; yield break; }

            yield return new WaitForSecondsRealtime(tiempo);
        }

        _autoHideRoutine = null;
        Hide();
        _pendingOnComplete = null;
        onComplete?.Invoke();
    }

    /// Fuerza el cierre inmediato del bocadillo con auto-hide en curso, como si su duración ya
    /// hubiera terminado: para el temporizador, lo oculta y dispara el mismo onComplete que se le
    /// pasó a Show() — así quien esperaba ese callback (típicamente ShowSpeechBubbleNode, para
    /// avanzar el grafo narrativo) lo recibe igual, solo que antes. No-op seguro si no hay ningún
    /// bocadillo con auto-hide en curso (duration <= 0, o ya se ocultó solo). Pensado para el botón
    /// global de "saltar" — ver ShowSpeechBubbleNode.RegisterSkipHandler.
    public void SkipCurrent()
    {
        SenalesDeHabla.Para(_target);
        if (_autoHideRoutine == null) return;
        StopCoroutine(_autoHideRoutine);
        _autoHideRoutine = null;
        var callback = _pendingOnComplete;
        _pendingOnComplete = null;
        Hide();
        callback?.Invoke();
    }

    void EmpezarHablaDePagina(string pagina, float duracion)
    {
        float segundos = (pagina?.Length ?? 0) / Mathf.Max(1f, _caracteresHabladosPorSegundo);
        if (segundos > 0f) SenalesDeHabla.Empieza(_target, duracion > 0f ? Mathf.Min(duracion, segundos) : segundos);
        else SenalesDeHabla.Para(_target);
    }

    /// Cierra el bocadillo solo si sigue siendo el de ese turno: quien limpia lo suyo no se lleva
    /// por delante el bocadillo que otro sistema haya puesto después.
    public void Hide(int turno)
    {
        if (turno == _turno) Hide();
    }

    public void Hide()
    {
        SenalesDeHabla.Para(_target);
        if (_autoHideRoutine != null) { StopCoroutine(_autoHideRoutine); _autoHideRoutine = null; }
        _isShowing = false;

        _rootGroup.DOKill();
        _bubbleRect.DOKill();

        _rootGroup.DOFade(0f, _fadeOutDuration).SetUpdate(true);
        _bubbleRect.DOScale(_presentacion == PresentacionDeTexto.Bocadillo ? Vector3.zero : Vector3.one, _popOutDuration)
                   .SetEase(Ease.InBack)
                   .SetUpdate(true);
    }

    // ── MenuManager (pausa / cualquier menú) ────────────────────────────────────

    /// <summary>Oculta el bocadillo mientras haya un menú (pausa incluida) abierto encima.</summary>
    void OnMenuOpened(MenuKind kind)
    {
        if (!_isShowing || _hiddenByMenu || _rootGroup == null) return;
        _hiddenByMenu = true;
        _rootGroup.DOKill();
        _rootGroup.DOFade(0f, 0.15f).SetUpdate(true);
        _rootGroup.blocksRaycasts = false;
    }

    /// <summary>Restaura el bocadillo al cerrarse el último menú abierto, si seguía en pantalla.</summary>
    void OnMenuClosed(MenuKind kind)
    {
        if (!_hiddenByMenu) return;
        if (MenuManager.AnyOpen()) return; // todavía queda otro menú abierto
        _hiddenByMenu = false;

        if (!_isShowing || _rootGroup == null) return; // se ocultó por otro motivo mientras tanto
        _rootGroup.DOKill();
        _rootGroup.DOFade(1f, 0.2f).SetUpdate(true);
        _rootGroup.blocksRaycasts = false; // este bocadillo nunca bloquea clics, ver Awake
    }

    // ── Interno ───────────────────────────────────────────────────────────────

    IEnumerator AutoHide(float duration, Action onComplete)
    {
        yield return new WaitForSecondsRealtime(duration);
        Hide();
        _autoHideRoutine = null;
        _pendingOnComplete = null;
        onComplete?.Invoke();
    }

    Animator GetCachedAnimator(Transform target)
    {
        if (!_animatorCache.TryGetValue(target, out Animator anim))
        {
            anim = target.GetComponentInChildren<Animator>();
            _animatorCache[target] = anim;
        }
        return anim;
    }

    NPCSimpleAnimator GetCachedNPCAnimator(Transform target)
    {
        if (!_npcAnimCache.TryGetValue(target, out NPCSimpleAnimator npcAnim))
        {
            npcAnim = target.GetComponentInChildren<NPCSimpleAnimator>();
            _npcAnimCache[target] = npcAnim;
        }
        return npcAnim;
    }

    PlayerDialogueAnimator GetCachedPlayerAnimator(Transform target)
    {
        if (!_playerAnimCache.TryGetValue(target, out PlayerDialogueAnimator playerAnim))
        {
            playerAnim = target.GetComponentInChildren<PlayerDialogueAnimator>();
            _playerAnimCache[target] = playerAnim;
        }
        return playerAnim;
    }
}
