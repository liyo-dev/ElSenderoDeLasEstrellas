using UnityEngine;
using Game.NPC.Common;
using Game.NPC.Modules;

namespace Game.NPC.States
{
    /// <summary>
    /// Estado Idle - El NPC está quieto.
    /// Incluye detección visual realista (Raycast) para iniciar combate si es agresivo.
    /// </summary>
    public class IdleState : NPCStateBase
    {
        public override string StateName => "Idle";

        private float _idleTimer;
        private float _idleDuration;

        // Detección
        private float _playerDetectionTimer;
        private const float PLAYER_DETECTION_INTERVAL = 0.2f; // 5 veces por segundo es suficiente

        // Encuentros sociales (compartido con WanderState vía NPCStateBase.CheckSocialEncounter).
        // Antes solo se escaneaba en WanderState: un NPC parado o recién llegado nunca conversaba.
        private float _socialScanTimer;
        private const float SOCIAL_SCAN_INTERVAL = 3f;
        private readonly Collider[] _socialBuffer = new Collider[8];

        // Oficio ambiental: la ruta se busca cada medio segundo, no cada frame. Es una lista
        // estática pequeña (NPCWorkRoute), pero no hace falta recorrerla 60 veces por segundo.
        private float _workCheckTimer;
        private const float WORK_CHECK_INTERVAL = 0.5f;
        private NPCWorkRoute _rutaDeTrabajo;

        // ✅ FIX rendimiento: cacheado en OnEnter, no GetComponent en cada CheckPlayerDetection
        // (cada 0.2s por NPC parado). Mismo patrón que AlertState (FIX #10). La mayoría de NPCs
        // ambiente no tiene NPCTeamMember, así que el GetComponent fallaba constantemente y
        // aparecía como GC.Alloc en el profiler (NPCBehaviourManagerV2.Update -> CheckPlayerDetection).
        private NPCTeamMember _teamMember;
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        private bool _loggedCombatBlockThisIdle; // evita spam: solo un log por bloqueo, no por frame
#endif

        public override void OnEnter(NPCStateContext context)
        {
            base.OnEnter(context);
            StopMovement(context);

            // Seguridad: Si viene de combate/muerte, limpiar flags
            if (context.WasDefeatedInCombat && context.Animator != null)
                context.Animator.SetBattleMode(false);

            var ambientActivity = context.Config?.ambientConfig?.ambientActivity ?? NPCAmbientActivity.None;

            if (ambientActivity != NPCAmbientActivity.None)
            {
                // NPC con actividad fija: no vaga, permanece en la actividad indefinidamente
                context.Animator?.PlayAmbientActivity(ambientActivity);
                _idleDuration = float.MaxValue;
            }
            else
            {
                // Resetear el estado de animación a Idle para que el próximo WanderState
                // siempre dispare TransitionToLocomotion() correctamente.
                context.Animator?.TransitionToIdle();

                _idleDuration = context.Config != null
                    ? Random.Range(context.Config.minIdleTime, context.Config.maxIdleTime)
                    : 2f;
            }

            _idleTimer = 0f;
            _playerDetectionTimer = 0f;
            _socialScanTimer = 0f;
            _workCheckTimer = 0f;
            _rutaDeTrabajo = null;
            _teamMember = context.Transform.GetComponent<NPCTeamMember>(); // ✅ FIX rendimiento: una vez por entrada al estado
        }

        public override void OnExit(NPCStateContext context)
        {
            var ambientActivity = context.Config?.ambientConfig?.ambientActivity ?? NPCAmbientActivity.None;
            if (ambientActivity != NPCAmbientActivity.None)
                context.Animator?.StopAmbientActivity(ambientActivity);

            base.OnExit(context);
        }
        
        public override void OnUpdate(NPCStateContext context)
        {
            base.OnUpdate(context);
            
            _idleTimer += Time.deltaTime;
            
            // ✅ FIX CRÍTICO: Asegurar que el NavMeshAgent permanezca detenido
            // Esto previene que paths residuales o velocidad acumulada cause movimiento
            if (context.Agent != null && context.Agent.enabled && context.Agent.isOnNavMesh)
            {
                // ⚠️ DETENCIÓN MUY AGRESIVA: Forzar cada frame
                if (!context.Agent.isStopped)
                {
                    context.Log("[IdleState] ⚠️ Agent NO ESTABA DETENIDO - forzando detención");
                    context.Agent.isStopped = true;
                }
                
                if (context.Agent.hasPath)
                {
                    context.Log("[IdleState] ⚠️ Agent TIENE PATH ACTIVO - reseteando");
                    context.Agent.ResetPath();
                }
                
                if (context.Agent.velocity.sqrMagnitude > 0.01f)
                {
                    context.Log($"[IdleState] ⚠️ Agent TIENE VELOCIDAD ({context.Agent.velocity.magnitude:F1}) - limpiando");
                    context.Agent.velocity = Vector3.zero;
                }
            }
            
            // Detección visual periódica
            _playerDetectionTimer += Time.deltaTime;
            if (_playerDetectionTimer >= PLAYER_DETECTION_INTERVAL)
            {
                _playerDetectionTimer = 0f;
                CheckPlayerDetection(context);
            }

            // Encuentros sociales: un NPC parado también puede charlar con quien pase cerca,
            // no solo mientras vaga (ver Diseno_Refugio_Lluvia_y_Relaciones_NPC.md § B.6.2)
            _socialScanTimer += Time.deltaTime;
            if (_socialScanTimer >= SOCIAL_SCAN_INTERVAL)
            {
                _socialScanTimer = 0f;
                CheckSocialEncounter(context, _socialBuffer);
            }

            // Oficio ambiental: buscar una ruta libre de su puesto.
            _workCheckTimer += Time.deltaTime;
            if (_workCheckTimer >= WORK_CHECK_INTERVAL)
            {
                _workCheckTimer = 0f;
                _rutaDeTrabajo = BuscarRutaDeTrabajo(context);
            }
        }
        
        public override INPCState CheckTransitions(NPCStateContext context)
        {
            // 1. Prioridad Máxima
            if (context.IsInCinematic) return new CinematicState();
            if (context.WasDefeatedInCombat) return new DeadState(); // Cambio directo a muerte si procede
            
            // 2. Combate externo (ej: golpeado por detrás)
            if (context.IsInCombat) return new CombatState();
            
            // 3. Interacción
            if (context.IsInteracting) return null; // Quedarse en Idle mientras habla

            // 3b. Refugio de lluvia - interrumpe el idle normal, pero no combate/cinemática/interacción
            if (context.ShouldSeekShelter && context.CurrentShelter == null &&
                context.Config != null && context.Config.canSeekShelter)
            {
                return new SeekShelterState();
            }

            // 3c. Oficio ambiental: va a su ruta de trabajo antes de plantearse vagar.
            if (_rutaDeTrabajo != null && !context.EstaAnclado)
                return new WorkState(_rutaDeTrabajo);

            // 4. Lógica de Patrulla (Wander) - bloqueada si el NPC está anclado por el sistema de party
            if (context.Config != null && context.Config.enableWander && !context.EstaAnclado)
            {
                if (_idleTimer >= _idleDuration)
                {
                    return new WanderState();
                }
            }
            
            return null;
        }

        /// <summary>
        /// Busca una ruta de oficio libre para este NPC. Devuelve null si no tiene puesto
        /// asignado, si está anclado por el party o si la ruta está ocupada o desactivada por
        /// la narrativa.
        /// </summary>
        private static NPCWorkRoute BuscarRutaDeTrabajo(NPCStateContext context)
        {
            if (context.EstaAnclado) return null;

            var ambient = context.Config?.ambientConfig;
            if (ambient == null || !ambient.permitirTrabajo || string.IsNullOrEmpty(ambient.puestoId))
                return null;

            return NPCWorkRoute.TryFindFor(ambient.puestoId, out var ruta) ? ruta : null;
        }
        
        /// <summary>
        /// Sistema de Detección Visual (Igual que WanderState)
        /// </summary>
        private void CheckPlayerDetection(NPCStateContext context)
        {
            // 0. Filtros básicos
            if (context.WasDefeatedInCombat) return;
            if (context.Player == null) return;

            var teamMember = _teamMember; // ✅ FIX rendimiento: cacheado en OnEnter, ver campo _teamMember arriba

            // Bloqueo global: si ya hay otro combate activo, este NPC no debe iniciar uno nuevo.
            // EXCEPCIÓN: si un compañero de MI equipo ya está en combate, no bloquear. Este es
            // justo el caso que NPCCombatTeam.OnPlayerDetected()/IsAnyMemberInCombat() ya sabe
            // gestionar (deja que el equipo se una al mismo combate). Sin esta excepción, en
            // cuanto un miembro entraba en CombatState (y se registraba en ActiveCombatRegistry),
            // el resto del equipo quedaba bloqueado aquí para siempre y nunca llegaba a
            // TryNotifyTeamOfPlayer — bug observado: "Lety luchaba, Vicky se quedaba quieta".
            bool teammateAlreadyFighting = teamMember != null && teamMember.HasTeam
                && teamMember.Team.IsAnyMemberInCombat();
            if (!teammateAlreadyFighting
                && ActiveCombatRegistry.HasActiveCombatExcluding(context.Transform.gameObject))
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                // 🔍 DIAGNÓSTICO (incidencia recurrente "no me detectan" - Lety/Vicky y otros):
                // este early-return era totalmente silencioso, así que cada vez que el bloqueo
                // global de combate (un solo combate activo a la vez, ver ActiveCombatRegistry)
                // impedía la detección, no quedaba ningún rastro en consola de POR QUÉ. Log único
                // por NPC (no por frame) listando quién está ocupando el registro ahora mismo.
                if (!_loggedCombatBlockThisIdle)
                {
                    _loggedCombatBlockThisIdle = true;
                    var blockers = ActiveCombatRegistry.GetAllInCombat();
                    string blockerNames = blockers.Count > 0
                        ? string.Join(", ", blockers.ConvertAll(b => b != null ? b.name : "?"))
                        : "(ninguno con nombre resoluble - revisar CleanupDestroyedNPCs)";
                    context.Log($"[IdleState] 🚫 '{context.Transform.name}' NO detecta al jugador: bloqueo global de combate activo. Ocupando el registro: {blockerNames}");
                }
#endif
                return;
            }
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            _loggedCombatBlockThisIdle = false;
#endif

            // ✅ FIX: Si soy miembro de un equipo y ya notifiqué, no sigo detectando
            // Esto evita el bucle infinito de detección
            if (teamMember != null && teamMember.HasNotifiedTeam)
            {
                return; // Ya se notificó al equipo, el NPCCombatTeam se encarga
            }
            
            var combatConfig = context.Config?.combatConfig;
            if (combatConfig == null || !combatConfig.isAggressive) return;
            
            // 1. Distancia (sqrMagnitude es más rápido)
            Vector3 toPlayer = context.Player.position - context.Transform.position;
            float distSqr = toPlayer.sqrMagnitude;
            float detectionRange = combatConfig.detectionRange;
            
            if (distSqr > detectionRange * detectionRange) return;
            
            // 2. Campo de Visión (FOV)
            Vector3 eyePos = context.Transform.position + Vector3.up * 1.6f;
            Vector3 playerTarget = context.Player.position + Vector3.up * 1.0f;
            Vector3 dirToTarget = (playerTarget - eyePos).normalized;
            
            float angle = Vector3.Angle(context.Transform.forward, dirToTarget);
            float fov = combatConfig.fieldOfView > 0 ? combatConfig.fieldOfView : 160f;
            if (angle > fov * 0.5f) return;
            
            // 3. Línea de Visión (Raycast) - Evita ver a través de paredes
            int layerMask = ~0; // Todo
            if (combatConfig.coverLayerMask != 0) 
                layerMask = combatConfig.coverLayerMask | (1 << context.Player.gameObject.layer);

            if (Physics.Raycast(eyePos, dirToTarget, out RaycastHit hit, detectionRange, layerMask))
            {
                // Si chocamos con algo que NO es el jugador, estamos bloqueados
                if (hit.transform != context.Player && !hit.transform.IsChildOf(context.Player))
                {
                    // FIX INC-073: el layerMask usado aquí incluye "Everything" salvo que se
                    // configure coverLayerMask explícitamente, así que el propio compañero de
                    // equipo (p.ej. Lety y Vicky, colocados muy cerca el uno del otro) podía tapar
                    // el raycast del otro y ninguno de los dos llegaba a "ver" al jugador
                    // acercarse — había que atacarles para forzar el combate. Un compañero del
                    // mismo equipo no debe bloquear la detección.
                    var hitTeamMember = hit.transform.GetComponentInParent<NPCTeamMember>();
                    bool isTeammate = hitTeamMember != null && teamMember != null && hitTeamMember.Team == teamMember.Team;
                    if (!isTeammate)
                        return;
                }
            }
            
            // --- JUGADOR DETECTADO ---
            context.Log($"[IdleState] 👁️ Jugador visto. ¡Alerta!");

            // ✅ TEAM SUPPORT: da igual cuál de los miembros detecte — solo notificar al equipo y
            // dejar que NPCCombatTeam.Co_DetectAndEngage gestione TODA la secuencia (parar+mirar,
            // diálogo una sola vez para el equipo, combate para todos a la vez). NO crear un
            // AlertState individual aquí: competía con NPCCombatTeam y dejaba a los miembros en
            // estados inconsistentes según quién detectaba primero (bug histórico de Lety/Vicky).
            if (teamMember != null && teamMember.HasTeam)
            {
                teamMember.TryNotifyTeamOfPlayer(context.Player);
                return;
            }

            var alertStateDefault = new AlertState(
                duration: combatConfig.alertIconDuration,
                walk: true,
                stopDist: combatConfig.minAttackDistance + 1f
            );
            
            context.Brain?.ChangeState(alertStateDefault);
        }
    }
}
