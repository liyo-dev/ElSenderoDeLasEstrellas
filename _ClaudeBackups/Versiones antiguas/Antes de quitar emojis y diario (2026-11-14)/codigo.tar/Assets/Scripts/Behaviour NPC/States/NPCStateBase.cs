﻿using UnityEngine;
namespace Game.NPC.States
{
    public abstract class NPCStateBase : Common.INPCState
    {
        public abstract string StateName { get; }
        public virtual void OnEnter(Common.NPCStateContext context)
        {
            context.Log($"[{StateName}] OnEnter");
        }
        public virtual void OnUpdate(Common.NPCStateContext context) { }
        public virtual void OnExit(Common.NPCStateContext context)
        {
            context.Log($"[{StateName}] OnExit");
            if (context.Config != null && context.Config.resetAnimationOnStateExit)
            {
                context.Animator?.ResetMovement();
            }
        }
        public abstract Common.INPCState CheckTransitions(Common.NPCStateContext context);
        protected bool IsAgentValid(Common.NPCStateContext context)
        {
            return context.Agent != null && 
                   context.Agent.enabled && 
                   context.Agent.isOnNavMesh;
        }
        protected bool HasReachedDestination(Common.NPCStateContext context)
        {
            if (!IsAgentValid(context))
                return false;
            var agent = context.Agent;
            var config = context.Config;
            if (agent.pathPending)
                return false;
            float stoppingDist = config != null ? config.stoppingDistance : 0.5f;
            return agent.remainingDistance <= stoppingDist + 0.1f;
        }
        protected bool IsPathBlocked(Common.NPCStateContext context)
        {
            if (!IsAgentValid(context))
                return true;
            var agent = context.Agent;
            return agent.pathStatus == UnityEngine.AI.NavMeshPathStatus.PathPartial ||
                   agent.pathStatus == UnityEngine.AI.NavMeshPathStatus.PathInvalid;
        }
        protected void UpdateMovementAnimation(Common.NPCStateContext context)
        {
            if (!IsAgentValid(context) || context.Animator == null)
                return;
            float speedFactor = Common.NavMeshAgentUtility.FactorDeLocomocion(context.Agent);
            if (context.Config != null && speedFactor > 0f)
            {
                speedFactor = Mathf.Max(speedFactor, context.Config.minAnimSpeed);
            }
            context.Animator.SetMovementSpeed(speedFactor);
        }
        protected bool SetDestination(Common.NPCStateContext context, Vector3 destination)
        {
            if (!IsAgentValid(context))
            {
                context.LogWarning($"[{StateName}] Agent no válido, no se puede establecer destino");
                return false;
            }
            context.TargetDestination = destination;
            context.HasReachedDestination = false;
            Common.NavMeshAgentUtility.SetDestination(context.Agent, destination);
            return true;
        }
        protected void StopMovement(Common.NPCStateContext context)
        {
            if (context.Agent != null)
            {
                Common.NavMeshAgentUtility.HardStop(context.Agent);
            }
            if (context.Animator != null)
            {
                context.Animator.ResetMovement();
            }
        }

        // =================================================================================
        // 🌳 APROXIMACIÓN MANUAL FUERA DEL NAVMESH (refugio bajo copas de árbol)
        // =================================================================================
        //
        // Muchos árboles tienen su malla completa (tronco + copa) marcada como Navigation
        // Static, y el NavMesh se bakea con Render Meshes: como la copa suele colgar cerca del
        // suelo, el hueco no-transitable que se talla cubre todo el radio de la copa, no solo el
        // tronco. Un NPCShelterPoint colocado "bien adentro" del árbol cae entonces siempre fuera
        // del área caminable, y el NavMeshAgent solo puede llegar hasta el borde de ese hueco
        // (justo fuera del árbol) por muy cerca que se coloque el punto real. Arreglarlo por
        // NavMesh/colliders significaría retocar árbol por árbol en el editor (son muchos).
        //
        // En su lugar: cuando el NavMeshAgent ya no puede acercarse más, se completa el último
        // tramo moviendo el transform a mano — no hay ningún obstáculo físico real bajo la copa,
        // solo el hueco del bakeo. SeekShelterState hace esto al llegar; ReturnFromShelterState
        // lo hace a la inversa para volver a enganchar al NPC al NavMeshAgent antes de reanudar
        // el pathfinding normal. Ver NPCStateContext.ShelterEdgePosition.

        protected void BeginManualApproach(Common.NPCStateContext context)
        {
            var agent = context.Agent;
            if (agent == null) return;

            if (agent.isOnNavMesh)
            {
                agent.isStopped = true;
                agent.ResetPath();
            }
            agent.velocity = Vector3.zero;
            agent.nextPosition = context.Transform.position;
            agent.updatePosition = false;
            agent.updateRotation = false;
        }

        protected void EndManualApproach(Common.NPCStateContext context)
        {
            var agent = context.Agent;
            if (agent == null) return;

            agent.velocity = Vector3.zero;
            agent.nextPosition = context.Transform.position;
            agent.updatePosition = true;
            agent.updateRotation = true;
        }

        /// <summary>
        /// Da un paso de la aproximación manual hacia target: mueve el transform directamente y
        /// gira/anima al NPC a mano (SyncWithNavMeshAgent de NPCSimpleAnimator no hace nada
        /// mientras el agente esté fuera del NavMesh, así que hay que encargarse aquí). Devuelve
        /// true en cuanto llega.
        ///
        /// FIX INC-NPCS-EN-ARBOLES: el comentario de cabecera de BeginManualApproach asume que
        /// bajo la copa del árbol no hay ningún obstáculo físico real, solo el hueco del bakeo —
        /// pero eso solo es cierto si el área "Not Walkable" del árbol cubre TODA la copa. Si algún
        /// árbol tiene el radio de exclusión ajustado solo al tronco (bake más pequeño que la
        /// copa, o un NavMeshObstacle mal dimensionado), el paso recto de MoveTowards puede
        /// atravesarlo visualmente — exactamente el bug reportado de NPCs metiéndose en los
        /// árboles del bosque. En vez de confiar en que cada árbol de cada escena esté bakeado con
        /// el radio "correcto" (trabajo manual por árbol, no escalable), se comprueba con un
        /// Raycast (sin alloc, un único hit, igual de barato que el resto de chequeos de este
        /// estado) si el siguiente paso choca contra geometría real. Los personajes (jugador/otros
        /// NPCs, distinguibles por NPCSimpleAnimator — ver regla de AGENTS.md §2, "personajes vs.
        /// geometría en raycasts") no cuentan como bloqueo, solo props de escenario como el tronco.
        /// Si hay bloqueo, se da el tramo por completado ahí mismo (mismo criterio que ya usa
        /// SeekShelterState cuando el punto real está demasiado lejos del borde del NavMesh) en
        /// vez de quedarse congelado reintentando para siempre.
        ///
        /// FIX complementario (mismo INC): el propio collider del árbol/prop bajo el que está el
        /// punto de refugio (ownerCollider, ver NPCShelterPoint) se ignora explícitamente — es
        /// justo el obstáculo que esta aproximación manual existe para rodear, y bloquear contra él
        /// reintroduciría el bug original que BeginManualApproach ya arreglaba (el NPC se quedaba
        /// fuera de la copa, "respetando" ese mismo collider, en vez de llegar al punto real). Solo
        /// bloquea contra obstáculos AJENOS al punto de refugio (otro árbol, una roca, un muro).
        /// </summary>
        // FIX INC-NPCS-EN-ARBOLES (14 ago 2026, 2ª pasada): el diagnóstico que SeekShelterState ya
        // deja en consola ("revisar la altura Y del interactionPoint...") avisaba de que la Y
        // autoral del interactionPoint bajo cada árbol puede no coincidir con el suelo real de esa
        // escena (terreno irregular, o el punto colocado a ojo en el editor) — pero solo avisaba,
        // no lo corregía: MoveTowards interpola en línea recta hacia esa Y tal cual, así que un
        // desnivel entre el borde del NavMesh y el punto real se traduce directamente en el NPC
        // hundiéndose o flotando mientras camina el tramo manual (bug reportado por Raúl: "los npcs
        // se hunden en el suelo cuando se van al árbol porque llueve"). Repasar la Y de cada
        // interactionPoint de cada árbol a mano no escala (mismo motivo por el que arriba no se
        // arregla por NavMesh/colliders árbol por árbol) — en su lugar se reancla la Y de cada paso
        // al suelo real, mismo patrón que ya usa el proyecto para esto (ver
        // BossArenaController.PlaceBossOnFloor y AerialKnockbackReceiver._groundProbeMask):
        // Raycast hacia abajo contra las layers "Floor"+"Obstacle" (las únicas que son terreno
        // sólido de verdad, confirmado en AerialKnockbackReceiver). Si no hay suelo real cerca
        // (layer mal puesta, hueco raro), se cae a la Y interpolada de MoveTowards sin más — nunca
        // deja al NPC congelado por esto.
        //
        // "Obstacle" está incluido en la máscara porque puede haber suelo irregular (rocas, raíces)
        // que cuenta como terreno sólido — pero el propio árbol/prop del punto de refugio
        // (ignoreCollider, el mismo que ya se ignora en el chequeo horizontal de más abajo) también
        // puede estar en esa layer, y su copa cuelga precisamente por ENCIMA del punto de refugio:
        // un Raycast de un único hit podría golpear la cara inferior de la copa en vez de atravesarla
        // y llegar al suelo real, colocando al NPC "de pie sobre la copa" en vez de bajo ella —
        // exactamente el síntoma contrario (flotando) al que este fix arregla. Por eso se usa
        // RaycastNonAlloc (buffer fijo, sin alloc, mismo criterio que _obstructionHitsBuffer de
        // AerialKnockbackReceiver) y se descarta cualquier hit contra ignoreCollider, quedándose con
        // el primer hit real más cercano que sí sea terreno.
        private static readonly int GroundProbeMask = LayerMask.GetMask("Floor", "Obstacle");
        private const float GroundProbeHeightAbove = 2f;
        private const float GroundProbeDistance = 6f;
        private static readonly RaycastHit[] GroundProbeHitsBuffer = new RaycastHit[4];

        protected bool ManualApproachStep(Common.NPCStateContext context, Vector3 target, float speed, Collider ignoreCollider = null)
        {
            Transform t = context.Transform;
            Vector3 next = Vector3.MoveTowards(t.position, target, Mathf.Max(0.01f, speed) * Time.deltaTime);

            float probeTop = Mathf.Max(t.position.y, next.y) + GroundProbeHeightAbove;
            int groundHitCount = Physics.RaycastNonAlloc(new Vector3(next.x, probeTop, next.z), Vector3.down,
                GroundProbeHitsBuffer, GroundProbeDistance, GroundProbeMask, QueryTriggerInteraction.Ignore);
            float bestGroundDist = float.MaxValue;
            bool foundGround = false;
            float groundY = next.y;
            for (int i = 0; i < groundHitCount; i++)
            {
                var groundHit = GroundProbeHitsBuffer[i];
                if (groundHit.collider == ignoreCollider) continue; // la copa del propio árbol, no es "suelo"
                if (groundHit.distance < bestGroundDist)
                {
                    bestGroundDist = groundHit.distance;
                    groundY = groundHit.point.y;
                    foundGround = true;
                }
            }
            if (foundGround) next.y = groundY;

            Vector3 step = next - t.position;
            float stepDist = step.magnitude;
            if (stepDist > 0.0001f &&
                Physics.Raycast(t.position + Vector3.up, step / stepDist, out RaycastHit hit, stepDist, ~0, QueryTriggerInteraction.Ignore) &&
                hit.collider != ignoreCollider &&
                hit.transform.GetComponentInParent<NPCSimpleAnimator>() == null)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                context.LogWarning($"[ManualApproach] Paso bloqueado por '{hit.transform.name}' (posible tronco/prop) a {hit.distance:F2}m — no se atraviesa, se da el tramo por completado aquí.");
#endif
                context.Animator?.SetMovementSpeed(0f);
                return true;
            }

            t.position = next;

            Vector3 remaining = target - next;
            Vector3 dir = remaining;
            dir.y = 0f;
            if (dir.sqrMagnitude > 0.0001f)
            {
                Quaternion look = Quaternion.LookRotation(dir.normalized, Vector3.up);
                float turnSpeed = (context.Agent != null && context.Agent.angularSpeed > 1f)
                    ? context.Agent.angularSpeed : 360f;
                t.rotation = Quaternion.RotateTowards(t.rotation, look, turnSpeed * Time.deltaTime);
            }

            context.Animator?.SetMovementSpeed(1f);

            // FIX INC-NPCS-EN-ARBOLES (14 ago 2026, 2ª pasada): la llegada se mide ahora solo en
            // horizontal (dir, ya sin componente Y) en vez de con "remaining" (target - next) en
            // 3D completo. Motivo: next.y ya no seguía necesariamente la Y autoral de target — la
            // corrección de suelo de arriba la reancla al terreno real — así que si esa Y autoral
            // estaba desalineada con el suelo por más que arriveThreshold, "remaining" en 3D nunca
            // bajaba del umbral y el NPC se quedaba caminando en el sitio para siempre sin llegar
            // nunca a Arrive(). La posición vertical la decide el suelo, no interactionPoint; solo
            // importa si ya se llegó en X/Z.
            const float arriveThreshold = 0.05f;
            return dir.sqrMagnitude <= arriveThreshold * arriveThreshold;
        }

        // =================================================================================
        // 🗣️ ENCUENTROS SOCIALES (compartido entre WanderState e IdleState)
        // =================================================================================

        protected static readonly int SocialNpcLayerMask = LayerMask.GetMask("Interactable", "Default");

        /// <summary>
        /// Busca NPCs cercanos con los que iniciar un encuentro social, ponderado por personalidad,
        /// y resuelve la relación combinando el valor forjado en runtime (NPCRelationshipRegistry)
        /// con el valor autor del NPCSocialConfig. Compartido entre WanderState e IdleState para
        /// que los NPCs también puedan socializar mientras están parados, no solo mientras caminan
        /// (ver Diseno_Refugio_Lluvia_y_Relaciones_NPC.md § B.6.2).
        /// </summary>
        protected void CheckSocialEncounter(Common.NPCStateContext context, Collider[] socialBuffer)
        {
            var socialConfig = context.Config?.socialConfig;
            if (socialConfig == null) return;

            // Comprobar cooldown
            if (Time.time - context.LastSocialEncounterTime < socialConfig.socialCooldown) return;

            // El dado de sociabilidad: alta sociabilidad → mayor probabilidad de iniciar
            if (UnityEngine.Random.value > socialConfig.personality.sociability) return;

            float range = socialConfig.socialDetectionRange;
            int count = Physics.OverlapSphereNonAlloc(
                context.Transform.position, range, socialBuffer, SocialNpcLayerMask);

            for (int i = 0; i < count; i++)
            {
                var col = socialBuffer[i];
                if (col == null) continue;

                Transform root = col.transform.root;
                if (root == context.Transform.root) continue; // ignorar a sí mismo

                var partnerManager = root.GetComponent<Game.NPC.NPCBehaviourManagerV2>();
                if (partnerManager == null) continue;

                // Relación "autor" (relationships[] del SO), igual que antes
                string partnerAuthoredId = partnerManager.Configuration?.socialConfig?.npcId;
                NPCRelationType authoredRelation = socialConfig.GetRelationshipWith(partnerAuthoredId);

                // Los enemigos no tienen encuentros sociales amistosos
                if (authoredRelation == NPCRelationType.Enemy) continue;

                // Relación "efectiva": prioriza el vínculo forjado en runtime sobre el autor
                string myId = context.RelationshipId;
                string partnerId = partnerManager.Context?.RelationshipId;
                NPCRelationType relation = NPCRelationshipRegistry.Resolve(myId, partnerId, authoredRelation);

                // Intentar que el otro NPC acepte el encuentro
                if (partnerManager.TryAcceptSocialEncounter(context.Transform, relation))
                {
                    // El partner aceptó: yo también entro en el encuentro
                    context.PendingSocialPartner  = root;
                    context.PendingSocialRelation = relation;
                    context.Brain?.ChangeState(new NPCSocialEncounterState());
                    return;
                }
            }
        }
    }
}
