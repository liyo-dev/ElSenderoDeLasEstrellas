using UnityEngine;
using UnityEngine.AI;
using Game.NPC.Common;

namespace Game.NPC.States
{
    /// <summary>
    /// Estado especial para posicionar a un party member durante un diálogo.
    /// El NPC se mueve a una posición específica (al lado del player) y se queda ahí quieto.
    /// IMPORTANTE: Durante el diálogo, el party member mira al NPC con quien el player habla, NO al player.
    /// </summary>
    public class DialoguePositionState : NPCStateBase
    {
        public override string StateName => "DialoguePosition";

        private readonly NPCPartyMember _partyMember;
        private readonly Vector3 _targetPosition;
        private readonly Transform _npcTarget;
        private readonly float _maxTime;
        private readonly bool _mantenerFueraDelParty;
        
        private float _elapsedTime;
        private bool _hasReachedPosition;
        private bool _hasTeleported;
        private float _originalStoppingDistance;
        private bool _anclado;
        private NPCStateContext _contexto;

        // Override dinámico del objetivo de mirada: en diálogos grupales,
        // DialogueCinematicController lo actualiza en cada línea para que el compañero
        // gire hacia quien está hablando (player, NPC principal u otro compañero).
        // null → comportamiento por defecto (mirar al _npcTarget del diálogo).
        private Transform _lookTargetOverride;

        /// <summary>
        /// Cambia dinámicamente hacia quién mira el compañero mientras está en posición de
        /// diálogo. Pasar null para volver al objetivo por defecto (el NPC del diálogo).
        /// La rotación es suave (ROTATION_SPEED) porque la aplica RotateTowardsTargetSmooth.
        /// </summary>
        public void SetLookTargetOverride(Transform target)
        {
            _lookTargetOverride = target;
        }

        /// <summary>
        /// Deja al NPC fijo donde está: deja de mirar al objetivo y de moverlo, sin salir del
        /// estado. Así tampoco entra en encuentros sociales ni vuelve a Idle. Lo usa la
        /// tripulación del barco al colgarlo de su puesto; se suelta saliendo del estado, como
        /// cualquier posición de diálogo.
        /// </summary>
        public void Anclar()
        {
            _anclado = true;
            _hasReachedPosition = true;
            _hasTeleported = true;

            if (_contexto == null) return;

            var agent = _contexto.Agent;
            if (agent != null && agent.enabled && agent.isOnNavMesh)
            {
                agent.isStopped = true;
                agent.ResetPath();
                agent.updatePosition = false;
                agent.updateRotation = false;
            }

            _contexto.Animator?.SetMovementSpeed(0f);
            _contexto.Animator?.DisableAutoRotation();
        }

        private const float ARRIVAL_THRESHOLD = 0.5f;  // Distancia para considerar que llegó
        // Grados/segundo del giro continuo en posición. Bajado de 360 a 120: a 360 el compañero
        // daba latigazos de cuerpo cada vez que cambiaba el speaker del diálogo grupal — a 120
        // el giro se lee como "se vuelve hacia quien habla", no como un tic nervioso.
        private const float ROTATION_SPEED = 120f;

        public DialoguePositionState(NPCPartyMember partyMember, Vector3 targetPosition, float maxTime,
                                     Transform npcTarget = null, bool mantenerFueraDelParty = false)
        {
            _partyMember = partyMember;
            _targetPosition = targetPosition;
            _maxTime = maxTime;
            _npcTarget = npcTarget;
            _mantenerFueraDelParty = mantenerFueraDelParty;
        }

        public override void OnEnter(NPCStateContext context)
        {
            base.OnEnter(context);
            _contexto = context;
            _elapsedTime = 0f;
            _hasReachedPosition = false;
            _hasTeleported = false;
            _anclado = false;
            
            if (context.Agent != null && context.Agent.isOnNavMesh)
            {
                _originalStoppingDistance = context.Agent.stoppingDistance;
                
                // Si ya fue teleportado a la posición (por PlayerParty.PositionMembersForDialogue),
                // quedarse quieto directamente sin intentar navegar
                float distanceToTarget = Vector3.Distance(context.Transform.position, _targetPosition);
                if (distanceToTarget <= ARRIVAL_THRESHOLD)
                {
                    _hasReachedPosition = true;
                    context.Agent.isStopped = true;
                    context.Agent.updatePosition = false;
                    context.Agent.updateRotation = false;
                    context.Agent.ResetPath();
                    context.Animator?.SetMovementSpeed(0f);
                    context.Animator?.DisableAutoRotation();
                    RotateTowardsTarget(context);
                    return;
                }
                
                // Fallback: si por alguna razón no está en posición, navegar
                context.Agent.isStopped = false;
                context.Agent.updatePosition = true;
                context.Agent.updateRotation = true;
                context.Agent.speed = _partyMember.PartyConfig?.walkSpeed ?? 3.5f;
                context.Agent.stoppingDistance = ARRIVAL_THRESHOLD * 0.5f;
                context.Agent.SetDestination(_targetPosition);
            }
        }

        public override void OnUpdate(NPCStateContext context)
        {
            base.OnUpdate(context);

            // Anclado: el barco lleva el cuerpo; no se gira, no se teletransporta y no se mueve.
            if (_anclado) return;
            
            if (context.Agent == null || !context.Agent.isOnNavMesh)
                return;
            
            _elapsedTime += Time.deltaTime;
            
            // Verificar si llegó a la posición
            float distanceToTarget = Vector3.Distance(context.Transform.position, _targetPosition);
            
            if (!_hasReachedPosition && distanceToTarget <= ARRIVAL_THRESHOLD)
            {
                // ¡Llegó!
                _hasReachedPosition = true;
                
                // Detener movimiento
                context.Agent.isStopped = true;
                context.Agent.updatePosition = false;
                context.Agent.updateRotation = false; // ✅ Desactivar rotación automática del agent
                context.Agent.ResetPath();
                context.Animator?.SetMovementSpeed(0f);
                context.Animator?.DisableAutoRotation();

                // ✅ Girar hacia el NPC con quien el player está hablando (rotación inicial)
                RotateTowardsTarget(context);

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[DialoguePositionState:{context.Transform.name}] ✅ Llegó a posición de diálogo");
#endif
            }
            // Si tarda demasiado, teletransportar
            else if (!_hasTeleported && _elapsedTime > _maxTime && distanceToTarget > ARRIVAL_THRESHOLD)
            {
                _hasTeleported = true;
                
                // Teletransportar
                if (context.Agent.isOnNavMesh)
                {
                    context.Agent.Warp(_targetPosition);
                }
                else
                {
                    context.Transform.position = _targetPosition;
                }
                
                // Detener movimiento
                context.Agent.isStopped = true;
                context.Agent.updatePosition = false;
                context.Agent.updateRotation = false; // ✅ Desactivar rotación automática del agent
                context.Agent.ResetPath();
                context.Animator?.SetMovementSpeed(0f);
                context.Animator?.DisableAutoRotation();

                _hasReachedPosition = true;

                // ✅ Girar hacia el NPC (rotación inicial)
                RotateTowardsTarget(context);

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[DialoguePositionState:{context.Transform.name}] ⚡ Teletransportado a posición de diálogo (tardó {_elapsedTime:F1}s)");
#endif
            }
            // Actualizar animación mientras se mueve
            else if (!_hasReachedPosition)
            {
                UpdateMovementAnimation(context);
            }
            // ✅ NUEVO: Mantener rotación hacia el NPC mientras está en posición de diálogo
            else if (_hasReachedPosition)
            {
                // Mantener rotación suave hacia el NPC target durante todo el diálogo
                RotateTowardsTargetSmooth(context);
            }
        }
        
        /// <summary>
        /// Rota instantáneamente hacia el target (NPC o player como fallback)
        /// </summary>
        private void RotateTowardsTarget(NPCStateContext context)
        {
            if (_npcTarget != null)
            {
                Vector3 dirToNpc = (_npcTarget.position - context.Transform.position).normalized;
                dirToNpc.y = 0;
                
                if (dirToNpc.sqrMagnitude > 0.01f)
                {
                    context.Transform.rotation = Quaternion.LookRotation(dirToNpc);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[DialoguePositionState:{context.Transform.name}] 👁️ Mirando hacia {_npcTarget.name}");
#endif
                }
            }
            else if (PlayerService.TryGetPlayer(out var playerGo))
            {
                Vector3 dirToPlayer = (playerGo.transform.position - context.Transform.position).normalized;
                dirToPlayer.y = 0;
                
                if (dirToPlayer.sqrMagnitude > 0.01f)
                {
                    context.Transform.rotation = Quaternion.LookRotation(dirToPlayer);
                }
            }
        }
        
        /// <summary>
        /// Mantiene rotación suave hacia el target durante el diálogo
        /// </summary>
        private void RotateTowardsTargetSmooth(NPCStateContext context)
        {
            Vector3 targetDir = Vector3.zero;

            // Prioridad: speaker actual (diálogo grupal) → NPC del diálogo → player
            if (_lookTargetOverride != null && _lookTargetOverride != context.Transform)
            {
                targetDir = (_lookTargetOverride.position - context.Transform.position).normalized;
            }
            else if (_npcTarget != null)
            {
                targetDir = (_npcTarget.position - context.Transform.position).normalized;
            }
            else if (PlayerService.TryGetPlayer(out var playerGo))
            {
                targetDir = (playerGo.transform.position - context.Transform.position).normalized;
            }
            
            targetDir.y = 0;
            
            if (targetDir.sqrMagnitude > 0.01f)
            {
                Quaternion targetRot = Quaternion.LookRotation(targetDir);
                context.Transform.rotation = Quaternion.RotateTowards(
                    context.Transform.rotation, 
                    targetRot, 
                    ROTATION_SPEED * Time.deltaTime
                );
            }
        }

        public override void OnExit(NPCStateContext context)
        {
            context.Animator?.EndInteraction();
            context.Animator?.EnableAutoRotation();

            if (context.Agent != null && context.Agent.isOnNavMesh)
            {
                context.Agent.updatePosition = true;
                context.Agent.updateRotation = true;
                context.Agent.stoppingDistance = _originalStoppingDistance;
            }

            base.OnExit(context);
        }

        public override INPCState CheckTransitions(NPCStateContext context)
        {
            // Anclado (barco): el puesto manda hasta que se libere con Soltar(). Si no, una
            // transición de combate o cinemática lo saca del barco y lo devuelve a AllyCombatState
            // mientras sigue colgado de su puesto (ver INC-808).
            if (_anclado) return null;

            // Prioridad 1: Cinemática
            if (context.IsInCinematic) return new CinematicState();
            
            // Prioridad 2: Combate
            if (context.IsInCombat) return new AllyCombatState();
            
            // Prioridad 3: Ya no está en el party (salvo que quien lo llamó pida mantenerlo,
            // como el Will de la IA al subir al barco).
            if (!_mantenerFueraDelParty && (_partyMember == null || !_partyMember.IsInParty))
            {
                return new IdleState();
            }
            
            // Mantenerse en este estado hasta que se libere manualmente
            return null;
        }
    }
}
