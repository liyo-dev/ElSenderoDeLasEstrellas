using System;
using System.Collections;
using System.Collections.Generic;
using Game.NPC.Common;
using UnityEngine;
using UnityEngine.AI;

/// <summary>
/// Sistema profesional de animaciones para NPCs.
/// El ÚNICO responsable de controlar las animaciones del NPC.
/// Todos los demás sistemas (FSM, Combat, Quest, etc.) piden animaciones aquí.
/// </summary>
[DisallowMultipleComponent]
[RequireComponent(typeof(Animator))]
public class NPCSimpleAnimator : MonoBehaviour
{
    #region Serialized Fields
    
    [Header("Core Components")]
    [SerializeField] private Animator animator;
    [SerializeField] private NavMeshAgent navAgent;
    
    [Header("Animation States")]
    [Tooltip("Estado de locomotion base (ej: Free Locomotion blend tree)")]
    [SerializeField] private string locomotionState = "Free Locomotion";
    
    [Tooltip("Estado de idle normal")]
    [SerializeField] private string idleNormalState = "Idle_Normal_NoWeapon";
    
    [Tooltip("Estado de idle en batalla")]
    [SerializeField] private string idleBattleState = "Idle_Battle_NoWeapon";
    
    [Header("Animation Layers")]
    [Tooltip("Índice de la capa para animaciones de torso superior (ataques)")]
    [SerializeField] private int upperBodyLayer = 1;

    [Header("Locomotion Settings")]
    [Tooltip("Velocidad mínima para considerar que está en movimiento")]
    [SerializeField, Range(0.01f, 0.5f)] private float movementThreshold = 0.1f;
    
    [Tooltip("Multiplicador de velocidad de animación durante locomoción")]
    [SerializeField, Range(0.5f, 2f)] private float locomotionSpeedMultiplier = 1.0f;
    
    [Tooltip("Tiempo de blend para transiciones de locomoción")]
    [SerializeField, Range(0f, 0.5f)] private float locomotionBlendTime = 0.1f;
    
    [Tooltip("Dampening del parámetro InputMagnitude")]
    [SerializeField, Range(0f, 0.5f)] private float inputMagnitudeDampTime = 0.1f;
    
    [Header("Rotation Settings")]
    [Tooltip("Velocidad de rotación del NPC (grados/segundo)")]
    [SerializeField, Range(90f, 720f)] private float rotationSpeed = 360f;
    
    [Tooltip("Ángulo mínimo para considerar que debe rotar")]
    [SerializeField, Range(1f, 45f)] private float minRotationAngle = 5f;
    
    [Header("Interaction")]
    [SerializeField] private string interactState = "Talk01";
    [SerializeField] private string greetingState = "Greeting01_NoWeapon";

    [Header("Saludo al inicio de diálogo")]
    [Tooltip("Si está activo, reproduce una animación de saludo al iniciar un diálogo")]
    [SerializeField] private bool playGreetingOnDialogueStart = false;
    [Tooltip("Animación de saludo (ej: HandWave01, Reverence01, HeadNod01)")]
    [SerializeField] private string greetingDialogueState = "HandWave01";

    [Header("Idle Variations")]
    [Tooltip("Activar variaciones de idle aleatorias cuando el NPC está parado")]
    [SerializeField] private bool enableIdleVariations = true;
    [Tooltip("Estados de idle variante (deben existir en el Animator Controller)")]
    [SerializeField] private string[] idleVariationStates = { "Idle02_NoWeapon", "Idle03_NoWeapon" };
    [Tooltip("Tiempo mínimo en segundos entre variaciones")]
    [SerializeField, Range(3f, 60f)] private float minIdleVariationInterval = 8f;
    [Tooltip("Tiempo máximo en segundos entre variaciones")]
    [SerializeField, Range(5f, 120f)] private float maxIdleVariationInterval = 20f;
    [Tooltip("Variación individual de velocidad solo en los estados idle preparados por el menú de animación.")]
    [SerializeField, Range(0f, 0.05f)] private float variacionVelocidadIdle = 0.05f;
    [Tooltip("Segundos que tarda en soltarse un gesto de medio cuerpo al acabar. Con 0 se suelta de golpe.")]
    [SerializeField, Range(0f, 0.6f)] private float salidaDeGesto = 0.25f;
    private static readonly int VariacionIdleHash = Animator.StringToHash("VariacionIdle");
    private int _ultimaVariacionIdle = -1;
    
    [Header("Combat Animations")]
    [SerializeField] private string challengingState = "Challenging_NoWeapon";
    [SerializeField] private string senseSomethingState = "SenseSomethingStart_NoWeapon";
    [SerializeField] private string searchingState = "SenseSomethingSearching_NoWeapon"; // Animación cuando pierde de vista al jugador
    [SerializeField] private string defendState = "Idle_Battle_NoWeapon"; // Fallback a Battle Idle si no existe Defend
    
    [Tooltip("Animaciones de daño (se alterna aleatoriamente entre ellas para variedad)")]
    [SerializeField] private string[] getHitStates = new string[] { "TakeDamage", "TakeDamage_2" };
    
    [SerializeField] private string defendHitState = "DefendHit_NoWeapon"; // Animación cuando el escudo bloquea un ataque
    [SerializeField] private string dieState = "Die02_NoWeapon";
    [SerializeField] private string dizzyState = "Dizzy_NoWeapon"; // Animación de mareo después de levantarse
    [SerializeField] private string victoryState = "Victory_NoWeapon"; // Animación de victoria cuando el NPC gana
    
    [Header("Spell Cast Animations (UpperBody Layer)")]
    [Tooltip("Animación de disparo con mano izquierda")]
    [SerializeField] private string spellCastLeftState = "MagicLeft";
    
    [Tooltip("Animación de disparo con mano derecha")]
    [SerializeField] private string spellCastRightState = "MagicRight";
    
    [Tooltip("Animación de disparo especial (ambas manos)")]
    [SerializeField] private string spellCastSpecialState = "MagicSpecial";
    
    [Header("Root Motion")]
    [Tooltip("Usar Root Motion durante animaciones especiales")]
    [SerializeField] private bool useRootMotionForSpecialAnims = false;
    
    [Header("Debug")]
    [SerializeField] private bool debugMode = false;
    [SerializeField] private bool drawGizmos = true;
    
    #endregion
    
    #region Private Fields
    
    // Animation state
    private AnimationState _currentState = AnimationState.Idle;
    private bool _isInBattle;
    private bool _isInteracting;
    private float _currentMovementSpeed;
    private Vector3 _lastPosition;
    private float _actualSpeed;
    
    // Spell casting hand alternation
    private int _lastSpellHand = -1; // -1 = ninguno, 0 = izquierda, 1 = derecha
    
    // Animator parameters
    private static readonly int InputMagnitudeHash = Animator.StringToHash("InputMagnitude");

    // ✅ FIX: parámetros de suelo/vuelo del controller compartido de personajes jugables
    // (Will/Liam/Estela usan el Animator Controller de Invector, que trae un Any State →
    // "Falling" condicionado a IsGrounded=false / GroundDistance>0.25 / isFlying=false).
    // El controller genérico de NPCs (Eldran) no tiene ese Any State, así que esto es
    // inofensivo para él. Ver ForceGroundedForSit().
    private static readonly int HashIsGrounded    = Animator.StringToHash("IsGrounded");
    private static readonly int HashGroundDistance = Animator.StringToHash("GroundDistance");
    private static readonly int HashIsFlying      = Animator.StringToHash("isFlying");
    private HashSet<int> _animatorParamHashes;

    private EmotionProfile _emotionProfile;
    
    // References
    private Transform _player;
    private Transform _playerCam;
    private Interactable _interactable;
    
    // Coroutines
    private Coroutine _oneShotCoroutine;
    private int _oneShotLayer;
    private Coroutine _salidaDeGesto;
    private int _capaQueSeSuelta = -1;
    private Coroutine _rotationCoroutine;
    private Coroutine _idleVariationCoroutine;
    private Coroutine _activityCoroutine;
    private Coroutine _victoryCelebrationCoroutine;

    // Índice de ciclo de Talk para variedad (Neutral)
    private int _lastTalkIndex = -1;
    
    // Caches
    private AnimatorStateCache _stateCache;
    private Dictionary<string, float> _clipLengthCache = new Dictionary<string, float>();
    
    // Smooth rotation
    private Quaternion _targetRotation;
    private float _rotationVelocity;

    // ✅ Anti-spam para animaciones de idle
    private float _lastBattleIdleTime = -999f;
    private const float BattleIdleCooldown = 0.5f; // Mínimo 0.5s entre llamadas (antes 0.3s)
    private bool _disableAutoRotation; // Flag para desactivar rotación automática (usado durante diálogos)

    // ✅ FIX: recuerda si el NPC está sentado (PlayAmbientActivity con un Sit*) para que un
    // PlaySocialGesture/PlayOneShot lanzado durante un diálogo (p.ej. TabernaSequencer) no lo
    // deje de pie al terminar. Antes TransitionToIdle() siempre iba a idleNormalState, ignorando
    // que el NPC seguía sentado en la silla.
    private bool _isSeated;
    private NPCAmbientActivity _seatedActivity;
    
    // ✅ Corrutina para seguimiento de rotación durante diálogos
    private Coroutine _dialogueLookAtCoroutine;
    
    #endregion
    
    #region Public Properties
    
    /// <summary>
    /// Permite a sistemas externos (como narrativas) tomar control de la rotación.
    /// </summary>
    public bool AllowManualRotation { get; set; }

    /// <summary>
    /// FIX 5 sep 2026 (incidencia animación rota en escolta Eldran/guardia — "otra animación",
    /// brazos bajados, sin brinquitos de andar, "patinando sobre hielo"): permite a sistemas
    /// externos (CinematicState durante MoveToAction / LeadPlayerToAnchorSequence) tomar control
    /// EXPLÍCITO del parámetro InputMagnitude vía SetMovementSpeed(), desactivando el auto-sync de
    /// velocidad de SyncWithNavMeshAgent() mientras tanto. Sin esto, Update() de este mismo
    /// componente llama a SyncWithNavMeshAgent() TODOS los frames, sin ninguna comprobación de
    /// IsInCinematic, y esa función escribe su propio valor en InputMagnitude usando un mapa de
    /// dos segmentos sobre navAgent.velocity.magnitude — una fórmula de normalización DISTINTA a
    /// la que usa CinematicState (ComputeWalkGaitSpeedFactor con velocidad de referencia fija).
    /// Las dos llamadas a SetMovementSpeed() del mismo frame se pisan mutuamente sin coordinación
    /// (gana la que se ejecute última según el orden de Update() de Unity, no determinista), así
    /// que el blend tree recibe un valor que salta entre ambos cálculos en vez de seguir una
    /// progresión coherente — de ahí el aspecto de "otra animación completamente distinta" pese a
    /// que el Animator sigue correctamente dentro del estado "Free Locomotion" (confirmado con
    /// DebugLocomotionStateCheck(): enLocomotion=True, rootMotion=False, upperBodyW=0 durante todo
    /// el bug). Ver AllowManualRotation arriba para el precedente equivalente ya existente para
    /// rotación; a diferencia de esa, esta bandera NO toca la lógica de rotación de
    /// SyncWithNavMeshAgent(), solo su cálculo de velocidad.
    /// </summary>
    public bool AllowManualMovement { get; set; }

    /// <summary>
    /// Indica si el NPC está en modo batalla
    /// </summary>
    public bool IsInBattle => _isInBattle;

    /// <summary>
    /// DEBUG TEMPORAL (5 sep 2026, incidencia animación rota en escolta Eldran/guardia): resumen
    /// de diagnóstico del estado real del Animator en el momento de la llamada — para confirmar o
    /// descartar por datos (no suposición) si el problema es: (a) el CrossFade a "locomotionState"
    /// falló silenciosamente y el layer base sigue en otro estado, (b) applyRootMotion sigue en
    /// true cuando no debería, o (c) la capa UpperBody tiene peso >0 por una vía distinta a
    /// _isInBattle. Quitar junto con el resto de logs [ELDRAN_ANIM_DEBUG] cuando se cierre esto.
    public string DebugLocomotionStateCheck()
    {
        if (animator == null) return "no-animator";
        var info = animator.GetCurrentAnimatorStateInfo(0);
        bool isLoco = !string.IsNullOrEmpty(locomotionState) && info.IsName(locomotionState);
        bool transitioning = animator.IsInTransition(0);
        float upperW = (upperBodyLayer > 0 && upperBodyLayer < animator.layerCount)
            ? animator.GetLayerWeight(upperBodyLayer)
            : -1f;
        return $"enLocomotion={isLoco} enTransicion={transitioning} normTime={info.normalizedTime:F2} rootMotion={animator.applyRootMotion} upperBodyW={upperW:F2} animSpeed={animator.speed:F2}";
    }
    
    /// <summary>
    /// Indica si el NPC está en modo batalla (layer de Battle activo)
    /// </summary>
    public bool IsInBattleMode => _isInBattle;
    
    /// <summary>
    /// Indica si el NPC está actualmente reproduciendo la animación de mareo (dizzy)
    /// </summary>
    public bool IsInDizzyAnimation()
    {
        if (animator == null || string.IsNullOrEmpty(dizzyState))
            return false;

        AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo(0);
        return stateInfo.IsName(dizzyState);
    }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
    /// <summary>
    /// Solo para diagnóstico en Editor/Development Build: valor actual del InputMagnitude
    /// que este NPCSimpleAnimator está aplicando al Animator.
    /// </summary>
    public float DebugCurrentMovementSpeed => _currentMovementSpeed;

    /// <summary>
    /// Solo para diagnóstico: el NavMeshAgent que este NPCSimpleAnimator está usando
    /// para sincronizar la animación de locomoción (SyncWithNavMeshAgent). Si no coincide
    /// con el agente que un sistema externo está moviendo (p.ej. un sequencer cinemático),
    /// la animación nunca reflejará el movimiento real.
    /// </summary>
    public NavMeshAgent DebugSyncedAgent => navAgent;
#endif

    #endregion
    
    #region Enums
    
    public enum AnimationState
    {
        Idle,
        Walking,
        Running,
        Battle,
        Interacting,
        OneShot,
        Dead
    }
    
    #endregion
    
    #region Unity Lifecycle
    
    void Reset()
    {
        animator = GetComponent<Animator>();
        if (animator == null)
            animator = GetComponentInChildren<Animator>();
        navAgent = GetComponent<NavMeshAgent>();
    }
    
    void Awake()
    {
        // Sentado, la espalda y la cabeza se enderezan (las animaciones de sentado encorvan a los chibis).
        PosturaDeSentado.Asegurar(gameObject);
        // Al hablar solo se mueve la boca: la cabeza no cabecea con Talk01-03 (INC-1144).
        CabezaQuietaAlHablar.Asegurar(gameObject);

        // Get components
        if (animator == null)
        {
            animator = GetComponent<Animator>();
            if (animator == null)
                animator = GetComponentInChildren<Animator>();
        }
        
        if (navAgent == null)
            navAgent = GetComponent<NavMeshAgent>();
        
        _interactable = GetComponent<Interactable>();
        var emotionController = GetComponent<NPCEmotionController>();
        if (emotionController != null)
            _emotionProfile = emotionController.EmotionProfile;
        
        // Initialize
        if (animator != null)
        {
            animator.applyRootMotion = useRootMotionForSpecialAnims;
            _stateCache = new AnimatorStateCache(animator);
            CacheAnimationClips();

            // ✅ FIX: cachear qué parámetros existen realmente en ESTE Animator Controller.
            // Eldran (NPC_NoWeapon.controller) no tiene IsGrounded/GroundDistance/isFlying;
            // Will/Liam/Estela sí (Invector@BasicLocomotion.controller). Sin esta guarda,
            // SetBool/SetFloat sobre un parámetro inexistente sería un no-op silencioso pero
            // costoso (y con warnings en editor); con ella, ForceGroundedForSit() es seguro
            // de llamar en cualquier NPC sin comprobar antes qué controller tiene.
            _animatorParamHashes = new HashSet<int>();
            var animParams = animator.parameters;
            for (int i = 0; i < animParams.Length; i++)
                _animatorParamHashes.Add(animParams[i].nameHash);
            if (_animatorParamHashes.Contains(VariacionIdleHash))
                animator.SetFloat(VariacionIdleHash, UnityEngine.Random.Range(1f - variacionVelocidadIdle, 1f + variacionVelocidadIdle));
        }
        
        // ✅ FIX CRÍTICO: Configurar NavMeshAgent para control de rotación correcto
        if (navAgent != null)
        {
            // Desactivar rotación automática del NavMeshAgent
            navAgent.updateRotation = false;
            
            // Asegurar que angularSpeed sea lo suficientemente alto
            if (navAgent.angularSpeed < 120f)
            {
                if (debugMode)
                    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.LogWarning($"[NPCAnimator] NavMeshAgent.angularSpeed muy bajo ({navAgent.angularSpeed}), aumentando a 360°/s");
#endif
                    }
                navAgent.angularSpeed = 360f;
            }
        }
        
        _lastPosition = transform.position;
        _targetRotation = transform.rotation;

        SombraDeContacto.Asegurar(gameObject);
        MuelleDeHuesos.AsegurarCapa(gameObject);

        // La animación de andar ya no depende de las velocidades de la configuración (walkSpeed,
        // runSpeed, partyConfig): se calcula con la velocidad real en m/s, igual para todos. Con
        // las de party (5 y 10 m/s), Oliver andando a 2 m/s daba 0,2 en el blend tree y se
        // deslizaba sin mover las piernas. Ver NavMeshAgentUtility.FactorDeLocomocion (INC-466).

        // Bind to interactable if exists
        if (_interactable != null)
        {
            _interactable.OnStarted.AddListener(OnInteractionStarted);
            _interactable.OnFinished.AddListener(OnInteractionFinished);
        }
        
        ResolvePlayerReferences();
        
        // ✅ Suscribirse a eventos del DialogueManager
        DialogueManager.OnDialogueStarted += OnDialogueStarted;
        DialogueManager.OnDialogueClosed += OnDialogueClosed;
    }
    
    void OnDisable()
    {
        PararLaPose();
        // Una capa a medio soltar se quedaría con peso al apagarse el componente.
        if (_capaQueSeSuelta > 0 && animator != null && _capaQueSeSuelta < animator.layerCount)
            animator.SetLayerWeight(_capaQueSeSuelta, 0f);
        _salidaDeGesto = null;
        _capaQueSeSuelta = -1;
    }

    void OnDestroy()
    {
        // ✅ Desuscribirse de eventos del DialogueManager
        DialogueManager.OnDialogueStarted -= OnDialogueStarted;
        DialogueManager.OnDialogueClosed -= OnDialogueClosed;
        
        // Detener corrutina si existe
        if (_dialogueLookAtCoroutine != null)
        {
            StopCoroutine(_dialogueLookAtCoroutine);
            _dialogueLookAtCoroutine = null;
        }
    }
    
    void Start()
    {
        // Start in idle state
        TransitionToIdle();
    }
    
    void Update()
    {
        if (animator == null)
            return;
        
        // ✅ No procesar nada si el NPC está muerto
        if (_currentState == AnimationState.Dead)
            return;
        
        // Update actual speed based on position
        UpdateActualSpeed();
        
        // ✅ Sincronizar automáticamente con NavMeshAgent si existe y está activo
        // No necesita configuración manual - es siempre automático
        if (navAgent != null && navAgent.enabled && navAgent.isOnNavMesh)
        {
            SyncWithNavMeshAgent();
        }
    }
    
    void LateUpdate()
    {
        // ✅ No procesar rotación si el NPC está muerto
        if (_currentState == AnimationState.Dead)
            return;
            
        // Apply smooth rotation in LateUpdate for best results
        ApplySmoothRotation();
    }
    
    #endregion
    
    #region Public API - Movement & Speed
    
    /// <summary>
    /// Establece la velocidad de movimiento del NPC (0-1 normalizado)
    /// </summary>
    public void SetMovementSpeed(float normalizedSpeed, float dampTime = -1f)
    {
        if (animator == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[NPCAnimator] SetMovementSpeed llamado pero animator es null");
#endif
            return;
        }
        
        // ✅ No procesar movimiento si el NPC está muerto
        if (_currentState == AnimationState.Dead)
            return;
        
        _currentMovementSpeed = Mathf.Clamp01(normalizedSpeed);
        
        // Use configured damp time if not specified
        float damp = dampTime < 0 ? inputMagnitudeDampTime : dampTime;
        
        // Set animator parameter
        animator.SetFloat(InputMagnitudeHash, _currentMovementSpeed, damp, Time.deltaTime);
        
        // ✅ FIX CRÍTICO: SIEMPRE asegurar que animator.speed sea 1.0 cuando está quieto
        // Esto previene el temblor en Battle Idle cuando _currentMovementSpeed es muy bajo
        if (_currentMovementSpeed <= movementThreshold)
        {
            // ✅ IMPERATIVO: Velocidad normal cuando está quieto (evita temblor)
            animator.speed = 1f;
            if ((_currentState == AnimationState.Walking || _currentState == AnimationState.Running) && _poseSostenida != null)
            {
                TransitionToIdle();
            }
        }
        // Adjust animation speed to match movement speed (reduces foot sliding)
        else if (_currentMovementSpeed > movementThreshold)
        {
            animator.speed = Mathf.Lerp(1f, locomotionSpeedMultiplier, _currentMovementSpeed);
            
            // Ensure we're in locomotion state if moving
            if (_isInBattle && !_isInteracting)
            {
                if (_currentState != AnimationState.Walking && _currentState != AnimationState.Running)
                {
                    TransitionToLocomotion();
                }
            }
            else if ((_currentState == AnimationState.Idle || (_currentState == AnimationState.OneShot && _poseSostenida != null)) && !_isInteracting)
            {
                TransitionToLocomotion();
            }
        }
    }
    
    /// <summary>
    /// Resetea el movimiento a 0
    /// </summary>
    public void ResetMovement()
    {
        // ✅ No hacer nada si el NPC está muerto
        if (_currentState == AnimationState.Dead)
            return;
        
        // ✅ Forzar a 0 INMEDIATAMENTE sin dampening para evitar bugs de "andando en el sitio"
        _currentMovementSpeed = 0f;
        if (animator != null)
        {
            animator.SetFloat(InputMagnitudeHash, 0f);
            animator.speed = 1f;
        }
    }
    
    /// <summary>
    /// Para todo movimiento inmediatamente
    /// </summary>
    public void StopMovement()
    {
        ResetMovement();
        if (animator != null)
            animator.speed = 1f;
    }
    
    #endregion
    
    #region Public API - Battle Mode
    
    /// <summary>
    /// Activa/desactiva el modo batalla
    /// </summary>
    public void SetBattleMode(bool enable)
    {
        // ✅ No hacer nada si el NPC está muerto
        if (_currentState == AnimationState.Dead)
        {
            if (debugMode)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAnimator] SetBattleMode({enable}) ignorado - NPC está muerto");
#endif
                }
            return;
        }
        
        _isInBattle = enable;

        if (enable)
            StopIdleVariations();

        if (animator == null)
            return;

        // Set upper body layer weight
        if (upperBodyLayer > 0 && upperBodyLayer < animator.layerCount)
        {
            animator.SetLayerWeight(upperBodyLayer, enable ? 1f : 0f);
        }
        
        // Transition to appropriate state
        if (enable)
        {
            _currentState = AnimationState.Battle;

            // ✅ FIX (5 sep 2026, petición de Raúl): Idle_Battle_NoWeapon vive en la UpperBody
            // layer (torso/brazos, AvatarMask sin piernas) -- antes se reproducía en la Base
            // Layer (capa 0), que es la misma capa que controla el blend tree de locomoción
            // ("Free Locomotion"). Mientras la Base Layer se quedaba parada en esta pose de
            // cuerpo entero, cualquier NPC de combate que tuviera que caminar hacia el jugador
            // nada más entrar en combate se deslizaba sin mover las piernas hasta que
            // SetMovementSpeed()/TransitionToLocomotion() lograba recuperar la Base Layer (con
            // retraso, según lo rápido que acelerase el NavMeshAgent). Con la pose en UpperBody,
            // la Base Layer nunca sale del blend tree de locomoción -- las piernas caminan con
            // normalidad desde el primer frame -- y por eso ya no hace falta esperar a que el
            // NPC esté parado (_currentMovementSpeed < movementThreshold) para mostrarla.
            //
            // Guard _oneShotCoroutine == null: no cortar un one-shot que ya esté sonando en la
            // UpperBody layer (p. ej. PlayChallengingForBattle, que hace su propio CrossFade a
            // este mismo estado al terminar el Challenging).
            if (_oneShotCoroutine == null)
            {
                CrossFadeToState(idleBattleState, 0.2f, upperBodyLayer);
            }
        }
        else
        {
            _currentState = AnimationState.Idle;
            TransitionToIdle();
        }
        
        if (debugMode)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator] Battle mode: {enable}");
#endif
            }
    }
    
    /// <summary>
    /// Reproduce el idle de batalla
    /// Con protección anti-spam: solo cambia si no está ya en el estado
    /// </summary>
    public void PlayBattleIdle()
    {
        if (_isInBattle && !string.IsNullOrEmpty(idleBattleState))
        {
            // ✅ CRÍTICO: Cooldown para evitar spam de CrossFade
            // Si se llama demasiado frecuentemente, se reinicia la animación constantemente
            // causando temblor en el modelo y el Enemy Marker
            float timeSinceLastCall = Time.time - _lastBattleIdleTime;
            if (timeSinceLastCall < BattleIdleCooldown)
            {
                // Llamada demasiado frecuente, ignorar
                return;
            }
            
            // ✅ FIX (5 sep 2026): Idle_Battle_NoWeapon vive en UpperBody layer (ver
            // SetBattleMode) -- se comprueba y se reproduce en upperBodyLayer, no en la capa 0,
            // para no depender de la Base Layer (blend tree de locomoción) ni congelar piernas.
            // Guard _oneShotCoroutine == null: no cortar un ataque/hechizo en curso en esa misma capa.
            if (_oneShotCoroutine == null)
            {
                int targetHash = Animator.StringToHash(idleBattleState);
                AnimatorStateInfo currentState = animator.GetCurrentAnimatorStateInfo(upperBodyLayer);

                if (currentState.shortNameHash != targetHash)
                {
                    _lastBattleIdleTime = Time.time;
                    CrossFadeToState(idleBattleState, 0.2f, upperBodyLayer);
                }
            }
        }
    }
    
    /// <summary>
    /// Restaura el idle normal (permite transiciones de locomoción)
    /// </summary>
    public void PlayIdleNormal()
    {
        // Una actividad ambiental en curso (sentarse, comer, beber) dejaría viva su corrutina y,
        // al terminar su tramo Begin, volvería a poner el Loop pisando esta pose. Forzar idle
        // normal cancela también esa actividad. Va fuera del if del estado porque hay
        // controladores sin idleNormalState (ver PosarIdleDePie).
        DetenerActividadAmbiental();

        // Desactivar modo batalla para permitir transiciones de locomoción
        _isInBattle = false;
        _isSeated = false; // fuerza de pie explícitamente (usado al liberar un asiento)
        _currentState = AnimationState.Idle;
        PosarIdleDePie(0.2f);
    }
    
    /// <summary>
    /// Entra en modo batalla (método de conveniencia)
    /// </summary>
    public void EnterBattleMode()
    {
        SetBattleMode(true);
    }
    
    /// <summary>
    /// Sale del modo batalla (método de conveniencia)
    /// </summary>
    public void ExitBattleMode()
    {
        SetBattleMode(false);
    }
    
    #endregion
    
    #region Public API - One Shot Animations
    
    /// <summary>
    /// Reproduce una animación one-shot (ataque, habilidad, etc.)
    /// </summary>
    public void PlayOneShot(string stateName, int layer = 0, Action onComplete = null, float fundido = 0.08f)
    {
        if (string.IsNullOrEmpty(stateName))
            return;
        
        // Stop any current one-shot
        if (_oneShotCoroutine != null)
        {
            StopCoroutine(_oneShotCoroutine);
            // El gesto cortado estaba en otra capa de medio cuerpo: se suelta, o se quedaría puesto.
            if (_oneShotLayer > 0 && _oneShotLayer != layer) SoltarCapa(_oneShotLayer);
        }
        if (_capaQueSeSuelta == layer) DejarDeSoltar();

        // Y cualquier pose sostenida en este layer: un gesto nuevo manda sobre la pose que hubiera en su misma capa,
        // sin romper poses de otra capa (p.ej. un gesto de manos no debe interrumpir caer/volar en la capa base).
        PararLaPose(layer);
        
        _oneShotLayer = layer;
        _oneShotCoroutine = StartCoroutine(PlayOneShotCoroutine(stateName, layer, onComplete, fundido));
    }

    // ── Poses sostenidas ──────────────────────────────────────────────────────────────────────
    //
    // Un gesto es un DISPARO: se reproduce y, al acabar el clip, PlayOneShotCoroutine llama a
    // TransitionToIdle(). Para saludar está bien. Para una pose que tiene que DURAR —volar,
    // sostener un hechizo, quedarse en el aire— es exactamente lo contrario de lo que hace falta,
    // y es lo que Raúl veía en el prólogo: «cuando se encadenan varias animaciones, por ejemplo
    // salto y vuelo y disparo, o si se tiene que quedar volando, hay momentos donde pasa a idle».
    //
    // Antes esto se apañaba repitiendo el gesto N veces, y salían las dos formas del mismo fallo:
    // si la repetición llegaba antes de acabar el clip, la animación se reiniciaba desde el
    // fotograma 0 (el tirón, «parece que se ha quedado pillado»); si llegaba después, se colaba un
    // idle. Y la última repetición terminaba su corrutina en pleno vuelo y mandaba a idle a un
    // personaje que estaba a veinte metros de altura.
    //
    // HoldPose no repite nada: cruza UNA vez y se queda vigilando. Solo vuelve a cruzar si el
    // Animator se ha salido de la pose (porque otro sistema le ha mandado a idle o a locomoción),
    // así que en el caso normal el clip no se reinicia nunca. Un clip cíclico se ve en bucle; uno
    // que no lo es se queda congelado en su último fotograma, que para una pose en el aire es
    // justo lo que se quiere.
    private readonly Coroutine[] _poseCoroutines = new Coroutine[4];
    private readonly string[] _posesSostenidas = new string[4];
    private readonly bool[] _congelarPoseAlFinal = new bool[4];
    private string _poseSostenida => (_posesSostenidas.Length > 1 && !string.IsNullOrEmpty(_posesSostenidas[1])) ? _posesSostenidas[1] : _posesSostenidas[0];

    /// ¿Hay ahora mismo una pose sostenida? Lo pregunta quien podría pisarla sin querer — el
    /// relanzador de gestos de hablar de SayBeat, sin ir más lejos.
    public bool SosteniendoPose => (_poseCoroutines[0] != null && !string.IsNullOrEmpty(_posesSostenidas[0]))
        || (_poseCoroutines[1] != null && !string.IsNullOrEmpty(_posesSostenidas[1]));

    /// Mantiene una pose hasta que alguien diga lo contrario. Idempotente: pedir la pose que ya
    /// está puesta no la reinicia.
    public void HoldPose(string stateName, int layer = -1, bool congelarAlFinal = false, float fundido = 0.12f, bool alFinal = false)
    {
        if (string.IsNullOrEmpty(stateName) || animator == null || _currentState == AnimationState.Dead ||
            !isActiveAndEnabled || !gameObject.activeInHierarchy)
            return;

        if (layer < 0) layer = AnimatorLayerUtil.ResolveLayer(animator, stateName, upperBodyLayer);
        if (layer < 0 || layer >= _poseCoroutines.Length)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[NPCAnimator:{gameObject.name}] HoldPose('{stateName}'): ese estado no " +
                "existe en ningún layer válido de este Animator Controller. La pose no se va a ver.");
#endif
            return;
        }

        if (_posesSostenidas[layer] == stateName && _poseCoroutines[layer] != null)
        {
            _congelarPoseAlFinal[layer] = congelarAlFinal;
            return;
        }

        // Un gesto en curso en la capa de la pose se cierra aquí: si acabara después, soltaría la capa con la pose puesta.
        if (_oneShotCoroutine != null && (layer == 0 || _oneShotLayer == layer)) { StopCoroutine(_oneShotCoroutine); _oneShotCoroutine = null; }
        PararLaPose(layer);
        if (_capaQueSeSuelta == layer) DejarDeSoltar();

        _posesSostenidas[layer] = stateName;
        _congelarPoseAlFinal[layer] = congelarAlFinal;
        _poseCoroutines[layer] = StartCoroutine(SostenerPose(stateName, layer, fundido, congelarAlFinal, alFinal));
    }

    /// Suelta la pose. Por defecto devuelve al personaje a su pose normal; con `aIdle` a false lo
    /// deja donde esté, que es lo que hace falta cuando lo siguiente es otro gesto y no se quiere
    /// un idle de un fotograma entre medias.
    public void ReleasePose(bool aIdle = true)
    {
        PararLaPose(-1);

        if (aIdle && _currentState != AnimationState.Dead)
        {
            _currentState = AnimationState.Idle;
            TransitionToIdle();
            if (animator != null && upperBodyLayer > 0 && upperBodyLayer < animator.layerCount)
                animator.SetLayerWeight(upperBodyLayer, 0f);
        }
    }

    /// <summary>
    /// Suelta la pose de carga de dos manos y devuelve la capa UpperBody a su peso normal.
    /// No usa ReleasePose(true): eso devolvería TODO el personaje a idle y pisaría la animación
    /// de dejar la caja, que vive en la capa base.
    /// </summary>
    /// Suelta solo la pose de medio cuerpo; la de cuerpo entero (sentado, tumbado) sigue puesta.
    public void SoltarPoseDeMedioCuerpo()
    {
        if (upperBodyLayer <= 0 || upperBodyLayer >= _poseCoroutines.Length || _poseCoroutines[upperBodyLayer] == null) return;
        PararLaPose(upperBodyLayer);
        SoltarCapa(upperBodyLayer);
    }

    public void SoltarPoseDeCarga()
    {
        ReleasePose(false);

        if (animator != null && upperBodyLayer > 0 && upperBodyLayer < animator.layerCount)
            animator.SetLayerWeight(upperBodyLayer, 0f);
    }

    private void PararLaPose(int layer = -1)
    {
        if (layer < 0)
        {
            for (int i = 0; i < _poseCoroutines.Length; i++)
            {
                if (_poseCoroutines[i] != null) StopCoroutine(_poseCoroutines[i]);
                _poseCoroutines[i] = null;
                _posesSostenidas[i] = null;
                _congelarPoseAlFinal[i] = false;
            }
            if (animator != null && animator.speed == 0f) animator.speed = 1f;
            return;
        }

        if (layer < _poseCoroutines.Length)
        {
            if (_poseCoroutines[layer] != null) StopCoroutine(_poseCoroutines[layer]);
            _poseCoroutines[layer] = null;
            _posesSostenidas[layer] = null;
            _congelarPoseAlFinal[layer] = false;
            if (layer == 0 && animator != null && animator.speed == 0f) animator.speed = 1f;
        }
    }

    private IEnumerator SostenerPose(string stateName, int layer, float fundido, bool congelarAlFinal, bool alFinal)
    {
        if (layer == 0) _currentState = AnimationState.OneShot;
        if (layer > 0 && layer < animator.layerCount) animator.SetLayerWeight(layer, 1f);

        string resolvedStatePath = AnimatorLayerUtil.ResolveStatePath(animator, stateName, layer);
        int hash = Animator.StringToHash(resolvedStatePath);
        float targetNorm = stateName == "FoundSomething_NoWeapon" ? 0.65f : 0.98f;

        bool poseCongelada = false;
        if (alFinal)
        {
            animator.Play(hash, layer, targetNorm);
            poseCongelada = true;
        }
        else
        {
            CrossFadeToState(stateName, fundido, layer);
        }
        yield return null;

        try
        {
            while (true)
            {
                yield return null;
                if (animator == null) yield break;

                // Solo se recruza si se ha salido de verdad. Mientras esté en la pose —o entrando en
                // ella— no se toca, que es lo que evita el reinicio del clip.
                var actual = animator.GetCurrentAnimatorStateInfo(layer);
                var siguiente = animator.IsInTransition(layer) ? animator.GetNextAnimatorStateInfo(layer) : actual;

                if (actual.IsName(stateName))
                {
                    bool sale = animator.IsInTransition(layer) && !siguiente.IsName(stateName);
                    if (congelarAlFinal && !actual.loop)
                    {
                        if (actual.normalizedTime >= targetNorm || sale || poseCongelada)
                        {
                            animator.Play(hash, layer, targetNorm);
                            if (layer == 0) animator.speed = 0f;
                            poseCongelada = true;
                            continue;
                        }
                    }
                    else if (sale && actual.loop)
                    {
                        animator.Play(hash, layer, Mathf.Repeat(actual.normalizedTime, 1f));
                        continue;
                    }
                    continue;
                }
                if (animator.IsInTransition(layer)) continue;

                if (poseCongelada)
                {
                    animator.Play(hash, layer, targetNorm);
                }
                else
                {
                    CrossFadeToState(stateName, 0.12f, layer);
                }
            }
        }
        finally
        {
            if (layer == 0 && animator != null && animator.speed == 0f)
                animator.speed = 1f;
        }
    }
    
    private IEnumerator PlayOneShotCoroutine(string stateName, int layer, Action onComplete, float fundido)
    {
        _currentState = AnimationState.OneShot;
        
        // Ensure animation speed is normal
        if (animator != null)
            animator.speed = 1f;
        
        // Set layer weight if needed
        if (layer > 0 && layer < animator.layerCount)
        {
            animator.SetLayerWeight(layer, 1f);
        }
        
        // Play animation
        CrossFadeToState(stateName, fundido, layer);
        
        yield return null; // Wait one frame for transition to start
        
        // Wait for animation to complete
        float clipLength = GetClipLength(stateName);
        float waitTime = Mathf.Max(0.1f, clipLength);
        
        if (debugMode)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator] Playing one-shot: {stateName}, length: {waitTime:F2}s");
#endif
            }
        
        // Wait using normalized time for accuracy
        float elapsed = 0f;
        while (elapsed < waitTime + 0.2f)
        {
            var stateInfo = animator.GetCurrentAnimatorStateInfo(layer);
            if (stateInfo.IsName(stateName) && stateInfo.normalizedTime >= 0.95f)
            {
                break;
            }
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        // Callback
        onComplete?.Invoke();
        
        // ✅ NO hacer transición a Idle si el NPC está muerto
        // Esto previene que se cancele la animación de muerte
        if (_currentState == AnimationState.Dead)
        {
            if (debugMode)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAnimator] OneShot completado pero NPC está muerto - NO transicionar a Idle");
#endif
                }
            _oneShotCoroutine = null;
            yield break; // ✅ Usar yield break en lugar de return en coroutines
        }
        
        // Return to idle if not interacting (let the callback handle battle state)
        if (!_isInteracting && !_isInBattle)
        {
            if (layer == 0)
            {
                _currentState = AnimationState.Idle;
                TransitionToIdle();
            }
            else if (animator != null && layer < animator.layerCount)
            {
                SoltarCapa(layer);
            }
        }
        else if (_isInteracting)
        {
            PlayInteractionPose(0.15f);
        }
        
        _oneShotCoroutine = null;
    }

    /// Baja el peso de una capa de medio cuerpo hasta 0 en `salidaDeGesto` segundos, para que el
    /// final de un gesto se funda con la pose de debajo en vez de saltar a ella.
    private void SoltarCapa(int layer)
    {
        DejarDeSoltar();
        if (animator == null || layer <= 0 || layer >= animator.layerCount) return;
        if (salidaDeGesto <= 0f || !isActiveAndEnabled)
        {
            animator.SetLayerWeight(layer, 0f);
            return;
        }
        _capaQueSeSuelta = layer;
        _salidaDeGesto = StartCoroutine(SoltarCapaPocoAPoco(layer));
    }

    /// Deja de soltar la capa que se estuviera soltando (un gesto o una pose nuevos la toman).
    private void DejarDeSoltar()
    {
        if (_salidaDeGesto != null) StopCoroutine(_salidaDeGesto);
        _salidaDeGesto = null;
        _capaQueSeSuelta = -1;
    }

    private IEnumerator SoltarCapaPocoAPoco(int layer)
    {
        float desde = animator.GetLayerWeight(layer);
        float puesto = desde;
        float transcurrido = 0f;
        while (transcurrido < salidaDeGesto)
        {
            yield return null;
            if (animator == null) break;
            // Otro sistema ha cambiado el peso de la capa: es suya, ya no se suelta.
            if (Mathf.Abs(animator.GetLayerWeight(layer) - puesto) > 0.001f)
            {
                _salidaDeGesto = null;
                _capaQueSeSuelta = -1;
                yield break;
            }
            transcurrido += Time.deltaTime;
            puesto = Mathf.Lerp(desde, 0f, Mathf.SmoothStep(0f, 1f, transcurrido / salidaDeGesto));
            animator.SetLayerWeight(layer, puesto);
        }
        if (animator != null) animator.SetLayerWeight(layer, 0f);
        _salidaDeGesto = null;
        _capaQueSeSuelta = -1;
    }
    
    #endregion
    
    #region Public API - Interaction
    
    /// <summary>
    /// Inicia una interacción
    /// </summary>
    public void BeginInteraction() => BeginInteraction(girarAlJugador: true);

    private int _retencionesDePanel;

    /// Un panel que se abre hablando con el NPC (álbum, tienda, pregunta…) lo retiene: se queda
    /// quieto y de cara al jugador aunque la charla ya haya terminado. Cada Retener lleva su Soltar.
    /// Ver INC-1159.
    public void RetenerPorPanel()
    {
        _retencionesDePanel++;
        BeginInteraction();
    }

    public void SoltarPorPanel()
    {
        if (_retencionesDePanel <= 0) return;
        if (--_retencionesDePanel > 0) return;
        EndInteraction();
        EnableAutoRotation();
    }

    /// <param name="girarAlJugador">
    /// Girarse hacia el jugador al empezar a hablar. En el juego es lo correcto: te acercas a un
    /// NPC y se vuelve hacia ti. En una CINEMÁTICA es un fallo (INC-318), y de los gordos: el
    /// jugador está donde esté —en el prólogo, Will está durmiendo al otro lado del pueblo— así
    /// que cada personaje que abre la boca se gira hacia allí.
    ///
    /// Eso explica, de una vez, todos los «se gira y mira a nadie» del prólogo: el Archimago al
    /// decir «con cuidado», Liora al decir «no te tomas ni un día libre», el Mago Oscuro al decir
    /// «arrodillaos», y los dos girados en la última conversación. Ninguno era del encuadre.
    /// </param>
    public void BeginInteraction(bool girarAlJugador)
    {
        if (_isInteracting)
            return;

        StopIdleVariations();

        _isInteracting = true;
        _currentState = AnimationState.Interacting;
        
        if (girarAlJugador && _player != null && !_disableAutoRotation)
        {
            FaceTarget(_player.position);
        }
        
        PlayInteractionPose(0.15f);
        
        if (debugMode)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log("[NPCAnimator] Begin interaction");
#endif
            }
    }

    private void PlayInteractionPose(float transitionTime)
    {
        if (animator == null || _currentState == AnimationState.Dead)
            return;

        if (!_isSeated && !_isInBattle)
        {
            const string baseInteractState = "InteractWithPeople_NoWeapon";
            if (animator.HasState(0, Animator.StringToHash(baseInteractState)))
            {
                CrossFadeToState(baseInteractState, transitionTime, 0);
            }
        }

        if (!string.IsNullOrEmpty(interactState))
        {
            int layer = AnimatorLayerUtil.ResolveLayer(animator, interactState, upperBodyLayer);
            if (layer >= 0)
            {
                if (layer > 0 && layer < animator.layerCount)
                    animator.SetLayerWeight(layer, 1f);
                CrossFadeToState(interactState, transitionTime, layer);
            }
        }
    }
    
    /// <summary>
    /// Finaliza una interacción
    /// </summary>
    public void EndInteraction()
    {
        if (!_isInteracting)
            return;
        // Retenido por un panel abierto desde la charla: lo suelta SoltarPorPanel. Ver INC-1159.
        if (_retencionesDePanel > 0)
            return;
        
        _isInteracting = false;

        // Un gesto puntual en curso (p. ej. Oliver lanzando su hechizo justo cuando acaba de
        // hablar) no se corta. Antes, cerrar la charla 0,05 s después de lanzar el gesto lo pisaba
        // con el idle y no llegaba a verse. Si el gesto es de cuerpo entero (capa base), el propio
        // one-shot devuelve al NPC a su reposo al acabar; si es de la capa de brazos, se deja esa
        // capa en paz y solo la base vuelve al reposo.
        bool gestoEnCurso = _oneShotCoroutine != null && !_isInBattle;
        if (gestoEnCurso && _oneShotLayer == 0) return;

        if (!gestoEnCurso && !_isInBattle && !SosteniendoPose && _activityCoroutine == null &&
            animator != null && upperBodyLayer > 0 && upperBodyLayer < animator.layerCount)
        {
            if (animator.HasState(upperBodyLayer, Animator.StringToHash("Empty")))
                CrossFadeToState("Empty", 0.15f, upperBodyLayer);
            else
                animator.SetLayerWeight(upperBodyLayer, 0f);
        }
        
        // Return to appropriate state
        if (_isInBattle)
        {
            PlayBattleIdle();
            _currentState = AnimationState.Battle;
        }
        else
        {
            TransitionToIdle();
        }
        
        if (debugMode)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log("[NPCAnimator] End interaction");
#endif
            }
    }
    
    /// <summary>
    /// Reproduce el saludo configurado para ESTE NPC (greetingState, editable en el Inspector —
    /// cada NPC puede tener su propio gesto: Greeting01_NoWeapon, HandWave02, Reverence01...).
    /// </summary>
    /// <param name="onComplete">
    /// ✅ NUEVO (1 sep 2026, petición de Raúl): callback opcional invocado cuando el gesto termina
    /// de verdad (mismo mecanismo que PlayOneShot). Si el guard de abajo impide reproducirlo
    /// (_isInteracting activo o greetingState vacío), se invoca igualmente al momento para no
    /// dejar colgado a quien esté esperando el callback — ver
    /// NPCInteractiveNarrativeExecutor.ExecuteNarrativeChain.
    /// </param>
    public void PlayGreeting(Action onComplete = null)
    {
        if (!_isInteracting && !string.IsNullOrEmpty(greetingState))
        {
            // El gesto configurado vive en UpperBody layer (no debe congelar las piernas)
            PlayOneShot(greetingState, upperBodyLayer, onComplete);
        }
        else
        {
            onComplete?.Invoke();
        }
    }
    
    /// <summary>
    /// Establece si está hablando (para animaciones de boca)
    /// NOTA: Requiere parámetro 'IsTalking' en el Animator Controller
    /// </summary>
    public void SetTalking(bool isTalking)
    {
        if (animator != null && animator.parameterCount > 0)
        {
            // Solo intentar si el parámetro existe
            foreach (AnimatorControllerParameter param in animator.parameters)
            {
                if (param.name == "IsTalking")
                {
                    animator.SetBool("IsTalking", isTalking);
                    return;
                }
            }
            
            if (debugMode)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCAnimator] Parámetro 'IsTalking' no encontrado en Animator Controller");
#endif
                }
        }
    }
    
    #endregion
    
    #region Public API - Combat Animations
    
    /// <summary>
    /// Reproduce animación de desafío
    /// </summary>
    public void PlayChallenging()
    {
        if (!string.IsNullOrEmpty(challengingState))
        {
            // Challenging_NoWeapon vive en UpperBody layer (no debe congelar las piernas)
            PlayOneShot(challengingState, upperBodyLayer);
        }
    }
    
    /// <summary>
    /// Reproduce animación de Challenge y luego va a Idle Battle
    /// </summary>
    public void PlayChallengingForBattle()
    {
        if (!string.IsNullOrEmpty(challengingState))
        {
            // Challenging_NoWeapon vive en UpperBody layer (no debe congelar las piernas)
            PlayOneShot(challengingState, upperBodyLayer, () =>
            {
                _isInBattle = true;
                _currentState = AnimationState.Battle;
                
                // ✅ FIX (5 sep 2026): Idle_Battle_NoWeapon también vive en UpperBody layer
                // (ver comentario detallado en SetBattleMode) -- antes esto reproducía la pose
                // en la Base Layer y dejaba las piernas congeladas si el NPC tenía que caminar.
                if (!string.IsNullOrEmpty(idleBattleState))
                {
                    CrossFadeToState(idleBattleState, 0.2f, upperBodyLayer);
                }
            });
        }
        else
        {
            _isInBattle = true;
            _currentState = AnimationState.Battle;
            if (!string.IsNullOrEmpty(idleBattleState))
            {
                CrossFadeToState(idleBattleState, 0.15f, upperBodyLayer);
            }
        }
    }


    /// <summary>
    /// Reproduce la animación de alerta configurada para ESTE NPC (senseSomethingState, editable
    /// en el Inspector).
    /// </summary>
    /// <param name="onComplete">
    /// ✅ NUEVO (1 sep 2026): callback opcional invocado cuando la animación termina de verdad
    /// (mismo mecanismo que PlayGreeting/PlayOneShot). Si senseSomethingState está vacío se
    /// invoca igualmente al momento.
    /// </param>
    public void PlaySenseSomething(Action onComplete = null)
    {
        if (!string.IsNullOrEmpty(senseSomethingState))
        {
            // El gesto configurado vive en UpperBody layer (no debe congelar las piernas)
            PlayOneShot(senseSomethingState, upperBodyLayer, onComplete);
        }
        else
        {
            onComplete?.Invoke();
        }
    }
    
    /// <summary>
    /// Reproduce animación de búsqueda (cuando pierde de vista al jugador).
    /// Se usa típicamente cuando el NPC huye y luego se detiene sin ver al player.
    /// </summary>
    public void PlaySearching()
    {
        if (!string.IsNullOrEmpty(searchingState))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator:{gameObject.name}] 🔍 PlaySearching() - Buscando al jugador");
#endif
            // SenseSomethingSearching_NoWeapon vive en UpperBody layer (no debe congelar las piernas)
            PlayOneShot(searchingState, upperBodyLayer);
        }
    }
    
    /// <summary>
    /// Reproduce animación de defensa
    /// </summary>
    public void PlayDefend()
    {
        if (!string.IsNullOrEmpty(defendState))
        {
            PlayOneShot(defendState);
        }
    }
    
    /// <summary>
    /// Reproduce animación de recibir daño.
    /// Si hay múltiples animaciones configuradas, selecciona una aleatoriamente para variedad.
    /// </summary>
    public void PlayGetHit()
    {
        if (getHitStates == null || getHitStates.Length == 0)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[NPCAnimator:{gameObject.name}] ⚠️ No hay animaciones de daño configuradas");
#endif
            return;
        }
        
        // Seleccionar animación aleatoria del array
        string selectedHitAnim = getHitStates[UnityEngine.Random.Range(0, getHitStates.Length)];
        
        if (!string.IsNullOrEmpty(selectedHitAnim))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator:{gameObject.name}] 💥 PlayGetHit() - Animación seleccionada: '{selectedHitAnim}' ({getHitStates.Length} variantes disponibles)");
#endif
            PlayOneShot(selectedHitAnim);
        }
    }
    
    /// <summary>
    /// Reproduce animación de bloqueo con escudo (cuando el escudo absorbe un ataque)
    /// </summary>
    public void PlayDefendHit()
    {
        if (!string.IsNullOrEmpty(defendHitState))
        {
            PlayOneShot(defendHitState);
        }
    }
    
    /// <summary>
    /// Reproduce animación de muerte
    /// </summary>
    public void PlayDeath()
    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[NPCAnimator:{gameObject.name}] 💀 PlayDeath() llamado - dieState: '{dieState}'");
#endif
        
        if (!string.IsNullOrEmpty(dieState))
        {
            _currentState = AnimationState.Dead;
            StopIdleVariations();
            
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator:{gameObject.name}] 🎬 Reproduciendo animación de muerte: {dieState}");
#endif
            
            // Usar Play directamente para reproducir la animación de muerte inmediatamente
            // CrossFade puede causar que la animación no se vea si el NPC muere muy rápido
            if (animator != null)
            {
                // Resetear el parámetro InputMagnitude a 0 para evitar movimiento residual
                animator.SetFloat(InputMagnitudeHash, 0f);
                animator.Play(dieState, 0); // Layer 0, reproducción inmediata
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAnimator:{gameObject.name}] ✅ animator.Play('{dieState}', 0) ejecutado");
#endif
            }
            
            // Desactivar el NavMeshAgent si existe
            if (navAgent != null && navAgent.isOnNavMesh)
            {
                navAgent.isStopped = true;
                navAgent.velocity = Vector3.zero;
                navAgent.updateRotation = false;
                navAgent.updatePosition = false;
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAnimator:{gameObject.name}] NavMeshAgent detenido");
#endif
            }
            
            // NO desactivar el componente inmediatamente - dejar que la animación se reproduzca
            // enabled = false;  // ❌ COMENTADO - Esto evitaba que la animación se reprodujera
            
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator:{gameObject.name}] ✅ Animación de muerte iniciada");
#endif
        }
        else
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[NPCAnimator:{gameObject.name}] ⚠️ dieState está vacío - no se puede reproducir animación de muerte");
#endif
        }
    }
    
    [Tooltip("Animación de levantarse del suelo tras caer en combate (compañeros del grupo, INC-717). Vacío o inexistente = vuelve directamente a idle.")]
    [SerializeField] private string getUpState = "GetUp_NoWeapon";

    /// <summary>
    /// Sale de la pose de muerte: se levanta y vuelve a su animación normal. Lo usan los
    /// compañeros del grupo al ser reanimados (CuerpoDelGrupo, INC-717).
    /// </summary>
    public void Levantarse()
    {
        if (_currentState != AnimationState.Dead) return;
        _currentState = AnimationState.Idle;

        if (navAgent != null)
        {
            if (navAgent.isOnNavMesh) navAgent.Warp(transform.position);
            navAgent.updatePosition = true;
            navAgent.updateRotation = true;
            if (navAgent.isOnNavMesh) navAgent.isStopped = false;
        }

        if (animator != null && !string.IsNullOrEmpty(getUpState) && animator.HasState(0, Animator.StringToHash(getUpState)))
            PlayOneShot(getUpState);
        else
            TransitionToIdle();
    }

    /// <summary>
    /// Reproduce animación de victoria
    /// </summary>
    public void PlayVictory()
    {
        if (!string.IsNullOrEmpty(victoryState))
        {
            PlayOneShot(victoryState);
        }
    }
    
    /// <summary>
    /// Reproduce animación de mareo después de levantarse (post-derrota)
    /// El NPC se levanta aturdido y permanece en estado de mareo
    /// </summary>
    public void PlayDizzy()
    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[NPCAnimator:{gameObject.name}] 😵 PlayDizzy() llamado - dizzyState: '{dizzyState}'");
#endif
        
        if (!string.IsNullOrEmpty(dizzyState))
        {
            // Cambiar a estado normal (no muerto)
            _currentState = AnimationState.Idle;
            
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator:{gameObject.name}] 🎬 Reproduciendo animación de mareo: {dizzyState}");
#endif
            
            if (animator != null)
            {
                // Reproducir la animación de mareo
                animator.Play(dizzyState, 0);
                animator.speed = 1f; // Asegurar velocidad normal
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAnimator:{gameObject.name}] ✅ animator.Play('{dizzyState}', 0) ejecutado");
#endif
            }
            
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator:{gameObject.name}] ✅ Animación de mareo iniciada");
#endif
        }
        else
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[NPCAnimator:{gameObject.name}] ⚠️ dizzyState está vacío - no se puede reproducir animación de mareo");
#endif
        }
    }
    
    #endregion
    
    #region Public API - Spell Casting
    
    /// <summary>
    /// Reproduce animación de disparo de hechizo con alternancia automática de manos.
    /// Usa UpperBody layer y vuelve automáticamente a locomotion al terminar.
    /// </summary>
    public void PlaySpellCast()
    {
        // Alternar entre mano izquierda y derecha
        if (_lastSpellHand != 0) // Si la última fue derecha o ninguna, usar izquierda
        {
            PlaySpellCastLeft();
        }
        else // Si la última fue izquierda, usar derecha
        {
            PlaySpellCastRight();
        }
    }
    
    /// <summary>
    /// Reproduce animación de disparo con mano izquierda (UpperBody layer)
    /// </summary>
    public void PlaySpellCastLeft()
    {
        if (!string.IsNullOrEmpty(spellCastLeftState))
        {
            _lastSpellHand = 0;
            
            if (debugMode)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAnimator] PlaySpellCastLeft: {spellCastLeftState} en layer {upperBodyLayer}");
#endif
                }
            
            // Reproducir en el UpperBody layer con callback para volver a locomotion
            PlaySpellCastInternal(spellCastLeftState);
        }
    }
    
    /// <summary>
    /// Reproduce animación de disparo con mano derecha (UpperBody layer)
    /// </summary>
    public void PlaySpellCastRight()
    {
        if (!string.IsNullOrEmpty(spellCastRightState))
        {
            _lastSpellHand = 1;
            
            if (debugMode)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAnimator] PlaySpellCastRight: {spellCastRightState} en layer {upperBodyLayer}");
#endif
                }
            
            // Reproducir en el UpperBody layer con callback para volver a locomotion
            PlaySpellCastInternal(spellCastRightState);
        }
    }
    
    /// <summary>
    /// Reproduce animación de disparo especial con ambas manos (UpperBody layer)
    /// </summary>
    public void PlaySpellCastSpecial()
    {
        if (!string.IsNullOrEmpty(spellCastSpecialState))
        {
            _lastSpellHand = 2; // Marcar como especial
            
            if (debugMode)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAnimator] PlaySpellCastSpecial: {spellCastSpecialState} en layer {upperBodyLayer}");
#endif
                }
            
            // Reproducir en el UpperBody layer con callback para volver a locomotion
            PlaySpellCastInternal(spellCastSpecialState);
        }
    }
    
    /// <summary>
    /// Método interno para reproducir animaciones de spell cast en UpperBody layer
    /// </summary>
    private void PlaySpellCastInternal(string stateName)
    {
        if (string.IsNullOrEmpty(stateName) || animator == null)
            return;
        
        // Asegurar que el UpperBody layer esté activo
        if (upperBodyLayer > 0 && upperBodyLayer < animator.layerCount)
        {
            animator.SetLayerWeight(upperBodyLayer, 1f);
        }
        
        // Reproducir la animación en el UpperBody layer usando PlayOneShot
        // NO forzar transición a locomotion en el callback - dejar que el animator lo maneje naturalmente
        PlayOneShot(stateName, upperBodyLayer, () =>
        {
            if (debugMode)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAnimator] Spell cast completado en UpperBody layer");
#endif
                }
            
            // El UpperBody layer volverá a su estado idle automáticamente
            // El Base Layer (piernas) puede continuar con locomotion si se está moviendo
            // NO hacer nada aquí - dejar que el sistema fluya naturalmente
        });
    }
    
    #endregion
    
    #region Public API - Rotation
    
    /// <summary>
    /// Hace que el NPC mire hacia un objetivo
    /// </summary>
    public void FaceTarget(Vector3 targetPosition)
    {
        Vector3 direction = targetPosition - transform.position;
        direction.y = 0f;
        
        if (direction.sqrMagnitude < 0.001f)
            return;
        
        _targetRotation = Quaternion.LookRotation(direction.normalized);
    }
    
    /// <summary>
    /// Hace que el NPC mire hacia una dirección
    /// </summary>
    public void FaceDirection(Vector3 direction)
    {
        direction.y = 0f;
        
        if (direction.sqrMagnitude < 0.001f)
            return;
        
        _targetRotation = Quaternion.LookRotation(direction.normalized);
    }
    
    /// <summary>
    /// Desactiva la rotación automática (útil durante diálogos cuando otro sistema controla la rotación)
    /// </summary>
    public void DisableAutoRotation()
    {
        _disableAutoRotation = true;
    }
    
    /// <summary>
    /// Reactiva la rotación automática
    /// </summary>
    public void EnableAutoRotation()
    {
        _disableAutoRotation = false;
        
        // ✅ FIX: Sincronizar _targetRotation con la rotación actual del transform
        // Esto evita que al reactivar, el NPC gire hacia una dirección antigua
        _targetRotation = transform.rotation;
    }

    /// <summary>
    /// FIX INC-028: sincroniza únicamente el objetivo de rotación suave (_targetRotation) con la
    /// rotación actual del transform, SIN tocar _disableAutoRotation (a diferencia de
    /// EnableAutoRotation()). _targetRotation se cachea una sola vez en Awake() con la rotación
    /// que el NPC tiene en la escena en ese momento; si después algo reposiciona/reorienta al NPC
    /// externamente (p.ej. GameBootProfile aplicando la rotación persistida al cargar partida) sin
    /// llamar a esto, ApplySmoothRotation() lo arrastra en los siguientes frames de vuelta hacia esa
    /// rotación cacheada — SyncWithNavMeshAgent() no la actualiza mientras el agente esté parado/sin
    /// path, así que un NPC quieto (p.ej. Eldran esperando fuera de la taberna) se queda girando
    /// hacia la rotación por defecto de la escena en vez de mantener la que se acaba de restaurar.
    /// </summary>
    public void SyncTargetRotation()
    {
        _targetRotation = transform.rotation;
    }
    
    #region Dialogue Events
    
    /// <summary>
    /// Callback cuando se inicia un diálogo. Solo responde si este NPC es el involucrado.
    /// </summary>
    private void OnDialogueStarted(Transform npcInvolved)
    {
        // Solo procesar si este NPC es el que está en el diálogo
        if (npcInvolved != transform)
            return;
        
        if (debugMode)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator:{name}] 📢 OnDialogueStarted recibido");
#endif
            }
        
        // Detener cualquier corrutina previa
        if (_dialogueLookAtCoroutine != null)
        {
            StopCoroutine(_dialogueLookAtCoroutine);
        }
        
        // Rotar instantáneamente hacia el jugador y desactivar rotación automática
        FacePlayerInstantly();

        // Saludo opcional antes de que BeginInteraction fije la animación
        if (playGreetingOnDialogueStart && !string.IsNullOrEmpty(greetingDialogueState))
        {
            PlayOneShot(greetingDialogueState, 0, () =>
            {
                if (_isInteracting) CrossFadeToState(interactState, 0.15f);
            });
        }

        // Iniciar la corrutina de seguimiento continuo
        _dialogueLookAtCoroutine = StartCoroutine(KeepLookingAtPlayerDuringDialogue());
    }
    
    /// <summary>
    /// Callback cuando se cierra un diálogo. Solo responde si este NPC es el involucrado.
    /// </summary>
    private void OnDialogueClosed(Transform npcInvolved)
    {
        // Solo procesar si este NPC es el que estaba en el diálogo
        if (npcInvolved != transform)
            return;

        // Un panel abierto desde la charla (álbum, tienda…) lo mantiene de cara al jugador hasta
        // que se cierre: el final del diálogo llega DESPUÉS de que el panel lo retenga. Ver INC-1159.
        if (_retencionesDePanel > 0)
        {
            if (_dialogueLookAtCoroutine != null)
            {
                StopCoroutine(_dialogueLookAtCoroutine);
                _dialogueLookAtCoroutine = null;
            }
            return;
        }
        
        if (debugMode)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator:{name}] 📢 OnDialogueClosed recibido");
#endif
            }
        
        // Detener la corrutina de seguimiento
        if (_dialogueLookAtCoroutine != null)
        {
            StopCoroutine(_dialogueLookAtCoroutine);
            _dialogueLookAtCoroutine = null;
        }
        
        // Finalizar animación de interacción
        EndInteraction();
        
        // Reactivar la rotación automática después de un frame
        // para asegurar que el diálogo se cerró completamente
        StartCoroutine(ReactivateAutoRotationDelayed());
    }
    
    /// <summary>
    /// Mantiene al NPC mirando al jugador durante todo el diálogo
    /// </summary>
    private IEnumerator KeepLookingAtPlayerDuringDialogue()
    {
        // Obtener referencia al DialogueManager para verificar si el diálogo está abierto
        var dialogueManager = DialogueManager.Instance;
        
        if (_player == null)
        {
            if (PlayerService.TryGetPlayer(out var playerGo, allowSceneLookup: true) && playerGo != null)
            {
                _player = playerGo.transform;
            }
        }
        
        if (_player == null)
        {
            if (debugMode)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCAnimator:{name}] KeepLookingAtPlayerDuringDialogue - No se encontró el jugador");
                #endif
            }
            yield break;
        }
        
        if (debugMode)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator:{name}] 👁️ Seguimiento de rotación iniciado durante diálogo");
#endif
            }
        
        // Mantener rotación hacia el jugador mientras el diálogo esté abierto
        while (dialogueManager != null && dialogueManager.IsOpen && _player != null)
        {
            // Calcular dirección hacia el jugador (solo horizontal)
            Vector3 directionToPlayer = _player.position - transform.position;
            directionToPlayer.y = 0f;
            
            if (directionToPlayer.sqrMagnitude > 0.001f)
            {
                Quaternion targetRotation = Quaternion.LookRotation(directionToPlayer);
                
                // Rotar suavemente hacia el jugador (por si se mueve)
                transform.rotation = Quaternion.RotateTowards(
                    transform.rotation, 
                    targetRotation, 
                    rotationSpeed * Time.unscaledDeltaTime
                );
                
                // Sincronizar _targetRotation
                _targetRotation = transform.rotation;
            }
            
            yield return null;
        }
        
        if (debugMode)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator:{name}] 🔚 Seguimiento de rotación durante diálogo finalizado");
#endif
            }
    }
    
    /// <summary>
    /// Reactiva la rotación automática después de un frame
    /// </summary>
    private IEnumerator ReactivateAutoRotationDelayed()
    {
        // Esperar 1 frame para asegurar que el diálogo se cerró completamente
        yield return null;
        
        EnableAutoRotation();
        
        if (debugMode)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator:{name}] ✅ Rotación automática reactivada");
#endif
            }
    }
    
    #endregion
    
    /// <summary>
    /// Gira instantáneamente hacia el jugador (para inicio de diálogos).
    /// Desactiva la rotación automática para evitar conflictos.
    /// </summary>
    /// <returns>True si la rotación fue exitosa</returns>
    public bool FacePlayerInstantly()
    {
        // Buscar el jugador si no tenemos referencia
        if (_player == null)
        {
            if (PlayerService.TryGetPlayer(out var playerGo, allowSceneLookup: true) && playerGo != null)
            {
                _player = playerGo.transform;
            }
        }
        
        if (_player == null)
        {
            if (debugMode)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCAnimator:{name}] FacePlayerInstantly: No se encontró jugador");
                #endif
            }
            return false;
        }
        
        // Desactivar rotación automática para evitar que interfiera
        _disableAutoRotation = true;
        
        // Calcular dirección al jugador (solo horizontal)
        Vector3 directionToPlayer = _player.position - transform.position;
        directionToPlayer.y = 0f;
        
        if (directionToPlayer.sqrMagnitude > 0.001f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(directionToPlayer);
            transform.rotation = targetRotation;
            _targetRotation = targetRotation; // Sincronizar para evitar snapping posterior
            
            if (debugMode) 
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAnimator:{name}] 👁️ Rotado INSTANTÁNEAMENTE hacia el jugador (ángulo: {targetRotation.eulerAngles.y:F1}°)");
#endif
                }
            
            return true;
        }
        
        return false;
    }
    
    /// <summary>
    /// Rota el NPC suavemente hacia un objetivo durante un tiempo
    /// </summary>
    public void RotateTowardsTarget(Transform target, float duration = 0.3f)
    {
        if (_rotationCoroutine != null)
        {
            StopCoroutine(_rotationCoroutine);
        }
        
        _rotationCoroutine = StartCoroutine(RotateTowardsCoroutine(target, duration));
    }
    
    private IEnumerator RotateTowardsCoroutine(Transform target, float duration)
    {
        float elapsed = 0f;
        Quaternion startRotation = transform.rotation;
        
        while (elapsed < duration && target != null)
        {
            Vector3 direction = target.position - transform.position;
            direction.y = 0f;
            
            if (direction.sqrMagnitude > 0.001f)
            {
                Quaternion targetRot = Quaternion.LookRotation(direction.normalized);
                float t = Mathf.Clamp01(elapsed / duration);
                transform.rotation = Quaternion.Slerp(startRotation, targetRot, t);
            }
            
            elapsed += Time.deltaTime;
            yield return null;
        }
        
        _rotationCoroutine = null;
    }
    
    #endregion
    
    #region Public API - Social & Emotions

    /// <summary>
    /// Reproduce una animación corporal acorde a la emoción del NPC durante el diálogo.
    /// Las emociones Neutral/None rotan entre Talk01/02/03 para variedad.
    /// Si la emoción tiene el campo "Anim Corporal" vacío en el EmotionProfile, NO se reproduce
    /// ninguna animación: el NPC se queda con el gesto/pose que tuviera en ese momento (permite
    /// emociones que solo cambian la cara, sin tocar el cuerpo).
    /// Solo actúa si el NPC está en estado Interacting.
    /// </summary>
    // ── La cara, no solo el cuerpo (FIX 16 sep 2026) ─────────────────────────
    //
    // Raúl: "no veo que se cambie la cara de Will... cuando Oliver durante la explicación del menú
    // tampoco las cambia". Causa raíz: PlayBodyEmotion() solo tocaba el CUERPO. La cara
    // (NPCEmotionController.SetEmotion, que intercambia los meshes de ojos y boca) no la llamaba
    // NADIE en el camino de diálogo -- solo la llamaban a mano los sequencers escritos uno a uno
    // (EstelaAppears, LiamCrystalBall, MagoOscuro...). Es decir: en TODO el juego, ningún diálogo
    // normal ha cambiado nunca una cara, aunque su DialogueLine llevara emoción.
    //
    // Lo delata el propio comentario de ResolveBodyAnimStateName más abajo: habla de "emociones que
    // solo cambian la cara" y devuelve cadena vacía para ellas... pero como la cara no se tocaba,
    // esas emociones no hacían absolutamente nada.
    //
    // Se arregla aquí, en el punto por el que ya pasa todo el mundo, en vez de en cada llamador.
    private NPCEmotionController _emotionControllerCached;
    private bool _emotionControllerResolved;

    /// Resolución PEREZOSA a propósito: ver el comentario de EmotionControllerResolver — en Awake()
    /// el criterio todavía no es fiable porque depende de datos que cada controlador rellena en su
    /// propio Awake(), y el orden entre componentes del mismo GameObject no está garantizado.
    private NPCEmotionController ResolvedEmotionController
    {
        get
        {
            if (!_emotionControllerResolved)
            {
                _emotionControllerResolved = true;
                _emotionControllerCached = Game.NPC.Common.EmotionControllerResolver.Resolve(gameObject);
            }
            return _emotionControllerCached;
        }
    }

    /// Cambia la cara del personaje. None = sin cambio (se mantiene la que tenga puesta).
    public void SetFaceEmotion(NPCEmotion emotion)
    {
        if (emotion == NPCEmotion.None) return;
        var controlador = ResolvedEmotionController;
        if (controlador != null) controlador.Reaccionar(emotion);
    }

    public void PlayBodyEmotion(NPCEmotion emotion)
    {
        if (_currentState == AnimationState.Dead)
            return;

        // La cara reacciona con independencia de la animación corporal.
        SetFaceEmotion(emotion);

        if (!_isInteracting)
            return;

        string stateName = ResolveBodyAnimStateName(emotion);
        if (string.IsNullOrEmpty(stateName))
            return; // Emoción sin animación corporal asignada: se mantiene la pose actual

        // Los gestos corporales de diálogo (Talk01-03, Angry01-02, Cry01, Laugh01, Beg01, etc.)
        // viven en UpperBody layer para no congelar las piernas del NPC mientras gesticula.
        //
        // Prefiere UpperBody y usa Base Layer si el estado solo existe allí.
        int layer = AnimatorLayerUtil.ResolveLayer(animator, stateName, upperBodyLayer);
        if (layer < 0)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[NPCSimpleAnimator:{name}] La emoción {emotion} está mapeada a " +
                $"'{stateName}', que no existe en ninguna capa del Animator. Revisa el " +
                "EmotionProfile: ese nombre no hace nada.", this);
#endif
            return;
        }

        // La corrutina devuelve a conversación al terminar; evita iniciar dos fundidos al mismo estado.
        PlayOneShot(stateName, layer, fundido: 0.18f);
    }

    /// <summary>
    /// Resuelve el estado de animación corporal para una emoción.
    /// Neutral/None siempre rotan entre las animaciones neutrales (para dar variedad al hablar).
    /// Para el resto de emociones, devuelve tal cual el bodyAnimStateName configurado en el
    /// EmotionProfile: si está vacío, el llamador debe interpretarlo como "sin cambio de animación"
    /// (no hay fallback a Talk01, para no forzar un gesto en emociones que solo cambian la cara).
    /// Solo si no hay EmotionProfile asignado se usa un fallback de seguridad.
    /// </summary>
    /// Contador que reparte las variantes de gesto de cada emoción. Uno por NPC, así que dos
    /// personajes en la misma conversación no caen en el mismo gesto a la vez.
    private int _emotionRotation;

    private string ResolveBodyAnimStateName(NPCEmotion emotion)
    {
        string[] neutralAnims = (_emotionProfile != null && _emotionProfile.neutralBodyAnims is { Length: > 0 })
            ? _emotionProfile.neutralBodyAnims
            : new[] { "Talk01", "Talk02", "Talk03" };

        if (emotion == NPCEmotion.None || emotion == NPCEmotion.Neutral)
        {
            _lastTalkIndex = (_lastTalkIndex + 1) % neutralAnims.Length;
            return neutralAnims[_lastTalkIndex];
        }

        if (_emotionProfile != null)
        {
            var data = _emotionProfile.GetEmotionData(emotion);
            // Si la emoción tiene repertorio, se va rotando: dos NPCs enfadados, o el mismo dos
            // frases seguidas, no repiten el mismo gesto. Puede venir vacío a propósito, que el
            // llamador interpreta como "sin cambio".
            _emotionRotation++;
            return data.PickBodyAnim(_emotionRotation);
        }

        return neutralAnims[0];
    }

    /// <summary>
    /// Reproduce un gesto social como one-shot (para uso desde sistemas narrativos/quest).
    /// Disponible siempre, no requiere que el NPC esté en interacción.
    /// </summary>
    public void PlaySocialGesture(string stateName, Action onComplete = null)
    {
        if (string.IsNullOrEmpty(stateName) || _currentState == AnimationState.Dead)
            return;

        // Los gestos sociales pueden vivir en el Base Layer (locomoción/pose completa) o en el
        // UpperBody layer (gestos que no deben congelar las piernas, p.ej. Greeting01/HandWave01).
        // AnimatorLayerUtil resuelve en qué layer existe realmente el estado antes de reproducirlo
        // (misma utilidad compartida que usa PlayerDialogueAnimator).
        int resolvedLayer = AnimatorLayerUtil.ResolveLayer(animator, stateName, upperBodyLayer);

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        // Diagnóstico siempre visible (no depende de debugMode): si el estado no existe en NINGÚN
        // layer del Animator Controller de este NPC en concreto, PlayOneShot fallará en silencio
        // (CrossFadeToState solo loguea con debugMode activo). Esto confirma o descarta rápidamente
        // si "no hacen animación al socializar" es un problema de contenido (estado/clip faltante
        // en ESTE controller) y no de la lógica del encuentro.
        if (animator != null && resolvedLayer < 0)
        {
            Debug.LogWarning($"[NPCAnimator:{gameObject.name}] ⚠️ PlaySocialGesture('{stateName}'): " +
                $"ese estado no existe en ningún layer del Animator Controller " +
                $"'{(animator.runtimeAnimatorController != null ? animator.runtimeAnimatorController.name : "null")}'. " +
                "El NPC se quedará callado en este gesto.");
        }
#endif

        PlayOneShot(stateName, resolvedLayer >= 0 ? resolvedLayer : 0, onComplete, 0.18f);
    }

    /// <summary>
    /// Celebración de victoria aleatoria (Cheer01, Cheer02, HandClap01).
    /// Permite delay para escalonar la celebración entre varios aliados.
    /// </summary>
    public void PlayVictoryCelebration(float delay = 0f)
    {
        if (_currentState == AnimationState.Dead)
            return;

        if (_victoryCelebrationCoroutine != null)
            StopCoroutine(_victoryCelebrationCoroutine);

        _victoryCelebrationCoroutine = StartCoroutine(VictoryCelebrationRoutine(delay));
    }

    /// Anula la celebración de victoria que esté esperando su retardo. La usa quien monta su propia
    /// celebración con este personaje (la foto de grupo al ganar, ver CelebracionEnGrupo).
    public void CancelarCelebracionDeVictoria()
    {
        if (_victoryCelebrationCoroutine == null) return;
        StopCoroutine(_victoryCelebrationCoroutine);
        _victoryCelebrationCoroutine = null;
    }

    private IEnumerator VictoryCelebrationRoutine(float delay)
    {
        if (delay > 0f)
            yield return new WaitForSeconds(delay);

        if (_currentState == AnimationState.Dead || _isInBattle)
            yield break;

        string[] options = { "Cheer01", "Cheer02", "HandClap01" };
        string chosen = options[UnityEngine.Random.Range(0, options.Length)];

        // Cheer01/Cheer02/HandClap01 viven en UpperBody layer (no deben congelar las piernas)
        PlayOneShot(chosen, upperBodyLayer, () =>
        {
            if (!_isInBattle && !_isInteracting && _currentState != AnimationState.Dead)
                TransitionToIdle();
        });

        _victoryCelebrationCoroutine = null;
    }

    #endregion

    #region Public API - Ambient Activity

    /// <summary>
    /// Inicia una actividad ambiental (sentarse, comer, beber, dormir).
    /// Reproduce Begin → Loop. El NPC permanece en el Loop hasta que se llame StopAmbientActivity.
    /// </summary>
    public void PlayAmbientActivity(NPCAmbientActivity activity, NPCWorldPoint worldPoint = null)
    {
        if (activity == NPCAmbientActivity.None || _currentState == AnimationState.Dead)
            return;

        // FIX INC-130 (5 sept 2026): SitGround/SitLow/SitMedium/SitHigh tienen sus estados de
        // Begin/Loop en el Animator Controller compartido, pero el Motion de esos 8 estados apunta
        // a un GUID que no corresponde a ningún asset del proyecto (clips "reservados" que nunca se
        // importaron, ver HasWorkingAnimation() más abajo). Como el estado SÍ existe, el diagnóstico
        // de más abajo (hasBeginState/hasLoopState) no lo detectaba y Mecanim entraba igualmente en
        // ese estado sin Motion, congelando al NPC en la última pose evaluada justo cuando ya ha
        // sido teleportado a la altura del asiento — visualmente, un NPC de pie/flotando sobre el
        // banco en vez de sentado ("se sientan en el aire"). Hasta que se importen y wireen los
        // clips reales, no reproducimos la actividad: el NPC sigue con su animación normal en vez
        // de mostrar el hueco.
        if (!HasWorkingAnimation(activity))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[NPCAnimator:{gameObject.name}] PlayAmbientActivity({activity}) omitida: " +
                "clips de Begin/Loop aún sin importar en el Animator Controller (INC-130). " +
                "El NPC no realizará la actividad hasta que se wireen los clips reales.");
#endif
            return;
        }

        StopIdleVariations();

        _isSeated       = IsSitActivity(activity);
        _seatedActivity = activity;

        // ✅ FIX: si el NPC viene de un modo especial (vuelo/salto/plataforma replicado del
        // jugador vía FollowPlayerState) puede quedar con IsGrounded=false, GroundDistance
        // alto o isFlying=true en el Animator. En el controller compartido de personajes
        // jugables (Will/Liam/Estela) eso dispara un Any State → "Falling" que interrumpe
        // CUALQUIER estado activo, incluido el loop de sentado — el NPC se teletransporta
        // bien a la silla pero la animación salta a caída/de pie ("se sienta mal"). Eldran
        // usa un controller sin ese Any State, así que para él esto es inofensivo.
        if (_isSeated)
            ForceGroundedForSit();

        // Comer/beber viven en la UpperBody layer (torso/brazos, sin piernas) para no pisar la
        // locomoción de la Base Layer — el NPC puede seguir de pie/caminando con normalidad
        // mientras el gesto se reproduce encima. Ver GetActivityLayer().
        int activityLayer = GetActivityLayer(activity);
        if (activityLayer > 0 && animator != null && activityLayer < animator.layerCount)
            animator.SetLayerWeight(activityLayer, 1f);

        if (_activityCoroutine != null)
            StopCoroutine(_activityCoroutine);

        _activityCoroutine = StartCoroutine(AmbientActivityRoutine(activity, worldPoint));
    }

    /// <summary>
    /// Quita el root motion del Animator. Lo necesitan las poses "en el sitio": con root motion,
    /// el clip mueve al personaje y se nota el tirón.
    /// </summary>
    public void QuitarRootMotion()
    {
        if (animator != null) animator.applyRootMotion = false;
    }

    private void ForceGroundedForSit()
    {
        TrySetBool(HashIsGrounded, true);
        TrySetFloat(HashGroundDistance, 0f);
        TrySetBool(HashIsFlying, false);
    }

    /// <summary>
    /// Fuerza al NPC a estar en el suelo (IsGrounded / GroundDistance / isFlying). Hace falta
    /// cuando se le mueve a mano (al subirlo a un barco, por ejemplo): si no, el «Any State →
    /// Falling» del Animator lo saca de cualquier estado y se queda en un bucle de caída
    /// (parece que está convulsando).
    /// </summary>
    public void ForzarEnElSuelo()
    {
        ForceGroundedForSit();
    }

    private void TrySetBool(int paramHash, bool value)
    {
        if (animator == null) return;
        if (_animatorParamHashes != null && !_animatorParamHashes.Contains(paramHash)) return;
        try { animator.SetBool(paramHash, value); } catch { }
    }

    private void TrySetFloat(int paramHash, float value)
    {
        if (animator == null) return;
        if (_animatorParamHashes != null && !_animatorParamHashes.Contains(paramHash)) return;
        try { animator.SetFloat(paramHash, value); } catch { }
    }

    private static bool IsSitActivity(NPCAmbientActivity activity)
    {
        return activity == NPCAmbientActivity.SitGround
            || activity == NPCAmbientActivity.SitLow
            || activity == NPCAmbientActivity.SitMedium
            || activity == NPCAmbientActivity.SitHigh;
    }

    /// <summary>
    /// True si la actividad tiene clips de animación reales asignados en el Animator Controller
    /// compartido de NPCs. FIX INC-130 (5 sept 2026): los 4 pares Begin/Loop de Sit* (SitGround,
    /// SitLow, SitMedium, SitHigh) existen como ESTADOS en 'NPC_NoWeapon.controller' pero su Motion
    /// apunta a un GUID que no corresponde a ningún asset del proyecto — nombres reservados para
    /// clips que nunca se llegaron a importar (ver
    /// 'incidencia-npc-hundido-sentado-y-lluvia-causa-real-2026-08-31.md'). 'Animator.HasState' solo
    /// comprueba que el estado exista, no que su Motion sea válido, así que no basta con ese chequeo.
    /// Este método centraliza el interruptor: en cuanto se importen y wireen los clips reales en el
    /// controller, basta con quitar la actividad del switch de abajo para reactivarla en los tres
    /// caminos que sientan a un NPC (actividad fija, refugio de lluvia y NPCWorldPoint/bancos).
    ///
    /// (7 oct 2026) Los clips ya están: los 12 estados Sit* del controller apuntan a las animaciones
    /// de Kevin Iglesias (HumanM@Sit*01 Begin/Loop/Stop), comprobado GUID a GUID. Sentarse vuelve a
    /// estar activo en todos los caminos. Se deja el interruptor por si falta alguna actividad nueva.
    /// </summary>
    public static bool HasWorkingAnimation(NPCAmbientActivity activity)
    {
        return true;
    }

    /// <summary>
    /// Detiene la actividad ambiental en curso sin reproducir su animación de salida. Se usa
    /// cuando otro sistema toma el control de la pose (p. ej. subir a un barco): si la corrutina
    /// siguiera viva, al terminar su tramo Begin volvería a poner el Loop y pisaría la pose nueva.
    /// </summary>
    public void DetenerActividadAmbiental()
    {
        _isSeated = false;
        _seatedActivity = NPCAmbientActivity.None;

        if (_activityCoroutine != null)
        {
            StopCoroutine(_activityCoroutine);
            _activityCoroutine = null;
        }

        // Comer/beber viven en la UpperBody layer; al quitar la actividad hay que soltar su
        // peso o el torso se queda con el gesto congelado encima de la pose nueva.
        if (animator != null && upperBodyLayer > 0 && upperBodyLayer < animator.layerCount)
            animator.SetLayerWeight(upperBodyLayer, 0f);
    }

    /// <summary>
    /// Para la actividad ambiental activa. La animación de salida (Exit) se aplica si existe;
    /// luego el animator vuelve a idle normal.
    /// </summary>
    public void StopAmbientActivity(NPCAmbientActivity activity, NPCWorldPoint worldPoint = null)
    {
        _isSeated = false;

        if (_activityCoroutine != null)
        {
            StopCoroutine(_activityCoroutine);
            _activityCoroutine = null;
        }

        // Devolver el prop a su posición original antes de volver al idle
        worldPoint?.DetachProp();

        // Si la actividad usaba la UpperBody layer (comer/beber), soltarla al terminar para no
        // dejar el torso "congelado" en la última pose sobre la locomoción normal.
        int activityLayer = GetActivityLayer(activity);
        if (activityLayer > 0 && animator != null && activityLayer < animator.layerCount)
            animator.SetLayerWeight(activityLayer, 0f);

        string exitState = GetActivityExitState(activity);
        if (!string.IsNullOrEmpty(exitState) && animator != null && animator.HasState(0, Animator.StringToHash(exitState)))
        {
            PlayOneShot(exitState, 0, () => TransitionToIdle());
        }
        else
        {
            TransitionToIdle();
        }
    }

    private IEnumerator AmbientActivityRoutine(NPCAmbientActivity activity, NPCWorldPoint worldPoint)
    {
        // Adjuntar prop a la mano derecha si el worldPoint tiene uno
        worldPoint?.AttachPropToOccupant(animator);

        string beginState = GetActivityBeginState(activity);
        string loopState  = GetActivityLoopState(activity);
        int layer = GetActivityLayer(activity);

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        // Diagnóstico (15 ago 2026): a diferencia de PlaySocialGesture (que sí avisa si el estado
        // no existe), este método no dejaba ningún rastro en consola cuando el Animator Controller
        // no tenía el estado begin/loop (p.ej. los clips de SitGround están "pendientes de
        // importar", ver comentario en GetActivityBeginState más abajo) — el NPC simplemente se
        // quedaba de pie sin ningún indicio de por qué (reportado por Raúl: los NPCs bajo el árbol
        // "se quedan quietos" en vez de sentarse o tiritar de frío). Este log confirma en la
        // práctica si es un problema de CONTENIDO (clip/estado faltante en ESTE controller en
        // concreto) y no de la lógica que llama a PlayAmbientActivity — que si llega hasta aquí,
        // ya está haciendo su parte correctamente.
        bool hasBeginState = !string.IsNullOrEmpty(beginState) && animator != null && animator.HasState(layer, Animator.StringToHash(beginState));
        bool hasLoopState  = !string.IsNullOrEmpty(loopState)  && animator != null && animator.HasState(layer, Animator.StringToHash(loopState));
        if (!hasBeginState && !hasLoopState && (!string.IsNullOrEmpty(beginState) || !string.IsNullOrEmpty(loopState)))
        {
            Debug.LogWarning($"[NPCAnimator:{gameObject.name}] ⚠️ PlayAmbientActivity({activity}): ni '{beginState}' ni '{loopState}' " +
                $"existen en la layer {layer} del Animator Controller " +
                $"'{(animator != null && animator.runtimeAnimatorController != null ? animator.runtimeAnimatorController.name : "null")}'. " +
                "El NPC se quedará de pie en vez de sentarse — revisar si los clips están importados y wireados en ESE controller.");
        }
#endif

        // Animación de inicio (one-shot)
        if (!string.IsNullOrEmpty(beginState) && animator != null && animator.HasState(layer, Animator.StringToHash(beginState)))
        {
            CrossFadeToState(beginState, 0.2f, layer);
            float clipLen = GetClipLength(beginState);
            yield return new WaitForSeconds(Mathf.Max(0.1f, clipLen));
        }

        // Loop hasta que se interrumpa externamente
        if (!string.IsNullOrEmpty(loopState) && animator != null && animator.HasState(layer, Animator.StringToHash(loopState)))
        {
            CrossFadeToState(loopState, 0.15f, layer);
        }

        _activityCoroutine = null;
    }

    /// <summary>
    /// Capa del Animator en la que vive cada actividad ambiental. Comer y beber viven en la
    /// UpperBody layer (torso/brazos, AvatarMask sin piernas) para que el NPC pueda seguir de pie
    /// o caminando con su locomoción normal de la Base Layer mientras el gesto se reproduce
    /// encima; el resto de actividades (sentarse, dormir) siguen siendo poses de cuerpo completo
    /// en la Base Layer (capa 0).
    /// </summary>
    private int GetActivityLayer(NPCAmbientActivity activity)
    {
        return activity switch
        {
            NPCAmbientActivity.Eat   => upperBodyLayer,
            NPCAmbientActivity.Drink => upperBodyLayer,
            _                        => 0
        };
    }

    // Los nombres de estado de cada actividad. Públicos porque los guiones horneados (sienta /
    // levanta) usan los mismos: un solo sitio dice qué animación es sentarse.
    public static string GetActivityBeginState(NPCAmbientActivity activity)
    {
        return activity switch
        {
            // Sentarse (clips HumanM@Sit*01 de Kevin Iglesias)
            NPCAmbientActivity.SitGround  => "SitGround_Begin",
            NPCAmbientActivity.SitLow     => "SitLow_Begin",
            NPCAmbientActivity.SitMedium  => "SitMedium_Begin",
            NPCAmbientActivity.SitHigh    => "SitHigh_Begin",
            // Comer — pendiente de importar los clips
            NPCAmbientActivity.Eat        => "Eat_Begin",
            // Beber: usa DrinkPotion_NoWeapon como one-shot y luego idle
            NPCAmbientActivity.Drink      => "DrinkPotion_NoWeapon",
            // Dormir: sin transición de entrada, va directo al loop
            NPCAmbientActivity.Sleep      => string.Empty,
            _                             => string.Empty
        };
    }

    public static string GetActivityLoopState(NPCAmbientActivity activity)
    {
        return activity switch
        {
            // Sentarse (clips HumanM@Sit*01 de Kevin Iglesias)
            NPCAmbientActivity.SitGround  => "SitGround_Loop",
            NPCAmbientActivity.SitLow     => "SitLow_Loop",
            NPCAmbientActivity.SitMedium  => "SitMedium_Loop",
            NPCAmbientActivity.SitHigh    => "SitHigh_Loop",
            // Comer — pendiente
            NPCAmbientActivity.Eat        => "Eat_Loop",
            // Beber: el one-shot ya es la animación completa, sin loop
            NPCAmbientActivity.Drink      => string.Empty,
            // Dormir: loop real del personaje durmiendo
            NPCAmbientActivity.Sleep      => "Sleeping_NoWeapon",
            _                             => string.Empty
        };
    }

    public static string GetActivityExitState(NPCAmbientActivity activity)
    {
        return activity switch
        {
            // Sentarse (clips HumanM@Sit*01 de Kevin Iglesias)
            NPCAmbientActivity.SitGround  => "SitGround_Exit",
            NPCAmbientActivity.SitLow     => "SitLow_Exit",
            NPCAmbientActivity.SitMedium  => "SitMedium_Exit",
            NPCAmbientActivity.SitHigh    => "SitHigh_Exit",
            // Dormir, comer y beber: sin animación de salida, vuelven directo a idle
            _                             => string.Empty
        };
    }

    #endregion

    #region Public API - Utility

    /// <summary>
    /// Establece el override de interacción (estado custom)
    /// </summary>
    public void SetInteractOverride(string stateName, bool clearOnEnd = true)
    {
        if (!string.IsNullOrEmpty(stateName))
        {
            interactState = stateName;
        }
    }
    
    /// <summary>
    /// Limpia el override de interacción
    /// </summary>
    public void ClearInteractOverride()
    {
        interactState = "Talk01";
    }
    
    /// <summary>
    /// Establece la referencia del jugador
    /// </summary>
    public void SetPlayer(Transform player, Transform playerCam = null)
    {
        _player = player;
        if (playerCam != null)
            _playerCam = playerCam;
    }
    
    /// <summary>
    /// Obtiene el estado actual de animación
    /// </summary>
    public AnimationState GetCurrentState() => _currentState;
    
    /// <summary>
    /// Verifica si está reproduciendo una animación
    /// </summary>
    public bool IsPlayingAnimation() => _oneShotCoroutine != null;

    /// Corta el gesto o la pose que esté en marcha para que el NPC pueda echar a andar (INC-602).
    ///
    /// Durante un gesto el estado es OneShot y SetMovementSpeed no pasa a locomoción: el
    /// personaje se desliza por el suelo con el gesto puesto. En el despertar, Eldran huía
    /// encogido en Fear01 (con la cámara lenta del guion el gesto dura cinco veces más), y eso
    /// parecía «la animación de miedo con el cuello roto».
    public void CortarGestoParaAndar()
    {
        if (_currentState == AnimationState.Dead) return;
        if (_oneShotCoroutine != null) { StopCoroutine(_oneShotCoroutine); _oneShotCoroutine = null; }
        _currentState = AnimationState.Idle;
        TransitionToIdle();
    }
    
    #endregion
    
    #region Private Methods - Idle Variations

    private void StartIdleVariations()
    {
        // FIX 4 sep 2026 (petición de Raúl: "vamos a quitar que no cambie de idle porque no me
        // gustan las animaciones, que se quede con el idle normal"): se desactiva la
        // funcionalidad entera aquí, en vez de solo cambiar el valor por defecto de
        // enableIdleVariations — ese campo ya viene serializado a `true` en el Inspector de
        // muchos NPCs existentes, así que cambiar el default en el script no les habría afectado.
        // Con este return incondicional NINGÚN NPC vuelve a cambiar de idle, sea cual sea el
        // valor guardado en su prefab/instancia; se deja el resto del sistema (campos, coroutine)
        // intacto por si se quiere reactivar más adelante.
        return;

#pragma warning disable CS0162 // código inalcanzable a propósito, ver comentario arriba
        if (!enableIdleVariations || idleVariationStates == null || idleVariationStates.Length == 0)
            return;
        if (_isInBattle || _isInteracting || _currentState == AnimationState.Dead)
            return;

        StopIdleVariations();
        _idleVariationCoroutine = StartCoroutine(IdleVariationLoop());
#pragma warning restore CS0162
    }

    private void StopIdleVariations()
    {
        if (_idleVariationCoroutine == null)
            return;

        StopCoroutine(_idleVariationCoroutine);
        _idleVariationCoroutine = null;
    }

    private IEnumerator IdleVariationLoop()
    {
        while (true)
        {
            float wait = UnityEngine.Random.Range(minIdleVariationInterval, maxIdleVariationInterval);
            yield return new WaitForSeconds(wait);

            // Guardas: solo si seguimos en Idle puro
            if (_currentState != AnimationState.Idle || _isInBattle || _isInteracting)
                continue;

            if (idleVariationStates.Length == 0)
                continue;

            int cantidad = idleVariationStates.Length;
            int indice = UnityEngine.Random.Range(0, cantidad > 1 && _ultimaVariacionIdle >= 0 ? cantidad - 1 : cantidad);
            if (cantidad > 1 && _ultimaVariacionIdle >= 0 && indice >= _ultimaVariacionIdle) indice++;
            _ultimaVariacionIdle = indice;
            string variation = idleVariationStates[indice];

            if (string.IsNullOrEmpty(variation) || animator == null || !animator.HasState(0, Animator.StringToHash(variation)))
                continue;

            PlayOneShot(variation, 0, fundido: 0.2f);
        }
    }

    #endregion

    #region Private Methods - Core
    
    private void UpdateActualSpeed()
    {
        // Calculate actual movement speed based on position change
        Vector3 currentPosition = transform.position;
        float distance = Vector3.Distance(currentPosition, _lastPosition);
        _actualSpeed = distance / Time.deltaTime;
        _lastPosition = currentPosition;
    }
    
    private void SyncWithNavMeshAgent()
    {
        if (!navAgent.enabled || !navAgent.isOnNavMesh)
            return;
        
        // ✅ FIX CRÍTICO: Solo sincronizar si el agente tiene un path activo y no está detenido
        // Esto previene que velocidad residual cause movimiento constante
        if (navAgent.isStopped || !navAgent.hasPath)
        {
            // FIX 5 sep 2026 (ver AllowManualMovement): si un sistema externo tiene el control
            // explícito del InputMagnitude, no lo pisamos aquí -- solo dejamos de aplicar esta
            // rama; el resto (early return, sin rotación) se mantiene igual.
            if (!AllowManualMovement)
                SetMovementSpeed(0f);
            return;
        }
        
        // Get agent velocity
        float agentSpeed = navAgent.velocity.magnitude;

        // ✅ Threshold más estricto: Si la velocidad es muy baja, considerarlo como parado
        if (agentSpeed < movementThreshold * 0.5f)
        {
            if (!AllowManualMovement)
                SetMovementSpeed(0f);
            return;
        }

        if (!AllowManualMovement)
        {
            // El mismo criterio que todos los estados y secuencias: ver
            // NavMeshAgentUtility.FactorDeLocomocion (INC-466). Antes aquí había un mapa propio con
            // la velocidad de andar y correr del animador, que peleaba cada frame con el de
            // FollowPlayerState y dejaba a Oliver deslizándose con las piernas casi quietas.
            float normalizedSpeed = Game.NPC.Common.NavMeshAgentUtility.FactorDeLocomocion(navAgent);

            // Apply to animation
            SetMovementSpeed(normalizedSpeed);
        }
        // FIX 5 sep 2026 (incidencia animación rota en escolta Eldran/guardia): cuando
        // AllowManualMovement es true (CinematicState controlando la secuencia), NO llamamos a
        // SetMovementSpeed() aquí -- el InputMagnitude queda 100% en manos de CinematicState
        // (ComputeWalkGaitSpeedFactor), en vez de que ambos cálculos se pisen mutuamente cada
        // frame según el orden de Update() (no determinista), que es lo que producía el efecto
        // de "otra animación"/"patinando sobre hielo" pese a que el Animator seguía correctamente
        // en el estado "Free Locomotion".
        
        // ✅ FIX: No actualizar rotación si está deshabilitada (ej: durante/después de cinemáticas)
        if (_disableAutoRotation || AllowManualRotation)
            return;
        
        // Update rotation based on velocity
        if (agentSpeed > movementThreshold && navAgent.velocity.sqrMagnitude > 0.01f)
        {
            Vector3 direction = navAgent.velocity.normalized;
            
            // ✅ DEBUG: Log rotación
            if (debugMode && Time.frameCount % 30 == 0) // Cada 30 frames
            {
                Vector3 forward = transform.forward;
                float angleDiff = Vector3.Angle(forward, direction);
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAnimator] ROTACIÓN DEBUG:\n" +
                         $"  Transform.forward: {forward}\n" +
                         $"  NavAgent.velocity: {navAgent.velocity}\n" +
                         $"  Direction: {direction}\n" +
                         $"  Angle diff: {angleDiff:F1}°\n" +
                         $"  updateRotation: {navAgent.updateRotation}\n" +
                         $"  _disableAutoRotation: {_disableAutoRotation}");
                #endif
            }
            
            FaceDirection(direction);
        }
    }
    
    private void ApplySmoothRotation()
    {
        // Skip if auto rotation is disabled (e.g. during dialogue)
        if (_disableAutoRotation || AllowManualRotation)
            return;
            
        // Calculate angle difference
        float angle = Quaternion.Angle(transform.rotation, _targetRotation);
        
        if (angle < minRotationAngle)
            return;
        
        // ✅ DEBUG: Log aplicación de rotación
        if (debugMode && Time.frameCount % 60 == 0) // Cada 60 frames
        {
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator] APLICANDO ROTACIÓN:\n" +
                     $"  Current: {transform.rotation.eulerAngles}\n" +
                     $"  Target: {_targetRotation.eulerAngles}\n" +
                     $"  Angle diff: {angle:F1}°\n" +
                     $"  Speed: {rotationSpeed}°/s");
            #endif
        }
        
        // Apply smooth rotation
        float maxDegreesDelta = rotationSpeed * Time.deltaTime;
        transform.rotation = Quaternion.RotateTowards(
            transform.rotation,
            _targetRotation,
            maxDegreesDelta
        );
    }
    
    #endregion
    
    #region Private Methods - State Transitions
    
    /// <summary>
    /// Transiciona al estado Idle. Público para reseteo externo (ej: después de stun)
    /// </summary>
    public void TransitionToIdle()
    {
        _currentState = AnimationState.Idle;

        // ✅ FIX: Desactivar root motion en Idle también
        if (animator != null)
        {
            animator.applyRootMotion = false;
        }

        // ✅ FIX: si el NPC sigue sentado (p.ej. este TransitionToIdle llega desde el callback
        // de PlayOneShot al terminar un PlaySocialGesture lanzado mientras estaba en la mesa),
        // volver al loop de sentado en vez de ponerlo de pie con idleNormalState.
        if (_isSeated && !_isInBattle)
        {
            string seatLoop = GetActivityLoopState(_seatedActivity);
            if (!string.IsNullOrEmpty(seatLoop) && animator != null && animator.HasState(0, Animator.StringToHash(seatLoop)))
            {
                CrossFadeToState(seatLoop, 0.2f);
                return; // no arrancar variaciones de idle de pie mientras sigue sentado
            }
        }

        if (_isInBattle)
        {
            // En batalla, Idle_Battle_NoWeapon vive en UpperBody layer (ver SetBattleMode): la
            // Base Layer (capa 0) se queda siempre en el blend tree de locomoción, así que las
            // piernas nunca dependen de este idle para poder caminar.
            if (TieneEstado(idleBattleState, upperBodyLayer))
                CrossFadeToState(idleBattleState, 0.2f, upperBodyLayer);
        }
        else
        {
            // Fuera de batalla, idle de pie de la capa base, con respaldo al blend tree de
            // locomoción cuando el controlador no tiene idleNormalState.
            PosarIdleDePie(0.2f);
        }

        StartIdleVariations();
    }
    
    /// <summary>
    /// Fuerza transición a estado de locomotion (caminar/correr).
    /// Útil cuando necesitas mover el NPC inmediatamente desde dizzy u otro estado.
    /// </summary>
    public void TransitionToLocomotion()
    {
        if (_currentMovementSpeed > movementThreshold * 2f)
        {
            _currentState = AnimationState.Running;
        }
        else
        {
            _currentState = AnimationState.Walking;
        }
        
        // ✅ FIX CRÍTICO: Desactivar root motion durante locomotion
        // para que el NPCSimpleAnimator controle la rotación, no la animación
        if (animator != null)
        {
            animator.applyRootMotion = false;
        }
        
        if (string.IsNullOrEmpty(locomotionState))
        {
            if (debugMode)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogError($"[NPCAnimator] locomotionState está vacío");
#endif
                }
            return;
        }
        
        CrossFadeToState(locomotionState, locomotionBlendTime);
    }
    
    #endregion
    
    #region Private Methods - Animation Helpers
    
    /// <summary>True si ese layer del Animator tiene el estado (y el nombre no está vacío).</summary>
    private bool TieneEstado(string stateName, int layer)
    {
        return !string.IsNullOrEmpty(stateName) && animator != null &&
               animator.HasState(layer, Animator.StringToHash(stateName));
    }

    /// <summary>
    /// Pone la capa base en el idle de pie. Los controladores de Invector (Invector@BasicLocomotion,
    /// el de _LIAM y _ESTELA) no tienen idleNormalState —Idle_Normal_NoWeapon, que es del
    /// NPC_NoWeapon—: su idle de pie es el propio blend tree de locomoción con el InputMagnitude a
    /// cero. Sin este respaldo la llamada no hacía nada y el NPC se quedaba en el estado anterior
    /// (un salto de un solo uso en bucle, andando en el sitio...).
    /// </summary>
    private void PosarIdleDePie(float transitionTime)
    {
        if (animator == null) return;

        if (TieneEstado(idleNormalState, 0))
        {
            CrossFadeToState(idleNormalState, transitionTime);
            return;
        }

        if (!TieneEstado(locomotionState, 0)) return;

        // InputMagnitude a cero: sin esto el blend tree seguiría en el tramo de caminar.
        ResetMovement();

        // Si ya está en el blend tree no se recruza: reiniciaría el idle en cada aviso.
        if (animator.GetCurrentAnimatorStateInfo(0).shortNameHash == Animator.StringToHash(locomotionState))
            return;

        CrossFadeToState(locomotionState, transitionTime);
    }

    private void CrossFadeToState(string stateName, float transitionTime, int layer = 0)
    {
        if (string.IsNullOrEmpty(stateName) || animator == null)
        {
            // Solo loguear si no es un string vacío intencional
            if (!string.IsNullOrEmpty(stateName) && debugMode)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCAnimator] CrossFadeToState falló - stateName: {stateName}, animator: {animator != null}");
#endif
                }
            return;
        }
        
        string resolvedPath = AnimatorLayerUtil.ResolveStatePath(animator, stateName, layer);
        int stateHash = Animator.StringToHash(resolvedPath);
        
        // Check if state exists in specified layer
        if (animator.HasState(layer, stateHash))
        {
            animator.CrossFadeInFixedTime(stateHash, transitionTime, layer, 0f);
        }
        else
        {
            // ✅ Cambiado a Warning para no ensuciar la consola si un NPC específico no tiene una animación opcional
            if (debugMode)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCAnimator] ⚠️ Estado '{stateName}' no encontrado en layer {layer} para {gameObject.name}.");
#endif
                }
        }
    }
    
    private float GetClipLength(string stateName)
    {
        // Check cache first
        if (_clipLengthCache.TryGetValue(stateName, out float cachedLength))
        {
            return cachedLength;
        }
        
        // Try to find clip length
        float length = 0f;
        
        if (animator != null && animator.runtimeAnimatorController != null)
        {
            var clips = animator.runtimeAnimatorController.animationClips;
            if (clips != null)
            {
                foreach (AnimationClip clip in clips)
                {
                    if (clip != null && clip.name.Contains(stateName))
                    {
                        length = clip.length;
                        break;
                    }
                }
            }
        }
        
        // Cache result
        if (length > 0f)
        {
            _clipLengthCache[stateName] = length;
        }
        
        return length > 0f ? length : 1f; // Fallback to 1 second
    }
    
    private void CacheAnimationClips()
    {
        if (animator == null || animator.runtimeAnimatorController == null)
            return;
        
        var clips = animator.runtimeAnimatorController.animationClips;
        if (clips == null)
            return;

        foreach (AnimationClip clip in clips)
        {
            if (clip != null && !_clipLengthCache.ContainsKey(clip.name))
            {
                _clipLengthCache[clip.name] = clip.length;
            }
        }
        
        if (debugMode)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCAnimator] Cached {_clipLengthCache.Count} animation clips");
#endif
            }
    }
    
    private void ResolvePlayerReferences()
    {
        _player = PlayerLocator.ResolvePlayer();
        _playerCam = PlayerLocator.ResolvePlayerCamera();
    }
    
    #endregion
    
    #region Event Handlers
    
    private void OnInteractionStarted()
    {
        BeginInteraction();
    }
    
    private void OnInteractionFinished()
    {
        EndInteraction();
    }
    
    #endregion
    
    #region Gizmos
    
    void OnDrawGizmosSelected()
    {
        if (!drawGizmos)
            return;
        
        // Draw movement direction
        if (_currentMovementSpeed > movementThreshold)
        {
            Gizmos.color = Color.green;
            Gizmos.DrawRay(transform.position + Vector3.up, transform.forward * 2f);
        }
        
        // Draw target rotation
        Gizmos.color = Color.yellow;
        Vector3 targetDir = _targetRotation * Vector3.forward;
        Gizmos.DrawRay(transform.position + Vector3.up * 1.5f, targetDir * 1.5f);
        
        // Draw state
        #if UNITY_EDITOR
        UnityEditor.Handles.Label(
            transform.position + Vector3.up * 2.5f,
            $"Anim: {_currentState}\nSpeed: {_currentMovementSpeed:F2}",
            new GUIStyle()
            {
                normal = new GUIStyleState() { textColor = Color.white },
                fontSize = 11,
                alignment = TextAnchor.MiddleCenter
            }
        );
        #endif
    }
    
    #endregion
}
