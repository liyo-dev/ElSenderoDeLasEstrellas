using System;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Events;
using Game.NPC.Common;
using Game.NPC.States;
using Game.NPC.Modules; // Necesario para CombatLifecycleHandler

namespace Game.NPC
{
    /// <summary>
    /// Gestor de comportamiento de NPC basado en FSM (Finite State Machine).
    /// Versión 2.1 - Integración completa con Sistema de Combate y Persistencia.
    /// </summary>
    [RequireComponent(typeof(NavMeshAgent))]
    [RequireComponent(typeof(NPCSimpleAnimator))]
    [DisallowMultipleComponent]
    public class NPCBehaviourManagerV2 : MonoBehaviour
    {
        #region ⚙️ Configuration
        [Header("FSM Configuration")]
        [SerializeField] private NPCConfiguration configuration = new NPCConfiguration();
        [SerializeField] private bool debugMode = false;
        [Tooltip("Desactiva el wander para que el NPC se quede estático en su posición inicial.")]
        [SerializeField] private bool disableWander = false;
        
        [Header("Initial State")]
        [SerializeField] private bool startInIdleState = true;
        
        [Header("Physics")]
        [SerializeField] private bool forceKinematicRigidbody = true;

        [Header("🌍 IA por Distancia (LOD)")]
        [Tooltip("Distancia (m) más allá de la cual este NPC deja de ejecutar su FSM (Brain.Update) y desactiva su NavMeshAgent, mientras no haya ninguna razón para mantenerlo activo (combate, cinemática, interacción, refugio de lluvia o ser parte del party). Pensado para mundos grandes con muchos NPCs esparcidos lejos del jugador, que hasta ahora seguían corriendo su FSM completa aunque estuvieran a cientos de metros. 0 = desactivado (el NPC siempre está activo, comportamiento anterior a esta optimización).")]
        [Min(0f)]
        [SerializeField] private float aiUpdateDistance = 45f;

        [Tooltip("Margen (m) que se SUMA a aiUpdateDistance antes de que el NPC se 'duerma'; para volver a despertar tiene que acercarse por debajo de aiUpdateDistance. Esta histéresis evita que un NPC justo en el límite se active/desactive en bucle en cada comprobación.")]
        [Min(0f)]
        [SerializeField] private float aiWakeUpMargin = 8f;

        [Tooltip("Cada cuántos segundos se comprueba la distancia al jugador (no hace falta comprobarlo cada frame). El primer chequeo de cada NPC se retrasa con un offset aleatorio para no acumular todas las comprobaciones de todos los NPCs en el mismo frame.")]
        [Min(0.05f)]
        [SerializeField] private float aiDistanceCheckInterval = 0.5f;

        [Header("Save System")]
        [Tooltip("Si está activado, el sistema de guardado recordará la última posición del NPC")]
        [SerializeField] public bool persistLastPosition = false;
        
        // Runtime Data
        [NonSerialized] public Vector3 lastPosition;

        [Header("Identidad NPC")]
        [Tooltip("ID único para persistencia y registro (ej: 'NPC_InteractiveNarrative_Config_Eldran_cd6ce7a3')")]
        [SerializeField] private string persistenceId;

        [Tooltip("ID del personaje para diálogos (ej: 'CHAR_ELDRAN'). Se usa para identificar al speaker en diálogos con múltiples participantes.")]
        [SerializeField] private string dialogueCharacterId;

        [Header("Interacción")]
        [Tooltip("¿El NPC gira hacia el jugador al interactuar?")]
        [SerializeField] private bool rotateToPlayerOnInteract = true;

        [Min(0f)]
        [Tooltip("Duración de la rotación hacia el jugador")]
        [SerializeField] private float rotationDuration = 0.3f;

        [Header("Layer Management")]
        [Tooltip("Capa inicial del NPC. Cambiará a 'Enemy' al iniciar combate si switchToEnemyLayerOnCombat está activo.")]
        [SerializeField] private Modules.LayerMode initialLayer = Modules.LayerMode.Interactable;

        [Tooltip("¿Cambiar automáticamente a la capa 'Enemy' cuando se inicie un combate (acción StartCombat)?")]
        [SerializeField] private bool switchToEnemyLayerOnCombat = true;

        // Los campos de "Detección Narrativa" (narrativeDetectionRange, walkTowardsPlayerOnAlert,
        // stopDistanceFromPlayer, narrativeAlertIconPrefab) vivían aquí y se movieron a
        // NarrativeActor.cs el 12 sept 2026 — solo los usa NPCInteractiveNarrativeExecutor
        // (sistema Interactive, congelado). EnsureRequiredComponents() más abajo garantiza que
        // cualquier NPC que active ese módulo tenga también NarrativeActor.
        #endregion

        #region 🔌 Core Components
        private NavMeshAgent _agent;
        private NPCSimpleAnimator _animator;
        private Animator _unityAnimator;
        private Rigidbody _rigidbody;
        private NPCBrain _brain;
        private NPCStateContext _context;
        private int _externalMovementOverrideRequests;

        // LOD de IA por distancia
        private float _distanceCheckTimer;
        private bool _isFarFromPlayer;

        // Player References
        private Transform _player;
        private Transform _playerCamera;

        // Cached components (evita GetComponent repetido)
        private NPCPartyMember _cachedPartyMember;
        private NPCCombatLifecycleHandler _cachedLifecycle;
        #endregion

        #region 📢 Public API
        public NPCBrain Brain => _brain;
        public NPCStateContext Context => _context;
        public NPCConfiguration Configuration => configuration;

        /// <summary>
        /// Sentado fijo: actividad de sentarse sin paseo (un vecino en su banco). Su sitio es el punto
        /// de salida tal cual, así que nunca lleva el NavMeshAgent encendido ni se recoloca sobre la
        /// malla: el banco recorta la malla y el agente lo sacaría al lado del asiento (INC-1028).
        /// </summary>
        public bool SentadoFijo
        {
            get
            {
                var ambiente = configuration?.ambientConfig;
                if (ambiente == null || ambiente.enableWander) return false;
                var a = ambiente.ambientActivity;
                return a == NPCAmbientActivity.SitGround || a == NPCAmbientActivity.SitLow
                    || a == NPCAmbientActivity.SitMedium || a == NPCAmbientActivity.SitHigh;
            }
        }
        public bool IsInCinematic => _context != null && _context.IsInCinematic;
        public bool IsExternalMovementOverrideActive => _externalMovementOverrideRequests > 0;
        
        // Accessors
        public NavMeshAgent Agent => _agent;
        public Animator Animator => _unityAnimator;
        public NPCSimpleAnimator SimpleAnimator => _animator;
        public Transform Player => _player;
        
        /// <summary>
        /// Indica si este NPC es un aliado del jugador (miembro del party).
        /// </summary>
        public bool IsAlly => _cachedPartyMember != null && _cachedPartyMember.IsInParty;

        // Identidad NPC (migrado desde NPCInteractiveNarrativeConfig)
        public string PersistenceId => persistenceId;

        /// <summary>
        /// Sobrescribe el persistenceId del prefab. SOLO es válido ANTES de Awake(): el registro
        /// en NPCRegistry ocurre dentro de Awake(), así que llamarlo después no cambia con qué id
        /// quedó registrado el NPC.
        ///
        /// Lo usa <see cref="NpcSpawner"/>, que instancia el prefab dentro de un contenedor
        /// desactivado justo para poder llamar aquí antes de que Unity ejecute Awake().
        /// </summary>
        public void OverrideIdentityBeforeAwake(string newPersistenceId)
        {
            if (string.IsNullOrEmpty(newPersistenceId)) return;

            if (_identityRegistered)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogError($"[NPCBehaviourV2:{name}] OverrideIdentityBeforeAwake('{newPersistenceId}') llamado DESPUÉS de Awake(). " +
                               $"El NPC ya está registrado como '{persistenceId}' y este cambio no tendrá efecto en NPCRegistry.");
#endif
                return;
            }

            persistenceId = newPersistenceId;
        }

        private bool _identityRegistered;
        public string DialogueCharacterId => dialogueCharacterId;
        public bool IsInCombatOrAlert => _brain != null && (_brain.CurrentState is States.CombatState || _brain.CurrentState is States.AlertState);

        // Interacción
        public bool RotateToPlayerOnInteract => rotateToPlayerOnInteract;
        public float RotationDuration => rotationDuration;

        // Layer Management
        public Modules.LayerMode InitialLayer => initialLayer;
        public bool SwitchToEnemyLayerOnCombat => switchToEnemyLayerOnCombat;

        #endregion

        void Awake()
        {
            // 1. Validación de Configuración
            if (!configuration.Validate(out string errors))
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogError($"[NPCBehaviourV2:{name}] ❌ ERROR DE CONFIG:\n{errors}");
#endif
            }
            
            // 2. Obtener Componentes Core
            _agent = GetComponent<NavMeshAgent>();
            _animator = GetComponent<NPCSimpleAnimator>();
            _unityAnimator = GetComponent<Animator>();
            _rigidbody = GetComponent<Rigidbody>();
            
            // ✅ FIX: Configurar NavMeshAgent para que NO controle la rotación
            // NPCSimpleAnimator se encarga de la rotación para evitar conflictos
            if (_agent != null)
            {
                _agent.updateRotation = false;
            }
            
            // 3. Configurar Físicas
            if (forceKinematicRigidbody && _rigidbody != null)
            {
                // IMPORTANTE: Resetear velocidades ANTES de hacer el rigidbody kinematic
                // Unity no permite modificar velocidades de rigidbodies kinematic
                if (!_rigidbody.isKinematic)
                {
                    _rigidbody.linearVelocity = Vector3.zero;
                    _rigidbody.angularVelocity = Vector3.zero;
                }
                _rigidbody.isKinematic = true;
            }
            
            // 4. Aplicar overrides de configuración
            if (disableWander)
                configuration.DisableWander();

            // Los NPCs narrativos (con persistenceId) no deben desaparecer refugiándose de la
            // lluvia: podrían ser necesarios para una interacción o quest en curso. Ver
            // Diseno_Refugio_Lluvia_y_Relaciones_NPC.md § A.4.
            if (!string.IsNullOrEmpty(persistenceId))
                configuration.DisableShelterSeeking();

            // 5. Crear Contexto FSM
            _context = new NPCStateContext(null, transform, _agent, _animator, _unityAnimator, _rigidbody)
            {
                Config = configuration,
                DebugMode = debugMode,
                RelationshipId = ResolveRelationshipId()
            };
            
            // 6. Crear Brain
            _brain = new NPCBrain(_context);
            _context.Brain = _brain; // Cerrar referencia circular
            
            // 6. INYECCIÓN DE DEPENDENCIAS AUTOMÁTICA
            EnsureRequiredComponents();
            
            // 7. Registro Narrativo
            RegisterNarrativeIdentity();
            
            // 8. Eventos Globales
            PlayerService.OnPlayerRegistered += OnPlayerRegistered;
            PlayerService.OnPlayerUnregistered += OnPlayerUnregistered;
            ResolvePlayerReferences();

            // 9. Refugio de lluvia: DESACTIVADO (31 ago 2026, a petición de diseño de Raúl —
            // ya no quiere que los NPCs reaccionen a la lluvia sentándose/tiritando bajo un
            // NPCShelterPoint). El sistema completo (SeekShelterState, ReturnFromShelterState,
            // NPCShelterPoint, los chequeos en IdleState/WanderState/WalkToActivityState) se deja
            // intacto en el código por si se retoma más adelante: basta con descomentar estas 3
            // líneas para reactivarlo. Con ShouldSeekShelter siempre en su valor por defecto
            // (false), esos 3 estados nunca disparan la transición a SeekShelterState.
            // NPCWeatherAwareness.RainStarted += HandleRainStarted;
            // NPCWeatherAwareness.RainStopped += HandleRainStopped;
            // _context.ShouldSeekShelter = NPCWeatherAwareness.IsRaining;

            // 🌍 LOD de IA: offset aleatorio para no acumular las comprobaciones de distancia de
            // todos los NPCs de la escena en el mismo frame (ver aiDistanceCheckInterval).
            _distanceCheckTimer = UnityEngine.Random.Range(0f, Mathf.Max(0.05f, aiDistanceCheckInterval));
        }

        private void HandleRainStarted()
        {
            if (_context != null) _context.ShouldSeekShelter = true;
        }

        private void HandleRainStopped()
        {
            if (_context == null) return;

            // El propio SeekShelterState (todavía activo y recibiendo Update normalmente, el NPC
            // nunca se desactiva) detecta este flag en su CheckTransitions y hace que el NPC
            // camine de vuelta a ShelterOriginPosition vía ReturnFromShelterState.
            _context.ShouldSeekShelter = false;
        }
        
        void OnEnable()
        {
            // _context ya existe siempre aquí: Unity llama Awake() antes que OnEnable(),
            // incluida la primera activación. Ver NPCAmbientRegistry para el uso (radar de amistad).
            if (_context != null)
                NPCAmbientRegistry.Register(_context.RelationshipId, this);

            DialogueManager.OnDialogueStarted += HandleDialogueStarted;
            DialogueManager.OnDialogueClosed += HandleDialogueClosed;
        }

        void OnDisable()
        {
            if (_context != null)
            {
                NPCAmbientRegistry.Unregister(_context.RelationshipId, this);
                _context.IsInteracting = false;
            }

            DialogueManager.OnDialogueStarted -= HandleDialogueStarted;
            DialogueManager.OnDialogueClosed -= HandleDialogueClosed;
        }

        private void HandleDialogueStarted(Transform speaker)
        {
            if (speaker == transform || (speaker != null && speaker.IsChildOf(transform)))
            {
                if (_context != null) _context.IsInteracting = true;
            }
        }

        private void HandleDialogueClosed(Transform speaker)
        {
            if (_context != null && _context.IsInteracting)
            {
                _context.IsInteracting = false;
            }
        }

        void Start()
        {
            // Aplicar persistencia si existe
            if (persistLastPosition && lastPosition != Vector3.zero)
            {
                ApplyLastPositionIfNeeded();
            }

            // Solo inicializar a Idle si ningún sistema externo ya asignó un estado
            // (ej: ActiveCharacterSwapper puede poner al Will NPC en AllyCombatState antes de que Start() corra)
            if (startInIdleState && _brain.CurrentState == null)
            {
                _brain.ChangeState(new States.IdleState());
            }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            WarnIfFixedSitterMisplaced();
#endif
        }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        // FIX (30 ago 2026, incidencia reportada por Raúl: NPC sentado pero hundido en el suelo —
        // confirmado que NO estaba en un NPCShelterPoint, así que SeekShelterState queda descartado
        // como causa): los NPCs con actividad ambiental FIJA (ambientConfig.enableWander = false +
        // ambientActivity = Sit*, ver IdleState.OnEnter) se sientan exactamente en su posición de
        // spawn — un Transform colocado a mano en la escena — sin ningún raycast de comprobación
        // contra el suelo real, a diferencia de SeekShelterState, que sí avisa si su punto de
        // refugio queda muy por encima/debajo del NavMesh (ver LogWarning en esa clase). Como estos
        // NPCs nunca caminan (enableWander = false), si el Transform se colocó ligeramente por
        // debajo de la malla de terreno al diseñar la escena, el NPC se sienta ahí hundido para
        // siempre y nada lo corrige ni lo detecta solo. Este chequeo solo avisa por consola al
        // arrancar — no mueve al NPC — para poder localizar rápido qué NPC/escena tiene el
        // Transform mal colocado la próxima vez que se reporte este síntoma.
        private const float SitterGroundMismatchWarnThreshold = 0.15f;

        private void WarnIfFixedSitterMisplaced()
        {
            var ambientConfig = configuration?.ambientConfig;
            if (ambientConfig == null || ambientConfig.enableWander) return;

            bool isSitActivity = ambientConfig.ambientActivity == NPCAmbientActivity.SitGround
                || ambientConfig.ambientActivity == NPCAmbientActivity.SitLow
                || ambientConfig.ambientActivity == NPCAmbientActivity.SitMedium
                || ambientConfig.ambientActivity == NPCAmbientActivity.SitHigh;
            if (!isSitActivity) return;

            Vector3 origin = transform.position + Vector3.up * 1.5f;
            var hits = Physics.RaycastAll(origin, Vector3.down, 5f, ~0, QueryTriggerInteraction.Ignore);
            System.Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));

            foreach (var hit in hits)
            {
                if (hit.transform == transform || hit.transform.IsChildOf(transform)) continue;

                float verticalDiff = hit.point.y - transform.position.y;
                if (Mathf.Abs(verticalDiff) > SitterGroundMismatchWarnThreshold)
                {
                    Debug.LogWarning($"[NPCBehaviourManagerV2:{gameObject.name}] NPC con actividad fija '{ambientConfig.ambientActivity}' " +
                        $"(enableWander=false) tiene su Transform a {Mathf.Abs(verticalDiff):F2}m " +
                        $"{(verticalDiff > 0 ? "por debajo del suelo detectado (probablemente hundido)" : "por encima del suelo detectado")} " +
                        $"bajo '{hit.collider.name}' — revisar la altura Y de su Transform en el Editor, se sentará así para siempre sin corregirse solo.");
                }
                break; // solo el primer hit válido (el más cercano que no sea el propio NPC)
            }
        }
#endif
        
        void Update()
        {
            if (aiUpdateDistance > 0f)
            {
                _distanceCheckTimer -= Time.deltaTime;

                // FIX (31 ago 2026, INC-129 — NPC "congelado" en la pose de reacción a la lluvia
                // tras dejar de llover, aunque el causante concreto -el refugio de lluvia- se ha
                // desactivado por diseño más abajo, esta carrera de condiciones es general): si
                // el chequeo periódico de distancia duerme a este NPC en ESTE mismo frame
                // (justEnteredFar), antes se saltaba _brain.Update() sin más — y si justo en ese
                // instante una condición de exención (ver HasActiveAiExemption) acababa de pasar
                // a false, el estado activo nunca llegaba a enterarse del cambio y se quedaba
                // congelado hasta que el jugador volviera a acercarse. Ahora, el frame en el que
                // el NPC pasa a estar "lejos" siempre deja pasar un último _brain.Update() antes
                // de empezar a saltárselo, para que cualquier transición pendiente por un cambio
                // de flag reciente se procese antes de dormir al NPC.
                bool justEnteredFar = false;
                if (_distanceCheckTimer <= 0f)
                {
                    _distanceCheckTimer = aiDistanceCheckInterval;
                    bool wasFarBefore = _isFarFromPlayer;
                    UpdateDistanceLOD();
                    justEnteredFar = !wasFarBefore && _isFarFromPlayer;
                }

                // El NPC está "dormido" (lejos y sin ninguna razón para seguir activo): nos
                // saltamos por completo el Brain.Update() de este frame. Esto es lo que causaba
                // el frame time alto en exteriores grandes: cada NPC esparcido por el mundo
                // seguía corriendo su FSM entera (detección, wander, NavMeshAgent...) aunque
                // estuviera a cientos de metros del jugador y fuera de cámara.
                if (_isFarFromPlayer && !justEnteredFar)
                {
                    // Si justo AHORA aparece una razón para estar activo (p.ej. algo externo nos
                    // metió en combate/cinemática mientras dormíamos), despertamos de inmediato en
                    // vez de esperar al próximo chequeo de distancia — sin esto, el Brain podría
                    // intentar usar un NavMeshAgent que dejamos deshabilitado en EnterFarState().
                    if (HasActiveAiExemption())
                    {
                        _isFarFromPlayer = false;
                        ExitFarState();
                    }
                    else
                    {
                        UpdatePersistedPositionIfNeeded();
                        return;
                    }
                }
            }

            _brain?.Update();

            UpdatePersistedPositionIfNeeded();
        }

        private void UpdatePersistedPositionIfNeeded()
        {
            // Actualizar posición para guardado (solo si es necesario para evitar overhead)
            if (persistLastPosition && Time.frameCount % 60 == 0) // Optimización: cada 60 frames
            {
                lastPosition = transform.position;
            }
        }

        /// <summary>
        /// Comprueba la distancia al jugador y decide si este NPC debe "dormirse" (dejar de
        /// ejecutar su FSM y desactivar su NavMeshAgent) o "despertar". Usa histéresis
        /// (aiWakeUpMargin) para no oscilar justo en el límite. Se llama cada
        /// aiDistanceCheckInterval segundos, no cada frame.
        /// </summary>
        private void UpdateDistanceLOD()
        {
            if (_player == null)
            {
                // Sin referencia al jugador todavía (o desregistrado): mejor no dormir al NPC,
                // pagar el coste de más que dejarlo colgado en un estado inconsistente.
                _isFarFromPlayer = false;
                return;
            }

            // FIX 04 sep 2026 (Raúl: Eldran "da saltitos y a veces no anima las piernas" al
            // guiar al jugador a un punto de guardado tras un boss, incluso siendo la MISMA
            // secuencia -LeadPlayerToAnchorSequence, sin cambios de código- que "antes funcionaba").
            // Este método dormía al NPC (EnterFarState desactiva agent.enabled) SOLO por distancia
            // al jugador, sin comprobar HasActiveAiExemption() -combate/cinemática/interacción-.
            // HasActiveAiExemption() solo se consultaba en Update(), UN FRAME DESPUÉS, para decidir
            // si despertarlo de nuevo — es decir, con dos sistemas independientes tocando el mismo
            // NavMeshAgent: este chequeo de distancia (ciego a la cinemática) y la secuencia de
            // escolta (que asume el agente siempre habilitado). Durante una escolta como la de
            // Eldran, si el jugador se queda un poco atrás (fácil cerca de las montañas, con más
            // desnivel/rodeos), este método desactivaba el agente ese mismo frame -antes de que
            // Update() llegara a comprobar la exención- y solo se reactivaba el frame siguiente:
            // ese frame de agente desactivado es exactamente el "se mueve sin animar piernas"
            // (velocity cae a 0 con el agente off) y el Warp de vuelta al reactivarlo es el
            // "saltito". Si el jugador se quedaba atrás más de un frame, el NPC directamente
            // dejaba de moverse del todo mientras la secuencia seguía llamando a un agente inerte.
            // Con esta comprobación, un NPC con exención activa nunca llega a dormirse por
            // distancia, y si ya estaba dormido al activarse la exención, se despierta aquí mismo
            // en vez de esperar al chequeo de Update().
            if (HasActiveAiExemption())
            {
                if (_isFarFromPlayer)
                {
                    _isFarFromPlayer = false;
                    ExitFarState();
                }
                return;
            }

            float distSqr = (transform.position - _player.position).sqrMagnitude;
            float sleepThreshold = aiUpdateDistance + aiWakeUpMargin;

            if (!_isFarFromPlayer && distSqr > sleepThreshold * sleepThreshold)
            {
                _isFarFromPlayer = true;
                EnterFarState();
            }
            else if (_isFarFromPlayer && distSqr < aiUpdateDistance * aiUpdateDistance)
            {
                _isFarFromPlayer = false;
                ExitFarState();
            }
        }

        /// <summary>
        /// Casos en los que NUNCA debemos dormir a un NPC aunque esté lejos: combate, cinemática,
        /// interacción en curso, refugiándose de la lluvia, o siendo un aliado del party (que en
        /// la práctica siempre está pegado al jugador, pero por seguridad se excluye igualmente).
        /// </summary>
        private bool HasActiveAiExemption()
        {
            if (_context == null) return true; // Sin contexto FSM, no tocar nada por seguridad

            return _context.IsInCombat
                || _context.IsInCinematic
                || _context.IsInteracting
                || _context.ShouldSeekShelter
                || IsAlly
                // IsAlly exige NPCPartyMember.IsInParty, pero el NPC de Will cuando otro va al
                // mando (ControlDelJugador.NpcDe) sigue al jugador sin pasar por JoinParty. Sin
                // esto podría «dormirse» lejos (EnterFarState apaga el NavMeshAgent y Brain.Update)
                // y reaparecer a saltos. IsActivelyFollowingPlayer cubre a cualquier compañero que
                // siga al jugador sin estar en PlayerParty.
                || _context.IsActivelyFollowingPlayer;
        }

        // Lo que EnterFarState cambia para devolverlo igual al despertar.
        private AnimatorCullingMode _cullingAntesDeDormir;
        private bool _cullingCambiadoPorDistancia;
        private SombraDeContacto _sombraApagadaPorDistancia;

        private void EnterFarState()
        {
            // Lejos, el animador solo trabaja si alguna cámara lo ve, y la sombra de contacto
            // (un rayo por fotograma) se apaga: a esta distancia no se distingue.
            if (_unityAnimator != null)
            {
                _cullingAntesDeDormir = _unityAnimator.cullingMode;
                _unityAnimator.cullingMode = AnimatorCullingMode.CullCompletely;
                _cullingCambiadoPorDistancia = true;
            }
            if (TryGetComponent(out SombraDeContacto sombra) && sombra.enabled)
            {
                sombra.enabled = false;
                _sombraApagadaPorDistancia = sombra;
            }

            // Además de detener el movimiento, desactivamos el propio componente NavMeshAgent:
            // dejarlo solo "isStopped = true" no lo saca del sistema interno de NavMesh de Unity
            // (PreUpdate.AIUpdate / AIUpdatePostScript en el Profiler), que sigue procesando el
            // agente igualmente mientras esté enabled. Con enabled = false sí desaparece de ahí.
            if (_agent != null && _agent.enabled)
            {
                if (_agent.isOnNavMesh)
                {
                    _agent.isStopped = true;
                    if (_agent.hasPath)
                        _agent.ResetPath();
                }
                _agent.enabled = false;
            }
        }

        private void ExitFarState()
        {
            if (_cullingCambiadoPorDistancia && _unityAnimator != null)
                _unityAnimator.cullingMode = _cullingAntesDeDormir;
            _cullingCambiadoPorDistancia = false;
            if (_sombraApagadaPorDistancia != null)
            {
                _sombraApagadaPorDistancia.enabled = true;
                _sombraApagadaPorDistancia = null;
            }

            if (_agent != null && !_agent.enabled && !SentadoFijo)
            {
                // ✅ FIX (04 sep 2026): antes se hacía "_agent.enabled = true" a secas y solo
                // DESPUÉS se comprobaba isOnNavMesh para recolocar con Warp. Unity valida
                // transform.position en el instante mismo de poner enabled = true — si el NPC
                // llevaba dormido un rato (agent deshabilitado) y su transform quedó fuera del
                // NavMesh mientras tanto (p.ej. el jugador se teletransportó o el NPC se movió por
                // GameBootProfile.ApplyNpcPositionsToScene con el agent aún desactivado), ese
                // "enabled = true" a secas ya loggeaba "Failed to create agent because it is not
                // close enough to the NavMesh" aunque el Warp de la línea siguiente corrigiera la
                // posición de inmediato — el mismo patrón que NavMeshAgentUtility.SafeEnable()
                // documenta y que este mismo fichero ya evita en ApplyLastPositionIfNeeded (más abajo).
                // Esto explica el spam masivo de ese warning "nada más darle a Play": con el
                // sistema de sueño por distancia (añadido hoy) TODOS los NPCs lejos del jugador al
                // cargar la escena entran en EnterFarState/ExitFarState mientras las posiciones se
                // estabilizan, y cada ExitFarState con el transform aún fuera de sitio disparaba el
                // warning. SafeEnable recoloca el transform en un punto válido del NavMesh ANTES de
                // habilitar, evitando el falso error en vez de corregirlo tarde.
                NavMeshAgentUtility.SafeEnable(_agent, transform, transform.position);
            }

            // No hace falta nada más aquí: el próximo Update() ya llama a _brain.Update() con
            // normalidad, y el estado activo (Wander/Idle/Alert...) recalcula su CheckTransitions
            // como si nunca se hubiera dormido.
        }

        void LateUpdate()
        {
            if (IsExternalMovementOverrideActive)
                return;

            // ✅ SAFETY CHECK: Si está en IdleState pero el agente no está detenido, forzar detención
            // Esto captura casos donde algo externo está activando el agente
            // FIX M12 (auditoría 2026-08-07, parcial): comparación por tipo en vez de por string
            // (evita comparar StateName == "Idle" cada NPC/frame). No se ha unificado con la
            // vigilancia equivalente de IdleState.OnUpdate — ambas llevan el comentario "FIX
            // CRÍTICO" propio, señal de que cada una se añadió para tapar un caso real distinto;
            // fusionarlas sin poder reproducir esos casos en el editor es más riesgo del que
            // conviene asumir ahora mismo.
            if (_brain != null && _brain.CurrentState is IdleState &&
                _agent != null && _agent.enabled && _agent.isOnNavMesh)
            {
                if (!_agent.isStopped || _agent.velocity.sqrMagnitude > 0.01f)
                {
                    if (debugMode)
                        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.LogWarning($"[NPCManager:{name}] ⚠️ LateUpdate Safety: Agent no detenido en IdleState (isStopped={_agent.isStopped}, vel={_agent.velocity.magnitude:F1})");
#endif
                        }
                    
                    _agent.isStopped = true;
                    _agent.velocity = Vector3.zero;
                    if (_agent.hasPath)
                        _agent.ResetPath();
                }
            }
        }

        void OnDestroy()
        {
            // Limpiar registro de combate
            ActiveCombatRegistry.UnregisterNPC(gameObject);
            
            UnregisterNarrativeIdentity();
            PlayerService.OnPlayerRegistered -= OnPlayerRegistered;
            PlayerService.OnPlayerUnregistered -= OnPlayerUnregistered;
            // Ver Awake(): suscripción desactivada, así que no hace falta des-suscribirse.
            // NPCWeatherAwareness.RainStarted -= HandleRainStarted;
            // NPCWeatherAwareness.RainStopped -= HandleRainStopped;
        }

        // =================================================================================
        // 🧩 AUTO-COMPONENT MANAGEMENT (MEJORADO)
        // =================================================================================
        
        private void EnsureRequiredComponents()
        {
            if (debugMode)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCManager] 🔧 Verificando módulos...");
                #endif
            }
            
            // 1. QUEST MODULE
            if (configuration.HasBehaviour(NPCBehaviourType.Quest) && configuration.questConfig != null)
            {
                // NarrativeActor antes que nada: NPCQuestConfig.autoStartOnDetection y el propio
                // NPCQuestActionExecutor pueden necesitar los campos de detección/icono que ahora
                // vive ahí (movidos desde este archivo el 12 sept 2026).
                if (!GetComponent<NarrativeActor>())
                    gameObject.AddComponent<NarrativeActor>();

                if (!GetComponent<NPCQuestActionExecutor>())
                    gameObject.AddComponent<NPCQuestActionExecutor>();
                
                // Añadir gestor de iconos de quest
                if (!GetComponent<NPCQuestIconManager>())
                {
                    gameObject.AddComponent<NPCQuestIconManager>();
                    if (debugMode)
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[NPCManager] 🎯 NPCQuestIconManager añadido para {name}");
                        #endif
                    }
                }
            }
            
            // 2. INTERACTIVE NARRATIVE
            if (configuration.HasBehaviour(NPCBehaviourType.InteractiveNarrative) && configuration.interactiveNarrativeConfig != null)
            {
                if (!GetComponent<NarrativeActor>())
                    gameObject.AddComponent<NarrativeActor>();

                if (!GetComponent<NPCInteractiveNarrativeExecutor>())
                    gameObject.AddComponent<NPCInteractiveNarrativeExecutor>();
            }

            // 3. COMBAT MODULE - 🔥 MEJORA CRÍTICA 🔥
            // Inicializamos los componentes "físicos" (Salud, Targetable) AHORA.
            // La "IA" (CombatBrain) se añade luego en CombatState.
            if (configuration.HasBehaviour(NPCBehaviourType.Combat) && configuration.combatConfig != null)
            {
                // A. Damageable (Vida) - Para que pueda morir por emboscada
                if (!GetComponent<Damageable>())
                {
                    var dmg = gameObject.AddComponent<Damageable>();
                    dmg.SetMaxAndCurrent(configuration.combatConfig.health, configuration.combatConfig.health);
                    
                    // ✅ CRÍTICO: Establecer destroyOnDeath=false INMEDIATAMENTE
                    // El LifecycleHandler controlará la muerte manualmente
                    dmg.SetDestroyOnDeath(false);
                    
                    if (debugMode)
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[NPCManager] 🛡️ Damageable añadido (Pre-Combate) - destroyOnDeath=false");
                        #endif
                    }
                }

                // B. CombatLifecycleHandler (Gestión de muerte/stun)
                if (!GetComponent<NPCCombatLifecycleHandler>())
                {
                    gameObject.AddComponent<NPCCombatLifecycleHandler>();
                    //if (debugMode) Debug.Log($"[NPCManager] ☠️ NPCCombatLifecycleHandler añadido (Pre-Combate) para {name}");
                }
                else
                {
                    //if (debugMode) Debug.Log($"[NPCManager] ℹ️ NPCCombatLifecycleHandler ya existe en {name}");
                }

                // C. Targetable (Para que el jugador pueda apuntarle antes de pelear)
                if (!GetComponent<Targetable>())
                {
                    gameObject.AddComponent<Targetable>();
                    if (debugMode)
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[NPCManager] 🎯 Targetable añadido (Pre-Combate)");
                        #endif
                    }
                }
                
                // D. NPCHealthBarSpawner (Barra de vida)
                if (!GetComponent<NPCHealthBarSpawner>())
                {
                    var spawner = gameObject.AddComponent<NPCHealthBarSpawner>();
                    if (configuration.combatConfig.healthBarPrefab != null)
                        spawner.SetHealthBarPrefab(configuration.combatConfig.healthBarPrefab);
                }
            }
            
            // 4. COMPANION MODULE (Party System)
            // Permite que el NPC se una al equipo del jugador
            if (configuration.HasBehaviour(NPCBehaviourType.Companion) && configuration.partyConfig != null)
            {
                if (!GetComponent<NPCPartyMember>())
                {
                    var partyMember = gameObject.AddComponent<NPCPartyMember>();
                    partyMember.SetConfig(configuration.partyConfig);
                    if (debugMode)
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[NPCManager] 🤝 NPCPartyMember añadido para {name}");
                        #endif
                    }
                }

                // Prompt "Sígueme": se muestra cuando el jugador se acerca y el equipo está disuelto
                if (!GetComponent<CompanionFollowPrompt>() &&
                    configuration.partyConfig.followPromptIconPrefab != null)
                {
                    var prompt = gameObject.AddComponent<CompanionFollowPrompt>();
                    prompt.SetFollowIcon(configuration.partyConfig.followPromptIconPrefab);
                    prompt.SetStopFollowIcon(configuration.partyConfig.stopFollowIconPrefab);
                }
            }

            // Cachear componentes frecuentemente usados
            _cachedPartyMember = GetComponent<NPCPartyMember>();
            _cachedLifecycle = GetComponent<NPCCombatLifecycleHandler>();
        }

        // =================================================================================
        // 🎮 STATE CONTROL API
        // =================================================================================

        public void EnterCombat()
        {
            // Evitar entrar en combate si ya estamos muertos
            if (_cachedLifecycle != null && _cachedLifecycle.IsDefeatedAndInactive) return;

            _context.IsInCombat = true;

            // ✅ Verificar si es un aliado (miembro del party)
            bool isAlly = _cachedPartyMember != null && _cachedPartyMember.IsInParty;
            
            if (isAlly)
            {
                // 🤝 ALIADO: Usar AllyCombatState (ataca enemigos, no al jugador)
                // NO registrar en ActiveCombatRegistry (eso es para enemigos)
                if (!(_brain.CurrentState is States.AllyCombatState))
                {
                    if (debugMode)
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[NPCManager] 🤝 {name} entrando en AllyCombatState (es aliado)");
                        #endif
                    }
                    _brain.ChangeState(new States.AllyCombatState());
                }
                return; // No continuar con lógica de enemigos
            }
            
            // ⚔️ ENEMIGO: Lógica normal
            // Registrar NPC en el registro de combate activo
            ActiveCombatRegistry.RegisterNPC(gameObject);
            
            if (!(_brain.CurrentState is States.CombatState))
            {
                _brain.ChangeState(new States.CombatState());
            }
            
            // Si es líder de un equipo, hacer que los compañeros también entren en combate
            var combatTeam = GetComponent<NPCCombatTeam>();
            if (combatTeam != null)
            {
                // Obtener el jugador como objetivo
                Transform target = _context.Player;
                if (target == null && PlayerService.TryGetPlayer(out var player))
                {
                    target = player.transform;
                }
                
                if (target != null)
                {
                    // ForceTeamCombat hará que todos los miembros entren en combate
                    combatTeam.ForceTeamCombat(target);
                }
            }
        }
        
        public void ExitCombat()
        {
            _context.IsInCombat = false;
            
            // ✅ Desregistrar NPC del registro de combate activo
            ActiveCombatRegistry.UnregisterNPC(gameObject);
            
            // El CombatState detectará el flag en su Update y saldrá solo
        }
        
        /// <summary>
        /// Fuerza al NPC a entrar en combate inmediatamente contra un objetivo específico.
        /// Usado por el sistema de equipos de combate (NPCCombatTeam).
        /// </summary>
        public void ForceEnterCombat(Transform target)
        {
            // Evitar entrar en combate si ya estamos muertos
            if (_cachedLifecycle != null && _cachedLifecycle.IsDefeatedAndInactive) return;

            // FIX C5 (auditoría 2026-08-07): NPCCombatLifecycleHandler.OnDamaged llama a este
            // método sin comprobar si el NPC está en mitad de una cinemática. Golpear a un NPC
            // durante una cinemática forzaba la salida de CinematicState (vía ForceState del
            // brain, más abajo) a mitad de secuencia, dejando colgados los secuenciadores que
            // encadenan pasos por onComplete (MountainSequencer, ReinoExitBanterSequencer). El
            // combate se resolverá igualmente en cuanto la cinemática termine — el atacante no
            // pierde el registro, solo se evita interrumpir la secuencia en curso.
            if (_context != null && _context.IsInCinematic) return;

            // Asignar el objetivo
            _context.Player = target;
            _context.IsInCombat = true;
            
            // Registrar en el registro de combate activo
            ActiveCombatRegistry.RegisterNPC(gameObject);
            
            // Forzar cambio a estado de combate
            if (!(_brain.CurrentState is States.CombatState))
            {
                if (debugMode)
                {
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[NPCManager] ⚔️ {name} forzado a entrar en combate contra {target.name}");
                    #endif
                }
                _brain.ForceState(new States.CombatState());
            }
        }

        public void ForceIdle()
        {
            _brain.ForceState(new States.IdleState());
        }

        public void PushExternalMovementOverride()
        {
            _externalMovementOverrideRequests++;
        }

        public void PopExternalMovementOverride()
        {
            if (_externalMovementOverrideRequests > 0)
                _externalMovementOverrideRequests--;
        }

        // =================================================================================
        // 🤝 PARTY SYSTEM API
        // =================================================================================
        
        #region Party Events
        
        [Header("Party Events")]
        [Tooltip("Evento que se invoca cuando el NPC se une al party")]
        [SerializeField] private UnityEvent onJoinedParty;
        
        [Tooltip("Evento que se invoca cuando el NPC abandona el party")]
        [SerializeField] private UnityEvent onLeftParty;
        
        /// <summary>
        /// Evento C# que se dispara cuando el NPC se une al party
        /// </summary>
        public event Action OnJoinedParty;
        
        /// <summary>
        /// Evento C# que se dispara cuando el NPC abandona el party
        /// </summary>
        public event Action OnLeftParty;
        
        #endregion
        
        /// <summary>
        /// Une este NPC al equipo del jugador.
        /// Requiere que el NPC tenga el comportamiento Companion configurado.
        /// </summary>
        public bool JoinPlayerParty()
        {
            if (_cachedPartyMember == null)
            {
                if (debugMode)
                {
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.LogWarning($"[NPCManager] {name} no tiene NPCPartyMember. Asegúrate de configurar Companion behaviour.");
                    #endif
                }
                return false;
            }

            bool success = _cachedPartyMember.JoinParty();
            
            if (success)
            {
                // Disparar eventos
                onJoinedParty?.Invoke();
                OnJoinedParty?.Invoke();
                
                if (debugMode)
                {
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[NPCManager:{name}] ✅ Se unió al party - Eventos disparados");
                    #endif
                }
            }
            
            return success;
        }
        
        /// <summary>
        /// Remueve este NPC del equipo del jugador.
        /// </summary>
        public bool LeavePlayerParty()
        {
            if (_cachedPartyMember == null) return false;

            bool success = _cachedPartyMember.LeaveParty();
            
            if (success)
            {
                // Disparar eventos
                onLeftParty?.Invoke();
                OnLeftParty?.Invoke();
                
                if (debugMode)
                {
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[NPCManager:{name}] 👋 Abandonó el party - Eventos disparados");
                    #endif
                }
            }
            
            return success;
        }
        
        /// <summary>
        /// Comprueba si este NPC está actualmente en el equipo del jugador.
        /// </summary>
        public bool IsInPlayerParty() => _cachedPartyMember != null && _cachedPartyMember.IsInParty;
        
        /// <summary>
        /// Une este NPC al party del jugador.
        /// Versión void para poder usarse desde Unity Events (OnMinigameWon, etc.)
        /// </summary>
        [ContextMenu("Añadir al Party")]
        public void AddToParty()
        {
            bool success = JoinPlayerParty();
            if (success)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCManager:{name}] ✅ AddToParty exitoso");
#endif
            }
            else if (debugMode)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCManager:{name}] ⚠️ AddToParty falló - ¿Tiene Companion behaviour configurado?");
#endif
            }
        }
        
        /// <summary>
        /// Remueve este NPC del party del jugador.
        /// Versión void para poder usarse desde Unity Events.
        /// </summary>
        public void RemoveFromParty()
        {
            bool success = LeavePlayerParty();
            if (!success && debugMode)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCManager:{name}] ⚠️ RemoveFromParty falló");
#endif
            }
        }

        // =================================================================================
        // 🗣️ SOCIAL ENCOUNTER API
        // =================================================================================

        /// <summary>
        /// Llamado por otro NPC que quiere iniciar un encuentro social con este.
        /// Devuelve true si se acepta; en ese caso el NPC entra directamente en NPCSocialEncounterState.
        /// </summary>
        public bool TryAcceptSocialEncounter(Transform initiator, NPCRelationType relation)
        {
            if (_context == null) return false;
            if (_context.IsInCombat || _context.IsInCinematic || _context.IsInteracting) return false;
            if (_context.WasDefeatedInCombat) return false;
            if (_brain.CurrentState is States.NPCSocialEncounterState) return false;

            float cooldown = configuration.socialConfig?.socialCooldown ?? 30f;
            if (Time.time - _context.LastSocialEncounterTime < cooldown) return false;

            _context.PendingSocialPartner  = initiator;
            _context.PendingSocialRelation = relation;
            _brain.ChangeState(new States.NPCSocialEncounterState());
            return true;
        }

        // =================================================================================
        // 🎬 CINEMATICS & MOVEMENT API
        // =================================================================================

        public void MoveToPosition(Vector3 targetPosition, float walkDuration = 2f, float maxDuration = 15f, bool turn = false, Action onComplete = null)
        {
            var sequence = new States.MoveToPositionSequence(this, targetPosition, maxDuration, turn, walkDuration);
            if (onComplete != null) StartCoroutine(WaitForSequence(sequence, onComplete));
            StartCinematicSequence(sequence);
        }

        public void StartCinematicSequence(States.CinematicSequence sequence)
        {
            if (sequence == null) return;
            if (_brain == null)
            {
                if (_context == null)
                {
                    _agent = GetComponent<NavMeshAgent>();
                    _animator = GetComponent<NPCSimpleAnimator>();
                    _unityAnimator = GetComponent<Animator>();
                    _rigidbody = GetComponent<Rigidbody>();
                    _context = new NPCStateContext(null, transform, _agent, _animator, _unityAnimator, _rigidbody)
                    {
                        Config = configuration,
                        DebugMode = debugMode,
                        RelationshipId = ResolveRelationshipId()
                    };
                }
                _brain = new NPCBrain(_context);
                _context.Brain = _brain;
            }
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            if (_brain != null && _brain.CurrentState is States.CinematicState)
            {
                Debug.LogWarning($"[NPCBehaviourManagerV2:{name}] StartCinematicSequence({sequence.GetType().Name}) " +
                    "llamado mientras YA había una CinematicState activa -- la secuencia anterior va a ser " +
                    "desalojada sin avisar a quien la lanzo (ForceState no comprueba solapes).");
            }
#endif
            if (_brain != null)
            {
                var state = new States.CinematicState();
                state.StartSequence(sequence);
                _brain.ForceState(state);
            }
        }

        private System.Collections.IEnumerator WaitForSequence(States.CinematicSequence seq, Action callback)
        {
            while (!seq.IsCompleted) yield return null;
            callback?.Invoke();
        }

        // =================================================================================
        // 💾 PERSISTENCE & UTILS
        // =================================================================================

        public void ApplyLastPositionIfNeeded()
        {
            if (!persistLastPosition || lastPosition == Vector3.zero || SentadoFijo) return;

            // FIX INC-070: si el NavMesh se ha vuelto a bakear (o el terreno cambió) desde que se
            // guardó lastPosition, esa altura guardada puede ya no coincidir con la superficie
            // actual. Antes, si _agent.isOnNavMesh daba false en este punto (p.ej. porque la
            // posición de editor del NPC quedó fuera del NavMesh rebakeado), se hacía un
            // "transform.position = lastPosition" en crudo, sin comprobar el NavMesh actual — el
            // NPC quedaba flotando/enterrado ahí para siempre, ya que es cinemático
            // (forceKinematicRigidbody) y sin gravedad que lo corrija. Ahora buscamos primero el
            // punto válido más cercano en el NavMesh vigente antes de colocar al NPC.
            if (NavMesh.SamplePosition(lastPosition, out var hit, 5f, NavMesh.AllAreas))
            {
                if (_agent != null)
                {
                    bool wasEnabled = _agent.enabled;
                    if (!wasEnabled)
                    {
                        // FIX: Unity valida transform.position en el instante de poner
                        // enabled = true (antes de que el Warp de abajo pueda corregirlo). Si el
                        // transform seguía en su posición vieja (fuera del NavMesh rebakeado),
                        // ese "enabled = true" a secas loggeaba "Failed to create agent because
                        // there is no valid NavMesh" aunque el Warp siguiente ya llevara al NPC al
                        // punto correcto. SafeEnable recoloca el transform en hit.position ANTES
                        // de habilitar, evitando el falso error.
                        NavMeshAgentUtility.SafeEnable(_agent, transform, hit.position);
                    }
                    _agent.Warp(hit.position);
                    if (!wasEnabled) _agent.enabled = false;
                }
                else
                {
                    transform.position = hit.position;
                }
            }
            else if (_agent != null && _agent.isOnNavMesh)
            {
                _agent.Warp(lastPosition);
            }
            else
            {
                transform.position = lastPosition;
            }

            if(debugMode)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCManager] 📍 Posición restaurada: {lastPosition}");
                #endif
            }
        }
        
        public void HandleInteraction(GameObject interactor)
            => TryHandleInteraction(interactor);

        /// <summary>True si el grafo estaba esperando esta charla y se queda con ella.</summary>
        public bool TryHandleNarrativeInteraction()
            => _context != null && !_context.IsInCombat && _brain != null && _brain.TryHandleNarrativeInteraction();

        /// <summary>Frase que el grafo asigna ahora a este NPC (p. ej. «mientras tanto» de una misión).</summary>
        public bool TryGetStandingLine(out DialogueAsset dialogue)
        {
            dialogue = null;
            if (string.IsNullOrEmpty(PersistenceId) || !NarrativeStandingLines.TryFind(PersistenceId, out var frase)) return false;
            dialogue = frase as DialogueAsset;
            return dialogue != null;
        }

        public bool TryHandleInteraction(GameObject interactor)
        {
            // No interactuar si estamos muertos o en combate
            if (_context == null || _context.IsInCombat) return false;
            if (_cachedLifecycle != null && _cachedLifecycle.IsDefeatedAndInactive)
            {
                // TODO: Implementar HandlePostDefeatInteraction en NPCCombatLifecycleHandler
                // Por ahora, delegar al Brain para que maneje la interacción normalmente
                // lifecycle.HandlePostDefeatInteraction(interactor);
                return _brain != null && _brain.HandleInteraction(interactor);
            }

            return _brain != null && _brain.HandleInteraction(interactor);
        }

        /// <summary>
        /// Id estable para el registro de relaciones dinámicas (NPCRelationshipRegistry).
        /// Los NPCs con historia propia ya tienen un npcId único en su NPCSocialConfig individual.
        /// Los NPCs de relleno comparten un NPCSocialConfig de arquetipo con npcId vacío
        /// (ej. NPC_Social_Archetype_Friendly.asset) — para esos, generamos un id único por
        /// instancia aquí. Nunca se escribe de vuelta al ScriptableObject compartido.
        /// Ver Diseno_Refugio_Lluvia_y_Relaciones_NPC.md § B.2.
        /// </summary>
        private string ResolveRelationshipId()
        {
            string authoredId = configuration?.socialConfig?.npcId;
            if (!string.IsNullOrEmpty(authoredId)) return authoredId;

            if (!string.IsNullOrEmpty(persistenceId)) return persistenceId;

            return $"{gameObject.name}_{GetEntityId()}";
        }

        private void RegisterNarrativeIdentity()
        {
            _identityRegistered = true;
            string registryId = !string.IsNullOrEmpty(persistenceId) ? persistenceId : null;

            if (registryId == null)
            {
                if (configuration.HasBehaviour(NPCBehaviourType.InteractiveNarrative) ||
                    configuration.HasBehaviour(NPCBehaviourType.Companion) ||
                    GetComponent<NPCPartyMember>() != null)
                {
                    registryId = gameObject.name;
                }
            }

            if (!string.IsNullOrEmpty(registryId))
            {
                NPCRegistry.Instance.RegisterNPC(registryId, null, this);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                if (debugMode) Debug.Log($"[NPCBehaviourManagerV2] NPC '{registryId}' registrado en NPCRegistry");
#endif
            }
        }
        
        private void UnregisterNarrativeIdentity()
        {
            string registryId = !string.IsNullOrEmpty(persistenceId) ? persistenceId : null;

            if (registryId == null && configuration != null)
            {
                if (configuration.HasBehaviour(NPCBehaviourType.InteractiveNarrative) ||
                    configuration.HasBehaviour(NPCBehaviourType.Companion) ||
                    GetComponent<NPCPartyMember>() != null)
                {
                    registryId = gameObject.name;
                }
            }

            if (!string.IsNullOrEmpty(registryId) && Game.NPC.NPCRegistry.HasInstance)
            {
                NPCRegistry.Instance.UnregisterNPC(registryId, null);
            }
        }

        #region Player References
        private void OnPlayerRegistered(GameObject player) => ResolvePlayerReferences();
        private void OnPlayerUnregistered() { 
            _player = null; _playerCamera = null; 
            if(_context != null) { _context.Player = null; _context.PlayerCamera = null; }
        }
        private void ResolvePlayerReferences() {
            if (ServiceLocator.TryGet(out PlayerService ps) && PlayerService.Player != null) {
                _player = PlayerService.Player.transform;
                // ✅ OPTIMIZACIÓN: Cachear Camera.main solo si no la tenemos ya
                if (_playerCamera == null)
                {
                    _playerCamera = Camera.main?.transform;
                }
                if (_context != null) { _context.Player = _player; _context.PlayerCamera = _playerCamera; }
            }
        }
        #endregion

#if UNITY_EDITOR
        void OnDrawGizmosSelected()
        {
            if (!Application.isPlaying || _context == null) return;
            
            // Visualizar Destino
            if (_context.TargetDestination != Vector3.zero) {
                Gizmos.color = Color.yellow;
                Gizmos.DrawWireSphere(_context.TargetDestination, 0.5f);
                Gizmos.DrawLine(transform.position, _context.TargetDestination);
            }

            // Visualizar rango de combate si existe
            if (configuration.combatConfig != null) {
                Gizmos.color = new Color(1, 0, 0, 0.3f);
                Gizmos.DrawWireSphere(transform.position, configuration.combatConfig.minAttackDistance);
                Gizmos.color = new Color(1, 0, 0, 0.5f);
                Gizmos.DrawWireSphere(transform.position, configuration.combatConfig.maxAttackDistance);
            }

            // Visualizar radio de LOD de IA (azul = dormido ahora mismo, verde = activo)
            if (aiUpdateDistance > 0f) {
                Gizmos.color = _isFarFromPlayer ? new Color(0.3f, 0.5f, 1f, 0.5f) : new Color(0.3f, 1f, 0.4f, 0.25f);
                Gizmos.DrawWireSphere(transform.position, aiUpdateDistance);
            }
        }
#endif
    }
}
