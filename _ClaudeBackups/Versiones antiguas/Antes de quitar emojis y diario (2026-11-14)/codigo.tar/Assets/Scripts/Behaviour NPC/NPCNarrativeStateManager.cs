using UnityEngine;
using Game.NPC.Modules;

namespace Game.NPC
{
    // ───────────────────────────────────────────────────────────────────────
    // CONGELADO — utilidad de reset del motor Interactive/PlayerPrefs
    // NarrativeState_* legacy. No tiene sustituto activo: el grafo nuevo no
    // necesita nada equivalente (persiste vía blackboard/preset, sin PlayerPrefs).
    // Ver claude/catalogo-sistemas-legacy-vs-grafo-nuevo-2026-09-12.md § 2.
    // ───────────────────────────────────────────────────────────────────────
    /// <summary>
    /// Manager que resetea el estado de todos los NPCs con narrativas interactivas.
    /// Llamar NPCNarrativeStateManager.ResetAllNPCs() al iniciar una nueva partida.
    /// </summary>
    public static class NPCNarrativeStateManager
    {
        /// <summary>
        /// Resetea el estado de TODOS los NPCs con narrativas interactivas en la escena.
        /// Llamar este método al iniciar una nueva partida.
        /// </summary>
        public static void ResetAllNPCs()
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log("[NPCNarrativeStateManager] 🔄 Iniciando reset de todos los NPCs...");
#endif
            
            var allExecutors = NPCInteractiveNarrativeRegistry.GetAll();
            
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCNarrativeStateManager] 📋 Encontrados {allExecutors.Count} executors en el registro");
#endif
            
            int resetCount = 0;
            int failedCount = 0;
            
            foreach (var executor in allExecutors)
            {
                if (executor != null)
                {
                    try
                    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[NPCNarrativeStateManager] 🔄 Reseteando: {executor.name}");
#endif
                        executor.ResetState();
                        resetCount++;
                    }
                    catch (System.Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        ex
#endif
                    )
                    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.LogError($"[NPCNarrativeStateManager] ❌ Error al resetear {executor.name}: {ex.Message}");
#endif
                        failedCount++;
                    }
                }
                else
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.LogWarning("[NPCNarrativeStateManager] ⚠️ Executor null en la lista");
#endif
                    failedCount++;
                }
            }
            
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCNarrativeStateManager] ✅ Reset completado: {resetCount} NPCs reseteados, {failedCount} fallos");
#endif
        }
        
        /// <summary>
        /// Resetea el estado de un NPC específico por nombre
        /// </summary>
        public static bool ResetNPC(string npcName)
        {
            var executor = NPCInteractiveNarrativeRegistry.GetByName(npcName);
            
            if (executor != null)
            {
                executor.ResetState();
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCNarrativeStateManager] 🔄 NPC '{npcName}' reseteado");
#endif
                return true;
            }
            
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[NPCNarrativeStateManager] ⚠️ No se encontró NPC con nombre '{npcName}'");
#endif
            return false;
        }
        
        /// <summary>
        /// Limpia todos los datos de persistencia de narrativas guardados
        /// </summary>
        public static void ClearAllSavedStates()
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log("[NPCNarrativeStateManager] 🗑️ Iniciando limpieza de estados guardados...");
#endif
            
            // Buscar todas las claves que empiezan con "NarrativeState_"
            int clearedCount = 0;
            
            // Obtener todos los executors desde el registro
            var allExecutors = NPCInteractiveNarrativeRegistry.GetAll();
            
            // Obtener el preset activo del GameBootService
            var preset = Partida.Preset;
            
            foreach (var executor in allExecutors)
            {
                if (executor != null)
                {
                    var config = executor.GetConfiguration();
                    var mgr = executor.Manager;
                    string pId = mgr != null ? mgr.PersistenceId : null;

                    if (config != null && config.persistState && !string.IsNullOrEmpty(pId))
                    {
                        // Limpiar PlayerPrefs (sistema antiguo)
                        string key = $"NarrativeState_{pId}";
                        if (PlayerPrefs.HasKey(key))
                        {
                            PlayerPrefs.DeleteKey(key);
                            clearedCount++;
                        }
                        
                        // Limpiar narrativas condicionales en PlayerPrefs
                        if (config.conditionalNarratives != null)
                        {
                            for (int i = 0; i < config.conditionalNarratives.Length; i++)
                            {
                                string narrativeKey = $"NarrativeState_{pId}_Conditional_{i}";
                                if (PlayerPrefs.HasKey(narrativeKey))
                                {
                                    PlayerPrefs.DeleteKey(narrativeKey);
                                }
                            }
                        }
                        
                        // CRÍTICO: Limpiar del GameBootService.Profile (donde realmente se lee)
                        if (preset != null && preset.completedInteractiveNarratives != null)
                        {
                            bool removed = preset.completedInteractiveNarratives.Remove(pId);
                            if (removed)
                            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                                Debug.Log($"[NPCNarrativeStateManager] Removido '{pId}' de GameBootService.Profile");
#endif
                            }
                        }
                    }
                }
            }
            
            PlayerPrefs.Save();
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCNarrativeStateManager] ✅ Limpieza completada: {clearedCount} estados de PlayerPrefs limpiados");
#endif
        }
        
        /// <summary>
        /// Obtiene información de debug sobre todos los NPCs con narrativas
        /// </summary>
        public static string GetDebugInfo()
        {
            var allExecutors = NPCInteractiveNarrativeRegistry.GetAll();
            
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.AppendLine($"=== NPCs con Narrativas Interactivas ({allExecutors.Count}) ===");
            
            foreach (var executor in allExecutors)
            {
                if (executor != null)
                {
                    var config = executor.GetConfiguration();
                    if (config != null)
                    {
                        string pId = executor.Manager != null ? executor.Manager.PersistenceId : "N/A";
                        sb.AppendLine($"\n🎭 {executor.name}");
                        sb.AppendLine($"   Persist: {config.persistState}");
                        sb.AppendLine($"   ID: {pId}");
                        sb.AppendLine($"   Narrativas: {config.conditionalNarratives?.Length ?? 0}");
                        
                        if (config.conditionalNarratives != null)
                        {
                            for (int i = 0; i < config.conditionalNarratives.Length; i++)
                            {
                                var narrative = config.conditionalNarratives[i];
                                if (narrative != null)
                                {
                                    sb.AppendLine($"      {i}. {narrative.description} - SingleUse: {narrative.singleUse}, Ejecutada: {narrative.HasBeenExecuted}");
                                }
                            }
                        }
                    }
                }
            }
            
            return sb.ToString();
        }
    }
}

