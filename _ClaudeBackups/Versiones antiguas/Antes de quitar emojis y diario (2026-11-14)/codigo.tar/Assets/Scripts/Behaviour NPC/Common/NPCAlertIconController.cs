﻿using System.Collections;
using UnityEngine;
using DG.Tweening;

namespace Game.NPC.Common
{
    /// <summary>
    /// Controla los iconos visuales sobre la cabeza del NPC.
    /// Los prefabs se configuran en NPCCombatConfig y se pasan como parámetros.
    /// Solo usa prefabs reutilizables - La forma más limpia y profesional.
    /// Incluye animaciones DOTween para aparición/desaparición.
    /// </summary>
    public class NPCAlertIconController : MonoBehaviour
    {
        [Header("Configuración de Posición")]
        [Tooltip("Offset adicional sobre la cabeza del NPC")]
        [SerializeField] private Vector3 iconOffset = new Vector3(0f, 0.3f, 0f);
        
        [Tooltip("Altura de fallback si no se encuentra la cabeza (desde transform.position)")]
        [SerializeField] private float fallbackHeight = 2.2f;
        
        [Tooltip("Nombres de huesos a buscar para la cabeza (en orden de prioridad)")]
        [SerializeField] private string[] headBoneNames = { "Head", "head", "Bip001 Head", "mixamorig:Head", "Cabeza" };
        
        [Header("Configuración de Duración")]
        [Tooltip("Duración del icono en segundos (si no se especifica)")]
        [SerializeField] private float iconDuration = 2f;
        
        [Header("Animación de Bounce")]
        [Tooltip("Si está activo, el icono hace bounce animado")]
        [SerializeField] private bool animateBounce = true;
        
        [Tooltip("Amplitud del bounce")]
        [SerializeField] private float bounceAmplitude = 0.15f;
        
        [Tooltip("Velocidad del bounce")]
        [SerializeField] private float bounceSpeed = 4f;
        
        [Header("Animaciones DOTween")]
        [Tooltip("Duración de la animación de aparición")]
        [SerializeField] private float showAnimDuration = 0.25f;
        
        [Tooltip("Duración de la animación de desaparición")]
        [SerializeField] private float hideAnimDuration = 0.15f;
        
        [Tooltip("Escala del icono")]
        [SerializeField] private float iconScale = 1f;
        
        [Tooltip("Delay antes de mostrar el icono tras cerrar un diálogo (para que la cámara vuelva)")]
        [SerializeField] private float restoreAfterDialogueDelay = 0.5f;
        
        [Header("Debug")]
        [SerializeField] private bool showDebugLogs = false;
        
        // Referencias
        private GameObject _currentIconInstance;
        private Coroutine _iconRoutine;
        private Coroutine _restoreAfterDialogueCoroutine;
        private Camera _mainCamera;
        private Tween _currentTween;
        private Transform _headBone;
        private bool _headBoneSearched;

        // El NPC sobre cuya cabeza va el icono. Por defecto, este mismo objeto; SeguirA() permite
        // vivir en un hijo dedicado (como hace NPCQuestIconManager, para no pisarse con otro
        // controlador del raíz) y aun así encontrar la cabeza del NPC (INC-429).
        private Transform _ancla;
        private Transform Ancla => _ancla != null ? _ancla : transform;

        /// Si es false, el icono sigue visible mientras hay un diálogo abierto (INC-429: el
        /// bocadillo de pelea de Eldran y Victoria tiene que verse mientras Oliver habla).
        public bool OcultarDuranteDialogos { get; set; } = true;

        /// Si es true (por defecto), un icono PERSISTENTE (misión, «!», seguir...) se esconde
        /// mientras hay una secuencia en curso y vuelve al acabar. Solo se pone a false cuando el
        /// icono forma parte de la propia escena, como el de pelea de DiscusionEnBucle, que tiene
        /// que verse durante la secuencia de Oliver. Ver INC-457.
        public bool OcultarDuranteSecuencias { get; set; } = true;

        /// ¿Hay una secuencia en curso? SequencePlayer (vía CinematicSequencerBase) o cualquier
        /// cosa que retenga al jugador en modo Cinematic: bocadillos tras una compra, un NPC que
        /// viene a hablarte, LockPlayer del grafo, la caja de diálogo...
        public static bool HaySecuenciaEnCurso()
        {
            if (CinematicSequencerBase.AnySequenceActive) return true;

            if (s_accionesJugador == null)
            {
                if (!PlayerService.HasInstance) return false;
                var jugador = PlayerService.Player;
                if (jugador == null) return false;
                s_accionesJugador = jugador.GetComponent<PlayerActionManager>();
                if (s_accionesJugador == null) return false;
            }
            return s_accionesJugador.IsInMode(ActionMode.Cinematic);
        }
        private static PlayerActionManager s_accionesJugador;

#if UNITY_EDITOR
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void ResetStatics() { s_accionesJugador = null; }
#endif

        /// Coloca el icono sobre la cabeza de 'npc' aunque este componente viva en otro objeto.
        public void SeguirA(Transform npc)
        {
            _ancla = npc;
            _headBone = null;
            _headBoneSearched = false;
        }
        
        // Estado
        private bool _isHiding;
        private bool _hiddenDuringDialogue;
        private bool _hiddenDuringSequence;
        private Vector3 _targetScale;
        
        private void Start()
        {
            UpdateCameraReference();
            FindHeadBone();
        }
        
        private void OnEnable()
        {
            DialogueManager.OnDialogueStarted += OnDialogueStarted;
            DialogueManager.OnDialogueClosed += OnDialogueClosed;
        }
        
        private void OnDisable()
        {
            DialogueManager.OnDialogueStarted -= OnDialogueStarted;
            DialogueManager.OnDialogueClosed -= OnDialogueClosed;

            // La corrutina de icono vive en este componente, no en el propio icono (sin padre).
            // Si el NPC se desactiva sin pasar por AlertState.OnExit, la corrutina se detiene y el
            // icono quedaría huérfano y congelado — OnDisable lo limpia explícitamente. Ver INC-184.
            HideAlertIconImmediate();
        }
        
        /// <summary>
        /// Busca el hueso de la cabeza del NPC para posicionar el icono correctamente
        /// </summary>
        private void FindHeadBone()
        {
            if (_headBoneSearched) return;
            _headBoneSearched = true;
            
            // Buscar Animator primero
            var animator = Ancla.GetComponentInChildren<Animator>();
            if (animator != null && animator.isHuman)
            {
                _headBone = animator.GetBoneTransform(HumanBodyBones.Head);
                if (_headBone != null)
                {
                    if (showDebugLogs)
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[NPCAlertIcon:{name}] ✅ Cabeza encontrada via Animator: {_headBone.name}");
                        #endif
                    }
                    return;
                }
            }
            
            // Buscar por nombre de hueso
            foreach (string boneName in headBoneNames)
            {
                _headBone = FindChildRecursive(Ancla, boneName);
                if (_headBone != null)
                {
                    if (showDebugLogs)
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[NPCAlertIcon:{name}] ✅ Cabeza encontrada por nombre: {_headBone.name}");
                        #endif
                    }
                    return;
                }
            }
            
            if (showDebugLogs)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCAlertIcon:{name}] ⚠️ No se encontró hueso de cabeza, usando fallback height={fallbackHeight}");
                #endif
            }
        }
        
        private Transform FindChildRecursive(Transform parent, string name)
        {
            foreach (Transform child in parent)
            {
                if (child.name.Equals(name, System.StringComparison.OrdinalIgnoreCase))
                    return child;
                    
                var found = FindChildRecursive(child, name);
                if (found != null) return found;
            }
            return null;
        }
        
        /// <summary>
        /// Calcula la posición donde debe aparecer el icono.
        /// Usa fallbackHeight como la altura desde los pies del NPC, más iconOffset adicional.
        /// Si se encuentra la cabeza y está cerca de fallbackHeight, usa la cabeza como referencia.
        /// </summary>
        private Vector3 GetIconWorldPosition()
        {
            // Posición base: pies del NPC
            Vector3 feetPosition = Ancla.position;
            
            // La altura configurada (alertIconHeight) se usa directamente
            Vector3 targetPos = feetPosition + Vector3.up * fallbackHeight;
            
            // Si encontramos la cabeza, verificar si está cerca de la altura configurada
            // y usarla para un posicionamiento más preciso
            if (_headBone != null)
            {
                float headHeight = _headBone.position.y - feetPosition.y;
                
                // Si la cabeza está por debajo de la altura configurada,
                // usar la cabeza + un pequeño offset para mantener el icono visible
                if (headHeight > 0 && headHeight < fallbackHeight)
                {
                    // Usar la posición de la cabeza + la diferencia hasta fallbackHeight
                    float extraHeight = fallbackHeight - headHeight;
                    targetPos = _headBone.position + Vector3.up * Mathf.Max(extraHeight, 0.2f);
                }
            }
            
            // Agregar offset adicional (X, Z principalmente, Y es pequeño ~0.2)
            return targetPos + iconOffset;
        }
        
        /// <summary>¿Hay un diálogo en pantalla ahora mismo? (fuente de verdad, no un flag propio)</summary>
        private static bool IsDialogueOpenNow() =>
            DialogueManager.Instance != null && DialogueManager.Instance.IsOpen;

        /// <summary>
        /// Cuando inicia un diálogo, ocultar el icono temporalmente
        /// </summary>
        private void OnDialogueStarted(Transform npcInvolved)
        {
            if (!OcultarDuranteDialogos) return;

            // Con dos diálogos seguidos sin cancelar la restauración pendiente, el icono reaparece
            // en mitad del segundo diálogo: la animación de restauración (0.5s) del primero completa
            // justo cuando el segundo ya está activo. Cancelar y re-ocultar siempre previene esto.
            if (_restoreAfterDialogueCoroutine != null)
            {
                StopCoroutine(_restoreAfterDialogueCoroutine);
                _restoreAfterDialogueCoroutine = null;
            }

            if (_currentIconInstance != null && !_isHiding)
            {
                _hiddenDuringDialogue = true;
                
                // Matar cualquier tween en progreso
                _currentTween?.Kill();
                
                // Ocultar con animación rápida pero NO destruir
                _currentIconInstance.transform.DOScale(Vector3.zero, 0.1f)
                    .SetEase(Ease.InBack)
                    .SetUpdate(true)
                    .SetId(this);
                    
                if (showDebugLogs)
                {
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[NPCAlertIcon:{name}] 🔇 Ocultando icono durante diálogo");
                    #endif
                }
            }
        }
        
        /// <summary>
        /// Cuando termina un diálogo, restaurar el icono si estaba visible (con delay para esperar a la cámara)
        /// </summary>
        private void OnDialogueClosed(Transform npcInvolved)
        {
            if (_hiddenDuringDialogue && _currentIconInstance != null && !_isHiding)
            {
                // Cancelar cualquier restauración pendiente
                if (_restoreAfterDialogueCoroutine != null)
                {
                    StopCoroutine(_restoreAfterDialogueCoroutine);
                }
                
                // Iniciar restauración con delay para que la cámara tenga tiempo de volver
                _restoreAfterDialogueCoroutine = StartCoroutine(RestoreIconAfterDialogueDelay());
            }
        }
        
        /// <summary>
        /// Corrutina que espera un momento antes de restaurar el icono tras el diálogo
        /// </summary>
        private IEnumerator RestoreIconAfterDialogueDelay()
        {
            // Esperar el delay configurado para que la cámara vuelva a su posición normal
            yield return new WaitForSecondsRealtime(restoreAfterDialogueDelay);

            _restoreAfterDialogueCoroutine = null;

            // Si sigue habiendo una secuencia en curso, el icono sigue escondido: lo sacará el
            // bucle del icono persistente cuando la secuencia acabe.
            if (_hiddenDuringSequence)
            {
                _hiddenDuringDialogue = false;
                yield break;
            }

            // Verificar que el icono aún existe y debe mostrarse
            if (_currentIconInstance != null && !_isHiding)
            {
                // Fijar posición y orientación correctas ANTES de animar la escala.
                // Así el coroutine loop no interfiere con el billboard mientras DOScale
                // anima desde cero (lo que producía deformación visual).
                _currentIconInstance.transform.position = GetIconWorldPosition();
                _currentIconInstance.transform.localScale = Vector3.zero;
                ApplyBillboard(_currentIconInstance.transform);

                DOTween.Kill(this);
                _currentIconInstance.transform.DOScale(_targetScale, 0.2f)
                    .SetEase(Ease.OutBack)
                    .SetId(this)
                    .OnComplete(() => _hiddenDuringDialogue = false); // Reanudar updates DESPUÉS de la animación

                if (showDebugLogs)
                {
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[NPCAlertIcon:{name}] 🔊 Restaurando icono tras diálogo (después de {restoreAfterDialogueDelay}s de delay)");
                    #endif
                }
            }
            else
            {
                _hiddenDuringDialogue = false;
            }
        }
        
        /// <summary>
        /// Actualiza la referencia de cámara para usar la cámara activa actual
        /// </summary>
        private void UpdateCameraReference()
        {
            // Prioridad 1: Camera.main si está habilitada
            Camera mainCam = Camera.main;
            if (mainCam != null && mainCam.isActiveAndEnabled)
            {
                _mainCamera = mainCam;
                return;
            }
            
            // Prioridad 2: Buscar cualquier cámara habilitada con mayor depth
            Camera[] allCameras = Camera.allCameras;
            Camera bestCamera = null;
            float highestDepth = float.MinValue;
            
            foreach (Camera cam in allCameras)
            {
                if (cam != null && cam.isActiveAndEnabled && cam.depth > highestDepth)
                {
                    highestDepth = cam.depth;
                    bestCamera = cam;
                }
            }
            
            if (bestCamera != null)
            {
                _mainCamera = bestCamera;
                return;
            }
            
            _mainCamera = mainCam;
        }
        
        private Camera GetCurrentCamera()
        {
            if (_mainCamera == null || !_mainCamera.isActiveAndEnabled)
            {
                UpdateCameraReference();
            }
            return _mainCamera;
        }
        
        /// <summary>
        /// Muestra un icono de alerta usando un prefab de GameObject
        /// </summary>
        public void ShowAlertIcon(GameObject iconPrefab, float duration = -1f)
        {
            if (iconPrefab == null)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCAlertIconController:{name}] IconPrefab es null");
#endif
                return;
            }
            
            // Asegurarse de encontrar la cabeza
            if (!_headBoneSearched) FindHeadBone();
            
            // Limpiar icono anterior inmediatamente
            HideAlertIconImmediate();
            
            float useDuration = duration > 0f ? duration : iconDuration;
            
            // Multiplica la escala del prefab por iconScale para respetar la proporción original.
            _targetScale = Vector3.Scale(iconPrefab.transform.localScale, Vector3.one * iconScale);
            
            _iconRoutine = StartCoroutine(ShowIconRoutine(iconPrefab, useDuration));
            
            if (showDebugLogs)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAlertIcon:{name}] 🔔 Mostrando icono por {useDuration}s");
                #endif
            }
        }

        /// <summary>
        /// Muestra el icono de alerta (❗) - Detectó al jugador
        /// </summary>
        public void ShowAlert(GameObject alertPrefab, float duration = -1f)
        {
            if (alertPrefab != null)
            {
                ShowAlertIcon(alertPrefab, duration);
            }
            else
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCAlertIcon:{name}] ⚠️ alertPrefab no proporcionado");
#endif
            }
        }
        
        /// <summary>
        /// Muestra el icono de interrogación (❓) - Buscando al jugador
        /// </summary>
        public void ShowQuestion(GameObject questionPrefab, float duration = -1f)
        {
            if (questionPrefab != null)
            {
                ShowAlertIcon(questionPrefab, duration);
            }
            else
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCAlertIcon:{name}] ⚠️ questionPrefab no proporcionado");
#endif
            }
        }
        
        /// <summary>
        /// Establece la altura del icono sobre el NPC.
        /// El valor representa la altura TOTAL desde los pies del NPC donde debe aparecer el icono.
        /// Si se encuentra la cabeza del NPC, se usa como referencia y se ajusta el offset.
        /// Si no se encuentra, se usa directamente como altura desde transform.position.
        /// </summary>
        public void SetIconOffset(Vector3 offset)
        {
            // Guardar la altura deseada como fallbackHeight (altura desde los pies)
            if (offset.y > 0)
            {
                fallbackHeight = offset.y;
            }
            
            // El iconOffset será un pequeño offset adicional sobre el punto de anclaje
            // (ya sea la cabeza encontrada o el fallbackHeight)
            iconOffset = new Vector3(offset.x, 0.2f, offset.z);
            
            if (showDebugLogs) 
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAlertIcon:{name}] SetIconOffset: altura deseada={offset.y}, fallbackHeight={fallbackHeight}");
#endif
                }
        }
        
        /// <summary>
        /// Establece la escala del icono (multiplica sobre la escala del prefab)
        /// </summary>
        public void SetIconScale(float scale)
        {
            iconScale = Mathf.Max(0.01f, scale);
        }

        /// <summary>
        /// Establece directamente la altura del icono (valor Y desde los pies del NPC)
        /// </summary>
        public void SetIconHeight(float height)
        {
            if (height > 0)
            {
                fallbackHeight = height;
            }
            
            if (showDebugLogs)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAlertIcon:{name}] SetIconHeight: {height}");
#endif
                }
        }
        
        /// <summary>
        /// Muestra el icono de admiración (❗) - ¡Encontró al jugador!
        /// </summary>
        public void ShowExclamation(GameObject exclamationPrefab, float duration = -1f)
        {
            if (exclamationPrefab != null)
            {
                ShowAlertIcon(exclamationPrefab, duration);
            }
            else
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCAlertIcon:{name}] ⚠️ exclamationPrefab no proporcionado");
#endif
            }
        }
        
        /// <summary>
        /// Muestra un icono persistente (sin duración) - se mantiene hasta llamar HideAlertIcon()
        /// Útil para indicar que hay una narrativa/quest disponible
        /// </summary>
        public void ShowPersistentIcon(GameObject iconPrefab)
        {
            if (iconPrefab == null)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[NPCAlertIconController:{name}] ⚠️ persistentIconPrefab es null");
#endif
                return;
            }
            
            // No mostrar si ya hay un icono activo del mismo prefab (no oculto)
            // Si está ocultándose (_isHiding=true), cancelamos el ocultado y recreamos
            if (_currentIconInstance != null && !_isHiding && _currentIconInstance.name.Contains(iconPrefab.name))
            {
                return;
            }
            
            // Asegurarse de encontrar la cabeza
            if (!_headBoneSearched) FindHeadBone();
            
            UpdateCameraReference();
            HideAlertIconImmediate();
            
            // Multiplica la escala del prefab por iconScale para respetar la proporción original.
            _targetScale = Vector3.Scale(iconPrefab.transform.localScale, Vector3.one * iconScale);

            _iconRoutine = StartCoroutine(ShowPersistentIconRoutine(iconPrefab));
            
            if (showDebugLogs)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAlertIcon:{name}] 📌 Mostrando icono persistente");
                #endif
            }
        }
        
        /// <summary>
        /// Verifica si hay un icono persistente activo
        /// </summary>
        public bool HasPersistentIcon => _currentIconInstance != null && !_isHiding;
        
        /// <summary>
        /// Oculta el icono de alerta actual con animación
        /// </summary>
        public void HideAlertIcon()
        {
            if (_iconRoutine != null)
            {
                StopCoroutine(_iconRoutine);
                _iconRoutine = null;
            }
            
            // Si ya se está ocultando o no hay icono, salir
            if (_isHiding || _currentIconInstance == null) return;

            _isHiding = true;
            _hiddenDuringDialogue = false;
            _hiddenDuringSequence = false;
            
            // Matar todos los tweens de este objeto
            DOTween.Kill(this);
            
            // Capturar referencia para el closure
            GameObject instanceToHide = _currentIconInstance;
            var iconTransform = instanceToHide.transform;
            
            // Asegurar que tiene escala válida antes de animar
            if (iconTransform.localScale.sqrMagnitude < 0.01f)
            {
                // Si la escala ya es casi cero, destruir directamente
                Destroy(instanceToHide);
                _currentIconInstance = null;
                _isHiding = false;
                return;
            }
            
            Vector3 targetPos = iconTransform.position + Vector3.down * 0.2f;
            
            Sequence hideSeq = DOTween.Sequence();
            hideSeq.Append(iconTransform.DOScale(Vector3.zero, hideAnimDuration).SetEase(Ease.InBack));
            hideSeq.Join(iconTransform.DOMove(targetPos, hideAnimDuration).SetEase(Ease.InQuad));
            hideSeq.SetUpdate(true);
            hideSeq.OnComplete(() =>
            {
                if (instanceToHide != null)
                {
                    Destroy(instanceToHide);
                }
                
                if (_currentIconInstance == instanceToHide)
                {
                    _currentIconInstance = null;
                    _isHiding = false;
                }
            });
            hideSeq.SetId(this);
            _currentTween = hideSeq;
            
            if (showDebugLogs)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAlertIcon:{name}] 🔕 Ocultando icono con animación");
                #endif
            }
        }
        
        /// <summary>
        /// Oculta el icono inmediatamente sin animación (para cleanup)
        /// </summary>
        public void HideAlertIconImmediate()
        {
            DOTween.Kill(this);
            _currentTween?.Kill();
            
            if (_iconRoutine != null)
            {
                StopCoroutine(_iconRoutine);
                _iconRoutine = null;
            }
            
            if (_currentIconInstance != null)
            {
                Destroy(_currentIconInstance);
                _currentIconInstance = null;
            }
            
            _isHiding = false;
            _hiddenDuringDialogue = false;
            _hiddenDuringSequence = false;
            
            if (showDebugLogs)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCAlertIcon:{name}] ⚡ Icono eliminado inmediatamente");
                #endif
            }
        }
        
        private IEnumerator ShowIconRoutine(GameObject iconPrefab, float duration, System.Action<GameObject> onInstanceCreated = null)
        {

            // Instanciar en WORLD SPACE
            _currentIconInstance = Instantiate(iconPrefab);
            _currentIconInstance.name = $"{iconPrefab.name}_{name}_Alert";
            
            // Callback de configuración
            onInstanceCreated?.Invoke(_currentIconInstance);
            
            // Calcular posición inicial (ligeramente debajo de la posición final para el pop-up)
            Vector3 targetPos = GetIconWorldPosition();
            Vector3 startPos = targetPos + Vector3.down * 0.3f;
            
            _currentIconInstance.transform.position = startPos;
            _currentIconInstance.transform.rotation = Quaternion.identity;
            _currentIconInstance.transform.localScale = Vector3.zero;
            _currentIconInstance.SetActive(true);
            
            // Aplicar billboard inicial
            ApplyBillboard(_currentIconInstance.transform);
            
            // Animar aparición
            var iconTransform = _currentIconInstance.transform;
            
            DOTween.Kill(this); // Matar tweens anteriores de este objeto
            
            Sequence showSeq = DOTween.Sequence();
            showSeq.Append(iconTransform.DOScale(_targetScale, showAnimDuration).SetEase(Ease.OutBack));
            showSeq.Join(iconTransform.DOMove(targetPos, showAnimDuration).SetEase(Ease.OutBack));
            showSeq.SetUpdate(true);
            showSeq.SetId(this);
            _currentTween = showSeq;

            yield return new WaitForSecondsRealtime(showAnimDuration);

            // Loop de actualización durante la duración
            float elapsed = 0f;
            float remainingDuration = duration - showAnimDuration;
            float baseTime = Time.unscaledTime;
            
            while (elapsed < remainingDuration)
            {
                if (_currentIconInstance == null || _isHiding) yield break;
                
                // No actualizar si está oculto por diálogo
                if (!_hiddenDuringDialogue)
                {
                    // Actualizar posición siguiendo la cabeza del NPC
                    Vector3 newTargetPos = GetIconWorldPosition();
                    
                    // Aplicar bounce si está activado
                    if (animateBounce)
                    {
                        float bounce = Mathf.Sin((Time.unscaledTime - baseTime) * bounceSpeed) * bounceAmplitude;
                        newTargetPos.y += bounce;
                    }

                    _currentIconInstance.transform.position = newTargetPos;

                    // Mantener billboard hacia cámara
                    ApplyBillboard(_currentIconInstance.transform);
                }

                elapsed += Time.unscaledDeltaTime;
                yield return null;
            }

            // Terminar con animación de ocultado
            HideAlertIcon();
        }
        
        /// <summary>
        /// Aplica efecto billboard para que el icono mire a la cámara
        /// </summary>
        private void ApplyBillboard(Transform iconTransform)
        {
            var cam = GetCurrentCamera();
            if (cam != null && iconTransform != null)
            {
                // Apuntar hacia la cámara muestra la cara frontal del sprite.
                Vector3 lookDir = cam.transform.position - iconTransform.position;
                lookDir.y = 0; // Solo rotar en Y para mantener vertical
                
                if (lookDir.sqrMagnitude > 0.001f)
                {
                    iconTransform.rotation = Quaternion.LookRotation(lookDir);
                }
            }
        }
        
        /// <summary>
        /// Rutina para icono persistente (sin duración, se mantiene hasta HideAlertIcon)
        /// </summary>
        private IEnumerator ShowPersistentIconRoutine(GameObject iconPrefab)
        {
            // Instanciar en WORLD SPACE
            _currentIconInstance = Instantiate(iconPrefab);
            _currentIconInstance.name = $"{iconPrefab.name}_{name}_Persistent";
            
            // Calcular posición inicial
            Vector3 targetPos = GetIconWorldPosition();
            Vector3 startPos = targetPos + Vector3.down * 0.3f;
            
            _currentIconInstance.transform.position = startPos;
            _currentIconInstance.transform.rotation = Quaternion.identity;
            _currentIconInstance.transform.localScale = Vector3.zero;
            _currentIconInstance.SetActive(true);
            
            // Aplicar billboard inicial
            ApplyBillboard(_currentIconInstance.transform);
            
            // Animar aparición
            var iconTransform = _currentIconInstance.transform;
            
            DOTween.Kill(this);

            // Si el icono nace con un diálogo ya abierto, nace oculto y espera a OnDialogueClosed
            // en vez de animarse en mitad de la conversación.
            bool bornDuringDialogue = OcultarDuranteDialogos && IsDialogueOpenNow();
            bool bornDuringSequence = OcultarDuranteSecuencias && HaySecuenciaEnCurso();
            if (bornDuringSequence && !bornDuringDialogue)
            {
                // Igual que el caso del diálogo: nace a escala 0 y el bucle de abajo lo saca
                // cuando la secuencia termine.
                _hiddenDuringSequence = true;
                iconTransform.position = targetPos;
                iconTransform.localScale = Vector3.zero;
            }
            else if (bornDuringDialogue)
            {
                // Nace oculto: se queda a escala 0 en su sitio y espera a OnDialogueClosed, que
                // dispara la restauración normal. El bucle de abajo sigue corriendo (respeta
                // _hiddenDuringDialogue), así que el icono queda bien colocado al reaparecer.
                _hiddenDuringDialogue = true;
                iconTransform.position = targetPos;
                iconTransform.localScale = Vector3.zero;
            }
            else
            {
                Sequence showSeq = DOTween.Sequence();
                showSeq.Append(iconTransform.DOScale(_targetScale, showAnimDuration).SetEase(Ease.OutBack));
                showSeq.Join(iconTransform.DOMove(targetPos, showAnimDuration).SetEase(Ease.OutBack));
                showSeq.SetUpdate(true);
                showSeq.SetId(this);
                _currentTween = showSeq;

                yield return new WaitForSecondsRealtime(showAnimDuration);
            }

            float baseTime = Time.unscaledTime;

            // Loop de actualización infinito (hasta que se llame HideAlertIcon)
            while (_currentIconInstance != null && !_isHiding)
            {
                ActualizarOcultoPorSecuencia();

                if (!_hiddenDuringDialogue)
                {
                    Vector3 newTargetPos = GetIconWorldPosition();

                    if (animateBounce)
                    {
                        float bounce = Mathf.Sin((Time.unscaledTime - baseTime) * bounceSpeed) * bounceAmplitude;
                        newTargetPos.y += bounce;
                    }

                    _currentIconInstance.transform.position = newTargetPos;
                    ApplyBillboard(_currentIconInstance.transform);
                }

                yield return null;
            }
        }
        
        /// Esconde el icono persistente al empezar una secuencia y lo vuelve a sacar al acabar
        /// (INC-457). Mismo gesto que con los diálogos: se encoge sin destruirse, así que al
        /// terminar reaparece el mismo icono en su sitio.
        private void ActualizarOcultoPorSecuencia()
        {
            bool ocultar = OcultarDuranteSecuencias && HaySecuenciaEnCurso();
            if (ocultar == _hiddenDuringSequence || _currentIconInstance == null) return;
            _hiddenDuringSequence = ocultar;

            var icono = _currentIconInstance.transform;
            DOTween.Kill(this);

            if (ocultar)
            {
                // Si estaba a punto de volver tras un diálogo, esa vuelta se cancela: matar su
                // tween dejaría _hiddenDuringDialogue en true para siempre (lo baja su OnComplete)
                // y el icono no volvería a salir. Lo sacará esta misma función al acabar.
                if (_restoreAfterDialogueCoroutine != null)
                {
                    StopCoroutine(_restoreAfterDialogueCoroutine);
                    _restoreAfterDialogueCoroutine = null;
                }
                if (!IsDialogueOpenNow()) _hiddenDuringDialogue = false;

                icono.DOScale(Vector3.zero, 0.1f)
                    .SetEase(Ease.InBack)
                    .SetUpdate(true)
                    .SetId(this);
                return;
            }

            // Si además hay un diálogo abierto, lo saca la restauración del diálogo al cerrarse.
            if (_hiddenDuringDialogue) return;

            icono.position = GetIconWorldPosition();
            icono.localScale = Vector3.zero;
            ApplyBillboard(icono);
            icono.DOScale(_targetScale, 0.2f)
                .SetEase(Ease.OutBack)
                .SetUpdate(true)
                .SetId(this);
        }

        private void OnDestroy()
        {
            DOTween.Kill(this);
            _currentTween?.Kill();
            HideAlertIconImmediate();
        }
        
        /// <summary>
        /// Propiedad para verificar si hay un icono visible
        /// </summary>
        public bool HasActiveIcon => _currentIconInstance != null && !_isHiding;
    }
}
