using System;
using UnityEngine;
using UnityEngine.AI;
using Game.NPC.Common;
using Game.NPC.Modules;
using Game.NPC.States;

namespace Game.NPC
{
    /// <summary>
    /// Componente que permite a un NPC unirse al equipo (Party) del jugador.
    /// Gestiona la lógica de seguimiento y comportamiento como compañero.
    /// </summary>
    [DisallowMultipleComponent]
    public class NPCPartyMember : MonoBehaviour
    {
        #region Serialized Fields
        [Header("Party Configuration")]
        [SerializeField] private NPCPartyConfig partyConfig;
        
        [Header("Estado Inicial")]
        [Tooltip("Si está activado, este NPC se unirá al equipo automáticamente al iniciar")]
        [SerializeField] private bool autoJoinOnStart = false;

        [Tooltip("Si está activado, este NPC se ocultará (SetActive false) cuando no esté en el party y se activará al unirse")]
        [SerializeField] private bool hideWhenNotInParty = false;
        
        [Header("Debug")]
        [SerializeField] private bool debugMode = false;
        #endregion

        #region State
        private PlayerParty _party;
        private NPCBehaviourManagerV2 _npcManager;
        private NavMeshAgent _agent;
        private Interactable _interactable;
        private bool _isInParty;
        private bool _wasInPartyBeforeCombat;
        private INPCState _stateBeforeJoining;
        private bool _isJoining; // Flag para evitar joins simultáneos
        private float _nextIdleCheck;
        private Damageable _damageable;
        // --- Preparación para escalada ---
        private bool _waitingForClimb = false;
        private Vector3 _climbBasePosition = Vector3.zero;
        // Slot activo cuando este NPC se unió al party; null = unión mientras Will era activo (miembro compartido)
        internal PartyControlManager.CharacterSlot? _joinedForSlot;
        #endregion

        #region Events
        /// <summary>
        /// Se dispara cuando este NPC se une al equipo
        /// </summary>
        public event Action OnJoined;
        
        /// <summary>
        /// Se dispara cuando este NPC abandona el equipo
        /// </summary>
        public event Action OnLeft;
        #endregion

        #region Runtime spell overrides
        private System.Collections.Generic.List<MagicSpellSO> _runtimeBasics; // null = los de la ficha
        private MagicSpellSO _runtimeSpecial;
        private readonly System.Collections.Generic.List<MagicSpellSO> _effective = new System.Collections.Generic.List<MagicSpellSO>(5);

        /// <summary>
        /// Sobreescribe los hechizos en runtime sin modificar la ficha.
        /// Usado por ActiveCharacterSwapper para que el Will de la IA lleve los básicos del jugador.
        /// </summary>
        public void SetRuntimeSpells(MagicSpellSO left, MagicSpellSO right, MagicSpellSO special)
        {
            SetRuntimeBasics(new[] { left, right }, special);
        }

        /// <summary>Los básicos (hasta 4) y el especial que usa en runtime. INC-498.</summary>
        public void SetRuntimeBasics(System.Collections.Generic.IReadOnlyList<MagicSpellSO> basics, MagicSpellSO special = null)
        {
            _runtimeBasics = new System.Collections.Generic.List<MagicSpellSO>(4);
            if (basics != null)
                foreach (var s in basics)
                    if (s != null && !_runtimeBasics.Contains(s)) _runtimeBasics.Add(s);
            _runtimeSpecial = special;
        }

        /// <summary>
        /// Los hechizos que usa la IA, en el orden en que los rota: sus básicos (los de runtime o los
        /// de la ficha, ver INC-483) y después el especial. Sin huecos ni levitación. INC-498.
        /// </summary>
        public System.Collections.Generic.IReadOnlyList<MagicSpellSO> EffectiveSpells
        {
            get
            {
                _effective.Clear();
                if (_personaje == null) _personaje = GetComponent<Personaje>();
                var ficha = _personaje != null ? _personaje.Ficha : null;

                // Estela y Liam: los que tengan equipados en el grimorio (INC-503); si no, los de su ficha.
                System.Collections.Generic.IReadOnlyList<MagicSpellSO> basics = _runtimeBasics;
                if (basics == null && ficha != null)
                    basics = ficha.Personaje != PartyControlManager.CharacterSlot.Will
                        ? GrimorioDelPersonaje.BasicosEquipados(ficha.Personaje)
                        : ficha.Basicos;
                if (basics != null)
                    foreach (var s in basics) Add(s);
                Add(_runtimeSpecial != null ? _runtimeSpecial : (_runtimeBasics == null && ficha != null ? ficha.Hechizo(2) : null));
                return _effective;

                void Add(MagicSpellSO s)
                {
                    if (s == null || s.kind == MagicKind.Levitation || _effective.Contains(s)) return;
                    _effective.Add(s);
                }
            }
        }

        /// <summary>El hechizo número <paramref name="index"/> de <see cref="EffectiveSpells"/> (null si no hay).</summary>
        public MagicSpellSO GetEffectiveSpell(int index)
        {
            var list = EffectiveSpells;
            return index >= 0 && index < list.Count ? list[index] : null;
        }

        private Personaje _personaje;
        #endregion

        #region Properties
        /// <summary>
        /// Configuración de comportamiento en el equipo
        /// </summary>
        public NPCPartyConfig PartyConfig => partyConfig;
        
        /// <summary>
        /// Referencia al manager principal del NPC
        /// </summary>
        public NPCBehaviourManagerV2 NPCManager => _npcManager;
        
        /// <summary>
        /// Si true, el NPC se oculta cuando no está en el party y se activa al unirse.
        /// </summary>
        public bool HideWhenNotInParty => hideWhenNotInParty;

        /// <summary>
        /// ¿Está actualmente en el equipo?
        /// </summary>
        public bool IsInParty => _isInParty;
        
        /// <summary>
        /// ¿Está activo en el equipo? (en party y no en combate/cinemática)
        /// </summary>
        public bool IsActiveInParty => _isInParty &&
            _npcManager != null &&
            !_npcManager.Context.IsInCombat &&
            !_npcManager.Context.IsInCinematic &&
            !CinematicSequencerBase.AnySequenceActive;
        
        /// <summary>
        /// Nombre para mostrar en UI
        /// </summary>
        public string DisplayName => partyConfig?.displayName ??
            (_npcManager?.PersistenceId ?? gameObject.name);

        /// <summary>
        /// Índice en el equipo (para formación)
        /// </summary>
        public int PartyIndex
        {
            get
            {
                if (_party == null) return -1;
                var members = _party.Members;
                for (int i = 0; i < members.Count; i++)
                {
                    if (members[i] == this) return i;
                }
                return -1;
            }
        }

        /// <summary>
        /// Indica si este miembro está en modo "preparado para trepar" (esperando espacio en la base).
        /// </summary>
        public bool IsWaitingForClimb => _waitingForClimb;

        /// <summary>
        /// Posición base donde se espera que el miembro comience la escalada.
        /// </summary>
        public Vector3 ClimbBasePosition => _climbBasePosition;
        #endregion

        #region Unity Lifecycle
        void Awake()
        {
            _npcManager = GetComponent<NPCBehaviourManagerV2>();
            _agent = GetComponent<NavMeshAgent>();
            _interactable = GetComponent<Interactable>() ?? GetComponentInChildren<Interactable>(true);
            _damageable = GetComponent<Damageable>();
            
            if (_npcManager == null)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogError($"[NPCPartyMember] {name} requiere NPCBehaviourManagerV2");
#endif
            }
        }

        void Start()
        {
            if (autoJoinOnStart)
            {
                // Sistema robusto sin delays: intentar join inmediato
                TryAutoJoin();
            }
        }
        
        /// <summary>
        /// Intenta auto-join de forma inmediata y robusta.
        /// Si no está listo, se suscribe a eventos para intentar después.
        /// CERO delays, CERO "yield return null".
        /// </summary>
        private void TryAutoJoin()
        {
            // Verificación inmediata de estado
            if (!NPCInitializer.IsNPCReady(_npcManager, out string reason))
            {
                if (debugMode)
                    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[NPCPartyMember:{name}] No listo para auto-join: {reason}. Reintentando en Update.");
#endif
                    }
                
                // Si no está listo AHORA, lo intentaremos en Update hasta que lo esté
                return;
            }
            
            // ¡Está listo! Unirse inmediatamente
            JoinParty();
        }
        
        void Update()
        {
            // Si está esperando auto-join, verificar en cada frame hasta que esté listo
            if (autoJoinOnStart && !_isInParty && !_isJoining)
            {
                var party = PlayerParty.Instance;
                if (party != null && !party.IsFull && NPCInitializer.IsNPCReady(_npcManager, out _))
                {
                    JoinParty();
                }
            }
            
            // Si está en el party pero no está siguiendo (Brain no estaba listo), verificar cada 0.5s
            // No actuar si este NPC está oculto (controlado por el jugador vía character swap)
            if (_isInParty && _npcManager != null && _npcManager.Brain != null && Time.time >= _nextIdleCheck)
            {
                _nextIdleCheck = Time.time + 0.5f;

                if (ControlDelJugador.RepresentadoPorElJugador(this))
                    return;

                var currentState = _npcManager.Brain.CurrentState;
                // Además de Context.IsInCinematic (solo lo pone CinematicState de la FSM), mira
                // CinematicSequencerBase.AnySequenceActive: los secuenciadores sientan a los NPCs
                // pausando NPCBehaviourManagerV2 (ForceIdle() + enabled=false) sin pasar por la
                // FSM, y este componente sigue corriendo. Ver INC-059.
                if (currentState != null && currentState.StateName == "Idle"
                    && !_npcManager.Context.IsInCombat && !_npcManager.Context.IsInCinematic
                    && !CinematicSequencerBase.AnySequenceActive
                    && PartyControlManager.DebeSeguirAlJugador(this)
                    // Un NPC anclado (barco, modo Libre) no vuelve a seguir aunque su cerebro
                    // esté en Idle: el ancla manda.
                    && !(_npcManager.Context?.EstaAnclado ?? false)
                    && GetDistanceToPlayer() <= 40f)
                {
                    StartFollowing();
                }
            }
        }

        void OnDestroy()
        {
            if (_isInParty)
            {
                // No llamar LeaveParty() al destruirse por cambio de escena:
                // LeaveParty() → SyncPartyToPreset() vaciaría partyMemberIds uno a uno
                // mientras Unity destruye todos los GOs, corrompiendo el preset para el restore.
                // Usamos una ruta silenciosa que preserva el preset intacto.
                _isInParty = false;
                var partyRef = _party;
                _party = null;
                partyRef?.RemoveMemberFromDestroy(this);
            }
        }
        #endregion

        #region Public API
        /// <summary>
        /// Configura el PartyConfig programáticamente.
        /// Útil cuando el componente se añade en runtime.
        /// </summary>
        public void SetConfig(NPCPartyConfig config)
        {
            partyConfig = config;
        }
        
        /// <summary>
        /// Une este NPC al equipo del jugador.
        /// </summary>
        /// <param name="isRestore">
        /// True cuando la unión viene de restaurar una partida/preset guardado (el miembro ya
        /// formaba parte del equipo antes del guardado). En ese caso NO debe disparar los efectos
        /// secundarios de una unión "en vivo" (p.ej. auto-completar pasos de misión ligados a
        /// requiredPartyMembers), porque esos pasos ya reflejan el estado real guardado y no deben
        /// re-evaluarse solo por reconstruir el equipo al cargar.
        /// </param>
        public bool JoinParty(bool isRestore = false)
        {
            if (_isInParty)
            {
                Log("Ya está en el equipo");
                return false;
            }
            
            // ✅ FIX: Evitar joins simultáneos durante la carga de partida
            if (_isJoining)
            {
                LogWarning("Ya hay un proceso de unión en curso, ignorando llamada duplicada");
                return false;
            }
            
            // ✅ FIX: Verificar que el NPC esté completamente inicializado
            if (_npcManager == null || _agent == null)
            {
                LogWarning("NPC no está completamente inicializado, esperando...");
                return false;
            }

            // Al restaurar el equipo, un compañero retenido por una secuencia espera a que lo suelte:
            // la escena manda en su sitio y en su NavMeshAgent (lo apaga para llevarlo por su camino),
            // y unirse ahora lo recolocaría en el NavMesh a mitad de plano. PlayerParty lo reintenta.
            if (isRestore && _npcManager.IsInCinematic)
            {
                Log("Retenido por una secuencia: se unirá al equipo cuando acabe");
                return false;
            }
            
            // ✅ FIX: Verificar que el NavMeshAgent esté en un NavMesh
            if (!_agent.isOnNavMesh)
            {
                // FIX (17 ago 2026) — CAUSA RAÍZ REAL confirmada por consola + inspector del bug
                // crítico "Estela/Liam no vuelven al party tras cerrar y reabrir el juego":
                // NPCBehaviourManagerV2.UpdateDistanceLOD() "duerme" a cualquier NPC lejos del
                // jugador (EnterFarState() → agent.enabled = false, optimización de rendimiento
                // para NPCs ambientales dispersos por el mundo). En un arranque en frío, un
                // compañero de equipo aparece en su posición de diseño de escena — que puede
                // estar a cientos de metros del punto de guardado del jugador (Estela: 578m) —
                // y ese chequeo de distancia se dispara ANTES de que PlayerParty consiga
                // restaurarlo. HasActiveAiExemption() solo exime de dormir a NPCs con
                // IsAlly=true (ya unidos al party) — un compañero todavía PENDIENTE de unirse no
                // cuenta, así que nunca se despertaba: dormido porque no está en el party,
                // incapaz de unirse al party porque está dormido (agent.enabled=false, por lo que
                // ni SamplePosition+Warp sirven de nada — un NavMeshAgent deshabilitado no puede
                // estar "on mesh" pase lo que pase). Este método es el único sitio por el que
                // pasa CUALQUIER intento de unirse al equipo (incluido cada reintento cada 2s
                // desde PlayerParty.RetryPendingMembers), así que es el punto correcto para
                // reactivarlo: en cuanto el join tenga éxito más abajo, IsAlly pasará a true y el
                // propio Update() de NPCBehaviourManagerV2 llamará a ExitFarState() de forma
                // normal en su siguiente ciclo, dejando todo consistente (Brain, animaciones, etc).
                if (_agent.enabled == false)
                {
                    _agent.enabled = true;
                    LogWarning("NavMeshAgent estaba deshabilitado (NPC 'dormido' por estar lejos del jugador — UpdateDistanceLOD/EnterFarState) — reactivado para poder unirse al party");
                }

                if (NavMesh.SamplePosition(transform.position, out var navHit, 10f, NavMesh.AllAreas))
                {
                    _agent.Warp(navHit.position);
                    LogWarning($"NavMeshAgent no estaba en NavMesh — auto-recuperado con Warp a {navHit.position} (pos. previa: {transform.position})");
                }

                if (!_agent.isOnNavMesh)
                {
                    LogWarning("NavMeshAgent no está en NavMesh, no se puede unir al party ahora (auto-recuperación falló: no se encontró NavMesh cerca de la posición actual)");
                    return false;
                }
            }

            _isJoining = true;

            _party = PlayerParty.Instance;
            if (_party == null)
            {
                LogWarning("No se encontró PlayerParty en la escena");
                _isJoining = false;
                return false;
            }
            
            if (_party.IsFull)
            {
                LogWarning("El equipo está lleno");
                _isJoining = false;
                return false;
            }
            
            // Guardar estado actual para restaurarlo si sale del equipo
            if (_npcManager?.Brain != null)
            {
                _stateBeforeJoining = _npcManager.Brain.CurrentState;
            }
            
            bool success = _party.AddMember(this, isRestore);
            
            if (!success)
            {
                _isJoining = false;
            }
            
            return success;
        }

        /// <summary>
        /// Remueve este NPC del equipo del jugador.
        /// </summary>
        public bool LeaveParty()
        {
            if (!_isInParty || _party == null)
            {
                Log("No está en el equipo");
                return false;
            }
            
            return _party.RemoveMember(this);
        }

        /// <summary>
        /// Cambia al estado de seguir al jugador.
        /// </summary>
        public void StartFollowing()
        {
            if (_npcManager?.Brain == null || EstaCaido) return;

            // Un NPC anclado (barco, modo Libre) no vuelve a seguir aunque otro sistema llame
            // aquí directamente: el ancla manda y la suelta quien la puso.
            if (_npcManager.Context?.EstaAnclado ?? false) return;

            // Solo cambiar a FollowState si no estamos en combate/cinemática (ver Update()).
            if (!_npcManager.Context.IsInCombat && !_npcManager.Context.IsInCinematic
                && !CinematicSequencerBase.AnySequenceActive)
            {
                _npcManager.Brain.ChangeState(new FollowPlayerState(this));
            }
        }

        /// <summary>
        /// Igual que StartFollowing pero omite la verificación de pertenencia al party.
        /// Útil para NPCs temporales como el Will NPC instanciado al cambiar de personaje.
        /// </summary>
        public void StartFollowingIgnorePartyCheck()
        {
            if (_npcManager?.Brain == null || EstaCaido) return;

            // Mismo invariante que StartFollowing: el ancla manda.
            if (_npcManager.Context?.EstaAnclado ?? false) return;

            if (!_npcManager.Context.IsInCombat && !_npcManager.Context.IsInCinematic
                && !CinematicSequencerBase.AnySequenceActive)
                _npcManager.Brain.ChangeState(new FollowPlayerState(this, skipPartyCheck: true));
        }

        /// <summary>
        /// Detiene el seguimiento y vuelve al estado anterior o Idle.
        /// </summary>
        public void StopFollowing()
        {
            if (_npcManager?.Brain == null) return;
            
            if (_stateBeforeJoining != null && !(_stateBeforeJoining is FollowPlayerState))
            {
                _npcManager.Brain.ChangeState(_stateBeforeJoining);
            }
            else
            {
                _npcManager.ForceIdle();
            }
        }
        
        /// <summary>
        /// Mueve al NPC a una posición específica para un diálogo.
        /// El NPC cambia temporalmente a un estado de movimiento hacia esa posición.
        /// </summary>
        /// <param name="targetPosition">Posición objetivo al lado del player</param>
        /// <param name="maxTime">Tiempo máximo antes de teletransportar</param>
        /// <param name="npcTarget">El NPC con quien se está hablando (para mirar hacia él)</param>
        /// <param name="mantenerFueraDelParty">
        /// True para que el NPC siga en la posición aunque no esté en el equipo (el Will de la IA
        /// mientras el jugador lleva a otro personaje). Sin esto, el estado pasa a Idle al frame
        /// siguiente y no llega a andar hasta el destino.
        /// </param>
        public void MoveToDialoguePosition(Vector3 targetPosition, float maxTime, Transform npcTarget = null,
                                           bool mantenerFueraDelParty = false)
        {
            if (_npcManager?.Brain == null || _agent == null)
            {
                LogWarning("No se puede mover a posición de diálogo: NPC no inicializado");
                return;
            }
            
            // Cambiar a un estado especial de diálogo con el NPC target
            _npcManager.Brain.ChangeState(new Game.NPC.States.DialoguePositionState(
                this, targetPosition, maxTime, npcTarget, mantenerFueraDelParty));
            
            Log($"📍 Moviéndose a posición de diálogo: {targetPosition}");
        }
        
        /// <summary>
        /// En diálogos grupales: cambia hacia quién mira este compañero mientras mantiene su
        /// posición de diálogo. La usa DialogueCinematicController en cada línea para que los
        /// personajes se miren entre ellos cuando se contestan. Pasar null para volver al
        /// objetivo por defecto (el NPC del diálogo). No hace nada si el compañero no está
        /// en DialoguePositionState (p.ej. anclado en modo Libre o en combate).
        /// </summary>
        public void SetDialogueLookTarget(Transform target)
        {
            if (_npcManager?.Brain?.CurrentState is Game.NPC.States.DialoguePositionState dialogueState)
            {
                dialogueState.SetLookTargetOverride(target);
            }
        }

        /// <summary>
        /// Libera al NPC del posicionamiento de diálogo y vuelve a seguir al player.
        /// </summary>
        public void ReleaseDialoguePosition()
        {
            if (!_isInParty || _npcManager?.Brain == null)
                return;
            
            // Volver al estado de seguir al player
            var currentState = _npcManager.Brain.CurrentState;
            if (currentState is Game.NPC.States.DialoguePositionState)
            {
                _npcManager.Brain.ChangeState(new Game.NPC.States.FollowPlayerState(this));
                Log("🔓 Liberado de posición de diálogo, volviendo a seguir");
            }
        }
        
        #endregion

        #region Internal Callbacks (llamados por PlayerParty)
        /// <summary>
        /// Llamado cuando se ha añadido exitosamente al equipo.
        /// </summary>
        /// <param name="isRestore">
        /// True cuando el join viene de restaurar una partida guardada (ver JoinParty). En ese caso
        /// NUNCA se debe leer PartyControlManager.ActiveSlot para fijar _joinedForSlot: PlayerParty
        /// restaura los miembros desde OnProfileReady, suscrito en su Awake (execution order -500),
        /// mientras que PartyControlManager.HandleProfileReady —que resetea _activeIndex a Will,
        /// "al cargar partida siempre se arranca como Will"— se suscribe en su Start (-200) y por
        /// tanto se ejecuta DESPUÉS en la invocación del mismo evento. Sin este parámetro, un
        /// miembro restaurado podía heredar el _activeIndex TODAVÍA SIN RESETEAR de la sesión
        /// anterior (p.ej. si el jugador murió controlando a Estela, _activeIndex seguía en Estela
        /// en el momento del restore) y quedar mal etiquetado con _joinedForSlot=Estela aunque la
        /// partida recién cargada arranca en Will. Ese etiquetado erróneo podía provocar que
        /// ActiveCharacterSwapper.SwitchCharacter desvinculara compañeros del equipo al cambiar de
        /// personaje sin motivo (ver comentario "5b. Desvincular compañeros..." en ese archivo).
        /// </param>
        internal void OnJoinedParty(PlayerParty party, bool isRestore = false)
        {
            // Registrar el slot activo en el momento del join.
            // Will (slot 1) → null (miembro compartido). Liam/Estela → ese slot específico.
            // Al restaurar una partida no existe todavía un "personaje activo en vivo": siempre null.
            var activeSlot = isRestore ? null : PartyControlManager.Instance?.ActiveSlot;
            _joinedForSlot = (activeSlot.HasValue && activeSlot.Value != PartyControlManager.CharacterSlot.Will)
                ? activeSlot
                : null;

            // Al unirse sigue al jugador: suelta el ancla de estar fuera del grupo y la del modo
            // Libre (como al pulsar «Sígueme»). Las de otros sistemas (el barco) siguen.
            if (_npcManager?.Context != null)
            {
                _npcManager.Context.Soltar(this);
                _npcManager.Context.Soltar(PartyControlManager.AnclaDelModoLibre);
            }

            // Renderers visibles (HideNonPartyNPCs los apaga a quien no está en el grupo), salvo
            // si el jugador lleva a este personaje: esa visibilidad es del relevo de personaje.
            if (!ControlDelJugador.RepresentadoPorElJugador(this))
            {
                foreach (var r in GetComponentsInChildren<Renderer>(true))
                    r.enabled = true;
            }

            _party = party;
            _isInParty = true;
            _isJoining = false;
            if (_interactable == null)
                _interactable = GetComponent<Interactable>() ?? GetComponentInChildren<Interactable>(true);
            _interactable?.SetHintVisible(false);
            
            Log($"✨ Unido al equipo (índice {PartyIndex})");

            // Sistema robusto: verificar estado inmediatamente
            if (_npcManager?.Brain != null)
            {
                // Iniciar seguimiento INMEDIATAMENTE
                StartFollowing();
            }
            else
            {
                LogWarning("Brain no inicializado. El Update verificará cuando esté listo.");
                // Update verificará y llamará StartFollowing cuando esté listo
            }
            
            OnJoined?.Invoke();
        }
        

        /// <summary>
        /// Llamado cuando se ha removido del equipo.
        /// </summary>
        internal void OnLeftParty()
        {
            _isInParty = false;
            _isJoining = false;
            _joinedForSlot = null;

            Log("👋 Abandonó el equipo");

            // Fuera del grupo se queda donde está, sin vagar, hasta que vuelva a unirse.
            _npcManager?.Context?.Anclar(this);

            // Forzar Idle directamente (no restaurar estado anterior que podría ser WanderState)
            _npcManager?.ForceIdle();

            _party = null;
            OnLeft?.Invoke();
        }

        /// <summary>
        /// Llamado cuando el jugador entra en combate.
        /// SIMPLIFICADO: Entra en combate sin verificar rango.
        /// </summary>
        internal void OnPlayerEnteredCombat(Transform enemy)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[NPCPartyMember:{name}] 🔔 OnPlayerEnteredCombat - Enemigo: {enemy?.name}");
#endif

            if (_npcManager?.Brain == null)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogError($"[NPCPartyMember:{name}] ⚠️ _npcManager.Brain es NULL!");
#endif
                return;
            }

            // Un compañero caído no lucha hasta que lo levantan (INC-717).
            if (EstaCaido) return;

            // Un NPC anclado (barco, asiento, modo Libre) no entra en combate: si no, el
            // AllyCombatState lo saca del puesto y lo pone a lanzar hechizos en bucle encima
            // del barco (ver INC-808).
            if (_npcManager.Context?.EstaAnclado ?? false)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCPartyMember:{name}] ⚓ Ignorando combate: NPC anclado");
#endif
                return;
            }

            // No interrumpir si el jugador está controlando directamente este NPC
            if (ControlDelJugador.RepresentadoPorElJugador(this))
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCPartyMember:{name}] ℹ️ Ignorando combate: personaje bajo control del jugador");
#endif
                return;
            }
            
            _wasInPartyBeforeCombat = _isInParty;
            
            // Entrar en combate directamente
            _npcManager.Context.IsInCombat = true;
            
            // Cambiar a AllyCombatState CON EL TARGET
            if (!(_npcManager.Brain.CurrentState is States.AllyCombatState))
            {
                // Pasar el enemigo al constructor para que lo ataque directamente
                _npcManager.Brain.ChangeState(new States.AllyCombatState(enemy));
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCPartyMember:{name}] ⚔️ CAMBIADO A AllyCombatState con target: {enemy?.name}");
#endif
            }
        }

        /// <summary>
        /// Está caído en combate (CuerpoDelGrupo, INC-717): no lucha ni sigue hasta que lo levantan.
        /// </summary>
        public bool EstaCaido => TryGetComponent(out CuerpoDelGrupo cuerpo) && cuerpo.Caido;

        /// <summary>Su cerebro está siguiendo al jugador (FollowPlayerState).</summary>
        public bool EstaSiguiendo => _npcManager?.Brain?.CurrentState is FollowPlayerState;

        /// <summary>
        /// Tras levantarse de una caída: vuelve al combate si sigue habiendo enemigos, o a seguir
        /// al jugador (o a quedarse quieto si el grupo está en modo libre). Ver INC-717.
        /// </summary>
        public void VolverAlCombateOSeguir()
        {
            if (_npcManager?.Brain == null || EstaCaido) return;
            Transform enemigo = null;
            foreach (var go in ActiveCombatRegistry.GetAllInCombat())
            {
                if (go == null || go.GetComponent<NPCPartyMember>() != null) continue;
                enemigo = go.transform;
                break;
            }
            if (enemigo != null) { OnPlayerEnteredCombat(enemigo); return; }
            _npcManager.Context.IsInCombat = false;
            if (PartyControlManager.DebeSeguirAlJugador(this)) StartFollowingIgnorePartyCheck();
            else _npcManager.ForceIdle();
        }

        /// <summary>
        /// Llamado cuando el jugador sale del combate.
        /// </summary>
        internal void OnPlayerExitedCombat()
        {
            if (_npcManager == null || EstaCaido) return;

            // Si está anclado, solo se limpia el flag de combate: sigue en su puesto y no
            // vuelve a seguir ni a Idle (ver INC-808).
            if (_npcManager.Context?.EstaAnclado ?? false)
            {
                _npcManager.ExitCombat();
                return;
            }
            
            // Si estaba en party antes del combate, volver a seguir
            if (_wasInPartyBeforeCombat && _isInParty)
            {
                Log("🏳️ Combate terminado, volviendo a seguir al jugador");
                _npcManager.ExitCombat();
                if (PartyControlManager.DebeSeguirAlJugador(this))
                    StartFollowing();
                else
                    _npcManager.ForceIdle();
            }
        }

        /// <summary>
        /// Llamado cuando ha sido teletransportado cerca del jugador.
        /// </summary>
        internal void OnTeleportedToPlayer()
        {
            Log("⚡ Teletransportado cerca del jugador");

            if (_isInParty && _npcManager?.Brain?.CurrentState is not FollowPlayerState
                && PartyControlManager.DebeSeguirAlJugador(this))
            {
                StartFollowing();
            }
        }

        /// <summary>
        /// Marca a este NPC como "preparado para trepar". Se llama desde PlayerParty
        /// cuando el player inicia una escalada. El NPC se moverá a la posición base
        /// y esperará hasta que haya espacio para empezar a subir.
        /// </summary>
        public void PrepareForClimb(Vector3 basePosition)
        {
            _climbBasePosition = basePosition;
            _waitingForClimb = true;
            Log($"Preparado para trepar (base: {_climbBasePosition})");
            // Si estamos ya siguiendo, cambiamos a FollowPlayerState para que el state
            // especial de Follow maneje el movimiento 3D hacia la formación en la base.
            if (_npcManager?.Brain != null)
            {
                _npcManager.Brain.ChangeState(new Game.NPC.States.FollowPlayerState(this));
            }
        }

        /// <summary>
        /// Cancela la preparación para la escalada (p.ej. player abandonó la escalada).
        /// </summary>
        public void CancelClimbPreparation()
        {
            if (!_waitingForClimb) return;
            _waitingForClimb = false;
            _climbBasePosition = Vector3.zero;
            Log("Cancelada preparación de escalada");
            // Volver a seguir normalmente si corresponde
            if (_isInParty && _npcManager?.Brain != null)
            {
                if (PartyControlManager.DebeSeguirAlJugador(this))
                    StartFollowing();
                else
                    _npcManager.ForceIdle();
            }
        }
        #endregion

        #region Helpers
        /// <summary>
        /// Obtiene la distancia actual al jugador.
        /// </summary>
        public float GetDistanceToPlayer()
        {
            if (_party?.PlayerTransform == null) return float.MaxValue;
            return Vector3.Distance(transform.position, _party.PlayerTransform.position);
        }

        /// <summary>
        /// Obtiene la posición de formación asignada.
        /// </summary>
        public Vector3 GetFormationPosition()
        {
            if (_party != null) return _party.GetFormationPosition(PartyIndex);

            // FIX (25 ago 2026, INC-095) — cuando este NPC sigue al jugador SIN estar registrado
            // en PlayerParty (p.ej. el NPC de Will, ver NPCStateContext.IsActivelyFollowingPlayer
            // / ActiveCharacterSwapper), _party es siempre null y PartyIndex siempre -1. El
            // fallback anterior devolvía transform.position — la propia posición ACTUAL de este
            // mismo NPC — como "posición de formación": FollowPlayerState.UpdateDestination() la
            // usaba tal cual como destino del NavMeshAgent, así que el agente pathfindeaba hacia
            // sí mismo y no se movía ni un metro, aunque el resto de la FSM (Agent.speed,
            // isStopped=false, animación) funcionara con normalidad — de ahí que Will se quedara
            // quieto sin caminar ni animar pese a estar activamente en FollowPlayerState. En su
            // lugar, sin registro de party, se calcula un punto justo detrás del jugador (mismo
            // criterio que el seguimiento especial en FollowPlayerState.GetFormationTarget3D, sin
            // spread lateral por índice porque aquí no hay un PartyIndex válido) — nunca la propia
            // posición del NPC, que nunca es un destino de seguimiento válido.
            Transform player = _npcManager != null ? _npcManager.Context?.Player : null;
            if (player == null) return transform.position; // sin jugador todavía: no hay nada mejor

            float followDist = partyConfig != null ? partyConfig.distanciaParaPararse : 1.2f;
            return player.position - player.forward * (followDist * 0.8f);
        }

        private void Log(string message)
        {
            if (debugMode)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[NPCPartyMember:{name}] {message}");
                #endif
            }
        }

        private void LogWarning(string message)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[NPCPartyMember:{name}] ⚠️ {message}");
#endif
        }
        #endregion

#if UNITY_EDITOR
        void OnDrawGizmosSelected()
        {
            if (!Application.isPlaying || !_isInParty) return;
            
            // Mostrar posición de formación
            if (_party?.PlayerTransform != null)
            {
                Vector3 formationPos = GetFormationPosition();
                Gizmos.color = Color.cyan;
                Gizmos.DrawWireSphere(formationPos, 0.3f);
                Gizmos.DrawLine(transform.position, formationPos);
            }
            
            // Mostrar rango de teleport
            if (partyConfig != null)
            {
                Gizmos.color = new Color(1, 0, 1, 0.2f);
                Gizmos.DrawWireSphere(transform.position, partyConfig.teleportDistance);
            }
        }
#endif
    }
}

