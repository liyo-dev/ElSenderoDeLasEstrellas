﻿﻿using System.Collections;
using UnityEngine;
using UnityEngine.AI;
using Sendero.Core.Feedback;
using Game.Player;
using Game.NPC;

namespace Game.NPC.Modules
{
    /// <summary>
    /// Maneja el ciclo de vida del combate: Daño, Stun, Muerte, SlowMotion y lógica Post-Batalla.
    /// Última actualización: 28/12/2024 - Agregado HandlePostDefeatInteraction
    /// </summary>
    [RequireComponent(typeof(Damageable))]
    [RequireComponent(typeof(NPCBehaviourManagerV2))]
    public class NPCCombatLifecycleHandler : MonoBehaviour
    {
        #region ⚙️ Configuration
        [Header("💥 Damage Feedback")]
        [SerializeField] private bool playDamageAnimation = true;
        [SerializeField, Range(0f, 2f)] private float damageStunDuration = 0.8f; // Reducido un poco para mayor dinamismo
        [SerializeField, Range(0f, 2f)] private float invulnerabilityDuration = 0.5f;
        
        [Header("🎥 Camera & Time")]
        [SerializeField] private bool enableCameraShake = true;
        [SerializeField] private float cameraShakeIntensity = 0.2f;
        [SerializeField] private float cameraShakeDuration = 0.15f;
        [SerializeField] private bool enableHitStop = true;
        [SerializeField, Range(0f, 1f)] private float hitStopTimeScale = 0.1f; // Más lento para mayor impacto
        [SerializeField] private float hitStopDuration = 0.15f;

        [Header("💀 Death Sequence")]
        [SerializeField] private bool enableDeathEffects = true;
        [SerializeField] private float deathSlowMoScale = 0.2f;
        [SerializeField] private float deathSlowMoDuration = 1.0f;
        [SerializeField] private GameObject deathVFXPrefab;
        [SerializeField] private Vector3 deathVFXOffset = Vector3.up;

        [Header("💀 Death Sequence - Cámara cinematográfica")]
        [Tooltip("Factor de zoom del FOV hacia el enemigo derrotado (1 = sin zoom, <1 = acercar). Comunica que la pausa es intencional en vez de sentirse como un cuelgue.")]
        [SerializeField, Range(0.5f, 1f)] private float deathZoomFactor = 0.85f;
        [Tooltip("Duración del zoom de entrada hacia el enemigo")]
        [SerializeField, Range(0f, 0.5f)] private float deathZoomDuration = 0.15f;
        [Tooltip("Duración de la vuelta a la normalidad (FOV y ritmo) al terminar el slow-mo")]
        [SerializeField, Range(0f, 1f)] private float deathReturnDuration = 0.35f;
        #endregion

        #region 🔌 Dependencies
        private NPCBehaviourManagerV2 _manager;
        private Damageable _damageable;
        private NPCSimpleAnimator _animator;
        private NavMeshAgent _agent;
        private NPCCombatBrain _brain;
        private NPCShieldController _shieldController;
        // ✅ FIX #25 (auditoría combate, 15 ago 2026): antes se llamaba GetComponent<NPCTeamMember>()
        // en OnDied/DeathRoutine/HandleGetUpDizzy/HandleMoveToAnchor/MoveTeamMembersToRandomPoints
        // (5 sitios distintos). Se cachea una sola vez... pero NO en Awake(): NPCTeamMember lo añade
        // dinámicamente NPCCombatTeam.Start() (ver NPCCombatTeam.cs, "AddComponent<NPCTeamMember>()"),
        // y Unity ejecuta TODOS los Awake() de la escena antes que CUALQUIER Start() — así que en el
        // momento de este Awake() el componente todavía no existe en el GameObject y GetComponent
        // devolvía null para siempre (el campo nunca se refrescaba después).
        // ✅ FIX #26 (16 ago 2026, bug reportado por Raúl - "combate dual"): ese null permanente
        // hacía que isInTeam fuera SIEMPRE false para cualquier NPC en equipo (dúo o grupo) — la
        // música/animación de victoria sonaba al derrotar al PRIMER enemigo (no al último) y la
        // música de combate se restauraba (se quitaba) justo después de esa primera derrota, en vez
        // de esperar a que cayera todo el equipo. Ahora se resuelve de forma perezosa (lazy) la
        // primera vez que se necesita, ya con el componente añadido por NPCCombatTeam.
        private NPCTeamMember _teamMember;

        /// <summary>
        /// Acceso perezoso a NPCTeamMember: NPCCombatTeam lo añade dinámicamente en su propio
        /// Start(), que se ejecuta DESPUÉS de este Awake() — cachearlo aquí en Awake devolvía null
        /// para siempre. Se resuelve (y cachea) en el primer uso real, ya en combate.
        /// </summary>
        private NPCTeamMember ResolvedTeamMember
        {
            get
            {
                if (_teamMember == null) _teamMember = GetComponent<NPCTeamMember>();
                return _teamMember;
            }
        }

        // ✅ CAMBIO: Obtener _config dinámicamente para asegurar que siempre tenga los valores actualizados
        // Esto es necesario porque NPCInteractiveNarrativeExecutor puede actualizar combatConfig después de Start()
        private NPCCombatConfig _config => _manager?.Configuration?.combatConfig;

        // Si en esta partida ya se le había derrotado antes de la caída en curso (revanchas).
        private bool _yaHabiaCaidoAntes;

        /// Se le ha derrotado ya alguna vez en esta partida.
        public bool YaDerrotadoEnLaPartida => FlagDePartida.EstaPuesto(ClaveDeDerrota());

        private string ClaveDeDerrota()
        {
            string id = _manager != null && !string.IsNullOrEmpty(_manager.PersistenceId) ? _manager.PersistenceId : name;
            return $"NPC_DERROTADO:{id}";
        }
        #endregion

        #region 📊 State
        public bool IsDefeatedAndInactive { get; private set; }
        public bool IsStunned { get; private set; }
        
        private bool _isProcessingDefeat;
        private bool _isInvulnerable;
        private bool _isCasting; // Para interrumpir hechizos
        private bool _shouldCancelDizzySequence; // Para interrumpir dizzy cuando inicia movimiento narrativo
        #endregion

        /// <summary>
        /// FIX INC-045: un proyectil ya lanzado puede matar a este NPC después de que el
        /// jugador haya muerto (game over en curso, ej: ambos se golpean casi a la vez).
        /// En ese caso el combate terminó en derrota, no en victoria: ni la música/animación
        /// de victoria ni la restauración de música ambiente deben sonar por encima del game over.
        /// </summary>
        private static bool IsPlayerDeadOrGameOverActive()
        {
            if (GameOverManager.Instance != null && GameOverManager.Instance.IsShown) return true;
            if (PlayerService.TryGetPlayer(out GameObject playerGo))
            {
                var health = playerGo.GetComponent<PlayerHealthSystem>();
                if (health != null && !health.IsAlive) return true;
            }
            return false;
        }

        private void Awake()
        {
            _manager = GetComponent<NPCBehaviourManagerV2>();
            _damageable = GetComponent<Damageable>();
            _animator = GetComponent<NPCSimpleAnimator>();
            _agent = GetComponent<NavMeshAgent>();
            _brain = GetComponent<NPCCombatBrain>();
            _shieldController = GetComponent<NPCShieldController>();
            // ✅ FIX #26: NO cachear NPCTeamMember aquí — todavía no existe (ver comentario en la
            // declaración del campo más arriba). Se resuelve perezosamente vía ResolvedTeamMember.

            // ✅ CRÍTICO: Configurar destroyOnDeath=false INMEDIATAMENTE en Awake
            // Esto se aplica tanto si el componente ya existía como si se acaba de añadir
            if (_damageable != null)
            {
                _damageable.SetDestroyOnDeath(false);
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                // Debug.Log($"[Lifecycle] ✅ destroyOnDeath establecido a FALSE en Awake para {name} (actual valor: {_damageable.GetComponent<Damageable>() != null})");
                #endif
            }
            else
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[Lifecycle] ⚠️ Damageable no encontrado en Awake para {name} - esperando que se añada después");
                #endif
            }
        }

        private void Start()
        {
            // ✅ _config ahora es una propiedad que obtiene el valor dinámicamente
            // No necesita asignación aquí

            // ✅ Verificación de respaldo: Si Damageable no estaba en Awake, obtenerlo ahora
            if (_damageable == null)
            {
                _damageable = GetComponent<Damageable>();
                if (_damageable != null)
                {
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.LogWarning($"[Lifecycle] ⚠️ Damageable se añadió después de Awake - configurando destroyOnDeath=false ahora");
                    #endif
                    _damageable.SetDestroyOnDeath(false);
                }
                else
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.LogError($"[Lifecycle] ❌ Damageable SIGUE siendo null en Start() para {name}");
#endif
                    return;
                }
            }
            
            // Verificación final: Asegurar que destroyOnDeath esté en false
            _damageable.SetDestroyOnDeath(false);
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            // Debug.Log($"[Lifecycle] 🔒 Verificación final en Start: destroyOnDeath=false para {name}");
            #endif

            // Suscribirse a eventos
            _damageable.OnDamaged += OnDamaged;
            _damageable.OnDied += OnDied;
            
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            // Debug.Log($"[Lifecycle] ✅ Suscrito a eventos OnDamaged y OnDied para {name}");
            #endif
        }

        private void OnDestroy()
        {
            if (_damageable != null)
            {
                _damageable.OnDamaged -= OnDamaged;
                _damageable.OnDied -= OnDied;
            }
            // Salvaguarda final por si se destruye durante slow-mo: cancelamos el efecto cinematográfico
            // (restaura FOV y libera _isEffectActive, si no quedaría bloqueado para la próxima muerte).
            // FIX C6 (auditoría 2026-08-07): antes forzaba Time.timeScale=1 "por si acaso", pisando
            // cualquier otro efecto activo (hitstop, cinemática) que no tuviera relación con esta
            // muerte. CancelDeathEffect() ya libera la petición de este NPC en TimeScaleArbiterService
            // (vía DeathCameraEffect.CancelEffect); no hace falta tocar Time.timeScale aquí.
            FeedbackService.CancelDeathEffect();
        }

        // =================================================================================
        // ⚔️ DAMAGE HANDLING
        // =================================================================================

        public void StartCasting(string animName, int layer) { _isCasting = true; }
        public void EndCasting() { _isCasting = false; }

        private void OnDamaged(float amount)
        {
            if (_isInvulnerable || _isProcessingDefeat) return;

            // Si el NPC no está en combate y recibe daño, entrar en combate inmediatamente.
            // Cubre ataques por la espalda y cualquier caso donde no haya detectado al jugador.
            if (_manager != null && _manager.Context != null && !_manager.Context.IsInCombat && !IsDefeatedAndInactive)
            {
                var attacker = _manager.Player;
                if (attacker != null)
                    _manager.ForceEnterCombat(attacker);
            }

            // 🔍 DEBUG: Log de vida actual
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] ⚔️ {name} recibió {amount} de daño - Vida: {_damageable.Current}/{_damageable.Max} - IsAlive: {_damageable.IsAlive}");
            #endif

            // ✅ Notificar al CombatBrain (para detectar ataques por la espalda durante búsqueda)
            if (_brain != null && _manager != null && _manager.Context != null && _manager.Context.Player != null)
            {
                _brain.OnTakeDamage(_manager.Context.Player.position);
            }

            // Interrupción de Casting
            if (_isCasting)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Lifecycle] ⚡ Interrumpiendo hechizo por daño!");
                #endif
                _isCasting = false;
                // ✅ FIX #19 (auditoría combate, 15 ago 2026): StopAllCoroutines() detenía el FSM del
                // brain sin dejar nada que lo reiniciara — un NPC golpeado mientras lanzaba un hechizo
                // se quedaba con la FSM de combate congelada para siempre (ningún otro código volvía a
                // llamar a StartCoroutine(FSM_Loop())). InterruptCasting() para la corrutina actual Y
                // la reinicia desde EVALUATE.
                if (_brain != null) _brain.InterruptCasting();
                // No hacemos return aquí, dejamos que el stun normal ocurra
            }

            StartCoroutine(DamageSequence());
        }

        private IEnumerator DamageSequence()
        {
            IsStunned = true;
            _isInvulnerable = true;

            // ✅ Si este golpe es LETAL, aplicar slow-mo AHORA (durante la animación de Hit)
            bool isLethalHit = !_damageable.IsAlive;
            
            if (isLethalHit && enableDeathEffects)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Lifecycle] 💀 GOLPE LETAL detectado - Aplicando slow motion cinematográfico durante animación de Hit");
                #endif
                FeedbackService.CameraShake(cameraShakeIntensity * 2f, 0.5f);
                // ✅ Usamos el efecto cinematográfico (zoom + easing de entrada/salida) en vez de un
                // Time.timeScale seco: el corte instantáneo se sentía como un cuelgue en vez de un
                // golpe deliberado. El zoom hacia el enemigo comunica que la pausa es intencional.
                FeedbackService.TriggerDeathEffect(transform, deathSlowMoScale, deathSlowMoDuration, deathZoomFactor, deathZoomDuration, deathReturnDuration);
            }

            // 1. Feedback Visual/Sonoro
            if (playDamageAnimation && _animator) _animator.PlayGetHit();
            if (!isLethalHit && enableCameraShake) FeedbackService.CameraShake(cameraShakeIntensity, cameraShakeDuration);
            if (!isLethalHit && enableHitStop) FeedbackService.HitStop(hitStopTimeScale, hitStopDuration);

            // 2. Detener movimiento físico
            // ✅ FIX (04 sep 2026): mismo patrón de bug que Spider1AI.EnterChaseMode (incidencia de
            // hoy) — tocar _agent.isStopped comprobando solo _agent.enabled no basta. Desde que
            // NPCBehaviourManagerV2 tiene el sistema de sueño por distancia (EnterFarState/
            // ExitFarState, hoy), un NPC recién "despertado" puede tener _agent.enabled = true un
            // frame antes de que Unity lo haya colocado realmente en el NavMesh (isOnNavMesh sigue
            // en false hasta que ExitFarState complete su SamplePosition/Warp). Si un proyectil de
            // daño golpea justo en ese frame, tocar isStopped lanza "can only be called on an
            // active agent that has been placed on a NavMesh". Se añade el mismo guard isOnNavMesh
            // que ya usa el resto del script (DeathRoutine más abajo tenía el mismo hueco, ver fix
            // gemelo un poco más adelante).
            bool wasMoving = _agent != null && _agent.enabled && _agent.isOnNavMesh && !_agent.isStopped;
            if (_agent && _agent.enabled && _agent.isOnNavMesh) _agent.isStopped = true;

            // 3. Esperar Stun (usar WaitForSecondsRealtime si está en slow-mo)
            if (isLethalHit && enableDeathEffects)
            {
                // El propio FeedbackService.TriggerDeathEffect ya restaura Time.timeScale de forma
                // suave (con zoom-out) al terminar su hold; aquí solo esperamos en tiempo real la
                // misma duración para mantener sincronizado el stun del NPC con el efecto visual.
                yield return new WaitForSecondsRealtime(deathSlowMoDuration);
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Lifecycle] ⏱️ Slow motion cinematográfico terminado");
                #endif
            }
            else
            {
                yield return new WaitForSeconds(damageStunDuration);
            }

            // ✅ FIX #2 (auditoría combate, 15 ago 2026): condición de carrera DamageSequence/DeathRoutine.
            // Un golpe casi simultáneo (o daño en área) puede disparar OnDied() — y por tanto DeathRoutine(),
            // que pasa a ser dueño del agent/animator para la secuencia cinemática de muerte — mientras
            // esta corrutina seguía suspendida en el stun de arriba. Sin este guard, al reanudar podía
            // "pelear" con DeathRoutine (reactivar el agent, forzar Idle) justo cuando necesitaba que el
            // NPC se quedara quieto. Si ya hay una derrota en curso, no tocamos nada más: DeathRoutine (o
            // Resurrect(), que resetea _isInvulnerable/IsStunned explícitamente) se encarga del resto.
            if (_isProcessingDefeat)
            {
                yield break;
            }

            // 4. Recuperación (solo si el NPC NO ha muerto)
            if (_damageable.IsAlive)
            {
                if (_animator)
                {
                    _animator.ResetMovement();
                    _animator.TransitionToIdle(); // Forzar vuelta a idle de combate
                }

                if (_agent && _agent.enabled && _agent.isOnNavMesh && wasMoving) 
                    _agent.isStopped = false;
            }
            // Si el NPC murió, NO hacer transición a Idle - DeathRoutine se encargará

            IsStunned = false;

            // Invulnerabilidad residual (frames de gracia) - solo si NO murió
            if (_damageable.IsAlive)
            {
                float graceTime = Mathf.Max(0, invulnerabilityDuration - damageStunDuration);
                if (graceTime > 0) yield return new WaitForSeconds(graceTime);
            }
            
            _isInvulnerable = false;
        }

        // =================================================================================
        // 💀 DEATH SEQUENCE
        // =================================================================================

        private void OnDied()
        {
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] 💀💀💀 OnDied() LLAMADO para {name} - _isProcessingDefeat: {_isProcessingDefeat}");
            #endif
            
            if (_isProcessingDefeat)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[Lifecycle] ⚠️ OnDied() ya en proceso, ignorando duplicado");
                #endif
                return;
            }
            
            _isProcessingDefeat = true;
            IsDefeatedAndInactive = true;
            _yaHabiaCaidoAntes = FlagDePartida.EstaPuesto(ClaveDeDerrota());
            FlagDePartida.Marcar(ClaveDeDerrota());
            
            // ✅ Notificar al equipo si pertenece a uno
            var teamMember = ResolvedTeamMember;
            if (teamMember != null)
            {
                teamMember.NotifyDefeated();
            }

            StartCoroutine(DeathRoutine());
        }

        private IEnumerator DeathRoutine()
        {
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] 💀 Iniciando secuencia de muerte: {name}");
            #endif
            
            // ✅ DEBUG: Verificar configuración de eventos de derrota
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] 🔍 Config de derrota para {name}:");
            #endif
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"    - _config es null: {_config == null}");
            #endif
            if (_config != null)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"    - sendEventOnDefeat: {_config.sendEventOnDefeat}");
                #endif
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"    - defeatEventKey: '{_config.defeatEventKey}'");
                #endif
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"    - sendDefeatEventBeforeDeath: {_config.sendDefeatEventBeforeDeath}");
                #endif
            }

            // 1. DETENER TODO INMEDIATAMENTE
            if (_brain) _brain.StopCombat();
            // ✅ FIX #12 (auditoría combate, 15 ago 2026): parada explícita del escudo aquí también.
            // _brain.StopCombat() ya para el escudo si _brain existe, pero este NPC puede tener
            // NPCShieldController sin _brain (o con _brain null por timing) — sin este guard extra,
            // el NPC podía morir a mitad de una animación de defensa y quedarse con el prefab del
            // escudo instanciado y visible sobre el cadáver.
            _shieldController?.StopDefending();
            // ✅ FIX (04 sep 2026): mismo guard isOnNavMesh que en DamageSequence (ver comentario
            // arriba) — un NPC muerto por un golpe justo al "despertar" del sueño por distancia
            // podía llegar aquí con _agent.enabled = true pero isOnNavMesh todavía false.
            if (_agent && _agent.enabled && _agent.isOnNavMesh) { _agent.isStopped = true; _agent.velocity = Vector3.zero; }
            if (_manager.Context != null)
            {
                _manager.Context.IsInCombat = false;
                _manager.Context.WasDefeatedInCombat = true;
            }
            
            // ✅ NUEVO: Enviar evento de derrota ANTES de la muerte si está configurado así
            if (_config != null && _config.sendEventOnDefeat && _config.sendDefeatEventBeforeDeath && !string.IsNullOrEmpty(_config.defeatEventKey))
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Lifecycle] 📤 Enviando evento de derrota ANTES de muerte: '{_config.defeatEventKey}'");
                #endif
                DefaultNarrativeSignals.Instance?.RaiseCustom(_config.defeatEventKey, name);
            }

            // 2. VFX inicial
            // ✅ FIX: VfxPoolService en vez de Instantiate suelto — el prefab no se autodestruía
            // y quedaba flotando en el suelo indefinidamente tras terminar el combate.
            if (deathVFXPrefab) VfxPoolService.Instance.Play(deathVFXPrefab, transform.position + deathVFXOffset, Quaternion.identity, 3f);

            // 3. Rotar hacia el jugador (Último aliento)
            if (PlayerService.TryGetPlayer(out GameObject player))
            {
                Vector3 dir = (player.transform.position - transform.position).normalized;
                dir.y = 0;
                transform.rotation = Quaternion.LookRotation(dir);
            }

            // ✅ 4. Pequeña pausa para que termine la animación de Hit
            // El slow-mo ya se aplicó en DamageSequence durante la animación de Hit
            yield return new WaitForSeconds(0.1f);

            // ✅ 5. INICIAR ANIMACIÓN DE MUERTE INMEDIATAMENTE
            PostDeathBehavior behavior = _config != null ? _config.postDeathBehavior : PostDeathBehavior.GetUpDizzy;
            
            if (behavior == PostDeathBehavior.GetUpDizzy && _animator)
            {
                // Iniciar animación de muerte YA
                _animator.PlayDeath();
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Lifecycle] 💀 Animación de muerte iniciada - transición directa desde Hit");
                #endif
            }

            // ✅ VERIFICAR SI PERTENECE A UN EQUIPO
            var teamMember = ResolvedTeamMember;
            bool isInTeam = teamMember != null && teamMember.HasTeam;
            bool isLastTeamMember = isInTeam && teamMember.Team.IsTeamDefeated;
            
            // ✅ 6. CELEBRACIÓN DEL JUGADOR
            // Solo celebrar si: NO es equipo, O es el último miembro del equipo
            bool shouldCelebrate = !isInTeam || isLastTeamMember;
            
            if (shouldCelebrate)
            {
                if (PlayerService.TryGetPlayer(out GameObject playerGo))
                {
                    if (IsPlayerDeadOrGameOverActive())
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log("[Lifecycle] ⚠️ Jugador ya murió (game over en curso) — se omite la celebración de victoria.");
                        #endif
                    }
                    else
                    {
                        var playerVictory = playerGo.GetComponent<PlayerBattleModeController>();
                        if (playerVictory != null)
                        {
                            string battleId = _config?.battleMusicId;
                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.Log($"[Lifecycle] 🎉 Llamando a PlayVictory() del player con battleId: {battleId}");
                            #endif
                            playerVictory.PlayVictory(battleId);

                            // ✅ Esperar a que termine la animación de victoria del jugador
                            float victoryTimeout = 15f; // Timeout de seguridad
                            float elapsed = 0f;

                            // Esperar a que comience la victoria (puede tomar un frame)
                            yield return null;

                            // Esperar mientras el jugador está reproduciendo la victoria
                            while (playerVictory.IsPlayingVictory && elapsed < victoryTimeout)
                            {
                                elapsed += Time.unscaledDeltaTime;
                                yield return null;
                            }

                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.Log($"[Lifecycle] ✅ Animación de victoria completada - la música se restaurará después del diálogo");
                            #endif
                        }
                    }
                }

                // NOTA: La restauración de música ahora se maneja manualmente después del diálogo post-derrota
                // en HandleGetUpDizzy(), permitiendo que la música de victoria suene durante todo el diálogo.
                // El evento RaiseBattleWon solo se usa para BossArenaController que no usa PlayVictoryForBattle.
            }
            else
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Lifecycle] 👥 {name} derrotado pero quedan miembros del equipo - sin celebración aún");
                #endif
                // Pequeña pausa para la animación de muerte
                yield return new WaitForSeconds(1f);
            }
            
            // ✅ 7. POST-MUERTE (Desaparecer o continuar con Dizzy)
            // El evento de derrota sale al acabar la secuencia completa (tras el diálogo del NPC),
            // para que lo que dé el grafo llegue después de lo que dice el NPC. Al desaparecer, el
            // objeto se apaga dentro de HandleDisappear y la corrutina ya no sigue: se envía antes.
            if (behavior == PostDeathBehavior.Disappear)
            {
                EnviarEventoDeDerrota();
                yield return HandleDisappear();
            }
            else
            {
                yield return HandleGetUpDizzy();
                EnviarEventoDeDerrota();
            }

            _isProcessingDefeat = false;
        }

        // --- Rutinas de Finalización ---

        private IEnumerator HandleDisappear()
        {
            // Diálogo final antes de irse
            if (_config?.dialogueOnDefeat != null)
            {
                yield return RunDialogueRoutine(_config.dialogueOnDefeat);
            }

            // VFX Desaparición
            if (_config?.disappearVFXPrefab)
                VfxPoolService.Instance.Play(_config.disappearVFXPrefab, transform.position + Vector3.up, Quaternion.identity, 3f);

            gameObject.SetActive(false);
        }

        // Evento de derrota al grafo narrativo, salvo que la config lo pida antes de la muerte.
        private void EnviarEventoDeDerrota()
        {
            if (_config == null || !_config.sendEventOnDefeat || _config.sendDefeatEventBeforeDeath || string.IsNullOrEmpty(_config.defeatEventKey))
                return;
            DefaultNarrativeSignals.Instance?.RaiseCustom(_config.defeatEventKey, name);
        }

        public void CancelDizzySequence()
        {
            _shouldCancelDizzySequence = true;
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] 🛑 Secuencia dizzy cancelada para {name} - movimiento narrativo iniciado");
            #endif
        }

        private IEnumerator HandleGetUpDizzy()
        {
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] 😵 Esperando transición a animación dizzy para {name}");
            #endif
            
            // ✅ Calcular si estamos en equipo y si somos el último miembro
            var teamMember = ResolvedTeamMember;
            bool isInTeam = teamMember != null && teamMember.Team != null;
            bool isLastTeamMember = isInTeam && teamMember.Team.IsTeamDefeated;
            
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] 🔍 DEBUG HandleGetUpDizzy INICIO: isInTeam={isInTeam}, isLastTeamMember={isLastTeamMember}, battleMusicId='{_config?.battleMusicId}'");
            #endif
            
            // 1. La animación de muerte ya se inició en DeathRoutine()
            // Solo esperamos a que esté en la animación de mareo (dizzy)
            float timeout = 10f; // Timeout de seguridad
            float elapsed = 0f;
            
            while (elapsed < timeout)
            {
                if (_animator != null && _animator.IsInDizzyAnimation())
                {
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] ✅ NPC ahora está en animación dizzy");
                    #endif
                    break;
                }
                
                elapsed += Time.deltaTime;
                yield return null;
            }
            
            if (elapsed >= timeout)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[Lifecycle] ⚠️ Timeout esperando animación dizzy - continuando de todas formas");
                #endif
            }
            
            // ✅ REDISEÑO (15 ago 2026, a petición de Raúl): cada NPC del equipo ahora dice su
            // PROPIA frase de derrota y ejecuta su PROPIA acción post-derrota de forma
            // independiente en cuanto ÉL MISMO muere — ya no espera a que caiga todo el equipo ni
            // a que el líder termine de hablar. Antes, un miembro no-líder que moría primero se
            // quedaba congelado en HandleGetUpDizzy hasta 2 minutos esperando al resto del equipo
            // (o más, esperando encima al diálogo del líder) — eso es justo el bug que describió
            // Raúl como "se ha ido uno de los dos y el otro seguía luchando": un NPC efectivamente
            // desaparecía de la pelea (congelado en dizzy o ya desaparecido) mientras su compañero
            // seguía luchando solo, sin que sonara ninguna frase propia suya.
            //
            // isLastTeamMember (calculado arriba, al ENTRAR a este método) ya nos dice si la
            // muerte de ESTE NPC fue la que completó la derrota del equipo — _defeatedCount se
            // incrementa de forma síncrona en OnDied()/OnMemberDefeated, así que el valor es
            // correcto sin importar el orden en que mueran. Se reutiliza esa misma bandera (en vez
            // de "soy el líder") para decidir quién dispara la única celebración/restauración de
            // música al final — igual que ya hacía shouldCelebrate en DeathRoutine.
            if (isInTeam)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Lifecycle] 👥 {name} es parte de un equipo - IsLeader: {teamMember.IsLeader}, isLastTeamMember: {isLastTeamMember}, Derrotados: {teamMember.Team.DefeatedCount}/{teamMember.Team.TeamSize}");
                #endif
            }

            // 2. Mostrar diálogo de mareo — SIEMPRE, cada NPC muestra el suyo propio (ya no se
            // salta para los no-líderes).
            bool shouldShowDialogue = true;
            
            if (shouldShowDialogue)
            {
                DialogueAsset dialogue = _yaHabiaCaidoAntes && _config?.dialogueOnDizzyRepeat != null
                    ? _config.dialogueOnDizzyRepeat
                    : _config?.dialogueOnDizzy ?? _config?.dialogueOnDefeat;
                if (dialogue != null)
                {
                    // ✅ Verificar antes de mostrar diálogo
                    if (_shouldCancelDizzySequence)
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[Lifecycle] 🛑 Diálogo omitido para {name} - movimiento iniciado");
                        #endif
                        yield break;
                    }
                    
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] 💬 Iniciando diálogo post-derrota para {name}");
                    #endif
                    bool finished = false;
                    DialogueManager.Instance.StartDialogue(dialogue, transform, () => finished = true);
                    
                    // Esperar a que termine el diálogo
                    while (!finished) 
                    {
                        // ✅ Verificar durante el diálogo también
                        if (_shouldCancelDizzySequence)
                        {
                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.Log($"[Lifecycle] 🛑 Diálogo interrumpido para {name}");
                            #endif
                            // Cerrar el diálogo si está abierto
                            if (DialogueManager.Instance != null && DialogueManager.Instance.IsOpen)
                            {
                                DialogueManager.Instance.Close();
                            }
                            yield break;
                        }
                        
                        yield return null;
                    }
                    
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] 💬 Diálogo de mareo completado");
                    #endif
                    
                    // ✅ Restaurar música de batalla DESPUÉS del diálogo
                    // Solo si es el último enemigo derrotado (líder o sin equipo)
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] 🔍 DEBUG Restauración música: isInTeam={isInTeam}, IsLeader={teamMember?.IsLeader}, isLastTeamMember={isLastTeamMember}");
                    #endif
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] 🔍 DEBUG Config: battleMusicId='{_config?.battleMusicId}', AudioService={AudioService.Instance != null}");
                    #endif
                    
                    if (IsPlayerDeadOrGameOverActive())
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log("[Lifecycle] ⚠️ Jugador ya murió (game over en curso) — se omite la restauración de música tras el diálogo.");
                        #endif
                    }
                    // ✅ REDISEÑO (15 ago 2026): ya no se exige ser el líder — la música/celebración
                    // se restaura una única vez, cuando el NPC cuya muerte completó al equipo
                    // (isLastTeamMember) termina SU PROPIO diálogo. Da igual si es el líder o no.
                    else if (!isInTeam || isLastTeamMember)
                    {
                        if (!string.IsNullOrEmpty(_config?.battleMusicId) && AudioService.Instance != null)
                        {
                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.Log($"[Lifecycle] 🎵 Restaurando música de batalla después del diálogo: {_config.battleMusicId}");
                            #endif
                            AudioService.Instance.EndBattleById(_config.battleMusicId);
                        }
                        else if (AudioService.Instance != null)
                        {
                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.Log($"[Lifecycle] 🎵 Restaurando música después del diálogo (sin battleMusicId)");
                            #endif
                            AudioService.Instance.RestoreAfterBattle();
                        }
                    }
                    else
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[Lifecycle] ℹ️ No se restaura música aún - quedan compañeros de equipo con vida");
                        #endif
                    }

                    // ✅ REDISEÑO (15 ago 2026): notifica "diálogo post-derrota terminado" quien
                    // remató al equipo, no necesariamente el líder.
                    if (isInTeam && isLastTeamMember)
                    {
                        teamMember.Team.NotifyPostDefeatDialogueFinished();
                    }
                }
                else
                {
                    // Si no hay diálogo pero esta muerte completó al equipo, notificar inmediatamente
                    if (isInTeam && isLastTeamMember)
                    {
                        teamMember.Team.NotifyPostDefeatDialogueFinished();
                    }

                    // ✅ Restaurar música si no hay diálogo
                    if (IsPlayerDeadOrGameOverActive())
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log("[Lifecycle] ⚠️ Jugador ya murió (game over en curso) — se omite la restauración de música (sin diálogo).");
                        #endif
                    }
                    else if (!isInTeam || isLastTeamMember)
                    {
                        if (!string.IsNullOrEmpty(_config?.battleMusicId) && AudioService.Instance != null)
                        {
                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.Log($"[Lifecycle] 🎵 Restaurando música de batalla (sin diálogo): {_config.battleMusicId}");
                            #endif
                            AudioService.Instance.EndBattleById(_config.battleMusicId);
                        }
                        else if (AudioService.Instance != null)
                        {
                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.Log($"[Lifecycle] 🎵 Restaurando música (sin diálogo, sin battleMusicId)");
                            #endif
                            AudioService.Instance.RestoreAfterBattle();
                        }
                    }
                }
            }
            
            // 3. Ejecutar acción post-derrota (si está configurada)
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] 🔍 Verificando postDefeatAction para {name}: config={(_config != null ? "OK" : "NULL")}, action={_config?.postDefeatAction}");
            #endif
            
            // ✅ Si es miembro de equipo (no líder) y el líder tiene moveTeamMembersOnDefeat activo,
            // NO ejecutar postDefeatAction individual porque el líder nos moverá
            bool skipPostDefeatBecauseLeaderWillMove = false;
            if (isInTeam && !teamMember.IsLeader)
            {
                var leaderConfig = teamMember.Team.Leader?.Configuration?.combatConfig;
                if (leaderConfig != null && 
                    leaderConfig.postDefeatAction == PostDefeatAction.MoveToAnchor && 
                    leaderConfig.moveTeamMembersOnDefeat)
                {
                    skipPostDefeatBecauseLeaderWillMove = true;
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] ℹ️ {name} omitirá postDefeatAction individual - el líder moverá al equipo");
                    #endif
                }
            }
            
            if (!skipPostDefeatBecauseLeaderWillMove && _config != null && _config.postDefeatAction != PostDefeatAction.None)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Lifecycle] 🎬 {name} ejecutará acción post-derrota: {_config.postDefeatAction}");
                #endif
                yield return HandlePostDefeatAction(_config.postDefeatAction);
            }
            else
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Lifecycle] ℹ️ {name} no tiene postDefeatAction configurada - configurando como interactuable");
                #endif
                // 4. Configurar para interacción futura (Hablar con el NPC derrotado)
                SetupPostCombatInteraction();
            }
            
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] ✅ Secuencia GetUpDizzy completada para {name}");
            #endif
        }

        private IEnumerator HandlePostDefeatAction(PostDefeatAction action)
        {
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] 🎬 Ejecutando acción post-derrota: {action}");
            #endif
            
            switch (action)
            {
                case PostDefeatAction.FleeAndDisappear:
                    bool fleeMovementStarted = false;
                    // Huir del jugador
                    if (PlayerService.TryGetPlayer(out GameObject player))
                    {
                        Vector3 fleeDir = (transform.position - player.transform.position).normalized;
                        Vector3 fleePos = transform.position + fleeDir * 10f;

                        // Usar NavMesh para encontrar punto válido inicial
                        if (NavMesh.SamplePosition(fleePos, out NavMeshHit hit, 5f, NavMesh.AllAreas))
                        {
                            fleePos = hit.position;
                        }

                        // Activar movimiento
                        if (_agent != null)
                        {
                            // FIX: si el NPC quedó fuera de malla mientras el agent estaba
                            // desactivado, hacer "_agent.enabled = true" a secas AQUÍ ya loggea
                            // "Failed to create agent because there is no valid NavMesh" (Unity
                            // valida transform.position en el instante de habilitar, antes de que
                            // el bloque de abajo pueda recolocarlo). SafeEnable recoloca el
                            // transform al punto de NavMesh válido más cercano antes de habilitar,
                            // evitando el falso error; la validación de abajo queda como red de
                            // seguridad para cuando no hay NavMesh cerca.
                            Game.NPC.Common.NavMeshAgentUtility.SafeEnable(_agent, transform, transform.position);

                            // ✅ VALIDACIÓN 1: Verificar que está en NavMesh
                            if (!_agent.isOnNavMesh)
                            {
                                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                                Debug.LogWarning($"[Lifecycle] ⚠️ {name} NO está en NavMesh! No puede huir. Posición: {transform.position}");
                                #endif
                                if (NavMesh.SamplePosition(transform.position, out NavMeshHit repoHit, 2f, NavMesh.AllAreas))
                                {
                                    transform.position = repoHit.position;
                                    _agent.Warp(repoHit.position);
                                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                                    Debug.Log($"[Lifecycle] 🔄 {name} recolocado en NavMesh: {repoHit.position}");
                                    #endif
                                }
                                else
                                {
                                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                                    Debug.LogWarning($"[Lifecycle] ⚠️ No se pudo recolocar {name} en NavMesh - se aplicará fallback de desaparición");
                                    #endif
                                }
                            }

                            if (_agent.isOnNavMesh)
                            {
                                // Guardar configuración original
                                bool originalUpdateRotation = _agent.updateRotation;
                                float originalSpeed = _agent.speed;

                                _agent.isStopped = false;
                                _agent.updatePosition = true; // PlayDeath lo desactiva
                                _agent.updateRotation = false; // NPCSimpleAnimator maneja la rotación

                                if (!_agent.Warp(transform.position))
                                {
                                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                                    Debug.LogWarning($"[Lifecycle] ⚠️ {name} no pudo hacer Warp a {transform.position} - se aplicará fallback de desaparición");
                                    #endif
                                }
                                else if (!TryResolveReachableDestination(_agent, fleePos, out Vector3 resolvedFleePos))
                                {
                                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                                    Debug.LogWarning($"[Lifecycle] ⚠️ {name} no encontró destino alcanzable para huida cerca de {fleePos}");
                                    #endif
                                }
                                else
                                {
                                    fleePos = resolvedFleePos;
                                    _agent.SetDestination(fleePos);

                                    float pathWaitTime = 0f;
                                    while (_agent.pathPending && pathWaitTime < 1f)
                                    {
                                        pathWaitTime += Time.deltaTime;
                                        yield return null;
                                    }

                                    if (_agent.hasPath && _agent.path.status == NavMeshPathStatus.PathComplete)
                                    {
                                        if (_animator != null)
                                        {
                                            _animator.AllowManualRotation = false;
                                            _animator.EnableAutoRotation();
                                            _animator.TransitionToLocomotion();
                                            _animator.SetMovementSpeed(1f, 0.1f);
                                        }

                                        // ✅ EXTRA: Dar 1 frame para que el agent procese el destino
                                        yield return null;

                                        float fleeTime = 0f;
                                        float maxFleeTime = 2f;
                                        Vector3 lastPosition = transform.position;
                                        float stuckCheckInterval = 1f;
                                        float timeSinceLastCheck = 0f;

                                        while (fleeTime < maxFleeTime && _agent != null && _agent.isOnNavMesh)
                                        {
                                            if (_animator != null && _agent.velocity.sqrMagnitude > 0.01f)
                                            {
                                                float speed = _agent.velocity.magnitude / Mathf.Max(_agent.speed, 0.1f);
                                                _animator.SetMovementSpeed(speed, 0.1f);

                                                Vector3 moveDir = _agent.velocity.normalized;
                                                moveDir.y = 0f;
                                                if (moveDir.sqrMagnitude > 0.01f)
                                                {
                                                    _animator.FaceDirection(moveDir);
                                                }
                                            }

                                            timeSinceLastCheck += Time.deltaTime;
                                            if (timeSinceLastCheck >= stuckCheckInterval)
                                            {
                                                float distanceMoved = Vector3.Distance(transform.position, lastPosition);
                                                if (distanceMoved < 0.1f && _agent.remainingDistance > 0.5f)
                                                {
                                                    _agent.isStopped = true;
                                                    yield return null;
                                                    _agent.isStopped = false;
                                                    _agent.SetDestination(fleePos);
                                                }

                                                lastPosition = transform.position;
                                                timeSinceLastCheck = 0f;
                                            }

                                            fleeTime += Time.deltaTime;
                                            yield return null;
                                        }

                                        fleeMovementStarted = true;
                                    }
                                    else
                                    {
                                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                                        Debug.LogWarning($"[Lifecycle] ⚠️ {name} no puede calcular path hacia {fleePos}! Status: {(_agent.hasPath ? _agent.path.status.ToString() : "NO PATH")}");
                                        #endif
                                    }
                                }

                                // Detener y restaurar configuración
                                if (_agent != null && _agent.isOnNavMesh)
                                {
                                    _agent.isStopped = true;
                                    _agent.updateRotation = originalUpdateRotation;
                                    _agent.speed = originalSpeed;
                                }
                            }
                        }
                    }

                    if (!fleeMovementStarted)
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.LogWarning($"[Lifecycle] ⚠️ {name} no pudo ejecutar huida - aplicando desaparición directa");
                        #endif
                    }
                    
                    // ✅ Desaparecer con TransitionManager si está configurado
                    if (_config?.disappearTransition != null)
                    {
                        var transitionManager = EasyTransition.TransitionManager.Instance();
                        if (transitionManager != null)
                        {
                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.Log($"[Lifecycle] 🎭 Iniciando transición de desaparición para {name}");
                            #endif
                            
                            bool transitionCompleted = false;
                            
                            // Callback para desactivar el NPC en el punto de corte
                            void OnCutPoint()
                            {
                                // Reproducir VFX si existe
                                if (_config?.disappearVFXPrefab != null)
                                {
                                    VfxPoolService.Instance.Play(_config.disappearVFXPrefab, transform.position + Vector3.up, Quaternion.identity, 3f);
                                }
                                
                                // Desactivar el GameObject
                                gameObject.SetActive(false);
                                transitionCompleted = true;
                                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                                Debug.Log($"[Lifecycle] ✅ {name} desactivado durante transición");
                                #endif
                            }
                            
                            // Suscribirse al evento de punto de corte
                            transitionManager.onTransitionCutPointReached += OnCutPoint;
                            
                            // Iniciar transición sin cambio de escena
                            transitionManager.Transition(_config.disappearTransition, 0f);
                            
                            // Esperar a que complete
                            float timeout = 5f;
                            while (!transitionCompleted && timeout > 0f)
                            {
                                timeout -= Time.deltaTime;
                                yield return null;
                            }
                            
                            // Limpiar callback
                            transitionManager.onTransitionCutPointReached -= OnCutPoint;
                            
                            if (!transitionCompleted)
                            {
                                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                                Debug.LogWarning($"[Lifecycle] ⚠️ Timeout esperando transición, desactivando {name} directamente");
                                #endif
                                gameObject.SetActive(false);
                            }
                        }
                        else
                        {
                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.LogWarning($"[Lifecycle] ⚠️ No se encontró TransitionManager, desapareciendo sin transición");
                            #endif
                            // Fallback: desaparecer sin transición
                            if (_config?.disappearVFXPrefab)
                                VfxPoolService.Instance.Play(_config.disappearVFXPrefab, transform.position + Vector3.up, Quaternion.identity, 3f);
                            gameObject.SetActive(false);
                        }
                    }
                    else
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[Lifecycle] ℹ️ No hay TransitionSettings configurado, desapareciendo sin transición");
                        #endif
                        // Desaparecer sin transición (comportamiento original)
                        if (_config?.disappearVFXPrefab)
                            VfxPoolService.Instance.Play(_config.disappearVFXPrefab, transform.position + Vector3.up, Quaternion.identity, 3f);
                        gameObject.SetActive(false);
                    }
                    break;
                    
                case PostDefeatAction.ReturnToIdle:
                    // ✅ Transicionar de dizzy a idle
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] 🔄 {name} volviendo a idle desde dizzy");
                    #endif
                    
                    if (_animator != null)
                    {
                        _animator.TransitionToIdle();
                        yield return new WaitForSeconds(0.3f); // Esperar transición
                    }
                    
                    // Configurar como interactuable
                    SetupPostCombatInteraction();
                    break;
                    
                case PostDefeatAction.MoveToAnchor:
                    yield return HandleMoveToAnchor();
                    break;
            }
        }
        
        /// <summary>
        /// Maneja el movimiento del NPC (y su equipo si es líder) a un anchor después de la derrota
        /// </summary>
        private IEnumerator HandleMoveToAnchor()
        {
            if (string.IsNullOrEmpty(_config?.postDefeatMoveAnchor))
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[Lifecycle] ⚠️ {name} tiene MoveToAnchor pero no hay anchor configurado");
                #endif
                SetupPostCombatInteraction();
                yield break;
            }
            
            // Buscar el anchor de destino (primero por SpawnAnchor ID, luego por nombre de GameObject)
            var anchorTransform = ResolveAnchorTransform(_config.postDefeatMoveAnchor);
            if (anchorTransform == null)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[Lifecycle] ⚠️ No se encontró el anchor '{_config.postDefeatMoveAnchor}' para {name}");
                #endif
                SetupPostCombatInteraction();
                yield break;
            }
            
            Vector3 targetPos = anchorTransform.position;
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] 🚶 {name} moviéndose a anchor '{_config.postDefeatMoveAnchor}'");
            #endif
            
            // Cancelar la secuencia dizzy para que no interfiera
            _shouldCancelDizzySequence = true;

            bool externalMovementOverridePushed = false;
            if (_manager != null)
            {
                _manager.PushExternalMovementOverride();
                externalMovementOverridePushed = true;
            }
            
            // ✅ Transicionar a animación de caminar
            if (_animator != null)
            {
                _animator.SetTalking(false);
                _animator.EndInteraction();
                _animator.TransitionToIdle();
                yield return new WaitForSeconds(0.3f);
                
                // ✅ Habilitar rotación automática ANTES de empezar a mover
                _animator.AllowManualRotation = false;
                _animator.EnableAutoRotation();
            }
            
            try
            {
                // Activar NavMeshAgent y mover
                if (_agent != null)
                {
                    // ✅ Validación exhaustiva del NavMeshAgent
                    if (!_agent.isOnNavMesh)
                    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.LogError($"[Lifecycle] ❌ {name} NO está en NavMesh! Posición: {transform.position}");
#endif
                        SetupPostCombatInteraction();
                        yield break;
                    }
                    
                    _agent.enabled = true;
                    _agent.isStopped = false;
                    
                    // ✅ Guardar configuración original para restaurar después
                    float originalSpeed = _agent.speed;
                    bool originalUpdateRotation = _agent.updateRotation;
                    
                    _agent.speed = originalSpeed * 0.5f; // Más lento de lo normal
                    _agent.updateRotation = false; // NPCSimpleAnimator maneja la rotación
                    
                    // ✅ CRÍTICO: Establecer destino y verificar que el path es válido
                    _agent.SetDestination(targetPos);
                    
                    // Esperar un frame para que Unity calcule el path
                    yield return null;
                    
                    // ✅ Verificar que el path es válido
                    if (_agent.pathPending)
                    {
                        float waitTime = 0f;
                        while (_agent.pathPending && waitTime < 1f)
                        {
                            waitTime += Time.deltaTime;
                            yield return null;
                        }
                    }
                    
                    if (_agent.path.status != NavMeshPathStatus.PathComplete)
                    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.LogError($"[Lifecycle] ❌ {name} no puede calcular path hacia {targetPos}! Status: {_agent.path.status}");
#endif
                        SetupPostCombatInteraction();
                        yield break;
                    }
                    
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] ✅ {name} iniciando movimiento:\n" +
                             $"  Destino: {targetPos}\n" +
                             $"  Distancia: {Vector3.Distance(transform.position, targetPos):F2}m\n" +
                             $"  Speed: {_agent.speed}\n" +
                             $"  Path Status: {_agent.path.status}\n" +
                             $"  UpdateRotation: {_agent.updateRotation}");
                    #endif
                    
                    // Loop de movimiento con verificación continua
                    float timeout = 30f;
                    float elapsed = 0f;
                    float stuckCheckInterval = 1f;
                    float lastStuckCheck = 0f;
                    Vector3 lastCheckPos = transform.position;
                    
                    while (elapsed < timeout)
                    {
                        if (_agent == null || !_agent.isOnNavMesh) break;
                        
                        // ✅ Verificar si está "atascado" (no se ha movido en 1 segundo)
                        if (elapsed - lastStuckCheck >= stuckCheckInterval)
                        {
                            float movedDistance = Vector3.Distance(transform.position, lastCheckPos);
                            if (movedDistance < 0.1f && !_agent.pathPending)
                            {
                                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                                Debug.LogWarning($"[Lifecycle] ⚠️ {name} parece estar atascado (movido {movedDistance:F3}m en {stuckCheckInterval}s)");
                                #endif
                                
                                // Intentar reconfigurar el agent
                                _agent.isStopped = true;
                                yield return new WaitForSeconds(0.1f);
                                _agent.isStopped = false;
                                _agent.SetDestination(targetPos);
                                
                                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                                Debug.Log($"[Lifecycle] 🔄 {name} reconfigurado - Velocity: {_agent.velocity.magnitude:F2}, IsOnNavMesh: {_agent.isOnNavMesh}");
                                #endif
                            }
                            
                            lastStuckCheck = elapsed;
                            lastCheckPos = transform.position;
                        }
                        
                        // ✅ CRÍTICO: Actualizar animación CADA FRAME
                        if (_animator != null)
                        {
                            float agentSpeed = _agent.velocity.magnitude;
                            
                            // ✅ Log si velocity es 0 pero debería moverse
                            if (agentSpeed < 0.01f && !_agent.pathPending && _agent.remainingDistance > _agent.stoppingDistance + 0.5f)
                            {
                                if (Time.frameCount % 60 == 0) // Cada 60 frames (~1 segundo)
                                {
                                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                                    Debug.LogWarning($"[Lifecycle] ⚠️ {name} velocity = 0 pero debería moverse!\n" +
                                                   $"  remainingDistance: {_agent.remainingDistance:F2}\n" +
                                                   $"  stoppingDistance: {_agent.stoppingDistance:F2}\n" +
                                                   $"  isStopped: {_agent.isStopped}\n" +
                                                   $"  pathPending: {_agent.pathPending}\n" +
                                                   $"  path.status: {_agent.path.status}");
                                    #endif
                                }
                            }
                            
                            if (agentSpeed > 0.01f)
                            {
                                // Calcular velocidad normalizada (0 = parado, 1 = velocidad máxima)
                                float maxSpeed = Mathf.Max(_agent.speed, 0.1f);
                                float normalizedSpeed = Mathf.Clamp01(agentSpeed / maxSpeed);
                                
                                // Aplicar velocidad más lenta (derrotado)
                                _animator.SetMovementSpeed(normalizedSpeed * 0.5f, 0.1f);
                                
                                // ✅ Rotar hacia la dirección del movimiento
                                Vector3 moveDir = _agent.velocity.normalized;
                                moveDir.y = 0f;
                                if (moveDir.sqrMagnitude > 0.01f)
                                {
                                    _animator.FaceDirection(moveDir);
                                }
                            }
                            else
                            {
                                // Si no se está moviendo, velocidad 0
                                _animator.SetMovementSpeed(0f, 0.1f);
                            }
                        }
                        
                        // Verificar si llegó
                        if (!_agent.pathPending && _agent.remainingDistance <= _agent.stoppingDistance + 0.1f)
                        {
                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.Log($"[Lifecycle] ✅ {name} llegó a su destino (elapsed: {elapsed:F1}s)");
                            #endif
                            break;
                        }
                        
                        elapsed += Time.deltaTime;
                        yield return null;
                    }
                    
                    if (elapsed >= timeout)
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.LogWarning($"[Lifecycle] ⏱️ {name} timeout alcanzado ({timeout}s) - Forzando parada");
                        #endif
                    }
                    
                    // Detener movimiento y restaurar configuración
                    _agent.isStopped = true;
                    _agent.speed = originalSpeed;
                    _agent.updateRotation = originalUpdateRotation;
                    
                    if (_animator != null)
                    {
                        _animator.SetMovementSpeed(0f, 0.1f);
                        _animator.TransitionToIdle();
                    }
                }
            }
            finally
            {
                if (externalMovementOverridePushed && _manager != null)
                {
                    _manager.PopExternalMovementOverride();
                }
            }

            // Si es líder de equipo y debe mover a los compañeros, hacerlo ANTES de desaparecer.
            var teamMember = ResolvedTeamMember;
            if (teamMember != null && teamMember.IsLeader && _config.moveTeamMembersOnDefeat)
            {
                yield return MoveTeamMembersToRandomPoints();
            }
            
            // ¿Desaparecer al llegar?
            if (_config.disappearOnArrival)
            {
                if (_config.disappearOnArrivalVFX != null)
                {
                    VfxPoolService.Instance.Play(_config.disappearOnArrivalVFX, transform.position + Vector3.up, Quaternion.identity, 3f);
                }
                
                yield return new WaitForSeconds(0.5f);
                gameObject.SetActive(false);
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Lifecycle] 👋 {name} desapareció al llegar a destino");
                #endif
            }
            else
            {
                // Configurar como interactuable
                SetupPostCombatInteraction();
            }
        }
        
        /// <summary>
        /// Mueve a los miembros del equipo a sus anchors configurados o puntos aleatorios si no tienen
        /// </summary>
        private IEnumerator MoveTeamMembersToRandomPoints()
        {
            var teamMember = ResolvedTeamMember;
            if (teamMember == null || teamMember.Team == null) yield break;
            
            var team = teamMember.Team;
            var members = team.AllMembers;
            
            foreach (var member in members)
            {
                if (member == null || member.gameObject == gameObject) continue;
                if (!member.gameObject.activeInHierarchy) continue;
                
                var memberHandler = member.GetComponent<NPCCombatLifecycleHandler>();
                if (memberHandler != null)
                {
                    memberHandler.CancelDizzySequence();
                }
                
                // ✅ FIX: Primero intentar usar el anchor individual del miembro
                Vector3 targetPos;
                var memberConfig = member.Configuration?.combatConfig;
                bool hasIndividualAnchor = false;
                
                if (memberConfig != null && 
                    memberConfig.postDefeatAction == PostDefeatAction.MoveToAnchor && 
                    !string.IsNullOrEmpty(memberConfig.postDefeatMoveAnchor))
                {
                    // Buscar el anchor individual del miembro
                    var memberAnchor = SpawnAnchor.FindById(memberConfig.postDefeatMoveAnchor);
                    if (memberAnchor != null)
                    {
                        targetPos = memberAnchor.transform.position;
                        hasIndividualAnchor = true;
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[Lifecycle] 🚶 Miembro {member.name} moviéndose a su SpawnAnchor: '{memberConfig.postDefeatMoveAnchor}'");
                        #endif
                    }
                    else
                    {
                        // Fallback: buscar por nombre
                        var anchorGo = GameObject.Find(memberConfig.postDefeatMoveAnchor);
                        if (anchorGo != null)
                        {
                            targetPos = anchorGo.transform.position;
                            hasIndividualAnchor = true;
                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.Log($"[Lifecycle] 🚶 Miembro {member.name} moviéndose a su anchor (GameObject): '{memberConfig.postDefeatMoveAnchor}'");
                            #endif
                        }
                        else
                        {
                            // No se encontró el anchor, usar punto aleatorio
                            Vector3 randomOffset = Random.insideUnitSphere * 5f;
                            randomOffset.y = 0;
                            targetPos = transform.position + randomOffset;
                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.LogWarning($"[Lifecycle] ⚠️ No se encontró anchor '{memberConfig.postDefeatMoveAnchor}' para {member.name}, usando punto aleatorio");
                            #endif
                        }
                    }
                }
                else
                {
                    // Sin anchor configurado, mover a punto aleatorio cerca del líder
                    Vector3 randomOffset = Random.insideUnitSphere * 5f;
                    randomOffset.y = 0;
                    targetPos = transform.position + randomOffset;
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] 🚶 Miembro {member.name} sin anchor configurado, moviendo a punto aleatorio");
                    #endif
                }
                
                if (NavMesh.SamplePosition(targetPos, out NavMeshHit hit, 5f, NavMesh.AllAreas))
                {
                    targetPos = hit.position;
                }
                
                var memberAgent = member.Agent;
                var memberAnimator = member.GetComponent<NPCSimpleAnimator>();
                
                if (memberAgent != null)
                {
                    // ✅ Validación exhaustiva del NavMeshAgent
                    if (!memberAgent.isOnNavMesh)
                    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.LogError($"[Lifecycle] ❌ Miembro {member.name} NO está en NavMesh! Posición: {member.transform.position}");
#endif
                        continue; // Saltar este miembro
                    }
                    
                    memberAgent.enabled = true;
                    memberAgent.isStopped = false;
                    
                    // ✅ Guardar configuración original
                    float originalSpeed = memberAgent.speed;
                    bool originalUpdateRotation = memberAgent.updateRotation;
                    
                    memberAgent.speed = originalSpeed * 0.5f;
                    memberAgent.updateRotation = false; // NPCSimpleAnimator maneja la rotación
                    member.PushExternalMovementOverride();
                    
                    // ✅ Establecer destino y esperar cálculo de path
                    memberAgent.SetDestination(targetPos);
                    
                    if (memberAnimator != null)
                    {
                        memberAnimator.SetTalking(false);
                        memberAnimator.EndInteraction();
                        memberAnimator.TransitionToIdle();
                        yield return new WaitForSeconds(0.1f); // Pequeña espera para transición
                        
                        // ✅ Habilitar rotación automática
                        memberAnimator.AllowManualRotation = false;
                        memberAnimator.EnableAutoRotation();
                    }
                    
                    // Esperar un frame para que Unity calcule el path
                    yield return null;
                    
                    // ✅ Verificar que el path es válido
                    if (memberAgent.pathPending)
                    {
                        float waitTime = 0f;
                        while (memberAgent.pathPending && waitTime < 1f)
                        {
                            waitTime += Time.deltaTime;
                            yield return null;
                        }
                    }
                    
                    if (memberAgent.path.status != NavMeshPathStatus.PathComplete)
                    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.LogError($"[Lifecycle] ❌ Miembro {member.name} no puede calcular path hacia {targetPos}! Status: {memberAgent.path.status}");
#endif
                        member.PopExternalMovementOverride();
                        continue; // Saltar este miembro
                    }
                    
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] ✅ Miembro {member.name} iniciando movimiento:\n" +
                             $"  Destino: {targetPos}\n" +
                             $"  Distancia: {Vector3.Distance(member.transform.position, targetPos):F2}m\n" +
                             $"  Speed: {memberAgent.speed}\n" +
                             $"  Path Status: {memberAgent.path.status}\n" +
                             $"  UpdateRotation: {memberAgent.updateRotation}");
                    #endif
                    
                    // ✅ Iniciar corrutina para esperar llegada y manejar post-acción
                    member.StartCoroutine(WaitForMemberArrivalAndHandle(member, memberConfig, hasIndividualAnchor, originalSpeed, originalUpdateRotation, true));
                }
            }
            
            // Pequeña espera para que empiecen a moverse
            yield return new WaitForSeconds(0.5f);
        }
        
        /// <summary>
        /// Espera a que un miembro llegue a su destino y maneja la post-acción
        /// </summary>
        private IEnumerator WaitForMemberArrivalAndHandle(NPCBehaviourManagerV2 member, NPCCombatConfig config, bool hasIndividualAnchor, float originalSpeed, bool originalUpdateRotation, bool releaseExternalMovementOverride)
        {
            if (member == null || member.Agent == null) yield break;
            
            var agent = member.Agent;
            float timeout = 30f;
            float elapsed = 0f;
            float stuckCheckInterval = 1f;
            float lastStuckCheck = 0f;
            Vector3 lastCheckPos = member.transform.position;
            
            while (elapsed < timeout && member != null && agent != null && agent.isOnNavMesh)
            {
                // ✅ Verificar si está "atascado" (no se ha movido en 1 segundo)
                if (elapsed - lastStuckCheck >= stuckCheckInterval)
                {
                    float movedDistance = Vector3.Distance(member.transform.position, lastCheckPos);
                    if (movedDistance < 0.1f && !agent.pathPending)
                    {
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.LogWarning($"[Lifecycle] ⚠️ Miembro {member.name} parece estar atascado (movido {movedDistance:F3}m en {stuckCheckInterval}s)");
                        #endif
                        
                        // Intentar reconfigurar el agent
                        Vector3 currentDest = agent.destination;
                        agent.isStopped = true;
                        yield return new WaitForSeconds(0.1f);
                        agent.isStopped = false;
                        agent.SetDestination(currentDest);
                        
                        #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                        Debug.Log($"[Lifecycle] 🔄 Miembro {member.name} reconfigurado - Velocity: {agent.velocity.magnitude:F2}");
                        #endif
                    }
                    
                    lastStuckCheck = elapsed;
                    lastCheckPos = member.transform.position;
                }
                
                // ✅ Actualizar animación CADA FRAME
                var animator = member.GetComponent<NPCSimpleAnimator>();
                if (animator != null)
                {
                    float agentSpeed = agent.velocity.magnitude;
                    
                    // ✅ Log si velocity es 0 pero debería moverse
                    if (agentSpeed < 0.01f && !agent.pathPending && agent.remainingDistance > agent.stoppingDistance + 0.5f)
                    {
                        if (Time.frameCount % 60 == 0) // Cada 60 frames
                        {
                            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                            Debug.LogWarning($"[Lifecycle] ⚠️ Miembro {member.name} velocity = 0 pero debería moverse!\n" +
                                           $"  remainingDistance: {agent.remainingDistance:F2}\n" +
                                           $"  stoppingDistance: {agent.stoppingDistance:F2}\n" +
                                           $"  isStopped: {agent.isStopped}\n" +
                                           $"  pathPending: {agent.pathPending}\n" +
                                           $"  path.status: {agent.path.status}");
                            #endif
                        }
                    }
                    
                    if (agentSpeed > 0.01f)
                    {
                        // Calcular velocidad normalizada
                        float maxSpeed = Mathf.Max(agent.speed, 0.1f);
                        float normalizedSpeed = Mathf.Clamp01(agentSpeed / maxSpeed);
                        
                        // Aplicar velocidad más lenta (derrotado)
                        animator.SetMovementSpeed(normalizedSpeed * 0.5f, 0.1f);
                        
                        // Rotar hacia la dirección del movimiento
                        Vector3 moveDir = agent.velocity.normalized;
                        moveDir.y = 0f;
                        if (moveDir.sqrMagnitude > 0.01f)
                        {
                            animator.FaceDirection(moveDir);
                        }
                    }
                    else
                    {
                        // Si no se está moviendo, velocidad 0
                        animator.SetMovementSpeed(0f, 0.1f);
                    }
                }
                
                // Verificar si llegó
                if (!agent.pathPending && agent.remainingDistance <= agent.stoppingDistance + 0.1f)
                {
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] ✅ Miembro {member.name} llegó a su destino (elapsed: {elapsed:F1}s)");
                    #endif
                    break;
                }
                
                elapsed += Time.deltaTime;
                yield return null;
            }
            
            if (elapsed >= timeout)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[Lifecycle] ⏱️ Miembro {member.name} timeout alcanzado ({timeout}s)");
                #endif
            }
            
            // Detener movimiento y restaurar configuración
            if (member != null && agent != null)
            {
                agent.isStopped = true;
                agent.speed = originalSpeed;
                agent.updateRotation = originalUpdateRotation;
                
                var animator = member.GetComponent<NPCSimpleAnimator>();
                if (animator != null)
                {
                    animator.SetMovementSpeed(0f, 0.1f);
                    animator.TransitionToIdle();
                }
                
                // ¿Desaparecer al llegar?
                if (config != null && config.disappearOnArrival)
                {
                    if (releaseExternalMovementOverride)
                    {
                        member.PopExternalMovementOverride();
                        releaseExternalMovementOverride = false;
                    }

                    if (config.disappearOnArrivalVFX != null)
                    {
                        VfxPoolService.Instance.Play(config.disappearOnArrivalVFX, member.transform.position + Vector3.up, Quaternion.identity, 3f);
                    }
                    
                    yield return new WaitForSeconds(0.5f);
                    member.gameObject.SetActive(false);
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] 👋 Miembro {member.name} desapareció al llegar a destino");
                    #endif
                }
                else
                {
                    // Configurar como interactuable
                    var memberHandler = member.GetComponent<NPCCombatLifecycleHandler>();
                    if (memberHandler != null)
                    {
                        memberHandler.SetupPostCombatInteraction();
                    }
                    #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Lifecycle] ✅ Miembro {member.name} configurado como interactuable en destino");
                    #endif
                }
            }

            if (releaseExternalMovementOverride && member != null)
            {
                member.PopExternalMovementOverride();
            }
        }

        private bool TryResolveReachableDestination(NavMeshAgent agent, Vector3 targetPos, out Vector3 resolvedPos)
        {
            resolvedPos = targetPos;
            NavMeshPath path = new NavMeshPath();
            
            if (agent.CalculatePath(targetPos, path))
            {
                if (path.status == NavMeshPathStatus.PathComplete)
                {
                    resolvedPos = targetPos;
                    return true;
                }
                
                if (path.status == NavMeshPathStatus.PathPartial && path.corners.Length > 0)
                {
                    resolvedPos = path.corners[path.corners.Length - 1];
                    return true;
                }
            }
            
            return false;
        }

        private Transform ResolveAnchorTransform(string anchorIdOrName)
        {
            if (string.IsNullOrWhiteSpace(anchorIdOrName))
                return null;

            var spawnAnchor = SpawnAnchor.FindById(anchorIdOrName);
            if (spawnAnchor != null)
                return spawnAnchor.transform;

            var anchorGo = GameObject.Find(anchorIdOrName);
            return anchorGo != null ? anchorGo.transform : null;
        }

        private IEnumerator RunDialogueRoutine(DialogueAsset dialogue)
        {
            bool finished = false;
            DialogueManager.Instance.StartDialogue(dialogue, transform, () => finished = true);
            while (!finished) yield return null;
        }

        // =================================================================================
        // 🛠️ HELPER: Configurar NPC como interactuable tras combate
        // =================================================================================
        
        public void SetupPostCombatInteraction()
        {
            // 1. Cambiar Layer
            int layer = LayerMask.NameToLayer("Interactable");
            if (layer != -1) gameObject.layer = layer;

            // 2. Activar Trigger
            var col = GetComponent<CapsuleCollider>();
            if (col) { col.enabled = true; col.isTrigger = true; }

            // Damageable.Die deja el Rigidbody sin detección de colisiones: sin ella el detector
            // de interacción no encuentra al NPC y no sale el botón A. Sigue cinemático para que
            // el trigger no lo deje caer. Ver INC-963.
            var rb = GetComponent<Rigidbody>();
            if (rb) rb.detectCollisions = true;

            // 3. Configurar Componente Interactable
            var interactable = GetComponent<Interactable>();
            if (!interactable) interactable = gameObject.AddComponent<Interactable>();
            
            interactable.enabled = true;
            
            // Asignar diálogo "Post-Derrota" (ej: "¿Qué quieres ahora?")
            if (_config?.dialogueAfterDefeat != null)
            {
                interactable.SetDialogue(_config.dialogueAfterDefeat);
                interactable.SetMode(InteractableMode.OpenDialogue);
            }
            
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] ✅ NPC {name} configurado como interactuable post-combate.");
            #endif
        }
        
        // =================================================================================
        // 🎭 POST-DEFEAT INTERACTION HANDLING
        // =================================================================================
        
        /// <summary>
        /// Maneja la interacción con el NPC después de haber sido derrotado.
        /// Retorna true si la interacción fue procesada.
        /// </summary>
        public bool HandlePostDefeatInteraction(GameObject interactor)
        {
            if (!IsDefeatedAndInactive)
                return false;
            
            // Si tiene diálogo post-derrota configurado, el sistema de Interactable lo manejará
            // Este método existe principalmente para validación y lógica adicional
            
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] 💬 Jugador interactúa con NPC derrotado: {name}");
            #endif
            
            // El Interactable component ya maneja el diálogo automáticamente
            // Solo retornamos true para indicar que la interacción es válida
            return true;
        }
        
        // =================================================================================
        // 🔄 RESURRECTION (Para sistema de equipos)
        // =================================================================================
        
        /// <summary>
        /// Resucita al NPC, restaurando su vida y estado.
        /// Usado por el sistema de equipos de combate (NPCCombatTeam).
        /// </summary>
        public void Resurrect()
        {
            if (!IsDefeatedAndInactive)
            {
                #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[Lifecycle] ⚠️ {name} no está derrotado, no se puede resucitar");
                #endif
                return;
            }
            
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] 🔄 Resucitando {name}...");
            #endif
            
            // 1. Restaurar vida, colisionador y Rigidbody (Heal no hace nada sobre un Damageable
            // muerto, y Die le apagó el colisionador y la detección de colisiones). Ver INC-963.
            if (_damageable != null)
            {
                _damageable.Revive(_damageable.Max);
            }
            
            // 2. Restaurar estado
            IsDefeatedAndInactive = false;
            _isProcessingDefeat = false;
            IsStunned = false;
            _isInvulnerable = false;
            
            // 3. Reactivar NavMeshAgent
            if (_agent != null)
            {
                _agent.enabled = true;
                if (_agent.isOnNavMesh)
                {
                    _agent.isStopped = false;
                }
            }
            
            // 4. Reproducir animación de levantarse (usar Victory como "levantarse feliz")
            if (_animator != null)
            {
                _animator.PlayVictory(); // Usamos Victory como animación de levantarse
            }
            
            // 5. Restaurar layer y collider
            int defaultLayer = LayerMask.NameToLayer("Default");
            if (defaultLayer != -1) gameObject.layer = defaultLayer;
            
            var col = GetComponent<CapsuleCollider>();
            if (col != null)
            {
                col.isTrigger = false;
            }
            
            // 6. Notificar al manager
            if (_manager != null && _manager.Context != null)
            {
                _manager.Context.WasDefeatedInCombat = false;
            }
            
            #if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Lifecycle] ✅ {name} resucitado exitosamente");
            #endif
        }
    }
}