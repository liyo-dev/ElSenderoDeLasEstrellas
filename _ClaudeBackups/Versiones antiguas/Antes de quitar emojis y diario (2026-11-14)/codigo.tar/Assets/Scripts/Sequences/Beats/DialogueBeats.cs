using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Beats de habla: bocadillo paginado por tiempo y diálogo normal de avance manual.

/// Un bocadillo sobre la cabeza de un actor, paginado por tiempo.
///
/// El texto se parte por saltos de línea: cada línea es una página. Para el ritmo de la escena es
/// preferible a un diálogo normal — no obliga al jugador a pulsar nada — así que es lo que se usa
/// para casi todo menos para contenido que el jugador deba poder leer con calma (ver DialogueBeat).
///
/// Sobre los gestos: el gesto específico ('gesture') se reproduce las primeras 'gestureRepeats'
/// veces y después el actor pasa a variaciones genéricas de hablar (Talk01/02/03), para que no se
/// quede repitiendo "enfadado" en bucle durante todo el párrafo ni congelado en una pose. Subir
/// 'gestureRepeats' a 2 sirve, por ejemplo, para un saludo al principio de una escena, cuando el
/// primer ciclo se pierde con la transición de entrada y apenas se ve.
[Serializable]
public class ExpresionDuranteLinea
{
    [Range(0f, 1f), Tooltip("Progreso aproximado de voz o lectura, ponderado por caracteres de las p?ginas.")]
    public float progreso;
    public EmotionBeat expresion = new();
}

[Serializable]
public class SayBeat : SequenceBeat
{
    [Tooltip("Presentación de esta línea; heredar usa el estilo de la secuencia.")]
    public PresentacionDeLinea presentacion = PresentacionDeLinea.HeredarDeLaSecuencia;
    [Tooltip("Color del nombre del hablante. Alpha cero usa el color por defecto.")]
    public Color colorDelNombre;
    [Tooltip("Cambios faciales durante la l?nea, sin gestos ni interrupciones de poses.")]
    public List<ExpresionDuranteLinea> expresiones = new();

    [Tooltip("IDs de los actores que escuchan; vacío mantiene el montaje existente.")]
    public List<string> oyentes = new();
    public ReaccionDeOyente reaccionDeOyentes = ReaccionDeOyente.Automatica;

    [Tooltip("Quién habla: 'Player' para Will, o el Persistence ID del NPC. Vacío = usar " +
             "'markName' en su lugar (una voz sin personaje visible, ver más abajo).")]
    public string actorId;

    [Tooltip("Si 'actorId' está vacío, el bocadillo sale anclado a esta marca de posición del " +
             "SequenceStage en vez de a un actor — para una voz que viene de fuera de plano " +
             "(alguien tras una ventana, algo que habla sin personaje en escena). Añadido para " +
             "SEQ_DiscusionVentana (17 sep 2026): dos voces discutiendo que Will oye desde la " +
             "cama, sin que haga falta tener ya colocados los NPCs que discuten. Una marca no " +
             "anima nada — sin gestos, sin pose de conversación.")]
    public string markName;

    [Tooltip("Voz de alguien que no está en el plano (solo hablando desde 'markName'): sale en " +
             "bocadillo aunque la cinemática esté en modo cine, anclado a la marca, sin cola, con " +
             "su nombre encima, un vaivén suave y, si hay 'retrato', la cara en un medallón. Siempre " +
             "dentro de la imagen, entre las bandas de cine. Es la única excepción al " +
             "subtítulo en las cinemáticas.")]
    public bool fueraDeEscena;

    [Tooltip("Cara de quien habla para el medallón de 'fueraDeEscena'. Vacío = sin medallón, solo el nombre.")]
    public Sprite retrato;

    [Tooltip("Clave de localización del texto. Los saltos de línea dentro del texto separan páginas.")]
    public string textKey;

    [Tooltip("Clave de voz opcional si no coincide con textKey. Vacío usa la propia clave del texto.")]
    public string voiceKey;

    [Tooltip("Segundos que dura cada página en pantalla. Se ignora si la línea tiene voz.")]
    public float pageDuration = 2.6f;

    [Tooltip("Gesto específico de esta frase (p. ej. 'Cheer02', 'Angry01'). Vacío = solo " +
             "actuación automática según el texto. Se ignora si se habla desde una marca ('markName'): " +
             "una marca no tiene animator que mover.")]
    public string gesture;

    [Tooltip("Cuántas veces se reproduce el gesto específico antes de pasar a las variaciones de " +
             "hablar. 1 es lo normal; 2 para que un gesto corto se lea bien al principio de una escena.")]
    public int gestureRepeats = 1;

    [Tooltip("Clave de localización del nombre del hablante, si el bocadillo debe mostrarlo. Vacío = sin nombre.")]
    public string speakerNameKey;

    [Tooltip("Desmárcalo cuando el personaje está haciendo otra cosa mientras habla (corriendo, " +
             "huyendo, peleando): solo sale el bocadillo, sin pose de conversación ni gestos. " +
             "Los gestos viven en la capa de tronco superior, así que encima de una carrera " +
             "producen posturas rotas — el clásico 'parece que se va a partir el cuello'. Sin " +
             "efecto si se habla desde una marca: ahí nunca hay gestos, con o sin marcar esto.")]
    public bool playGestures = true;

    [Tooltip("Sube o baja el punto sobre el que aparece el bocadillo respecto al offset de " +
             "siempre (2,2 m hacia arriba, pensado para la cabeza de un personaje). Pensado sobre " +
             "todo para 'markName': coloca la marca donde de verdad quieres el bocadillo y pon " +
             "aquí (0,0,0) en vez de tener que enterrar la marca 2,2 m bajo el suelo para " +
             "compensar.")]
    public bool overrideBubbleOffset = false;

    [Tooltip("Offset a aplicar cuando 'overrideBubbleOffset' está marcado.")]
    public Vector3 bubbleOffset = Vector3.zero;

    /// Cada cuántos segundos se relanza un gesto DENTRO de una misma página, para que el actor no
    /// se quede en una pose estática mientras el bocadillo sigue en pantalla.
    private const float TalkRetriggerInterval = 1.6f;

    private static readonly string[] TalkVariations = { "Talk01", "Talk02", "Talk03" };

    public override string Describe()
        => $"Dice: {(string.IsNullOrEmpty(actorId) ? $"({(fueraDeEscena ? "fuera de escena" : "marca")}) {markName}" : actorId)} → {textKey}"
           + (!string.IsNullOrEmpty(actorId) && playGestures
               ? (string.IsNullOrEmpty(gesture) ? "" : $" ({gesture}×{gestureRepeats})")
               : " (sin gestos)");

    public override IEnumerator Run(SequenceContext ctx)
    {
        // 'actorId' resuelve un actor de verdad (con animator); 'markName' resuelve solo un punto
        // del escenario — una voz sin personaje visible, como los dos que discuten al otro lado de
        // la ventana en SEQ_DiscusionVentana. 'animar' queda en false en ese segundo caso: no hay
        // nada que gesticular.
        Transform anchor;
        SequenceActor actor = null;

        if (!string.IsNullOrEmpty(actorId))
        {
            actor = ctx.GetActor(actorId);
            if (actor?.Transform == null) yield break;
            anchor = actor.Transform;
        }
        else
        {
            var mark = ctx.Stage != null ? ctx.Stage.GetMark(markName) : null;
            if (mark == null) yield break; // el aviso ya lo ha dado el stage
            anchor = mark;
        }

        if (SpeechBubbleUI.Instance == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[SayBeat] SpeechBubbleUI.Instance es null — no hay bocadillo que mostrar. " +
                "¿Arrancaste la escena desde Start.unity?");
#endif
            yield break;
        }

        string text = PresentadorDeLinea.Texto(textKey);
        string speakerName = PresentadorDeLinea.NombreDelHablante(speakerNameKey);

        bool animar = playGestures && actor != null;
        ActuacionAutomatica.Memoria(actor, out string anteriorActor, out string anteriorHablante);
        string[] gestosAutomaticos = animar && string.IsNullOrEmpty(gesture) ? ActuacionAutomatica.Preparar(text) : null;
        var escuchas = new List<EscuchaDuranteLinea>();
        EscuchaDuranteLinea miradaDelHablante = null;
        if (actor != null)
        {
            var listaOyentes = new List<SequenceActor>();
            if (oyentes != null && oyentes.Count > 0)
            {
                foreach (string id in oyentes)
                {
                    if (string.IsNullOrEmpty(id) || id == actorId) continue;
                    var oyente = ctx.GetActor(id);
                    if (oyente != null && !listaOyentes.Contains(oyente)) listaOyentes.Add(oyente);
                }
            }
            else
            {
                // Auto-detectar actores de la secuencia en rango de conversación (< 15 m)
                if (ctx.Actores != null)
                {
                    foreach (var act in ctx.Actores)
                    {
                        if (act == null || act == actor || act.Transform == null || !act.PuedeEscuchar) continue;
                        if (Vector3.Distance(act.Transform.position, actor.Transform.position) < 15f)
                            if (!listaOyentes.Contains(act)) listaOyentes.Add(act);
                    }
                }
            }

            if (listaOyentes.Count > 0)
            {
                string reaccion = ActuacionAutomatica.Reaccion(text, reaccionDeOyentes, ctx.AnimoVigente);
                NPCEmotion caraReaccion = ActuacionAutomatica.ReaccionCara(text, NPCEmotion.None, ctx.AnimoVigente);
                foreach (var oyente in listaOyentes)
                {
                    if (oyente == null || escuchas.Exists(e => e.Actor == oyente)) continue;
                    var escucha = new EscuchaDuranteLinea(oyente, actor, reaccion, caraReaccion, ctx, girar: true);
                    escuchas.Add(escucha);
                    ctx.Player?.RegisterCleanup(escucha.Cerrar);
                    if (miradaDelHablante == null && oyente.PuedeEscuchar && actor.PuedeEscuchar)
                    {
                        miradaDelHablante = new EscuchaDuranteLinea(actor, oyente, null, NPCEmotion.None, ctx, girar: false);
                        ctx.Player?.RegisterCleanup(miradaDelHablante.Cerrar);
                    }
                }
            }
        }

        // Mantener al actor en su pose de interacción durante toda la frase: si no, entre gesto y
        // gesto cae a Idle de pie y se le ve "parado sin hablar" a mitad de la línea.
        // Con playGestures desmarcado (o hablando desde una marca) NO se entra en modo interacción:
        // esa pose es la de alguien plantado conversando, y encima de un personaje que corre da el
        // andar ortopédico de siempre; una marca directamente no tiene nada que poner en esa pose.
        if (animar)
        {
            actor.BeginInteraction();
            actor.SetTalking(true);
        }
        ctx.MarcarHabla(actor, true);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        InformeDeRodaje.Linea(actorId, textKey);
#endif
        bool hablaCerrada = false;
        Action cerrarHabla = () =>
        {
            if (hablaCerrada) return;
            hablaCerrada = true;
            if (anchor != null) SenalesDeHabla.Para(anchor);
            ctx.MarcarHabla(actor, false);
            actor?.Emotion?.VolverAReposo();
            foreach (var escucha in escuchas) escucha.Cerrar();
            miradaDelHablante?.Cerrar();
            if (animar) { actor.SetTalking(false); actor.EndInteraction(); }
        };
        ctx.Player?.RegisterCleanup(cerrarHabla);

        int specificFired = 0;
        int talkIndex = 0;
        // Dónde se apoya el bocadillo. Un actor de carne y hueso se mide (su transform está en
        // los pies) y el bocadillo se le pega a lo alto de la cabeza. Una marca ya está colocada
        // a la altura de la cabeza, así que solo lleva el hueco de la cola: sumarle el offset de
        // los pies la mandaba muy por encima del personaje (VentanaIzq, en la discusión de las
        // cajas, acababa pegada al borde superior de la pantalla).
        const float HuecoSobreLaCabeza = 0.05f;
        Vector3? offsetOverride;
        if (overrideBubbleOffset) offsetOverride = bubbleOffset;
        else if (actor != null) offsetOverride = new Vector3(0f, actor.HeadTopHeight + HuecoSobreLaCabeza, 0f);
        else offsetOverride = new Vector3(0f, HuecoSobreLaCabeza, 0f);

        // Páginas: los saltos de línea del texto, y además ninguna de más de tres líneas en el
        // bocadillo (INC-435): SpeechBubbleUI las mide con la fuente y el ancho de verdad. Cada
        // página dura lo que pide el beat, pero nunca menos de lo que se tarda en leerla.
        var bubble = SpeechBubbleUI.Instance;
        int turnoDelBocadillo = 0;
        ctx.Player?.RegisterCleanup(() => { if (bubble != null) bubble.Hide(turnoDelBocadillo); });
        // La voz fuera de escena solo vale sin actor: quien está en el plano habla en modo cine.
        bool vozFuera = fueraDeEscena && actor == null;
        var estilo = vozFuera ? PresentacionDeTexto.Bocadillo : presentacion.Resolver(
            ctx.Player?.Definition != null ? ctx.Player.Definition.presentacionDeTexto : PresentacionDeTexto.Subtitulo);
        var pages = new System.Collections.Generic.List<string>();
        foreach (string raw in text.Split('\n'))
        {
            string trozo = raw.Trim();
            if (!string.IsNullOrEmpty(trozo)) pages.AddRange(bubble.Paginar(trozo, estilo));
        }

        string resolvedVoiceKey = string.IsNullOrWhiteSpace(voiceKey) ? textKey : voiceKey;
        bool hasVoice = PresentadorDeLinea.Voz(resolvedVoiceKey, out AudioClip voiceClip);
        int totalCharacters = 0;
        foreach (string page in pages) totalCharacters += page.Length;
        bool[] expresionesAplicadas = expresiones != null ? new bool[expresiones.Count] : null;
        int caracteresLeidos = 0;

        bool voiceStarted = false;
        bool voiceClosed = false;
        AudioService voiceService = null;
        Action stopVoice = () =>
        {
            if (voiceClosed) return;
            voiceClosed = true;
            if (voiceService != null && voiceService.IsVoicePlaying(voiceClip))
                voiceService.StopVoice();
        };

        int pageIndex = 0;
        foreach (string page in pages)
        {
            if (string.IsNullOrEmpty(page)) continue;

            bool done = false;
            string trigger = animar && !actor.SosteniendoPose
                ? NextGesture(actor, gestosAutomaticos, anteriorActor, anteriorHablante, ref specificFired, ref talkIndex) : null;
            float duracion = Mathf.Max(pageDuration, bubble.TiempoDeLectura(page));
            if (hasVoice)
            {
                float proportionalDuration = totalCharacters > 0
                    ? voiceClip.length * ((float)page.Length / totalCharacters) : 0f;
                duracion = Mathf.Max(bubble.TiempoDeLectura(page), proportionalDuration);
                if (pageIndex == pages.Count - 1) duracion += 0.3f;
            }

            if (anchor != null) SenalesDeHabla.Empieza(anchor, duracion);
            AplicarExpresiones(ctx, totalCharacters > 0 ? (float)caracteresLeidos / totalCharacters : 0f, expresionesAplicadas);
            turnoDelBocadillo = PresentadorDeLinea.Mostrar(anchor, page, duracion, estilo,
                speakerName, colorDelNombre, offsetOverride, () => done = true, trigger,
                fueraDeEscena: vozFuera, retrato: vozFuera ? retrato : null);

            if (hasVoice && !voiceStarted)
            {
                voiceStarted = true;
                voiceService = AudioService.Instance;
                ctx.Player?.RegisterCleanup(stopVoice);
                voiceService?.PlayVoice(voiceClip);
            }
            pageIndex++;

            // Tope de seguridad (auditoría 17 sep 2026). SpeechBubbleUI.Show() y Hide() matan el
            // temporizador del bocadillo anterior SIN llamar a su callback, así que dos bocadillos
            // solapados dejan al primero esperando un aviso que no va a llegar nunca — y esta
            // espera no tenía salida. El resultado sería la secuencia colgada para siempre, con el
            // input bloqueado y el HUD oculto: un cuelgue total del que no se sale jugando.
            //
            // Y solapar dos bocadillos es fácil de hacer sin querer: basta con meter dos beats de
            // hablar en el mismo Parallel, que es algo que el propio catálogo anima a hacer.
            float limite = duracion + 2f;
            float esperado = 0f;
            float sinceRetrigger = 0f;

            while (!done && esperado < limite)
            {
                yield return null;
                esperado += Time.unscaledDeltaTime;
                sinceRetrigger += Time.deltaTime;
                float progreso = totalCharacters > 0
                    ? (caracteresLeidos + page.Length * Mathf.Clamp01(esperado / duracion)) / totalCharacters : 1f;
                AplicarExpresiones(ctx, progreso, expresionesAplicadas);
                foreach (var escucha in escuchas) escucha.Actualizar(progreso);
                miradaDelHablante?.Actualizar(progreso);
                // Un gesto nuevo cada 1,6 s mientras dura el bocadillo, para que no se quede
                // parado a mitad de la frase. PERO nunca por encima de una pose sostenida: esa es
                // una decisión del montaje y pisarla es un fallo, no una animación.
                //
                // El caso que lo hace obligatorio: «Protección Absoluta» se dice EN EL AIRE, con
                // el Archimago sosteniendo la pose de salto. Sin esta guarda, a los 1,6 s de
                // frase le entra un gesto de charla y se le cae la pose en pleno vuelo.
                if (animar && !actor.SosteniendoPose && sinceRetrigger >= TalkRetriggerInterval)
                {
                    sinceRetrigger = 0f;
                    actor.PlayGesture(NextGesture(actor, gestosAutomaticos, anteriorActor, anteriorHablante, ref specificFired, ref talkIndex));
                }
            }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            if (!done)
                Debug.LogWarning($"[SayBeat] El bocadillo de '{(string.IsNullOrEmpty(actorId) ? markName : actorId)}' " +
                    $"({textKey}) no avisó de que había terminado y se ha seguido adelante por el tope de " +
                    "seguridad. Lo normal es que otro bocadillo lo haya pisado: mira si hay dos beats de " +
                    "hablar a la vez.");
#endif
            if (anchor != null) SenalesDeHabla.Para(anchor);
            caracteresLeidos += page.Length;
        }

        if (voiceStarted) stopVoice();

        foreach (var escucha in escuchas) escucha.Actualizar(1f);
        cerrarHabla();
    }

    private void AplicarExpresiones(SequenceContext ctx, float progreso, bool[] aplicadas)
    {
        if (aplicadas == null) return;
        for (int i = 0; i < expresiones.Count; i++)
        {
            var marca = expresiones[i];
            if (aplicadas[i] || marca == null || marca.expresion == null || progreso < marca.progreso) continue;
            aplicadas[i] = true;
            marca.expresion.Aplicar(ctx);
        }
    }

    /// Devuelve el gesto que toca: el específico mientras queden repeticiones, y a partir de ahí
    /// las variaciones genéricas de hablar, rotando.
    private string NextGesture(SequenceActor actor, string[] automaticos, string anteriorActor, string anteriorHablante,
        ref int specificFired, ref int talkIndex)
    {
        if (string.IsNullOrEmpty(gesture))
            return ActuacionAutomatica.Elegir(actor, automaticos, talkIndex++, anteriorActor, anteriorHablante);
        if (!string.IsNullOrEmpty(gesture) && specificFired < Mathf.Max(1, gestureRepeats))
        {
            specificFired++;
            ActuacionAutomatica.RecordarExplicito(actor, gesture);
            return gesture;
        }

        string chosen = TalkVariations[talkIndex % TalkVariations.Length];
        talkIndex++;
        ActuacionAutomatica.RecordarExplicito(actor, chosen);
        return chosen;
    }

    /// Control temporal de giro, mirada y reacción, con cierre idempotente para el salto.
    private sealed class EscuchaDuranteLinea
    {
        public SequenceActor Actor { get; }
        private readonly SequenceActor _objetivo;
        private string _reaccion;
        private readonly NPCEmotion _caraReaccion;
        private readonly SequenceContext _contexto;
        private readonly bool _girar;
        private IEnumerator _giro;
        private DialogueHeadLook _mirada;
        private Transform _objetivoAnterior;
        private bool _iniciada, _cerrada, _reaccionHecha;

        public EscuchaDuranteLinea(SequenceActor actor, SequenceActor objetivo, string reaccion, NPCEmotion caraReaccion, SequenceContext contexto, bool girar)
        { Actor = actor; _objetivo = objetivo; _reaccion = reaccion; _caraReaccion = caraReaccion; _contexto = contexto; _girar = girar; }

        public void Actualizar(float progreso)
        {
            if (_cerrada) return;
            if (!Actor.PuedeEscuchar || _objetivo.Transform == null) { Cerrar(); return; }
            if (!_iniciada)
            {
                _iniciada = true;
                if (_girar) _giro = Actor.GirarSuavemente(_objetivo.Transform.position, 0.45f);
                _mirada = Actor.Transform.GetComponent<DialogueHeadLook>();
                if (_mirada == null) _mirada = Actor.Transform.gameObject.AddComponent<DialogueHeadLook>();
                _objetivoAnterior = _mirada.Target;
                _mirada.SetTarget(_objetivo.Transform);
            }
            if (_giro != null && !_giro.MoveNext()) _giro = null;
            if (!_reaccionHecha && progreso >= 0.4f)
            {
                _reaccionHecha = true;
                if (!_contexto.PuedeReaccionar(Actor)) return;
                var animo = _contexto.AnimoVigente;
                if (animo == AnimoDeAccion.Amenaza || animo == AnimoDeAccion.Miedo ||
                    animo == AnimoDeAccion.Triste || animo == AnimoDeAccion.Enfado || animo == AnimoDeAccion.Sorpresa)
                    _reaccion = ReaccionesDeEscena.ElegirGesto(Actor, animo);
                if (!string.IsNullOrEmpty(_reaccion) && Actor.TieneEstado(_reaccion)) Actor.PlayGesture(_reaccion);
                if (_caraReaccion != NPCEmotion.None && Actor.Emotion != null) Actor.Emotion.Reaccionar(_caraReaccion);
            }
        }

        public void Cerrar()
        {
            if (_cerrada) return;
            _cerrada = true;
            (_giro as IDisposable)?.Dispose();
            _giro = null;
            if (_iniciada) Actor.SyncRotation();
            if (_mirada != null && _mirada.Target == _objetivo.Transform) _mirada.SetTarget(_objetivoAnterior);
            // Solo libera nuestra reacción; una acción posterior conserva su control.
            var animador = Actor.AnimadorDeActuacion;
            if (_reaccionHecha && !string.IsNullOrEmpty(_reaccion) && Actor.PuedeEscuchar && animador != null)
            {
                int capa = AnimatorLayerUtil.ResolveLayer(animador, _reaccion, animador.GetLayerIndex("UpperBody"));
                if (capa >= 0 && (animador.GetCurrentAnimatorStateInfo(capa).IsName(_reaccion) ||
                    (animador.IsInTransition(capa) && animador.GetNextAnimatorStateInfo(capa).IsName(_reaccion))))
                    Actor.ReturnToNormalPose();
            }
        }
    }
}

/// Un diálogo normal, con el componente de siempre (DialogueManager): avance manual, doblaje,
/// retratos.
///
/// Se usa cuando el jugador tiene que poder leer con calma — típicamente contenido que enseña a
/// jugar — en vez de que las frases pasen solas por tiempo. La secuencia se queda esperando hasta
/// que el diálogo termina; dentro de un guion, con 'detenerEscena' el reloj del guion también.
///
/// Desde un guion, las reacciones se escriben por actor: «reacciones_will=HeadNod01,Question01,-»
/// (gestos línea a línea, «-» = ninguno) y «caras_will=alegre,-,sorpresa».
[Serializable]
public class DialogueBeat : SequenceBeat, IConfigurableDesdeGuion
{
    [Tooltip("El DialogueAsset a reproducir.")]
    public DialogueAsset dialogue;

    [Tooltip("Sobre qué actor se ancla el diálogo (normalmente el NPC que habla).")]
    public string actorId;

    [Tooltip("Al terminar, apagar YA la cámara del diálogo en vez de esperar su período de gracia " +
             "(0,5 s, pensado para detectar diálogos encadenados). Dentro de una secuencia no hay " +
             "encadenamiento que detectar, y esperar deja la cámara del diálogo congelada en su " +
             "último encuadre medio segundo más — que es de donde salía el plano de la cabeza del " +
             "oyente al final. Desmarcar solo si de verdad se encadena otro diálogo justo después.")]
    public bool endDialogueCameraImmediately = true;

    [Tooltip("Marcado, el diálogo se ve con el plano que ya tenía la secuencia: no enciende la " +
             "cámara de diálogo (la que va de primer plano en primer plano). Para escenas en las " +
             "que se quiere ver a los dos personajes a la vez todo el rato.")]
    public bool conservarCamaraDeLaSecuencia = false;

    [Tooltip("Cómo reaccionan los que ESCUCHAN, línea a línea. DialogueManager solo anima al que " +
             "habla; sin esto, el otro personaje se queda en idle durante todo el diálogo.")]
    public List<DialogueReaction> reactions = new();

    [Tooltip("Dentro de un guion: la escena se detiene mientras el diálogo está abierto (el reloj " +
             "del guion no avanza hasta que el jugador lo cierra).")]
    public bool detenerEscena = false;

    public bool Configurar(string clave, string valor, Func<string, string> idDeActor)
    {
        bool gestos = clave.StartsWith("reacciones_", StringComparison.Ordinal);
        bool caras = clave.StartsWith("caras_", StringComparison.Ordinal);
        if (!gestos && !caras) return false;

        string alias = clave.Substring(clave.IndexOf('_') + 1);
        string id = idDeActor != null ? idDeActor(alias) : alias;
        reactions ??= new List<DialogueReaction>();
        var reaccion = reactions.Find(r => r != null && r.actorId == id);
        if (reaccion == null) reactions.Add(reaccion = new DialogueReaction { actorId = id });

        string[] partes = valor.Split(',');
        if (gestos)
        {
            reaccion.gestures = new string[partes.Length];
            for (int i = 0; i < partes.Length; i++)
                reaccion.gestures[i] = partes[i].Trim() == "-" ? string.Empty : partes[i].Trim();
        }
        else
        {
            reaccion.emotions = new NPCEmotion[partes.Length];
            for (int i = 0; i < partes.Length; i++)
                reaccion.emotions[i] = CarasDelGuion.Intentar(partes[i].Trim(), out var e) ? e : NPCEmotion.None;
        }
        return true;
    }

    public override string Describe()
        => $"Diálogo: {(dialogue != null ? dialogue.name : "SIN ASIGNAR")} con {actorId}"
           + (reactions != null && reactions.Count > 0 ? $" (+{reactions.Count} reaccionando)" : "");

    public override IEnumerator Run(SequenceContext ctx)
    {
        if (dialogue == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[DialogueBeat] Sin DialogueAsset asignado ({note}) — se salta este beat.");
#endif
            yield break;
        }

        if (DialogueManager.Instance == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[DialogueBeat] DialogueManager.Instance es null — se salta este beat.");
#endif
            yield break;
        }

        var actor = ctx.GetActor(actorId);
        Transform anchor = actor?.Transform;

        // Reacciones de los que escuchan. DialogueManager.ActivateSpeakerTalkAnimation() solo
        // anima al hablante de cada línea, así que el resto de personajes se quedan quietos durante
        // todo el diálogo. Enganchándonos a OnDialogueLineChanged podemos animar a los demás al
        // ritmo real de las líneas, sin tocar DialogueManager ni depender de tiempos fijos.
        int lineIndex = -1;
        System.Action<DialogueLine, Transform> onLine = (line, _) =>
        {
            lineIndex++;
            if (reactions == null) return;

            // Quién habla en ESTA línea, para no "reaccionar" sobre el que ya se está animando solo.
            string speakerId = line.isPlayerSpeaking ? SequenceActor.PlayerId : actorId;

            foreach (var reaction in reactions)
            {
                if (reaction == null || string.IsNullOrEmpty(reaction.actorId)) continue;
                if (reaction.actorId == speakerId) continue;

                var listener = ctx.GetActor(reaction.actorId);
                if (listener == null) continue;

                reaction.ApplyTo(listener, lineIndex);
            }
        };

        bool finished = false;
        DialogueManager.OnDialogueLineChanged += onLine;

        // OnDialogueLineChanged es ESTÁTICO, así que un handler olvidado sigue disparando el resto
        // de la partida: cada diálogo posterior aplicaría las reacciones de ESTA escena a quien
        // hablara, y además mantendría vivo el contexto entero de la secuencia. El finally de abajo
        // no basta, porque saltar la cinemática hace StopCoroutine sobre la corrutina principal y
        // eso NO ejecuta los finally de las anidadas (el proyecto lo documenta en tres sitios).
        // Registrándola en el reproductor, el cierre la ejecuta pase lo que pase.
        bool desuscrito = false;
        System.Action desuscribir = () =>
        {
            if (desuscrito) return;
            desuscrito = true;
            DialogueManager.OnDialogueLineChanged -= onLine;
        };
        ctx.Player?.RegisterCleanup(desuscribir);

        // El interruptor de la cámara es de DialogueManager, que es un singleton: se enciende
        // solo para este diálogo y se apaga pase lo que pase (también si se salta la cinemática,
        // que no ejecuta los finally de las corrutinas anidadas — por eso va también al cleanup).
        if (conservarCamaraDeLaSecuencia)
        {
            DialogueManager.Instance.ConservarCamaraDeSecuencia = true;
            ctx.Player?.RegisterCleanup(() =>
            {
                if (DialogueManager.Instance != null) DialogueManager.Instance.ConservarCamaraDeSecuencia = false;
            });
        }

        bool relojSoltado = !detenerEscena;
        System.Action soltarReloj = () =>
        {
            if (relojSoltado) return;
            relojSoltado = true;
            ctx.SoltarReloj();
        };
        if (detenerEscena)
        {
            ctx.RetenerReloj();
            ctx.Player?.RegisterCleanup(soltarReloj);
        }

        // La caja de diálogo es modo juego: la avanza el jugador, así que se ve sin bandas de cine.
        // Si la secuencia las tenía puestas, se retiran antes de abrir la caja y vuelven al cerrarla
        // para lo que quede de escena (si queda algo que ver). Ver INC-1141 e INC-1149.
        var bandas = BandasDeCineUI.Instance;
        float alturaDeBandas = bandas != null ? bandas.AlturaObjetivo : 0f;
        if (alturaDeBandas > 0f)
        {
            bandas.Mostrar(false, duracion: 0.25f);
            while (bandas != null && bandas.Animando) yield return null;
        }

        try
        {
            DialogueManager.Instance.StartDialogue(dialogue, anchor, () => finished = true,
                isSequenceDialogue: true);

            yield return new WaitUntil(() => finished);
        }
        finally
        {
            desuscribir();
            soltarReloj();

            if (conservarCamaraDeLaSecuencia && DialogueManager.Instance != null)
                DialogueManager.Instance.ConservarCamaraDeSecuencia = false;

            // FIX 16 sep 2026 (Raúl: "al acabar el diálogo del tutorial se ve el cabezón de Will",
            // y seguía viéndose tras el primer intento): devolver la cámara a la secuencia YA.
            //
            // DialogueManager llama a EndCinematic(), que NO apaga nada — espera
            // `chainDialogueGracePeriod` (0,5 s) por si viene otro diálogo encadenado, y durante ese
            // medio segundo la cámara de diálogo sigue activa y congelada en su último encuadre. El
            // primer intento de arreglarlo fue un corte de cámara más 0,4 s de margen, y falló por
            // dos motivos a la vez: 0,4 < 0,5, y el corte iba a NUESTRA cámara cinemática, que en
            // ese momento no es la que está pintando.
            //
            // Dentro de una secuencia no hay encadenamiento que detectar — el guion es nuestro — así
            // que se pide el apagado inmediato y recuperamos la cámara sin esperar.
            if (endDialogueCameraImmediately && !conservarCamaraDeLaSecuencia)
                DialogueCinematicController.Instance?.EndCinematicNow();
        }

        // Solo vuelven si queda escena que ver: si la secuencia acaba con esta caja, se pasa a jugar
        // sin bandas (antes volvían ~1,5 s y se iban otra vez). Ver INC-1149.
        if (alturaDeBandas > 0f && bandas != null && (ctx.Player == null || ctx.Player.QuedaAlgoQueVer()))
            bandas.Mostrar(true, alturaDeBandas, 0.25f);
    }
}

/// Cómo reacciona un personaje que ESCUCHA mientras otro habla, en un DialogueBeat.
///
/// Los gestos y las emociones se recorren en orden según avanzan las líneas, y vuelven a empezar
/// cuando se acaban: con dos gestos y siete líneas, alterna entre los dos. Dejar una de las dos
/// listas vacía significa "esa parte no cambia".
[System.Serializable]
public class DialogueReaction
{
    [Tooltip("Quién reacciona: 'Player' para Will, o el Persistence ID del NPC. Si coincide con " +
             "quien habla en esa línea, se ignora (a ese ya lo anima DialogueManager).")]
    public string actorId;

    [Tooltip("Gestos a ir soltando línea a línea (p. ej. HeadNod01, Question01). Vacío = sin gestos.")]
    public string[] gestures;

    [Tooltip("Caras a ir poniendo línea a línea. Vacío = no se toca la cara.")]
    public NPCEmotion[] emotions;

    /// Aplica la reacción que toca para el índice de línea dado.
    public void ApplyTo(SequenceActor listener, int lineIndex)
    {
        if (listener == null || lineIndex < 0) return;

        if (gestures != null && gestures.Length > 0)
            listener.PlayGesture(gestures[lineIndex % gestures.Length]);

        if (emotions != null && emotions.Length > 0)
            listener.Reaccionar(emotions[lineIndex % emotions.Length]);
    }
}
