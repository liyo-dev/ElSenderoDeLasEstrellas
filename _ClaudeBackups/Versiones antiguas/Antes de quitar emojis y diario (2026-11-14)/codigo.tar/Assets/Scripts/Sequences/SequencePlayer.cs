using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// Reproduce una SequenceDefinition. Es el único sequencer que hace falta escribir: cualquier
/// escena nueva es un asset de datos + este mismo componente, no una clase C# nueva.
///
/// Todo lo que hoy se copia de un sequencer a otro (y se rompe por el camino) vive aquí una sola
/// vez: el candado que saca a los NPCs de su comportamiento ambiental, el cierre limpio con
/// ResetMovement (INC-210), la restauración de los ajustes del NavMeshAgent, y el camino de skip.
/// Arreglar un bug en este archivo lo arregla para todas las secuencias futuras — que es la razón
/// de existir del sistema.
///
/// MONTAJE EN EL EDITOR (lo único que no se puede hacer por escrito):
///   1. Un GameObject propio en la escena — NUNCA dentro del prefab de un NPC (ver
///      incidencia-oliver-saludo-secuencia-en-prefab-trigger-prematuro-2026-09-15.md).
///   2. Asignar el asset de la secuencia (_definition) y el SequenceStage (_stage).
///   3. Asignar el CinematicCameraDriver y, si la escena lleva música propia, el AudioGraphProfile
///      — los dos son campos heredados de CinematicSequencerBase.
///   4. Colocar y nombrar los planos de cámara y las marcas en el SequenceStage.
/// A partir de ahí, el contenido de la escena se edita en el asset, sin tocar la escena ni recompilar.
[AddComponentMenu("Cinematics/Sequence Player")]
public class SequencePlayer : CinematicSequencerBase
{
    [Header("Secuencia")]
    [Tooltip("El asset que describe la escena: fases, beats, señales y música.")]
    [SerializeField] private SequenceDefinition _definition;

    [Tooltip("El escenario: planos de cámara y marcas de posición. Si se deja vacío, se busca un " +
             "SequenceStage en este mismo GameObject.")]
    [SerializeField] private SequenceStage _stage;

    [Header("Cierre")]
    [Tooltip("Segundos que los NPCs de la escena siguen retenidos DESPUÉS de que la pantalla haya " +
             "vuelto al gameplay, antes de devolverles su comportamiento ambiental. Sin este " +
             "margen, un NPC puede echarse a andar 1-3 segundos después de terminar una " +
             "conversación personal (su IdleState sortea ese tiempo antes de pasar a Wander), lo " +
             "que queda raro aunque sea comportamiento normal.")]
    [SerializeField] private float _idleGraceAfterSequence = 3.5f;

    /// El jugador ya ha vuelto a su pose normal al recuperar el control (antes de la gracia de los NPCs).
    private bool _jugadorDevuelto;

    [Tooltip("Duración del fundido que retira el negro al saltar la secuencia con el botón global " +
             "de skip. El cierre genérico de skip de la clase base deja la pantalla cubierta a " +
             "propósito (pensado para secuencias cuyo sistema siguiente gestiona su propio reveal); " +
             "estas secuencias no tienen sistema siguiente, así que revelan ellas.")]
    [SerializeField] private float _skipRevealDuration = 0.25f;

#if UNITY_EDITOR
    [Header("Pruebas (solo Editor)")]
    [Tooltip("Nombre de una fase por la que arrancar, saltándose las anteriores. Vacío = desde el " +
             "principio. Sirve para probar el final de una escena larga sin verla entera cada vez.")]
    [SerializeField] private string _startAtPhase;
#endif

    private SequenceContext _context;

    // Cámara del juego, cacheada: Camera.main hace una búsqueda por tag cada vez (CLAUDE.md § 2).
    private Camera _gameCamera;

    // Corrutinas de módulos lanzadas "de fondo" (ModuleBeat sin esperar). Se guardan para poder
    // pararlas al cerrar: una corrutina de mecánica que sobreviva a la secuencia sigue spawneando
    // cosas ya en pleno gameplay, que es el fallo que documenta Cleanup() del sequencer viejo.
    private readonly List<Coroutine> _backgroundRoutines = new();

    // Petición de terminar antes de tiempo (EndSequenceBeat), con la señal por la que salir.
    private bool _endRequested;
    private string _endSignalOverride;
    private SequenceEndScreen _endScreenOverride = SequenceEndScreen.ComoElAsset;

    // ¿Se ha levantado ya la señal de salida? Red de seguridad para el caso de que un beat reviente
    // a mitad: sin esto, una excepción devuelve el control al jugador pero deja al grafo narrativo
    // esperando un evento que no va a llegar nunca, y el capítulo no avanza sin ninguna pista.
    private bool _signalRaised;

    // Fase y beat que se están reproduciendo (-1: ninguno pendiente). Al saltar, lo que viene
    // detrás cumple lo suyo (CumplirLoQueQuedaba).
    private int _faseEnCurso = -1;
    private int _beatEnCurso = -1;

    // Las señales vienen del asset, no del Inspector: así una secuencia entera (contenido y
    // enganche con el grafo) se puede escribir como texto. Si el asset las deja vacías, se usan
    // las del Inspector heredadas de CinematicSequencerBase.
    /// Si una rama ya había decidido por dónde salir (un EndSequenceBeat con señal propia), saltar
    /// la secuencia debe salir por ahí y no por la señal general del asset. Si no, fallar el panic
    /// input y saltar acto seguido levantaría AWAKEN_DONE y desbloquearía la magia como si se
    /// hubiera acertado.
    protected override string SkipCompletionSignal => _endSignalOverride;

    protected override string SignalInOverride => _definition != null ? _definition.signalIn : null;
    protected override string SignalOutOverride => _definition != null ? _definition.signalOut : null;

    /// La cámara cinemática de esta secuencia. Se resuelve en Awake (Inspector, o la del
    /// SequenceStage si el campo del Inspector está vacío) para que el corte de apertura que hace
    /// la clase base durante el fundido use también la correcta.
    public CinematicCameraDriver ActiveCamera => _cinematicCamera;

    /// La cámara que está pintando, cacheada.
    public Camera CachedCamera
    {
        get
        {
            if (_gameCamera == null) _gameCamera = Camera.main;
            return _gameCamera;
        }
    }

    /// La secuencia que reproduce este player. De solo lectura, para las herramientas de Editor.
    public SequenceDefinition Definition => _definition;

    /// Monta en tiempo de ejecución un SequencePlayer para 'definicion' con los mismos ajustes que
    /// 'plantilla' (cámara, perfil de audio, transiciones, escenario…), sin tener que añadirlo a
    /// mano a la escena (INC-445: MainWorld está en binario y cada secuencia nueva obligaba a
    /// montarla en el Editor). No clona el GameObject de la plantilla —podría arrastrar hijos con
    /// disparadores propios—: crea uno vacío y copia solo los campos serializados de sus dos
    /// componentes. Se crea apagado y se enciende al final, para que Awake ya vea la definición.
    public static SequencePlayer CrearCopiaPara(SequenceDefinition definicion, SequencePlayer plantilla)
    {
        if (definicion == null || plantilla == null) return null;

        var go = new GameObject(definicion.name + " (en vivo)");
        go.SetActive(false);
        if (plantilla.gameObject.scene.IsValid())
            UnityEngine.SceneManagement.SceneManager.MoveGameObjectToScene(go, plantilla.gameObject.scene);
        go.transform.SetPositionAndRotation(plantilla.transform.position, plantilla.transform.rotation);

        SequenceStage escenario = null;
        var escenarioPlantilla = plantilla._stage != null ? plantilla._stage : plantilla.GetComponent<SequenceStage>();
        if (escenarioPlantilla != null)
        {
            escenario = go.AddComponent<SequenceStage>();
            JsonUtility.FromJsonOverwrite(JsonUtility.ToJson(escenarioPlantilla), escenario);
        }

        if (definicion.modulos != null)
        {
            if (escenario == null) escenario = go.AddComponent<SequenceStage>();
            var instancia = Instantiate(definicion.modulos, go.transform);
            instancia.name = definicion.modulos.name;
            escenario.AgregarModulos(instancia.GetComponentsInChildren<SequenceModule>(true));
        }

        var sp = go.AddComponent<SequencePlayer>();
        JsonUtility.FromJsonOverwrite(JsonUtility.ToJson(plantilla), sp);
        sp._definition = definicion;
        sp._stage = escenario;
#if UNITY_EDITOR
        sp._startAtPhase = null;
#endif
        go.SetActive(true);
        return sp;
    }
    public SequenceStage Stage => _stage;

    // Limpiezas que un beat deja pedidas y que hay que ejecutar sí o sí al cerrar. Existe porque
    // el try/finally de un beat NO es de fiar cuando la secuencia se salta: StopCoroutine sobre la
    // corrutina principal no ejecuta los finally de las anidadas, algo que este proyecto ya
    // documenta en tres sitios. Lo usa DialogueBeat para desuscribirse de un evento ESTÁTICO, que
    // olvidado se queda disparando el resto de la partida.
    private readonly List<System.Action> _pendingCleanups = new();

    public void RegisterCleanup(System.Action cleanup)
    {
        if (cleanup != null) _pendingCleanups.Add(cleanup);
    }

    // Lo que la secuencia pone encima de la imagen (bandas de cine...) se quita en cuanto la escena
    // devuelve el juego, no tras el margen de gracia de los NPCs: lo que el grafo lance justo
    // después (la presentación de un jefe, un aviso) no puede salir con las bandas puestas.
    // Ver INC-627.
    private readonly List<System.Action> _pendingScreenCleanups = new();

    public void RegisterScreenCleanup(System.Action cleanup)
    {
        if (cleanup != null) _pendingScreenCleanups.Add(cleanup);
    }

    private void RunScreenCleanups()
    {
        for (int i = 0; i < _pendingScreenCleanups.Count; i++)
        {
            try { _pendingScreenCleanups[i]?.Invoke(); }
            catch (System.Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                ex
#endif
            )
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[SequencePlayer:{name}] Una limpieza de pantalla ha fallado: {ex.Message}");
#endif
            }
        }
        _pendingScreenCleanups.Clear();
    }

    private void RunPendingCleanups()
    {
        for (int i = 0; i < _pendingCleanups.Count; i++)
        {
            try { _pendingCleanups[i]?.Invoke(); }
            catch (System.Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                ex
#endif
            )
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning($"[SequencePlayer:{name}] Una limpieza pendiente ha fallado: {ex.Message}");
#endif
            }
        }
        _pendingCleanups.Clear();
    }

    /// Registra una corrutina de módulo lanzada de fondo, para poder pararla al cerrar.
    public void TrackBackgroundRoutine(Coroutine routine)
    {
        if (routine != null) _backgroundRoutines.Add(routine);
    }

    /// Pide terminar la secuencia en cuanto acabe el beat actual, saltándose las fases que queden.
    /// Con una señal distinta a la del asset, si la rama que se está siguiendo sale por otro sitio.
    public void RequestEnd(string signalOverride = null,
        SequenceEndScreen screen = SequenceEndScreen.ComoElAsset)
    {
        _endRequested = true;
        if (!string.IsNullOrWhiteSpace(signalOverride)) _endSignalOverride = signalOverride.Trim();
        if (screen != SequenceEndScreen.ComoElAsset) _endScreenOverride = screen;
    }

    /// Cambia la música a mitad de secuencia. Usado por MusicBeat.
    public void PlayMusic(string musicId, bool continuarDondeIba = true, float fadeIn = 0f, float desdeSegundo = -1f)
    {
        var regla = ResolveAudioProfile()?.GetSequenceRule(musicId);
        if (regla?.music != null && AudioService.Instance != null)
            AudioService.Instance.PlayMusic(regla.music, fadeIn > 0f ? fadeIn : regla.fadeIn, continuarDondeIba, desdeSegundo);
        else PlaySequenceMusic(musicId);
    }

    /// Para la música. Usado por MusicBeat: hace falta para los silencios dramáticos y para dejar
    /// paso limpio a lo que venga detrás (la intro de un jefe, por ejemplo).
    public void StopMusicNow(float fadeOut)
    {
        if (AudioService.Instance != null) AudioService.Instance.StopMusic(Mathf.Max(0f, fadeOut));
    }

    /// Levanta una señal narrativa a mitad de secuencia. Usado por SignalBeat.
    public void Raise(string signal) => RaiseSignal(signal);

    protected override void Awake()
    {
        if (_stage == null) _stage = GetComponent<SequenceStage>();

        // _cinematicCamera es un campo protegido heredado de CinematicSequencerBase: si no se
        // asignó en el Inspector, se toma el del SequenceStage. Debe quedar resuelto ANTES de
        // base.Awake(), porque el corte de apertura durante el fundido lo usa directamente.
        if (_cinematicCamera == null && _stage != null && _stage.CameraDriver != null)
            _cinematicCamera = _stage.CameraDriver;

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        // Sin definición el SequencePlayer no escucha ninguna señal de entrada, así que el grafo
        // narrativo se quedaría esperando su señal de salida para siempre, sin ningún error. Ver INC-430.
        if (_definition == null)
            Debug.LogError($"[SequencePlayer:{name}] No tiene asignado ningún SequenceDefinition " +
                "(campo 'Definition', abajo del todo en el Inspector). Sin él esta secuencia no " +
                "escucha ninguna señal y no arrancará nunca: el grafo narrativo se quedará esperando. " +
                "Arrastra aquí su asset de Assets/_SEQUENCES y guarda la escena.", this);

        if (_cinematicCamera == null)
            Debug.LogWarning($"[SequencePlayer:{name}] Sin CinematicCameraDriver (ni en el Inspector " +
                "ni en el SequenceStage) — ningún corte de cámara de esta secuencia hará nada.");
#endif

        base.Awake();
    }

    /// Con la pantalla ya cubierta, la escena de la cinemática pasa a mandar. Se marca ACTIVA mientras
    /// dura: Unity coge el skybox, la niebla y la luz ambiente de la escena activa, y el prólogo se
    /// carga en aditivo mientras la activa sigue siendo la del jugador (la habitación de Will, un
    /// interior sin cielo). Y, si ocurre al aire libre, se fuerza que se vea el cielo; una secuencia
    /// de interior no lo fuerza porque el interior lo aplica la clase base justo después, y así no
    /// se le cuelgan lluvia ni niebla. Ver CinematicTimeOfDay.
    ///
    /// Va en el corte y no antes: hasta aquí la pantalla enseña la escena del jugador, y cambiar la
    /// escena activa al cargar la de la cinemática en aditivo le quitaba el cielo y la luz ambiente
    /// durante el fundido de entrada (INC-956). Tampoco en Awake por otro motivo: entre que el
    /// SequencePlayer despierta y que la secuencia arranca, el jugador puede haber entrado en una
    /// casa, que es lo que pasa en el prólogo.
    /// Sin interior en el Inspector, la cinemática ocurre donde arrancan sus actores: si el primero
    /// del guion empieza dentro de un interior cargado, es de interior (y el clima no entra). Así
    /// una secuencia montada desde otra escena (la de la torre de Liam vive en MainWorld) no
    /// depende de un campo que no puede apuntar a otra escena. Ver INC-1116.
    protected override AnchorEnvironment ResolverInterior()
    {
        if (_definition?.phases == null) return null;
        foreach (var fase in _definition.phases)
        {
            if (fase?.beats == null) continue;
            foreach (var beat in fase.beats)
            {
                if (beat is not GuionBeat g || g.guion == null) continue;
                foreach (var actor in g.guion.actores)
                    if (actor.posiciones != null && actor.posiciones.Count > 0)
                        return AnchorEnvironment.InteriorQueContiene(actor.posiciones[0].p);
            }
        }
        return null;
    }

    protected override void PrepararEscenaEnElCorte()
    {
        if (_stage != null) CinematicTimeOfDay.ActivarEscena(_stage.gameObject.scene);
        if (!OcurreEnInterior) CinematicTimeOfDay.MostrarExterior(CachedCamera);
    }

    /// El telón lo suelta el propio bucle de beats, en el primer plano. Ver Co_Play.
    protected override bool SueltaElTelonEnSuPrimerPlano => true;

    /// Deja montada, con la pantalla cubierta, la primera fase de la secuencia: es la única que
    /// se sabe con certeza que va a correr en el cut point (las demás pueden depender de marcas
    /// que todavía no existen). El guion horneado aprovecha para colocar a los actores y ponerles
    /// su pose del segundo inicial. Sin esto la entrada descubre la escena con los actores en su
    /// sitio y su pose de escena, y el primer fotograma del guion los recoloca a la vista: Liam
    /// aparecía de pie dentro de la silla hasta que arrancaba su pose de sentado.
    private void PrepararBeats()
    {
        if (_definition?.phases == null || _definition.phases.Count == 0) return;

        int indice = 0;
#if UNITY_EDITOR
        if (!string.IsNullOrWhiteSpace(_startAtPhase))
        {
            int idx = _definition.IndexOfPhase(_startAtPhase);
            if (idx >= 0) indice = idx;
        }
#endif

        var fase = _definition.phases[indice];
        if (fase?.beats == null || !fase.ShouldRun(_context)) return;
        foreach (var beat in fase.beats) beat?.Preparar(_context);
    }

    /// Beats que solo colocan: son instantáneos y no se ve nada de lo que hacen hasta que haya un
    /// plano. Con el telón cerrado se ejecutan a oscuras. Cualquier otro beat destapa antes de
    /// correr — si hay duda, mejor destapar que dejar la pantalla negra mientras pasan cosas.
    ///
    /// Lo declara el propio beat (SequenceBeat.SoloColoca), no el reproductor: así el reproductor
    /// no necesita saber qué tipos de beat existen.
    private static bool EsPreparacion(SequenceBeat beat) => beat != null && beat.SoloColoca;

    protected override IEnumerator Co_Sequence()
    {
        if (_definition == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogError($"[SequencePlayer:{name}] Sin SequenceDefinition asignada — no hay nada " +
                "que reproducir. La señal de salida se levanta igualmente para no dejar el grafo " +
                "narrativo esperando para siempre.");
#endif
            RaiseSignalOut();
            yield break;
        }

        _context = new SequenceContext(this, _stage);

        if (_stage != null && _stage.Actors != null)
        {
            foreach (var actor in _stage.Actors)
            {
                if (actor.target == null || string.IsNullOrWhiteSpace(actor.id)) continue;
                _context.RegisterActor(actor.id.Trim(), actor.target, actor.eyeHeight,
                    actor.animator, actor.emotionController);
            }
        }

        // Objetos del decorado que esta escena quiere poder encuadrar (el horno, la carreta, el
        // portón). Se registran aquí, antes del primer beat, para que el guion pueda encuadrarlos
        // igual que a un personaje. Ver SequenceStage.Props.
        if (_stage != null && _stage.Props != null)
        {
            foreach (var prop in _stage.Props)
            {
                if (prop.target == null || string.IsNullOrWhiteSpace(prop.id)) continue;
                _context.RegisterActor(prop.id.Trim(), prop.target, prop.eyeHeight);
            }
        }

        // EndSequenceBeat escribe estos campos para cerrar por una rama concreta. Si la secuencia
        // se relanza (p.ej. retry tras fallo de panic input), deben partir de cero o la segunda
        // ejecución salta todos los beats y levanta la señal de rama errónea de inmediato.
        _endRequested = false;
        _endSignalOverride = null;
        _endScreenOverride = SequenceEndScreen.ComoElAsset;
        _signalRaised = false;
        _jugadorDevuelto = false;
        _faseEnCurso = 0;
        _beatEnCurso = -1;

        try
        {
            yield return Co_Play();
        }
        finally
        {
            // Red de seguridad: si la corrutina termina de forma anómala (excepción, destrucción
            // del objeto a mitad), los NPCs no se quedan atrapados en CinematicState para siempre
            // ni con el NavMeshAgent tocado. Mismo patrón que Co_SequenceGuarded de la clase base.
            ReleaseAllActors();

            // Y el grafo narrativo no se queda esperando. Mismo criterio que el caso de "sin
            // definición asignada" de más arriba: es preferible avanzar la historia que dejar el
            // capítulo colgado sin que nadie sepa por qué.
            if (!_signalRaised)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogError($"[SequencePlayer:{name}] La secuencia terminó de forma anómala " +
                    "(lo normal es que un beat haya lanzado una excepción; mírala más arriba en la " +
                    "consola). Se levanta la señal de salida igualmente para no dejar el grafo " +
                    "narrativo esperando para siempre.");
#endif
                RaiseSignalOut();
            }
        }
    }

    private IEnumerator Co_Play()
    {
        // La música arranca en el CUT POINT (pantalla cubierta, AnySequenceActive ya en true).
        // Antes del cut point, LockCinematic() no ha ejecutado todavía y HandleInteriorExited del
        // portal picaría la música de zona encima de la de la secuencia.
        // El plano de apertura se aplica también en el cut point para que la escena aparezca ya
        // encuadrada.
        yield return Co_BeginCinematicWithTransition(() =>
        {
            ApplyOpeningShotIfDescribed();

            PrepararBeats();

            if (!string.IsNullOrEmpty(_definition.musicId))
                PlaySequenceMusic(_definition.musicId);
        });

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        // Comprobación tardía: si la música arrancó pero alguien la pisó justo después (el portal,
        // una AmbientZone, una batalla...), esto lo dice en vez de dejarnos adivinando. Es
        // fire-and-forget a propósito: no debe retrasar la secuencia.
        if (!string.IsNullOrEmpty(_definition.musicId))
            StartCoroutine(Co_CheckMusicStuck(_definition.musicId));
#endif

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        InformeDeRodaje.Iniciar(this);
#endif

        int startPhase = 0;
#if UNITY_EDITOR
        if (!string.IsNullOrWhiteSpace(_startAtPhase))
        {
            int idx = _definition.IndexOfPhase(_startAtPhase);
            if (idx >= 0)
            {
                startPhase = idx;
                Debug.LogWarning($"[SequencePlayer:{name}] Arrancando en la fase '{_definition.phases[idx].name}' " +
                    "(campo de pruebas '_startAtPhase'). Acuérdate de vaciarlo antes de dar la escena por buena.");
            }
            else
            {
                Debug.LogWarning($"[SequencePlayer:{name}] No hay ninguna fase llamada '{_startAtPhase}' " +
                    "— se arranca desde el principio.");
            }
        }
#endif

        for (int p = startPhase; p < _definition.phases.Count; p++)
        {
            var phase = _definition.phases[p];
            if (phase?.beats == null) continue;

            // Fases condicionales: es como una secuencia con más de un final sigue siendo una
            // lista ordenada que se lee de arriba abajo, en vez de un grafo dentro de otro grafo.
            if (!phase.ShouldRun(_context))
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[SequencePlayer:{name}] Fase {p + 1}/{_definition.phases.Count}: " +
                    $"'{phase.name}' SE SALTA porque {phase.DescribeSkipReason(_context)}.");
#endif
                continue;
            }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[SequencePlayer:{name}] Fase {p + 1}/{_definition.phases.Count}: '{phase.name}' " +
                $"({phase.beats.Count} beats).");
            InformeDeRodaje.Fase(phase.name);
#endif

            for (int b = 0; b < phase.beats.Count; b++)
            {
                if (_endRequested) break;
                var beat = phase.beats[b];
                if (beat == null) continue;

                // EL TELÓN (21 sep). Si esta secuencia empezó con la pantalla en negro, se queda en
                // negro mientras los beats solo COLOCAN cosas (poner a alguien en su marca, volcar
                // la carreta, la hora del día...), y se destapa con lo primero que se VE: su primer
                // plano, o el primer beat que tarde algo. Antes se destapaba al acabar la transición
                // de entrada, con el Mago Oscuro todavía en mitad de la plaza y la carreta sin volcar.
                if (Telon.Retiene(ClaveTelon) && !EsPreparacion(beat))
                    Telon.Soltar(ClaveTelon);

                _faseEnCurso = p;
                _beatEnCurso = b;
                yield return beat.Run(_context);
            }

            if (_endRequested)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[SequencePlayer:{name}] La secuencia termina en la fase '{phase.name}': " +
                    "un beat ha pedido cerrar antes de tiempo.");
#endif
                break;
            }
        }

        _faseEnCurso = -1;

        // La mecánica lanzada de fondo se para: a partir de aquí manda otra vez el juego.
        StopBackgroundRoutines();
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        InformeDeRodaje.Terminar(this);
#endif

        // Los módulos se cierran AQUÍ, no en ReleaseAllActors. Aquel corre después del margen de
        // gracia de los NPCs (3,5 s por defecto), y ese margen existe para que un NPC no eche a
        // andar nada más acabar la escena — no tiene nada que ver con la mecánica. Cerrarlos tarde
        // dejaba al módulo del Despertar con el lanzador de hechizos del jugador APAGADO durante
        // tres segundos y medio de juego real.
        if (_stage != null) _stage.CleanupModules();
        CinematicTimeOfDay.Restore();
        RunScreenCleanups();

        // Los bucles de sonido y demás limpiezas se paran antes de levantar la señal de salida:
        // el grafo puede cargar la escena siguiente en cuanto la reciba.
        RunPendingCleanups();

        // Red de seguridad del tiempo: si la escena iba en cámara lenta y su beat de vuelta no se
        // llegó a ejecutar (una rama que salió antes, un beat mal puesto), la partida se quedaría
        // al 20% de velocidad para siempre. Se suelta la petición de la secuencia (TimeScaleBeat
        // pide con el reproductor como clave), sin tocar las pausas de otros sistemas.
        TimeScaleArbiterService.Release(this);

        // Dejar a todos los actores parados y en Idle antes de devolver el control a la FSM.
        foreach (var actor in _context.ResolvedActors)
        {
            actor.EndAgentOverride();
            actor.StopMovement();
        }

        bool stayBlack = _endScreenOverride switch
        {
            SequenceEndScreen.Revelar => false,
            SequenceEndScreen.QuedarseEnNegro => true,
            _ => _definition.endStayBlack,
        };

        bool skipMusic = _definition.skipMusicRestore;
        if (stayBlack) yield return Co_EndCinematicStayBlack(skipMusic ? null : RestoreMusic);
        else yield return Co_EndCinematicWithTransition(skipMusic ? null : RestoreMusic);

        // El jugador ya tiene el control: su animación de andar se suelta ahora, no tras la gracia
        // de los NPCs. StopMovement la dejó forzada a cero y, mientras tanto, se movía sin mover
        // las piernas (al guiarle un NPC nada más acabar la escena, por ejemplo). Ver INC-948.
        foreach (var actor in _context.ResolvedActors)
            if (actor.IsPlayer) actor.ReturnToNormalPose();
        _jugadorDevuelto = true;

        // La señal de salida va EN CUANTO la pantalla vuelve al gameplay (INC-359). Antes iba
        // detrás de la gracia de 3,5 s de abajo, y todo lo que el grafo hace al acabar una escena
        // —el cartel de «Nueva misión», el tutorial, que Oliver se una al grupo— llegaba tres
        // segundos y medio tarde: «el pop-up de nueva misión tarda muchísimo en salir».
        // Una secuencia con dos finales sale por la señal de su rama, no por la del asset.
        _signalRaised = true;
        if (!string.IsNullOrEmpty(_endSignalOverride)) Raise(_endSignalOverride);
        else RaiseSignalOut();

        // Los NPCs siguen retenidos un poco más, con la pantalla ya de vuelta al gameplay, para que
        // no se les vea echarse a andar justo al terminar la escena. Esto ya no retrasa al grafo.
        if (_idleGraceAfterSequence > 0f)
            yield return new WaitForSeconds(_idleGraceAfterSequence);

        ReleaseAllActors();
    }

    /// Coloca la cámara en su plano de apertura. Se llama desde el cut point de la transición de
    /// entrada, así que el corte no se ve. Lo hace el primer beat si sabe (el guion horneado la
    /// compone con su primer plano): lo declara el propio beat, el reproductor no reconoce tipos.
    private void ApplyOpeningShotIfDescribed()
    {
        if (_definition == null || _definition.phases == null || _definition.phases.Count == 0) return;
        var beats = _definition.phases[0].beats;
        if (beats == null || beats.Count == 0) return;
        beats[0]?.ColocarCamaraDeApertura(this);
    }

    private void StopBackgroundRoutines()
    {
        for (int i = 0; i < _backgroundRoutines.Count; i++)
            if (_backgroundRoutines[i] != null) StopCoroutine(_backgroundRoutines[i]);
        _backgroundRoutines.Clear();
    }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
    /// Mira, un par de segundos después de arrancar, qué música está sonando de verdad. Si no es la
    /// de la secuencia, alguien la ha pisado — y el aviso dice cuál suena, que es justo el dato que
    /// hace falta para saber quién.
    private IEnumerator Co_CheckMusicStuck(string musicId)
    {
        yield return new WaitForSeconds(2f);

        if (AudioService.Instance == null) yield break;

        var esperada = ResolveAudioProfile()?.GetSequenceRule(musicId)?.music;
        var sonando = AudioService.Instance.CurrentMusicClip;

        if (esperada == null) yield break;

        if (sonando != esperada)
            Debug.LogWarning($"[SequencePlayer:{name}] La música de la secuencia ('{esperada.name}') " +
                $"NO es la que está sonando dos segundos después: suena " +
                $"'{(sonando != null ? sonando.name : "nada")}'. Alguien la ha pisado — mira qué otro " +
                "sistema tocó la música en esa ventana (portal de interior, AmbientZone, batalla).");
        else
            Debug.Log($"[SequencePlayer:{name}] Música de la secuencia sonando correctamente: '{esperada.name}'.");
    }
#endif

    /// Suelta a todos los actores que la secuencia haya tocado: restaura los ajustes de su
    /// NavMeshAgent, los deja parados en Idle y les devuelve su comportamiento ambiental.
    /// Idempotente — se llama desde el final normal, desde el finally de Co_Sequence y desde el
    /// camino de skip.
    private void ReleaseAllActors()
    {
        // Todo lo de aquí es idempotente y se llama desde los tres caminos de cierre (final
        // normal, finally de seguridad y skip), porque ninguno de los tres puede dar por hecho que
        // los otros hayan pasado.
        StopBackgroundRoutines();
        RunScreenCleanups();
        RunPendingCleanups();
        SpeechBubbleUI.Instance?.Hide();
        TimeScaleArbiterService.Release(this);
        // Si el guion se cerró sin soltar la cámara (una excepción a mitad), el driver se la
        // queda cedida y la cámara de juego no vuelve nunca.
        ActiveCamera?.DevolverElControl();
        if (_stage != null) _stage.CleanupModules();
        CinematicTimeOfDay.Restore();

        if (_context == null) return;
        foreach (var actor in _context.ResolvedActors)
        {
            if (actor.Emotion != null) actor.Emotion.VolverAReposo();
            actor.EndAgentOverride();

            // Si otro sistema ya se lo ha llevado (el grafo lo manda a guiar al jugador en cuanto
            // se levanta la señal de salida), pararlo aquí le rompería el camino. Ver INC-461.
            if (actor.LoHaTomadoOtroSistema)
            {
                actor.Release();
                continue;
            }

            // Devolverle a la locomoción otra vez, ya andando, le daría un tirón.
            if (actor.IsPlayer && _jugadorDevuelto)
            {
                actor.Release();
                continue;
            }

            actor.StopMovement();
            // Cierra cualquier animación de cuerpo entero que se haya quedado puesta — ver
            // PlayerDialogueAnimator.ReturnToLocomotion (el caso de Dizzy_NoWeapon en Will).
            actor.ReturnToNormalPose();
            actor.Release();
        }
        _context.SoltarReparto();
    }

    /// Ver CinematicSequencerBase.OnSkipCleanup: StopCoroutine no garantiza que se ejecute el
    /// try/finally de las corrutinas anidadas, así que todo lo que hay que limpiar siempre se
    /// repite aquí a mano.
    protected override void OnSkipCleanup()
    {
        // Un DialogueBeat no es una corrutina nuestra: el DialogueManager tiene su propio panel, su
        // propio modo de input y su propia cámara. Sin esto, saltar durante el diálogo del tutorial
        // dejaba la caja de diálogo encima del gameplay y la cámara congelada en el encuadre de la
        // conversación — o sea, saltar la escena no la saltaba.
        if (DialogueManager.Instance != null && DialogueManager.Instance.IsOpen)
            DialogueManager.Instance.Close();

        SpeechBubbleUI.Instance?.Hide();
        // Antes de soltar nada: el guion en marcha cumple lo suyo al cerrarse (ReleaseAllActors).
        _context?.MarcarSalto();
        CumplirLoQueQuedaba();
        ReleaseAllActors();

        // El cierre genérico de skip deja la pantalla cubierta a propósito. Estas secuencias no
        // tienen ningún sistema siguiente que la revele, así que la revelan ellas — si no, saltar
        // una secuencia deja la pantalla en negro para siempre (INC-208).
        // Si el objeto se está apagando (se descarga su escena), no puede arrancar corrutinas, y
        // la pantalla es de quien venga después: el prólogo acaba en blanco y lo destapa el grafo.
        if (isActiveAndEnabled) StartCoroutine(Co_RevealAfterSkip());
    }

    /// ¿Queda por delante algún beat que se VEA? Los que solo colocan cosas (SoloColoca) y las esperas
    /// sueltas (el aire del final de cada guion) no cuentan.
    /// Lo usa DialogueBeat para no volver a poner las bandas de cine cuando la escena acaba con su
    /// caja de diálogo: se pasaba de cine a juego con las bandas puestas un momento. Ver INC-1149.
    public bool QuedaAlgoQueVer()
    {
        if (_definition?.phases == null || _context == null || _faseEnCurso < 0 || _endRequested) return false;
        for (int p = _faseEnCurso; p < _definition.phases.Count; p++)
        {
            var fase = _definition.phases[p];
            if (fase?.beats == null) continue;
            bool enCurso = p == _faseEnCurso && _beatEnCurso >= 0;
            if (!enCurso && !fase.ShouldRun(_context)) continue;
            for (int b = enCurso ? _beatEnCurso + 1 : 0; b < fase.beats.Count; b++)
                if (SeVe(fase.beats[b])) return true;
        }
        return false;
    }

    private static bool SeVe(SequenceBeat beat) => beat != null && !EsPreparacion(beat) && !(beat is WaitBeat);

    /// Saltar la secuencia no puede dejar sin hacer lo que la historia espera de ella: los beats
    /// que no han llegado a correr cumplen lo suyo (SequenceBeat.CumplirAlSaltar). Ver INC-890.
    private void CumplirLoQueQuedaba()
    {
        if (_definition?.phases == null || _context == null || _faseEnCurso < 0 || _endRequested) return;
        for (int p = _faseEnCurso; p < _definition.phases.Count; p++)
        {
            var fase = _definition.phases[p];
            if (fase?.beats == null) continue;
            bool enCurso = p == _faseEnCurso && _beatEnCurso >= 0;
            if (!enCurso && !fase.ShouldRun(_context)) continue;
            for (int b = enCurso ? _beatEnCurso + 1 : 0; b < fase.beats.Count; b++)
            {
                try { fase.beats[b]?.CumplirAlSaltar(_context); }
                catch (System.Exception e) { Debug.LogException(e); }
            }
        }
        _faseEnCurso = -1;
    }

    private IEnumerator Co_RevealAfterSkip()
    {
        yield return Sendero.Core.Feedback.FeedbackService.ScreenFadeAsync(
            Color.black, _skipRevealDuration, fadeIn: false);
    }
}
