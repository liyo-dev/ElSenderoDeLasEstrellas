using UnityEngine;
using UnityEngine.AI;
using System.Collections;

/// <summary>
/// IA simple para Spider1 - Enemigo básico débil pero peligroso en grupo
/// </summary>
[RequireComponent(typeof(Animator))]
[RequireComponent(typeof(Damageable))]
public class Spider1AI : MonoBehaviour
{
    [Header("Referencias")]
    [SerializeField] private Transform player;
    [SerializeField] private Animator animator;
    [SerializeField] private Damageable damageable;
    [SerializeField] private NavMeshAgent agent;

    [Header("Comportamiento")]
    [SerializeField] private float detectionRange = 8f;
    [SerializeField] private float attackRange = 1.5f;
    [Tooltip("Radio de patrulla alrededor del punto de spawn. Antes era muy pequeño (5) y las arañas se veían encerradas en una zona diminuta; ahora patrullan una zona bastante más amplia.")]
    [SerializeField] private float patrolRadius = 18f;
    [Tooltip("Tiempo BASE de pausa entre tramos de patrulla. La pausa real se aleatoriza (ver RandomIdleTime) entre un 25% y un 100% de este valor para que no se vean todas las arañas paradas el mismo tiempo exacto.")]
    [SerializeField] private float idleTime = 1f;
    [SerializeField] private bool patrolEnabled = true;

    [Header("Combate")]
    [SerializeField] private float damage = 8f;
    [SerializeField] private float attackCooldown = 1f;
    [Tooltip("Pequeño impulso hacia el jugador al iniciar el golpe, para que el ataque se sienta con más impacto ('chicha') en vez de golpear en seco desde parado.")]
    [SerializeField, Min(0f)] private float attackLungeDistance = 0.4f;
    [SerializeField] private LayerMask playerLayer;

    [Header("Reacción al daño")]
    [Tooltip("Si está activo, al recibir daño la araña se detiene un instante (stun) antes de retomar su comportamiento.")]
    [SerializeField] private bool stopOnHit = true;
    [Tooltip("Tiempo detenido tras recibir daño (segundos).")]
    [SerializeField, Min(0f)] private float hitStunSeconds = 0.35f;
    [Tooltip("Al terminar el stun, si el jugador está en rango de detección, retomar persecución inmediatamente.")]
    [SerializeField] private bool reacquireTargetAfterHit = true;
    [Tooltip("Distancia extra para reenganchar la persecución tras el daño (multiplica detectionRange).")]
    [SerializeField, Min(1f)] private float reacquireRangeMultiplier = 1.0f;

    [Header("Configuración")]
    [SerializeField] private float moveSpeed = 3.5f;
    [SerializeField] private float chaseSpeedMultiplier = 1.3f;
    [SerializeField] private float modelRotationOffset = 180f; // Offset de rotación del modelo (si anda al revés)

    // Estado interno
    private enum SpiderState { Idle, Patrol, Chasing, Attacking, TakingDamage, Dead }
    private SpiderState currentState = SpiderState.Idle;
    
    private Vector3 spawnPosition;
    private Vector3 patrolTarget;
    private float lastAttackTime = -999f;
    private float idleTimer = 0f;
    private bool isAttacking = false;
    private bool isDead = false;
    private float originalSpeed;
    private float _targetRefreshTimer;
    // FIX A11 (auditoría 2026-08-07): referencia real a la corrutina de ataque activa, para poder
    // cancelarla de verdad desde OnDamageTaken. Antes había un método StopCoroutineSafe() que era
    // un no-op vacío: el daño se aplicaba igual aunque la araña estuviera en stun.
    private Coroutine _attackCoroutine;

    // Hash de animaciones
    private static readonly int AnimIdle = Animator.StringToHash("Idle");
    private static readonly int AnimWalk = Animator.StringToHash("Walk");
    private static readonly int AnimAttack = Animator.StringToHash("Attack");
    private static readonly int AnimDeath = Animator.StringToHash("Death");
    [Header("Animación de impacto (opcional)")]
    [SerializeField, Tooltip("Nombre del estado de animación de 'Hit'. Si está vacío, usará Idle durante el stun.")]
    private string hitStateName = ""; // p.ej. "Hit"
    private int AnimHit = 0;

    [Header("Knockback al recibir daño (opcional)")]
    [SerializeField, Min(0f)] private float hitKnockback = 0f;

    private Targetable _targetable;

    void Awake()
    {
        if (!animator) animator = GetComponent<Animator>();
        if (!damageable) damageable = GetComponent<Damageable>();
        if (!agent) agent = GetComponent<NavMeshAgent>();

        // Targetable y EnemyMarker: Spider1AI no pasa por CombatState (que es quien normalmente
        // los añade), así que hay que asegurarlos aquí. Sin Targetable, PlayerTargeting nunca
        // muestra el marker de objetivo sobre la araña; sin EnemyMarker, los sistemas de
        // puertas/gates no se enteran de cuándo muere.
        _targetable = GetComponent<Targetable>();
        if (_targetable == null) _targetable = gameObject.AddComponent<Targetable>();

        if (GetComponent<EnemyMarker>() == null) gameObject.AddComponent<EnemyMarker>();

        // Guardar posición inicial
        spawnPosition = transform.position;

        // Buscar al jugador si no está asignado
        if (!player)
        {
            var playerObj = GameObject.FindGameObjectWithTag("Player");
            if (playerObj) player = playerObj.transform;
        }
    }

    void Start()
    {
        if (damageable)
        {
            damageable.OnDamaged += OnDamageTaken;
            damageable.OnDied += OnDeath;
        }

        if (agent)
        {
            agent.speed = moveSpeed;
            originalSpeed = moveSpeed;
            // Ajustar stoppingDistance acorde al rango de ataque para evitar solapes
            agent.stoppingDistance = Mathf.Max(0.05f, attackRange * 0.9f);
        }

        if (!string.IsNullOrEmpty(hitStateName))
            AnimHit = Animator.StringToHash(hitStateName);

        // Iniciar con patrulla o idle
        if (patrolEnabled)
        {
            SetNewPatrolTarget();
        }
        else
        {
            currentState = SpiderState.Idle;
            idleTimer = RandomIdleTime();
        }
    }

    void OnDestroy()
    {
        if (damageable)
        {
            damageable.OnDamaged -= OnDamageTaken;
            damageable.OnDied -= OnDeath;
        }

        // Red de seguridad: si el GameObject se destruye a mitad de persecución (descarga de
        // escena, etc.) sin pasar por OnDeath/ExitChaseMode, no debe quedar "fake-null" en el
        // registro de combate (ActiveCombatRegistry.CleanupDestroyedNPCs ya lo tolera, pero
        // desregistrar aquí evita el hueco entre frames).
        ActiveCombatRegistry.UnregisterNPC(gameObject);
    }

    void Update()
    {
        if (isDead) return;

        // FIX (petición Raúl, 1 sep 2026): mientras hay un diálogo abierto en cualquier parte del
        // mundo, el jugador está bloqueado (ActionMode.Cinematic) y no puede reaccionar ni recibir
        // daño real (PlayerHealthSystem.TakeDamage ya lo bloquea en ese modo) — pero sin este gate
        // la araña seguía persiguiendo/atacando con normalidad delante del jugador congelado, lo
        // cual se veía mal. Se congela en sitio (sin tocar su estado de combate/registro) y se
        // retoma en cuanto el diálogo cierra.
        if (DialogueManager.Instance != null && DialogueManager.Instance.IsOpen)
        {
            if (agent && agent.isOnNavMesh && !agent.isStopped) agent.isStopped = true;
            return;
        }

        // Reevaluar objetivo más cercano cada 0.5s (jugador o compañero NPC)
        _targetRefreshTimer += Time.deltaTime;
        if (_targetRefreshTimer >= 0.5f)
        {
            _targetRefreshTimer = 0f;
            var nearest = CombatTargetProvider.GetNearestTarget(transform.position);
            if (nearest != null) player = nearest;
        }

        if (!player) return;

        float distanceToPlayer = Vector3.Distance(transform.position, player.position);

        // Detectar al jugador
        if (distanceToPlayer <= detectionRange && currentState != SpiderState.TakingDamage)
        {
            // Entrar en modo persecución
            if (currentState != SpiderState.Chasing && currentState != SpiderState.Attacking)
            {
                EnterChaseMode();
            }

            // Decidir si atacar o perseguir
            if (distanceToPlayer <= attackRange && !isAttacking)
            {
                _attackCoroutine = StartCoroutine(AttackPlayer()); // FIX A11 (auditoría 2026-08-07): guardar referencia real
            }
            else if (distanceToPlayer > attackRange && currentState == SpiderState.Chasing)
            {
                ChasePlayer();
            }
        }
        else if (currentState == SpiderState.Chasing)
        {
            // Perdió al jugador, volver a patrullar
            ExitChaseMode();
        }
        else if (currentState != SpiderState.TakingDamage)
        {
            // Comportamiento de patrulla/idle
            UpdatePatrolBehavior();
        }
    }

    private void UpdatePatrolBehavior()
    {
        if (currentState == SpiderState.Idle)
        {
            idleTimer -= Time.deltaTime;
            if (idleTimer <= 0f)
            {
                if (patrolEnabled)
                {
                    SetNewPatrolTarget();
                }
                else
                {
                    idleTimer = RandomIdleTime();
                }
            }

            PlayAnimation(AnimIdle);
        }
        else if (currentState == SpiderState.Patrol)
        {
            if (agent && agent.isOnNavMesh)
            {
                // Verificar si llegó al objetivo
                if (!agent.pathPending && agent.remainingDistance <= agent.stoppingDistance)
                {
                    currentState = SpiderState.Idle;
                    idleTimer = RandomIdleTime();
                }
                else
                {
                    // FIX 4 sep 2026: antes se reproducía AnimWalk de forma incondicional en cuanto
                    // el estado era Patrol, aunque el NavMeshAgent tuviera velocidad casi nula
                    // (bloqueado por un obstáculo/otra araña, o todavía acelerando) — se veía la
                    // araña "caminando en el sitio" sin desplazarse (reportado por Raúl). Ahora la
                    // animación de andar solo se reproduce si de verdad se está moviendo; si no, Idle.
                    if (agent.velocity.sqrMagnitude > 0.1f)
                    {
                        LookAtDirection(agent.velocity.normalized);
                        PlayAnimation(AnimWalk);
                    }
                    else
                    {
                        PlayAnimation(AnimIdle);
                    }
                }
            }
        }
    }

    /// <summary>
    /// Pausa de idle aleatorizada a partir de idleTime, para que las arañas no se vean todas
    /// "congeladas" el mismo tiempo exacto entre tramos de patrulla (petición Raúl, 4 sep 2026:
    /// "no tienen que estar quietas").
    /// </summary>
    private float RandomIdleTime()
    {
        return idleTime * Random.Range(0.25f, 1f);
    }

    private void SetNewPatrolTarget()
    {
        // Generar punto aleatorio cerca de la posición de spawn
        Vector2 randomCircle = Random.insideUnitCircle * patrolRadius;
        Vector3 randomPoint = spawnPosition + new Vector3(randomCircle.x, 0, randomCircle.y);

        // Buscar el punto más cercano en el NavMesh
        if (NavMesh.SamplePosition(randomPoint, out NavMeshHit hit, patrolRadius, NavMesh.AllAreas))
        {
            patrolTarget = hit.position;
            
            if (agent && agent.isOnNavMesh)
            {
                agent.isStopped = false;
                agent.speed = originalSpeed;
                agent.SetDestination(patrolTarget);
                currentState = SpiderState.Patrol;
            }
        }
        else
        {
            // Si no encuentra punto, quedarse idle
            currentState = SpiderState.Idle;
            idleTimer = RandomIdleTime();
        }
    }

    private void EnterChaseMode()
    {
        currentState = SpiderState.Chasing;

        if (agent)
        {
            agent.speed = originalSpeed * chaseSpeedMultiplier;
            // FIX (Raúl, 4 sep 2026): faltaba comprobar agent.isOnNavMesh antes de tocar isStopped.
            // Si EnterChaseMode() se disparaba en el mismo frame en que el agente aún no se había
            // registrado en el NavMesh (recién instanciado/reactivado), Unity lanzaba el error
            // "'Resume' can only be called on an active agent that has been placed on a NavMesh."
            // Con la comprobación, ese frame simplemente no toca isStopped; en cuanto isOnNavMesh
            // pasa a true, ChasePlayer()/UpdatePatrolBehavior() ya arrancan el movimiento normal.
            if (agent.isOnNavMesh) agent.isStopped = false;
        }

        // Activar el marker de objetivo del jugador (ver PlayerTargeting.Scan)
        if (_targetable != null) _targetable.isInActiveCombat = true;

        // FIX (petición Raúl, 1 sep 2026): Spider1AI no pasaba por ActiveCombatRegistry (a
        // diferencia de CombatState/ImpDemonAI/GolemBossAI), así que si se unía a una pelea ya en
        // marcha (p.ej. contra Lety+Vicky) L1/R1 (CombatCameraTargeting.GetOrderedTargets) nunca
        // la incluía en el ciclo de objetivos — quedaba imposible de seleccionar aunque estuviera
        // atacando. Registrarla aquí la hace ciclable igual que cualquier otro enemigo.
        // Petición de Raúl (1 sep 2026, misma sesión): enemigo "menor" — cuenta como combate
        // (Battle Mode, ciclable con L1/R1) pero NO debe enganchar la cámara automáticamente al
        // cruzarse con el jugador por el bosque (era muy tedioso). El marcador de apuntado para
        // hechizos lo sigue dando el auto-scan normal de PlayerTargeting, vía
        // Targetable.isInActiveCombat (ya activado arriba) — no depende de esto.
        ActiveCombatRegistry.RegisterNPC(gameObject, allowsCameraLock: false);
    }

    private void ExitChaseMode()
    {
        if (agent)
        {
            agent.speed = originalSpeed;
        }

        if (patrolEnabled)
        {
            SetNewPatrolTarget();
        }
        else
        {
            currentState = SpiderState.Idle;
            idleTimer = RandomIdleTime();
            if (agent && agent.isOnNavMesh) agent.isStopped = true;
        }

        if (_targetable != null) _targetable.isInActiveCombat = false;
        ActiveCombatRegistry.UnregisterNPC(gameObject);
    }

    private void ChasePlayer()
    {
        if (!player || !agent || !agent.isOnNavMesh) return;

        LookAtPlayer();
        agent.isStopped = false;
        agent.SetDestination(player.position);
        PlayAnimation(AnimWalk);
    }

    private IEnumerator AttackPlayer()
    {
        if (Time.time < lastAttackTime + attackCooldown) yield break;

        isAttacking = true;
        currentState = SpiderState.Attacking;
        lastAttackTime = Time.time;

        if (agent && agent.isOnNavMesh) agent.isStopped = true;

        LookAtPlayer();
        PlayAnimation(AnimAttack);

        // Impulso corto hacia el jugador al arrancar el golpe: sensación de más "chicha" en vez de
        // golpear en seco desde parado (petición Raúl, 4 sep 2026).
        if (attackLungeDistance > 0f && player)
        {
            Vector3 lungeDir = (player.position - transform.position); lungeDir.y = 0f;
            float currentDist = lungeDir.magnitude;
            if (currentDist > 0.0001f)
            {
                lungeDir /= currentDist;
                // No avanzar más allá de dejar el margen del attackRange, para no meterse dentro del jugador.
                float lungeDist = Mathf.Clamp(currentDist - attackRange * 0.5f, 0f, attackLungeDistance);
                if (lungeDist > 0f)
                {
                    Vector3 lungeTarget = transform.position + lungeDir * lungeDist;
                    if (agent && agent.isOnNavMesh) agent.Warp(lungeTarget);
                    else transform.position = lungeTarget;
                }
            }
        }

        // Esperar al momento del golpe (mitad de la animación)
        yield return new WaitForSeconds(0.3f);

        // Aplicar daño si el jugador sigue en rango
        if (player && Vector3.Distance(transform.position, player.position) <= attackRange * 1.2f)
        {
            DamagePlayer(damage);
        }

        // Esperar a que termine la animación
        yield return new WaitForSeconds(0.4f);

        isAttacking = false;

        // Volver a perseguir si el jugador sigue cerca
        if (player && Vector3.Distance(transform.position, player.position) <= detectionRange)
        {
            currentState = SpiderState.Chasing;
        }
        else
        {
            ExitChaseMode();
        }
    }

    private void DamagePlayer(float dmg)
    {
        if (!player) return;

        // Intentar con PlayerHealthSystem primero
        var playerHealth = player.GetComponent<PlayerHealthSystem>();
        if (playerHealth != null)
        {
            playerHealth.TakeDamage(dmg);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Spider1AI] Infligió {dmg} de daño al jugador");
#endif
            return;
        }

        // Fallback a IDamageable
        var damageable = player.GetComponent<IDamageable>();
        if (damageable != null && damageable.IsAlive)
        {
            damageable.TakeDamage(dmg);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Spider1AI] Infligió {dmg} de daño al jugador");
#endif
        }
    }

    private void LookAtPlayer()
    {
        if (!player) return;

        Vector3 direction = (player.position - transform.position).normalized;
        direction.y = 0;

        if (direction != Vector3.zero)
        {
            // Aplicar offset de rotación si el modelo está al revés
            Quaternion targetRotation = Quaternion.LookRotation(direction) * Quaternion.Euler(0, modelRotationOffset, 0);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime * 8f);
        }
    }

    private void LookAtDirection(Vector3 direction)
    {
        direction.y = 0;

        if (direction != Vector3.zero)
        {
            // Aplicar offset de rotación si el modelo está al revés
            Quaternion targetRotation = Quaternion.LookRotation(direction) * Quaternion.Euler(0, modelRotationOffset, 0);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, Time.deltaTime * 8f);
        }
    }

    private int _currentAnimHash = 0;
    private void PlayAnimation(int animHash)
    {
        if (!animator) return;
        if (_currentAnimHash == animHash) return; // no reiniciar cada frame
        _currentAnimHash = animHash;
        animator.Play(animHash, 0, 0f);
    }

    private void OnDamageTaken(float amount)
    {
        if (isDead) return;

        // FIX A11 (auditoría 2026-08-07): "Cancelar ataque en curso" antes llamaba a
        // StopCoroutineSafe(AttackPlayer()) — AttackPlayer() construye un IEnumerator NUEVO (no
        // ejecuta nada por sí solo) y StopCoroutineSafe era un no-op vacío: la corrutina de
        // ataque real (iniciada más arriba con StartCoroutine) seguía viva y aplicaba el daño de
        // todas formas aunque la araña acabara de recibir un golpe y entrara en stun. Ahora se
        // detiene la corrutina real, guardada en _attackCoroutine al iniciarla.
        isAttacking = false;
        if (_attackCoroutine != null)
        {
            StopCoroutine(_attackCoroutine);
            _attackCoroutine = null;
        }

        if (stopOnHit)
        {
            StartCoroutine(TakeDamageSequence());
        }
        else
        {
            // Opcional: reenganchar persecución directa según rango
            if (reacquireTargetAfterHit && player)
            {
                float distanceToPlayer = Vector3.Distance(transform.position, player.position);
                if (distanceToPlayer <= detectionRange * reacquireRangeMultiplier)
                    EnterChaseMode();
            }
        }
    }

    private IEnumerator TakeDamageSequence()
    {
        SpiderState previousState = currentState;
        currentState = SpiderState.TakingDamage;

        // Detener movimiento del agente durante el stun
        if (agent && agent.isOnNavMesh)
        {
            agent.isStopped = true;
            agent.velocity = Vector3.zero;
        }

        // Animación de impacto si existe, si no, Idle
        if (AnimHit != 0) PlayAnimation(AnimHit); else PlayAnimation(AnimIdle);

        // Empuje leve en dirección opuesta al jugador
        if (hitKnockback > 0f && player)
        {
            var rb = GetComponent<Rigidbody>();
            Vector3 dir = (transform.position - player.position); dir.y = 0f;
            if (dir.sqrMagnitude > 0.0001f) dir.Normalize(); else dir = -transform.forward;
            if (rb && !rb.isKinematic)
            {
                rb.AddForce(dir * hitKnockback, ForceMode.VelocityChange);
            }
        }

        // Stun configurable (no escalado por Time.timeScale)
        float t = 0f;
        while (t < hitStunSeconds)
        {
            t += Time.unscaledDeltaTime;
            yield return null;
        }

        if (isDead) yield break;

        // Reactivar movimiento
        if (agent && agent.isOnNavMesh)
            agent.isStopped = false;

        // Tras ser herida: re-evaluar objetivo
        if (reacquireTargetAfterHit && player && Vector3.Distance(transform.position, player.position) <= detectionRange * reacquireRangeMultiplier)
        {
            EnterChaseMode();
            ChasePlayer();
        }
        else
        {
            // Volver al estado anterior/patrulla de forma segura
            if (patrolEnabled) SetNewPatrolTarget(); else { currentState = SpiderState.Idle; idleTimer = RandomIdleTime(); }
        }
    }

    private void OnDeath()
    {
        if (isDead) return;

        isDead = true;
        currentState = SpiderState.Dead;

        if (_targetable != null) _targetable.isInActiveCombat = false;
        ActiveCombatRegistry.UnregisterNPC(gameObject);

        if (SintoniaEstelarService.Instance != null)
        {
            SintoniaEstelarService.Instance.SumarSintonia(15, transform.position);
        }

        if (agent && agent.isOnNavMesh)
        {
            agent.isStopped = true;
            agent.enabled = false;
        }

        StopAllCoroutines();
        PlayAnimation(AnimDeath);

        // Desactivar colisiones después de un momento
        StartCoroutine(DisableAfterDeath());
    }

    private IEnumerator DisableAfterDeath()
    {
        yield return new WaitForSeconds(1f);

        // Desactivar colisiones
        var colliders = GetComponentsInChildren<Collider>();
        foreach (var col in colliders)
        {
            col.enabled = false;
        }

        // Destruir después de un tiempo
        yield return new WaitForSeconds(3f);
        Destroy(gameObject);
    }

    // Debug visual
    void OnDrawGizmosSelected()
    {
        // Rango de detección
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, detectionRange);

        // Rango de ataque
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRange);

        // Radio de patrulla (desde spawn)
        if (Application.isPlaying)
        {
            Gizmos.color = Color.blue;
            Gizmos.DrawWireSphere(spawnPosition, patrolRadius);
        }
        else
        {
            Gizmos.color = Color.blue;
            Gizmos.DrawWireSphere(transform.position, patrolRadius);
        }
    }
}
