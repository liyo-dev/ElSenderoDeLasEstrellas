﻿﻿﻿namespace Sendero.Core.Feedback
{
    using UnityEngine;

    /// <summary>
    /// Servicio centralizado de feedbacks del juego (camera shake, VFX/SFX puntuales, etc.).
    /// - Orquesta llamadas y delega en proveedores especializados (Strategy pattern).
    /// - No mueve al jugador.
    /// - CameraShake actúa sobre la cámara especificada o la Main Camera por defecto.
    /// - Se auto-instancia (DontDestroyOnLoad) cuando se llama a cualquier método estático.
    /// </summary>
    public class FeedbackService : MonoBehaviour
    {
        private static FeedbackService _instance;

        // Proveedores (estrategias)
        private static ICameraShakeProvider _cameraShakeProvider;
        private static IScreenFlashProvider _screenFlashProvider;
        private static IHitStopProvider _hitStopProvider;
        private static IVfxProvider _vfxProvider;
        private static ISfxProvider _sfxProvider;
        private static DeathCameraEffect _deathCameraEffect;
        private static float _finDeLaVibracion;

#if UNITY_EDITOR
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics()
        {
            _instance = null;
            _cameraShakeProvider = null;
            _screenFlashProvider = null;
            _hitStopProvider = null;
            _vfxProvider = null;
            _sfxProvider = null;
            _deathCameraEffect = null;
            _finDeLaVibracion = 0f;
            _fadeRoot = null;
            _activeFadeRoutine = null;
        }
#endif

        // ===================== API PÚBLICA =====================

        // Camera Shake
        public static void CameraShake(float intensity, float duration)
        {
            if (intensity <= 0f || duration <= 0f) return;
            var inst = EnsureInstance();
            EnsureCameraShakeProvider().Shake(inst, intensity, duration);
        }

        /// <summary>
        /// Ejecuta un shake en una cámara específica.
        /// </summary>
        public static void CameraShake(Camera targetCamera, float intensity, float duration)
        {
            if (targetCamera == null || intensity <= 0f || duration <= 0f) return;
            var inst = EnsureInstance();
            EnsureCameraShakeProvider().Shake(inst, targetCamera, intensity, duration);
        }

        public static void CancelAllShakes() => _cameraShakeProvider?.CancelAll();

        public static void SetCameraShakeProvider(ICameraShakeProvider provider) => _cameraShakeProvider = provider;

        /// <summary>
        /// Vibración del mando: motores grave ('baja') y agudo ('alta') de 0 a 1 durante 'segundos'
        /// (tiempo real, no le afecta la cámara lenta). Respeta el ajuste de vibración. Un pulso
        /// nuevo sustituye al anterior.
        /// </summary>
        public static void Vibrar(float baja, float alta, float segundos)
        {
            if (segundos <= 0f || !PlayerSettings.Vibration) return;
            var mando = UnityEngine.InputSystem.Gamepad.current;
            if (mando == null) return;
            mando.SetMotorSpeeds(Mathf.Clamp01(baja), Mathf.Clamp01(alta));
            _finDeLaVibracion = Time.unscaledTime + segundos;
            EnsureInstance().StartCoroutine(Co_PararVibracion(_finDeLaVibracion));
        }

        private static System.Collections.IEnumerator Co_PararVibracion(float fin)
        {
            while (Time.unscaledTime < fin) yield return null;
            if (!Mathf.Approximately(fin, _finDeLaVibracion)) yield break;   // la sustituyó otra
            UnityEngine.InputSystem.Gamepad.current?.SetMotorSpeeds(0f, 0f);
        }

        private void OnDisable() => UnityEngine.InputSystem.Gamepad.current?.SetMotorSpeeds(0f, 0f);

        // Screen Flash
        public static void ScreenFlash(Color color, float duration)
        {
            if (duration <= 0f) return;
            var inst = EnsureInstance();
            EnsureScreenFlashProvider().Flash(inst, color, duration);
        }

        public static void SetScreenFlashProvider(IScreenFlashProvider provider) => _screenFlashProvider = provider;

        // Screen Fade (transición suave a/desde negro)
        /// <summary>
        /// Hace un fade de pantalla completa. fadeIn=true va de transparente a color, fadeIn=false va de color a transparente.
        /// </summary>
        // FIX M5 (auditoría 2026-08-07): ScreenFade lanzaba una corrutina nueva en cada llamada
        // sin cancelar una anterior todavía en curso. Con N llamadas solapadas, N corrutinas
        // escriben el mismo img.color a la vez y la pantalla puede quedarse en negro (o en
        // cualquier color a medias) según cuál termine última — no necesariamente la más reciente.
        private static Coroutine _activeFadeRoutine;

        public static void ScreenFade(Color color, float duration, bool fadeIn = true)
        {
            if (duration <= 0f) return;
            var inst = EnsureInstance();
            if (_activeFadeRoutine != null)
            {
                inst.StopCoroutine(_activeFadeRoutine);
                _activeFadeRoutine = null;
            }
            _activeFadeRoutine = inst.StartCoroutine(Co_ScreenFade(color, duration, fadeIn));
        }
        
        /// <summary>
        /// Versión async del fade de pantalla que permite hacer yield return.
        /// </summary>
        public static System.Collections.IEnumerator ScreenFadeAsync(Color color, float duration, bool fadeIn = true)
        {
            if (duration <= 0f) yield break;
            EnsureInstance();
            yield return Co_ScreenFade(color, duration, fadeIn);
        }

        /// Si la pantalla está tapada, cambia el color del fundido a 'color' (opaco) en 'duration',
        /// sin destaparla en ningún momento: p. ej. del blanco de un destello al negro de una
        /// transición. Si no está tapada, no hace nada.
        public static System.Collections.IEnumerator ScreenRecolorAsync(Color color, float duration)
        {
            if (!IsScreenFaded) yield break;
            var img = _fadeRoot.Image;
            var inst = EnsureInstance();
            if (_activeFadeRoutine != null && inst != null)
            {
                inst.StopCoroutine(_activeFadeRoutine);
                _activeFadeRoutine = null;
            }

            Color desde = img.color;
            Color hasta = color;
            hasta.a = 1f;
            float t = 0f;
            while (t < duration && img != null)
            {
                img.color = Color.Lerp(desde, hasta, t / duration);
                t += Time.unscaledDeltaTime;
                yield return null;
            }
            if (img != null) img.color = hasta;
        }

        /// <summary>
        /// Establece el overlay de fade de pantalla a un color exacto de forma instantánea, sin animación.
        /// Útil para poner la pantalla en negro antes de activar una nueva escena y evitar parpadeos.
        /// </summary>
        public static void SetScreenFadeImmediate(Color color)
        {
            // Con el telón cerrado nadie destapa (ver Telon). Tapar sí se puede siempre.
            if (color.a < 0.99f && Telon.Cerrado)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[FeedbackService] Destape inmediato ignorado: el telón está cerrado ({Telon.Describir()}).");
#endif
                return;
            }
            EnsureInstance();
            var root = EnsureFadeRoot();
            if (root?.Image != null) root.Image.color = color;
        }

        /// Color actual del lienzo de fundido, sin crear un lienzo si no existe.
        public static Color ColorDelFundido => _fadeRoot?.Image != null
            ? _fadeRoot.Image.color : Color.clear;

        /// Devuelve true si el overlay de fade está actualmente a opacidad completa (pantalla cubierta).
        public static bool IsScreenFaded
        {
            get
            {
                var root = _fadeRoot;
                return root?.Image != null && root.Image.color.a >= 0.99f;
            }
        }
        
        private static System.Collections.IEnumerator Co_ScreenFade(Color color, float duration, bool fadeIn)
        {
            var root = EnsureFadeRoot();
            if (root == null || root.Image == null) yield break;
            
            var img = root.Image;
            float elapsed = 0f;

            // Con el telón cerrado nadie destapa: un fundido de salida pedido ahora se ignora. El
            // telón destapará él solo cuando ya nadie lo retenga (ver Telon).
            if (!fadeIn && Telon.Cerrado)
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[FeedbackService] Fundido de salida ignorado: el telón está cerrado ({Telon.Describir()}).");
#endif
                yield break;
            }

            // Se parte de LO QUE HAY EN PANTALLA, no de cero (INC-323).
            //
            // Cubrir la pantalla arrancando siempre en alfa 0 significa que, si ya estaba negra,
            // el primer fotograma la deja transparente y se ve la escena antes de volver a
            // taparla. Es exactamente lo que Raul reporto en la novena grabacion: «cuando nos
            // vamos a negro vuelve a enfocarse la escena por un momento».
            //
            // Pasaba porque hay DOS fundidos seguidos y nadie lo habia mirado: el de la secuencia
            // (fase 8, «A NEGRO, y la explosion se oye DESPUES») y, detras, el cierre del propio
            // sistema —`Co_EndCinematicStayBlack`, que vuelve a llamar aqui con fadeIn: true para
            // garantizar que la cinematica termina en negro—. El segundo rebobinaba al primero.
            //
            // Partir del alfa actual es lo correcto en todos los casos: cubrir nunca puede
            // destapar. Y si ya esta cubierta, el fundido no hace nada visible, que es lo suyo.
            float desde = fadeIn ? img.color.a : color.a;
            float hasta = fadeIn ? color.a : 0f;

            while (elapsed < duration)
            {
                // Si a mitad de un destape alguien cierra el telón, se deja de destapar.
                if (!fadeIn && Telon.Cerrado) yield break;

                float t = elapsed / duration;
                var c = color;

                c.a = Mathf.Lerp(desde, hasta, t);
                
                img.color = c;
                elapsed += Time.unscaledDeltaTime;
                yield return null;
            }
            
            // Estado final
            var final = color;
            final.a = hasta;
            img.color = final;

            _activeFadeRoutine = null;
        }
        
        // Reutilizar el mismo sistema de overlay que Flash
        private class FadeRoot { public UnityEngine.UI.Image Image; }
        private static FadeRoot _fadeRoot;
        
        private static FadeRoot EnsureFadeRoot()
        {
            if (_fadeRoot != null && _fadeRoot.Image != null) return _fadeRoot;
            
            // Buscar si ya existe el FlashRoot y reutilizar su Image
            var flashGo = GameObject.Find("FS_ScreenFlash");
            if (flashGo != null)
            {
                var img = flashGo.GetComponentInChildren<UnityEngine.UI.Image>();
                if (img != null)
                {
                    _fadeRoot = new FadeRoot { Image = img };
                    return _fadeRoot;
                }
            }
            
            // Si no existe, crearlo
            var go = new GameObject("FS_ScreenFade");
            Object.DontDestroyOnLoad(go);
            
            var canvas = go.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 9998; // justo debajo del flash
            
            var cg = go.AddComponent<CanvasGroup>();
            cg.interactable = false;
            cg.blocksRaycasts = false;
            
            var imageGo = new GameObject("FadeImage");
            imageGo.transform.SetParent(go.transform, false);
            var image = imageGo.AddComponent<UnityEngine.UI.Image>();
            image.color = new Color(0, 0, 0, 0);
            
            var rt = image.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
            
            _fadeRoot = new FadeRoot { Image = image };
            return _fadeRoot;
        }

        // Hit Stop (pequeña pausa)
        public static void HitStop(float timeScale, float durationSeconds)
        {
            if (durationSeconds <= 0f) return;
            var inst = EnsureInstance();
            EnsureHitStopProvider().HitStop(inst, timeScale, durationSeconds);
        }

        public static void SetHitStopProvider(IHitStopProvider provider) => _hitStopProvider = provider;
        
        // Death Camera Effect (zoom + slowmotion cinematográfico)
        public static void TriggerDeathEffect(Transform target)
        {
            if (target == null) return;
            var inst = EnsureInstance();
            EnsureDeathCameraEffect().TriggerDeathEffect(target);
        }

        /// <summary>
        /// Variante configurable: permite a quien dispara el efecto (ej. NPCCombatLifecycleHandler)
        /// controlar el zoom y la duración del slow-mo por NPC, en vez de usar siempre los valores
        /// por defecto del componente. Pensado para sustituir un `Time.timeScale` manual y "seco"
        /// por el efecto cinematográfico ya existente (zoom + easing de entrada/salida).
        /// </summary>
        public static void TriggerDeathEffect(
            Transform target,
            float slowMotionScale,
            float holdDuration,
            float zoomFactor = 0.85f,
            float zoomDuration = 0.15f,
            float returnDuration = 0.35f)
        {
            if (target == null) return;
            var inst = EnsureInstance();
            var effect = EnsureDeathCameraEffect();
            effect.ConfigureEffect(zoomFactor, zoomDuration, holdDuration, returnDuration, slowMotionScale, holdDuration);
            effect.TriggerDeathEffect(target);
        }

        public static void CancelDeathEffect()
        {
            if (_deathCameraEffect != null)
                _deathCameraEffect.CancelEffect();
        }

        // VFX puntuales
        public static GameObject PlayVFX(GameObject prefab, Vector3 position, Quaternion rotation, float lifeTimeSeconds = 3f, Transform parent = null)
        {
            if (!prefab) return null;
            var inst = EnsureInstance();
            return EnsureVfxProvider().Play(inst, prefab, position, rotation, lifeTimeSeconds, parent);
        }

        public static void SetVfxProvider(IVfxProvider provider) => _vfxProvider = provider;

        // SFX puntuales — LEGACY: acepta un AudioClip directo y por tanto NO pasa por
        // AudioGraphProfile. No usar en código nuevo: usar AudioService.Instance.PlaySFX(eventKey, ...)
        // con una clave registrada en Assets/_AUDIOPROFILE/AudioGraphProfile.asset (ver ejemplo en
        // Assets/Scripts/Teleport/TeleportSystem.cs). Se mantiene solo por compatibilidad.
        public static void PlaySfx(AudioClip clip, Vector3 position, float volume = 1f)
        {
            if (!clip) return;
            var inst = EnsureInstance();
            EnsureSfxProvider().Play(inst, clip, position, Mathf.Clamp01(volume));
        }

        public static void SetSfxProvider(ISfxProvider provider) => _sfxProvider = provider;

        // ===================== Infraestructura =====================

        private static FeedbackService EnsureInstance()
        {
            if (_instance != null) return _instance;
            var go = new GameObject("FeedbackService");
            DontDestroyOnLoad(go);
            _instance = go.AddComponent<FeedbackService>();
            return _instance;
        }

        private static ICameraShakeProvider EnsureCameraShakeProvider()
        {
            if (_cameraShakeProvider == null)
                _cameraShakeProvider = new TransformPivotCameraShakeProvider();
            return _cameraShakeProvider;
        }

        private static IScreenFlashProvider EnsureScreenFlashProvider()
        {
            if (_screenFlashProvider == null)
                _screenFlashProvider = new UiOverlayScreenFlashProvider();
            return _screenFlashProvider;
        }

        private static IHitStopProvider EnsureHitStopProvider()
        {
            if (_hitStopProvider == null)
                _hitStopProvider = new SimpleHitStopProvider();
            return _hitStopProvider;
        }

        private static IVfxProvider EnsureVfxProvider()
        {
            if (_vfxProvider == null)
                _vfxProvider = new SimpleVfxProvider();
            return _vfxProvider;
        }

        private static ISfxProvider EnsureSfxProvider()
        {
            if (_sfxProvider == null)
                _sfxProvider = new SimpleSfxProvider();
            return _sfxProvider;
        }
        
        private static DeathCameraEffect EnsureDeathCameraEffect()
        {
            if (_deathCameraEffect == null)
            {
                var inst = EnsureInstance();
                _deathCameraEffect = inst.GetComponent<DeathCameraEffect>();
                if (_deathCameraEffect == null)
                {
                    _deathCameraEffect = inst.gameObject.AddComponent<DeathCameraEffect>();
                }
            }
            return _deathCameraEffect;
        }
    }
}
