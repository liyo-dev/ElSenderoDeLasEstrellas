using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Singleton service that exposes Player references without repeating expensive lookups.
/// Allows explicit player registration and performs lazy lookups when needed.
/// </summary>
// FIX Bajos (auditoría 2026-08-07): CLAUDE.md documenta -900 para PlayerService; el código tenía
// -600. Alineado al valor documentado (orden de inicialización temprano respecto a los sistemas
// que dependen de que el Player ya esté registrado).
[DefaultExecutionOrder(-900)]
[DisallowMultipleComponent]
public sealed class PlayerService : MonoBehaviour
{
    const string DefaultPlayerTag = "Player";

    static PlayerService _instance;
    static bool _isShuttingDown;

    [Tooltip("Optional manual reference to the player root. When empty the service locates it lazily.")]
    [SerializeField] private GameObject playerRoot;

    [Tooltip("Keep this service across scene loads (DontDestroyOnLoad).")]
    [SerializeField] private bool persistAcrossScenes = true;

    [Tooltip("Tag fallback used to locate the player when there is no explicit registration.")]
    [SerializeField] private string playerTag = DefaultPlayerTag;

    readonly Dictionary<Type, Component> _componentCache = new();

    // Lo que es del grupo y no del cuerpo (inventario, vestuario…). Ver GrupoDelJugador, INC-484.
    GameObject _grupo;

    public static event Action<GameObject> OnPlayerRegistered;
    public static event Action OnPlayerUnregistered;

#if UNITY_EDITOR
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    static void ResetStatics()
    {
        _instance = null;
        _isShuttingDown = false;
        OnPlayerRegistered = null;
        OnPlayerUnregistered = null;
    }
#endif

    public static PlayerService Instance
    {
        get
        {
            if (_isShuttingDown)
                return _instance;
            if (_instance != null)
                return _instance;
            return CreateRuntimeInstance();
        }
    }
    public static bool HasInstance => _instance != null;
    public static GameObject Player => Instance != null ? Instance.JugadorVigente() : null;
    public static Transform PlayerTransform => TryGetComponent(out Transform result) ? result : null;

    void Awake()
    {
        if (_instance != null && _instance != this)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[PlayerService] Instancia duplicada detectada en '{name}'. Se destruye el duplicado.");
#endif
            Destroy(gameObject);
            return;
        }

        _instance = this;
        _isShuttingDown = false;

        if (persistAcrossScenes)
            DontDestroyOnLoad(gameObject);

        ServiceLocator.Register(this);

        if (playerRoot != null)
            InternalRegister(playerRoot, true);
    }

    void OnDestroy()
    {
        if (_instance == this)
        {
            _instance = null;
            _componentCache.Clear();
            playerRoot = null;
            _isShuttingDown = true;

            ServiceLocator.Unregister(this);
        }
    }

    void OnApplicationQuit()
    {
        _isShuttingDown = true;
    }

    static PlayerService CreateRuntimeInstance()
    {
        var go = new GameObject(nameof(PlayerService));
        return go.AddComponent<PlayerService>();
    }

    /// <summary>
    /// Registra el GameObject del jugador y cachea componentes comunes.
    /// </summary>
    public static void RegisterPlayer(GameObject player, bool overwriteExisting = true)
    {
        if (player == null || _isShuttingDown) return;
        var inst = Instance;
        if (inst == null) return;
        inst.InternalRegister(player, overwriteExisting);
    }

    /// <summary>
    /// Registra manualmente un componente del jugador (Aotil para componentes creados en runtime).
    /// </summary>
    public static void RegisterComponent(Component component, bool overwriteExisting = true)
    {
        if (component == null || _isShuttingDown) return;
        var inst = Instance;
        if (inst == null) return;
        inst.InternalRegisterComponent(component, overwriteExisting);
    }

    /// <summary>
    /// Registra el objeto del grupo (GrupoDelJugador). TryGetComponent busca en él lo que no
    /// encuentra en el cuerpo del jugador.
    /// </summary>
    public static void RegistrarGrupo(GameObject grupo)
    {
        if (grupo == null || _isShuttingDown) return;
        var inst = Instance;
        if (inst == null) return;
        inst._grupo = grupo;
    }

    public static void QuitarGrupo(GameObject grupo)
    {
        if (_isShuttingDown || !HasInstance) return;
        if (_instance._grupo == grupo) _instance._grupo = null;
    }

    /// <summary>
    /// Limpia la referencia al jugador si coincide con la instancia registrada.
    /// </summary>
    public static void UnregisterPlayer(GameObject player)
    {
        if (_isShuttingDown || player == null) return;
        if (!HasInstance) return;
        Instance.InternalUnregister(player);
    }

    /// <summary>
    /// Obtiene el GameObject del jugador. Si no existe registro, intenta localizarlo en escena (una Aonica vez).
    /// </summary>
    public static bool TryGetPlayer(out GameObject player, bool allowSceneLookup = true)
    {
        player = null;
        if (_isShuttingDown)
            return false;
        var inst = Instance;
        if (inst == null) return false;
        return inst.TryGetPlayerInternal(out player, allowSceneLookup);
    }

    /// <summary>
    /// Obtiene un componente asociado al jugador utilizando la cachA interna. Si no estA disponible, se intenta localizar y cachear.
    /// </summary>
    public static bool TryGetComponent<T>(out T component, bool includeInactive = true, bool allowSceneLookup = true) where T : Component
    {
        component = null;
        if (_isShuttingDown)
            return false;
        var inst = Instance;
        if (inst == null) return false;
        return inst.TryGetComponentInternal(out component, includeInactive, allowSceneLookup);
    }

    public static bool TryGetInventory(out Inventory inventory, bool includeInactive = true, bool allowSceneLookup = true)
        => TryGetComponent(out inventory, includeInactive, allowSceneLookup);

    public static bool TryGetWardrobe(out WardrobeInventory wardrobe, bool includeInactive = true, bool allowSceneLookup = true)
        => TryGetComponent(out wardrobe, includeInactive, allowSceneLookup);

    /// <summary>
    /// Variante que lanza excepciA3n si el componente no existe. Astil para dependencias obligatorias.
    /// </summary>
    public static T RequireComponent<T>(bool includeInactive = true, bool allowSceneLookup = true) where T : Component
    {
        if (TryGetComponent<T>(out var component, includeInactive, allowSceneLookup))
            return component;

        throw new InvalidOperationException($"[PlayerService] No se pudo resolver el componente '{typeof(T).Name}'. AsegAorate de registrar el Player correctamente.");
    }

    void InternalRegister(GameObject player, bool overwriteExisting)
    {
        player = ResolverCuerpo(player);
        if (!overwriteExisting && playerRoot != null && playerRoot != player)
            return;

        playerRoot = player;
        _componentCache.Clear();
        CacheDefaultComponents(playerRoot);
        OnPlayerRegistered?.Invoke(playerRoot);
    }

    void InternalRegisterComponent(Component component, bool overwriteExisting)
    {
        if (component == null) return;

        var type = component.GetType();
        if (!overwriteExisting && _componentCache.TryGetValue(type, out var existing) && existing != null && existing != component)
            return;

        _componentCache[type] = component;
    }

    void InternalUnregister(GameObject player)
    {
        player = ResolverCuerpo(player);
        if (playerRoot != player) return;

        playerRoot = null;
        _componentCache.Clear();
        OnPlayerUnregistered?.Invoke();
    }

    // Si el cuerpo registrado se ha destruido (la escena se recargó después de registrarlo), se
    // olvida y se busca el nuevo una vez. Sin esto, quien registrara al jugador pronto dejaba a
    // `Player` devolviendo un objeto muerto para siempre. Ver INC-484.
    GameObject JugadorVigente()
    {
        if (playerRoot == null && !ReferenceEquals(playerRoot, null))
        {
            playerRoot = null;
            _componentCache.Clear();
            TryGetPlayerInternal(out _, true);
        }
        return playerRoot;
    }

    bool TryGetPlayerInternal(out GameObject player, bool allowSceneLookup)
    {
        if (playerRoot == null && allowSceneLookup)
        {
            var located = LocatePlayerInScene();
            if (located != null)
                InternalRegister(located, true);
        }

        player = playerRoot;
        return player != null;
    }

    bool TryGetComponentInternal<T>(out T component, bool includeInactive, bool allowSceneLookup) where T : Component
    {
        if (_componentCache.TryGetValue(typeof(T), out var cached) && cached != null)
        {
            component = cached as T;
            if (component != null && component) return true;
            _componentCache.Remove(typeof(T));
        }

        if (playerRoot == null && allowSceneLookup)
        {
            TryGetPlayerInternal(out _, true);
        }

        if (playerRoot != null)
        {
            component = includeInactive
                ? playerRoot.GetComponentInChildren<T>(true)
                : playerRoot.GetComponentInChildren<T>();

            if (component != null)
            {
                _componentCache[typeof(T)] = component;
                return true;
            }
        }

        if (_grupo != null)
        {
            component = _grupo.GetComponentInChildren<T>(includeInactive);
            if (component != null)
            {
                _componentCache[typeof(T)] = component;
                return true;
            }
        }

        component = null;
        return false;
    }

    /// El jugador es el cuerpo que se mueve, el que lleva el controller: la raíz del prefab del
    /// personaje es un contenedor que no se mueve en Play. Si se registra la raíz, se baja al cuerpo.
    /// Ver INC-482.
    static GameObject ResolverCuerpo(GameObject candidato)
    {
        if (candidato == null) return null;
        var controller = candidato.GetComponentInChildren<Invector.vCharacterController.vThirdPersonController>(true);
        return controller != null ? controller.gameObject : candidato;
    }

    void CacheDefaultComponents(GameObject player)
    {
        if (player == null) return;

        InternalRegisterComponent(player.transform, true);
        CacheIfPresent<PlayerHealthSystem>(player);
        CacheIfPresent<ManaPool>(player);
        CacheIfPresent<MagicCaster>(player);
        CacheIfPresent<PlayerActionManager>(player);
        CacheIfPresent<ModularAutoBuilder>(player);
        CacheIfPresent<PlayerPickupCollector>(player);
    }

    void CacheIfPresent<T>(GameObject root) where T : Component
    {
        var comp = root.GetComponentInChildren<T>(true);
        if (comp != null)
            _componentCache[typeof(T)] = comp;
    }

    GameObject LocatePlayerInScene()
    {
        GameObject byTag = null;
        if (!string.IsNullOrWhiteSpace(playerTag))
        {
            try
            {
                byTag = GameObject.FindGameObjectWithTag(playerTag);
            }
            catch (UnityException)
            {
                // El Tag no existe: silenciar la excepciA3n y continuar con los fallback.
            }
        }

        if (byTag != null) return byTag;

        var health = ServiceLocator.Get<PlayerHealthSystem>(false);
        if (health != null) return health.gameObject;

        var manaPool = ServiceLocator.Get<ManaPool>(false);
        if (manaPool != null) return manaPool.gameObject;

        return null;
    }
}

