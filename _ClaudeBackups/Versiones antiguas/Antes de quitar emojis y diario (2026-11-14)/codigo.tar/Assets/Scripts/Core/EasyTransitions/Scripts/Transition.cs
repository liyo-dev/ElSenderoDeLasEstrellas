using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace EasyTransition
{

    public class Transition : MonoBehaviour
    {
        public TransitionSettings transitionSettings;
        
        public Transform transitionPanelIN;
        public Transform transitionPanelOUT;

        public CanvasScaler transitionCanvas;

        public Material multiplyColorMaterial;
        public Material additiveColorMaterial;

        bool hasTransitionTriggeredOnce;

        private void Start()
        {
            //Making sure not to destroy the transition when a new scene gets load
            DontDestroyOnLoad(gameObject);

            //Setting the resolution of the transition canvas
            transitionCanvas.referenceResolution = transitionSettings.refrenceResolution;

            transitionPanelIN.gameObject.SetActive(false);
            transitionPanelOUT.gameObject.SetActive(false);

            //Setting up the transition objects
            transitionPanelIN.gameObject.SetActive(true);
            GameObject transitionIn = Instantiate(transitionSettings.transitionIn, transitionPanelIN);
            transitionIn.AddComponent<CanvasGroup>().blocksRaycasts = transitionSettings.blockRaycasts;

            //Setting the materials
            multiplyColorMaterial = transitionSettings.multiplyColorMaterial;
            additiveColorMaterial = transitionSettings.addColorMaterial;

            //Checking if the materials were correctly set
            if (multiplyColorMaterial == null || additiveColorMaterial == null)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.LogWarning("There are no color tint materials set for the transition. Changing the color tint will not affect the transition anymore!");
#endif
                }

            //Changing the color of the transition
            if (!transitionSettings.isCutoutTransition)
            {
                if (transitionIn.TryGetComponent<Image>(out Image parentImage))
                {
                    if (transitionSettings.colorTintMode == ColorTintMode.Multiply)
                    {
                        parentImage.material = multiplyColorMaterial;
                        parentImage.material.SetColor("_Color", transitionSettings.colorTint);
                    }
                    else if (transitionSettings.colorTintMode == ColorTintMode.Add)
                    {
                        parentImage.material = additiveColorMaterial;
                        parentImage.material.SetColor("_Color", transitionSettings.colorTint);
                    }
                }
                for (int i = 0; i < transitionIn.transform.childCount; i++)
                {
                    if (transitionIn.transform.GetChild(i).TryGetComponent<Image>(out Image childImage))
                    {
                        if (transitionSettings.colorTintMode == ColorTintMode.Multiply)
                        {
                            childImage.material = multiplyColorMaterial;
                            childImage.material.SetColor("_Color", transitionSettings.colorTint);
                        }
                        else if (transitionSettings.colorTintMode == ColorTintMode.Add)
                        {
                            childImage.material = additiveColorMaterial;
                            childImage.material.SetColor("_Color", transitionSettings.colorTint);
                        }
                    }
                }
            }

            //Flipping the scale if needed
            if (transitionSettings.flipX)
                transitionIn.transform.localScale = new Vector3(-transitionIn.transform.localScale.x, transitionIn.transform.localScale.y, transitionIn.transform.localScale.z);
            if (transitionSettings.flipY)
                transitionIn.transform.localScale = new Vector3(transitionIn.transform.localScale.x, -transitionIn.transform.localScale.y, transitionIn.transform.localScale.z);

            //Changing the animator speed
            if (transitionIn.TryGetComponent<Animator>(out Animator parentAnim) && transitionSettings.transitionSpeed != 0)
                parentAnim.speed = transitionSettings.transitionSpeed;
            else
            {
                for (int c = 0; c < transitionIn.transform.childCount; c++)
                {
                    if(transitionIn.transform.GetChild(c).TryGetComponent<Animator>(out Animator childAnim) && transitionSettings.transitionSpeed != 0)
                        childAnim.speed = transitionSettings.transitionSpeed;
                }
            }

            //Adding the funcion OnSceneLoad() to the sceneLoaded action
            SceneManager.sceneLoaded += OnSceneLoad;
        }

        // FIX A7 (auditoría 2026-08-07): sin este OnDestroy, la suscripción a sceneLoaded era
        // permanente — el objeto se destruye con Destroy(gameObject, destroyTime) pero nunca se
        // desuscribía, con lo que instancias viejas de Transition seguían vivas como listeners
        // (aunque su propio hasTransitionTriggeredOnce ya estuviera en true, cada carga de escena
        // futura invocaba igualmente su OnSceneLoad, coste creciente por transición jugada).
        private void OnDestroy()
        {
            SceneManager.sceneLoaded -= OnSceneLoad;
        }

        public void OnSceneLoad(Scene scene, LoadSceneMode mode)
        {
            //Checking if this transition instance has allready played
            if (hasTransitionTriggeredOnce) return;

            // FIX A7 (auditoría 2026-08-07): el proyecto usa carga aditiva multi-escena (ver
            // CLAUDE.md). Sin este filtro, cualquier escena cargada en modo Additive mientras esta
            // transición espera su propia carga (Single, normalmente) disparaba OnSceneLoad de
            // forma prematura — la transición "salía" (Fase OUT) antes de que la escena de destino
            // real hubiera terminado de cargar.
            if (mode == LoadSceneMode.Additive) return;


            transitionPanelIN.gameObject.SetActive(false);

            //Setting up the transition
            transitionPanelOUT.gameObject.SetActive(true);
            GameObject transitionOut = Instantiate(transitionSettings.transitionOut, transitionPanelOUT);
            transitionOut.AddComponent<CanvasGroup>().blocksRaycasts = transitionSettings.blockRaycasts;

            //Changing the color of the transition
            if (!transitionSettings.isCutoutTransition)
            {
                if (transitionOut.TryGetComponent<Image>(out Image parentImage))
                {
                    if (transitionSettings.colorTintMode == ColorTintMode.Multiply)
                    {
                        parentImage.material = multiplyColorMaterial;
                        parentImage.material.SetColor("_Color", transitionSettings.colorTint);
                    }
                    else if (transitionSettings.colorTintMode == ColorTintMode.Add)
                    {
                        parentImage.material = additiveColorMaterial;
                        parentImage.material.SetColor("_Color", transitionSettings.colorTint);
                    }
                }
                for (int i = 0; i < transitionOut.transform.childCount; i++)
                {
                    if (transitionOut.transform.GetChild(i).TryGetComponent<Image>(out Image childImage))
                    {
                        if (transitionSettings.colorTintMode == ColorTintMode.Multiply)
                        {
                            childImage.material = multiplyColorMaterial;
                            childImage.material.SetColor("_Color", transitionSettings.colorTint);
                        }
                        else if (transitionSettings.colorTintMode == ColorTintMode.Add)
                        {
                            childImage.material = additiveColorMaterial;
                            childImage.material.SetColor("_Color", transitionSettings.colorTint);
                        }
                    }
                }
            }

            //Flipping the scale if needed
            if (transitionSettings.flipX)
                transitionOut.transform.localScale = new Vector3(-transitionOut.transform.localScale.x, transitionOut.transform.localScale.y, transitionOut.transform.localScale.z);
            if (transitionSettings.flipY)
                transitionOut.transform.localScale = new Vector3(transitionOut.transform.localScale.x, -transitionOut.transform.localScale.y, transitionOut.transform.localScale.z);

            //Changeing the animator speed
            if (transitionOut.TryGetComponent<Animator>(out Animator parentAnim) && transitionSettings.transitionSpeed != 0)
                parentAnim.speed = transitionSettings.transitionSpeed;
            else
            {
                for (int c = 0; c < transitionOut.transform.childCount; c++)
                {
                    if (transitionOut.transform.GetChild(c).TryGetComponent<Animator>(out Animator childAnim) && transitionSettings.transitionSpeed != 0)
                        childAnim.speed = transitionSettings.transitionSpeed;
                }
            }

            //Turning on a safety switch so this transition instance cannot be triggered more than once
            hasTransitionTriggeredOnce = true;

            //Adjusting the destroy time if needed
            float destroyTime = transitionSettings.destroyTime;
            if (transitionSettings.autoAdjustTransitionTime)
                destroyTime = destroyTime / transitionSettings.transitionSpeed;

            //Destroying the transition
            Destroy(gameObject, destroyTime);
        }

        // FIX (14 sep 2026, reporte de Raúl — "al salir de la casa de Will la transición se queda
        // pillada casi terminando, efecto muy feo"): hasta ahora, si esta instancia quedaba
        // huérfana a mitad de su revelado (p. ej. por la carrera con la descarga aditiva del
        // interior descrita en incidencia-transicion-pillada-interiores-aditivo-2026-09-12), el
        // watchdog de TeleportService solo podía resetear los flags lógicos
        // (_sTransitionInProgress / runningTransition) — no tenía forma de tocar ESTE overlay
        // concreto, así que la pantalla se quedaba visualmente atascada aunque el jugador y los
        // teleports futuros ya estuvieran desbloqueados (limitación conocida, documentada en esa
        // misma incidencia). Este método, llamado desde
        // TransitionManager.ForceCompleteCurrentTransition() cuando el watchdog se dispara, oculta
        // los paneles a mano y se autodestruye, sin depender de que la animación de revelado (que
        // corre en tiempo escalado por Animator, no en el WaitForSecondsRealtime de la corrutina de
        // TransitionManager) llegue a completarse por su cuenta.
        public void ForceComplete()
        {
            hasTransitionTriggeredOnce = true;
            if (transitionPanelIN) transitionPanelIN.gameObject.SetActive(false);
            if (transitionPanelOUT) transitionPanelOUT.gameObject.SetActive(false);
            Destroy(gameObject);
        }
    }

}
