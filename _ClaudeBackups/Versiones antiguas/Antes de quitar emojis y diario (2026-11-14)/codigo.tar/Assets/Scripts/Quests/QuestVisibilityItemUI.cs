using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class QuestVisibilityItemUI : MonoBehaviour
{
    [Header("Refs")]
    [SerializeField] private TextMeshProUGUI questName;
    [SerializeField] private TextMeshProUGUI questState;
    [SerializeField] private TextMeshProUGUI questDescription;
    [SerializeField] private Image statePillBg;
    
    [Header("Buttons")]
    [Tooltip("Botón para archivar la misión (se muestra solo en panel de visibles)")]
    [SerializeField] private Button archiveButton;
    [Tooltip("Botón para activar/seguir la misión (se muestra solo en panel de archivados)")]
    [SerializeField] private Button activateButton;
    
    [Header("Sprites State Pill")]
    [Tooltip("Sprite del state pill cuando la quest está activa (azul)")]
    [SerializeField] private Sprite statePillSpriteActive;
    [Tooltip("Sprite del state pill cuando la quest está completada (verde)")]
    [SerializeField] private Sprite statePillSpriteCompleted;

    private QuestManager.RuntimeQuest _data;
    private Action<QuestManager.RuntimeQuest, QuestVisibility> _onChange;
    private QuestVisibility _currentVisibility;
    private ScrollRect _scrollRect;
    // PERF (7 sept 2026): con el pool nuevo de QuestMainMenuUI.Rebuild() esta fila puede
    // reutilizarse entre misiones con distinto QuestState -- antes (Destroy+Instantiate
    // en cada apertura) cada fila arrancaba siempre con el sprite por defecto del prefab,
    // asi que un estado sin sprite propio (Inactive/Failed) nunca se notaba. Se guarda el
    // sprite original del prefab la primera vez para poder volver a el cuando el estado
    // actual no tiene sprite dedicado, y que una fila reciclada no se quede pegada al
    // sprite (p.ej. "Completada") de la mision que tenia antes.
    private Sprite _defaultStatePillSprite;
    private bool _defaultStatePillCaptured;
    
    public Button GetArchiveButton() => archiveButton;
    public Button GetActivateButton() => activateButton;

    public void Bind(
        QuestManager.RuntimeQuest data,
        QuestVisibility visibility,
        Action<QuestManager.RuntimeQuest, QuestVisibility> onChange)
    {
        _data = data;
        _onChange = onChange;
        _currentVisibility = visibility;

        if (questName)
        {
            var display = data.Data.GetLocalizedName();
            questName.text = string.IsNullOrEmpty(display) ? data.Id : display;
        }

        if (questDescription)
        {
            // Panel de detalle de misión: usa la descripción detallada (guía completa,
            // con todos los pasos explicados) en vez de la descripción corta que ya
            // se muestra en el menú rápido de misiones.
            var description = data.Data.GetLocalizedDetailedDescription();
            questDescription.text = string.IsNullOrEmpty(description) ? string.Empty : description;
        }

        if (questState)
        {
            questState.text = GetStateLabel(data.State);
        }

        // Aplicar sprite del state pill según el estado
        if (statePillBg != null)
        {
            if (!_defaultStatePillCaptured)
            {
                _defaultStatePillSprite = statePillBg.sprite;
                _defaultStatePillCaptured = true;
            }

            switch (data.State)
            {
                case QuestState.Active:
                    statePillBg.sprite = statePillSpriteActive != null ? statePillSpriteActive : _defaultStatePillSprite;
                    break;

                case QuestState.Completed:
                    statePillBg.sprite = statePillSpriteCompleted != null ? statePillSpriteCompleted : _defaultStatePillSprite;
                    break;

                default:
                    // Inactive/Failed no tienen sprite dedicado -- volver al de fabrica
                    // del prefab en vez de dejar el de la mision anterior en esta fila
                    // reciclada.
                    statePillBg.sprite = _defaultStatePillSprite;
                    break;
            }
        }

        // Configurar botones según el panel actual
        if (visibility == QuestVisibility.Visible)
        {
            // Panel de visibles → Solo mostrar botón "Archivar"
            ConfigureButton(archiveButton, QuestVisibility.Hidden, "UI_ARCHIVAR");
            if (activateButton) activateButton.gameObject.SetActive(false);
        }
        else // QuestVisibility.Hidden
        {
            // Panel de archivados → Solo mostrar botón "Activar"
            ConfigureButton(activateButton, QuestVisibility.Visible, "UI_ACTIVAR");
            if (archiveButton) archiveButton.gameObject.SetActive(false);
        }

        DisableUnusedButtons();
    }

    public void ConfigureScrollRect(ScrollRect scrollRect)
    {
        _scrollRect = scrollRect;
        AttachScrollRelay(archiveButton);
        AttachScrollRelay(activateButton);
    }

    /// <summary>
    /// Configura un botón para cambiar la visibilidad de la quest
    /// </summary>
    /// <param name="actionKey">
    /// FIX 4 sep 2026 (petición de Raúl: "estoy en ingles y sale Archivar" — el botón de archivar
    /// del panel de misiones salía siempre en español, incluso jugando en inglés). Antes este
    /// parámetro se llamaba "actionName" y llegaba con el texto en español a pelo ("Archivar"/
    /// "Activar") — pero el método nunca llegó a usarlo para nada, así que el texto real del botón
    /// dependía por completo de que el LocalizedText de su prefab hiciera su trabajo por su cuenta,
    /// sin ninguna red de seguridad. Ahora es la CLAVE del catálogo (UI_ARCHIVAR/UI_ACTIVAR) y se
    /// aplica aquí explícitamente cada vez que se configura la fila — con el idioma que esté activo
    /// en ese momento — en vez de depender solo del componente del prefab.
    /// </param>
    void ConfigureButton(Button button, QuestVisibility targetVisibility, string actionKey)
    {
        if (button == null) return;

        button.gameObject.SetActive(true);
        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(() => NotifyChange(targetVisibility));
        button.interactable = true;

        var label = button.GetComponentInChildren<TextMeshProUGUI>(true);
        if (label != null && LocalizationManager.Instance != null)
            label.text = LocalizationManager.Instance.Get(actionKey, label.text);

        EnsureTextHighlight(button);
    }

    void NotifyChange(QuestVisibility visibility)
    {
        if (_data == null) return;
        if (visibility == _currentVisibility) return;

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"QuestVisibilityItemUI: NotifyChange for '{_data.Id}' -> {visibility}");
#endif

        _currentVisibility = visibility;
        _onChange?.Invoke(_data, visibility);
    }

    void DisableUnusedButtons()
    {
        foreach (var button in GetComponentsInChildren<Button>(true))
        {
            if (button == archiveButton || button == activateButton) continue;
            button.gameObject.SetActive(false);
        }
    }

    string GetStateLabel(QuestState state)
    {
        string fallback = state switch
        {
            QuestState.Inactive => "Inactiva",
            QuestState.Active => "Activa",
            QuestState.Completed => "Completada",
            _ => state.ToString()
        };

        if (LocalizationManager.Instance != null)
        {
            string key = state switch
            {
                QuestState.Inactive => "QUEST_STATE_INACTIVE",
                QuestState.Active => "QUEST_STATE_ACTIVE",
                QuestState.Completed => "QUEST_STATE_COMPLETED",
                _ => string.Empty
            };

            if (!string.IsNullOrEmpty(key))
                fallback = LocalizationManager.Instance.Get(key, fallback);
        }

        return fallback;
    }

    void EnsureTextHighlight(Button button)
    {
        if (button == null) return;

        var tmpLabels = new List<TextMeshProUGUI>();
        button.GetComponentsInChildren(includeInactive: true, tmpLabels);
        foreach (var label in tmpLabels)
        {
            if (label == null) continue;
            var highlight = label.GetComponent<MenuTextHighlight>();
            if (highlight == null)
                highlight = label.gameObject.AddComponent<MenuTextHighlight>();

            highlight.selectionOwner = button.gameObject;
        }
    }


    void AttachScrollRelay(Selectable selectable)
    {
        if (selectable == null || _scrollRect == null) return;
        var relay = selectable.gameObject.GetComponent<ScrollOnSelectRelay>();
        if (relay == null)
            relay = selectable.gameObject.AddComponent<ScrollOnSelectRelay>();
        relay.scrollRect = _scrollRect;
        relay.target = transform as RectTransform;
    }
}
