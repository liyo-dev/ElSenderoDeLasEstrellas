using UnityEngine;

/// <summary>
/// Proyectil mágico que se lanza desde MagicProjectileSpawner.
/// Maneja movimiento, colisiones, daño y efectos visuales/sonoros.
/// </summary>
[DisallowMultipleComponent]
[RequireComponent(typeof(Collider))]
public class MagicProjectile : MonoBehaviour, IDevolvible
{
    // ==== Config que inyecta el Spawner (no hay referencia a SO) =============

    [System.Serializable]
    public struct ProjectileConfig
    {
        // Daño / impacto
        public float damage;
        public float aoeRadius;          // 0 = impacto directo
        public float knockbackForce;     // 0 = sin empuje
        public LayerMask hitLayers;      // Capas que reciben daño (Enemy, Boss, etc.)
        public LayerMask collisionLayers; // Capas con las que colisiona (Enemy, Default, etc.)
        public bool destroyOnHit;

        // Vida / movimiento
        public float lifeTime;           // 0 = infinito
        public float maxRange;           // 0 = infinito
        public float initialSpeed;       // usado si NO hay Rigidbody
        public bool  useGravity;         // si hay Rigidbody

        // VFX (opcionales)
        public GameObject impactVFX;     // al impactar
        public GameObject despawnVFX;    // al morir sin impacto (TTL/rango)
        public float vfxLifetime;        // tiempo antes de destruir VFX (0 = no destruir)
        
        // Audio
        public string impactSFXKey;      // clave SFX al impactar
        public AudioEventSO impactEvent; // evento por capas al impactar (si tiene capas, sustituye a la clave)
        
        // Elemento de magia (para interacciones con puzzle)
    public MagicElement element;     // Elemento que reciben las piezas del mundo.

        // Modo preciso (Paso 5/6 del refactor Tramo 1): true si este proyectil concreto es la
        // variante "precisa" de un hechizo con MagicSpellSO.supportsPreciseMode (mantener el
        // botón), construida por MagicSpellSO.BuildPreciseVariant(). La lee, por ejemplo,
        // RuneCollar (Paso 6) para decidir si un impacto rompe el aro del demonio o no.
        public bool isPrecise;
    }

    // ==== Estado ===============================================================
    Rigidbody _rb;
    bool      _hasRb;
    bool      _ended;
    bool      _movementEnabled = true;

    ProjectileConfig _cfg;
    GameObject       _instigator;

    // Proyectil mejorado (INC-497): rebote, perforar y zona al impactar.
    int          _bouncesLeft;
    float        _bounceRange;
    int          _pierceLeft;
    MagicSpellSO _impactZone;
    MagicSpellSO _statusSpell;   // estado que pone al impactar (INC-499)
    float _abreProteccion;       // segundos que abre la protección de lo que alcanza (INC-724)
    GameObject _vfxProteccion;
    LayerMask    _zoneLayers;
    float        _zoneDamageMultiplier = 1f;
    readonly System.Collections.Generic.HashSet<Transform> _alreadyHit = new System.Collections.Generic.HashSet<Transform>();
    readonly System.Collections.Generic.HashSet<Transform> _aoeTargets = new System.Collections.Generic.HashSet<Transform>();
    static readonly Collider[] s_bounceBuffer = new Collider[24];
    // La máscara se calcula la primera vez que se usa: Unity no permite LayerMask.GetMask en
    // inicializadores de campo ni constructores estáticos de un MonoBehaviour. Ver INC-626.
    static int  s_bounceMask;
    static bool s_bounceMaskReady;
    static int BounceMask
    {
        get
        {
            if (!s_bounceMaskReady)
            {
                s_bounceMask = LayerMask.GetMask("Enemy", "Boss");
                s_bounceMaskReady = true;
            }
            return s_bounceMask;
        }
    }

    Vector3 _spawnPos;
    float   _spawnTime;

    // Corrección de rumbo hacia el objetivo fijado (INC-1147).
    Transform  _guia;
    Damageable _vidaDeLaGuia;
    Vector3    _centroLocalDeLaGuia;
    float      _gradosDeGuia;

    /// <summary>Daño configurado de este proyectil (usado p. ej. por ProjectileCollisionHandler al sumar daños en un choque de hechizos).</summary>
    public float Damage => _cfg.damage;
    /// <summary>Quién lanzó el proyectil (puede ser null). Lo usa el contraataque (INC-493).</summary>
    public GameObject Instigator => _instigator;
    public GameObject Lanzador => _instigator;
    /// <summary>Elemento del hechizo (lo conserva la bola si se devuelve con la B).</summary>
    public MagicElement Elemento => _cfg.element;
    public float DanoEntrante => Damage;
    public void Devolver(GameObject nuevoDueno, Transform objetivo, Vector3 direccionSiNoHayObjetivo, float dano)
    {
        if (_ended || AmenazasAlJugador.EsDelGrupoDelJugador(_instigator)) return;
        float velocidad = VelocidadDeAmenaza.magnitude;
        _ended = true;
        var devuelto = GetComponent<ProyectilDevuelto>() ?? gameObject.AddComponent<ProyectilDevuelto>();
        devuelto.TomarControl(this, nuevoDueno, objetivo, direccionSiNoHayObjetivo, velocidad, dano, _cfg.impactVFX, _instigator);
    }

    // Amenaza para el aviso de combate (INC-666): solo si lo lanza alguien ajeno al grupo.
    public Vector3 PosicionDeAmenaza => transform.position;
    public Vector3 VelocidadDeAmenaza => _hasRb ? _rb.linearVelocity : transform.forward * _cfg.initialSpeed;
    public TipoDeAmenaza TipoDeAmenaza => TipoDeAmenaza.Devolvible;

    void OnDisable() => AmenazasAlJugador.Quitar(this);

    /// <summary>true si este proyectil es la variante precisa de un hechizo con modo preciso (ver
    /// ProjectileConfig.isPrecise / MagicSpellSO.BuildPreciseVariant). Usado por RuneCollar.</summary>
    public bool IsPrecise => _cfg.isPrecise;
    
    // Buffer reutilizable para AOE
    private Collider[] _aoeHitBuffer = new Collider[32];

    // Grace period: ignora colisiones los primeros N segundos tras el spawn
    private float _spawnGraceEnd;
    // Guard I16: evita doble daño en el mismo frame
    private Collider _lastDamagedCollider;
    private int _lastDamagedFrame;
    
    [Header("Lifetime (optional)")]
    [Tooltip("If > 0, overrides the spell lifetime and this projectile will auto-despawn after these seconds.")]
    [SerializeField, Min(0f)] private float lifeTimeSeconds = 0f;

    // ==== Ciclo de vida ========================================================
    void Awake()
    {
        _rb = GetComponent<Rigidbody>();

        // Si no hay Rigidbody, añadimos uno cinemático para que las colisiones funcionen.
        // Nota: Unity solo envía OnTriggerEnter/OnCollisionEnter si al menos uno tiene Rigidbody.
        if (_rb == null)
        {
            _rb = gameObject.AddComponent<Rigidbody>();
            _rb.isKinematic = true;
            _rb.useGravity = false;
        }
        
        // Proyectil atraviesa geometría: todos los colliders son trigger.
        // Solo explota por código (OnTriggerEnter) cuando detecta capas de interés.
        foreach (var c in GetComponentsInChildren<Collider>(true)) c.isTrigger = true;

        // Configurar Rigidbody para detección continua
        if (_rb != null)
        {
            _rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            _rb.interpolation = RigidbodyInterpolation.Interpolate;
        }
        
        // Asegurar que el proyectil tenga la layer correcta para colisionar con enemigos
        if (gameObject.layer == 0) // Si está en Default, mover a Projectile
        {
            int projectileLayer = LayerMask.NameToLayer("Projectile");
            if (projectileLayer != -1)
            {
                gameObject.layer = projectileLayer;
            }
        }

        RefreshHasRigidbody();
    }

    void OnEnable()
    {
        _spawnPos  = transform.position;
        _spawnTime = Time.time;

        // Grace period mínimo: solo evitar auto-detonación en el propio spawner
        _spawnGraceEnd = Time.time + 0.05f;

        // Si el propio componente define un TTL, usarlo ya desde OnEnable
        CancelInvoke(nameof(EndByTTL));
        if (lifeTimeSeconds > 0f)
        {
            Invoke(nameof(EndByTTL), lifeTimeSeconds);
        }

        // Seguridad extra: si hay RB y se configuró gravedad
        if (_hasRb) _rb.useGravity = _cfg.useGravity;
    }

    /// <summary>
    /// Inyecta toda la configuración del proyectil y el instigador.
    /// Llamar inmediatamente tras instanciar el prefab.
    /// </summary>
    public void Configure(in ProjectileConfig cfg, GameObject instigator, bool ignoreSelfCollision = true)
    {
        _cfg        = cfg;
        _instigator = instigator;
        if (_instigator != null && !AmenazasAlJugador.EsDelGrupoDelJugador(_instigator)) AmenazasAlJugador.Registrar(this);
        else AmenazasAlJugador.Quitar(this);

        // ✅ IMPORTANTE: Aplicar el lifeTime de la configuración del SO
        // Esto sobrescribe el lifeTimeSeconds del prefab si el SO define un valor
        if (_cfg.lifeTime > 0f)
        {
            CancelInvoke(nameof(EndByTTL));
            Invoke(nameof(EndByTTL), _cfg.lifeTime);
        }

        // Ignorar colisiones con el instigador
        if (ignoreSelfCollision && _instigator)
        {
            var myCols  = GetComponentsInChildren<Collider>(true);
            var hisCols = _instigator.GetComponentsInChildren<Collider>(true);
            foreach (var a in myCols)
                foreach (var b in hisCols)
                    if (a && b) Physics.IgnoreCollision(a, b, true);
        }
    }

    /// <summary>
    /// Activa o desactiva el uso de Rigidbody en runtime (para cargas).
    /// Recalcula los flags internos para que el proyectil se mueva correctamente tras el cambio.
    /// </summary>
    public void SetKinematic(bool value)
    {
        if (_rb == null) return;
        _rb.isKinematic = value;
        RefreshHasRigidbody();
        // Cuando el proyectil se marca como kinematic queremos PAUSAR
        // su movimiento manual (esto se usa durante cargas/charge).
        _movementEnabled = !value;
        if (!_hasRb)
            _rb.useGravity = false;
    }

    /// <summary>
    /// Lanza el proyectil en la dirección dada aplicando velocidad/rotación.
    /// </summary>
    /// <summary>
    /// Opciones del proyectil mejorado sacadas del hechizo (INC-497). La llama el spawner tras
    /// Configure. 'zoneLayers' = capas que daña la zona que deja al impactar.
    /// </summary>
    public void ConfigureExtras(MagicSpellSO spell, LayerMask zoneLayers, float damageMultiplier)
    {
        if (spell == null) return;
        _bouncesLeft = spell.bounceCount;
        _bounceRange = spell.bounceRange;
        _pierceLeft = spell.pierceCount;
        _impactZone = spell.impactZone != null && spell.impactZone.kind == MagicKind.Zone ? spell.impactZone : null;
        _zoneLayers = zoneLayers;
        _zoneDamageMultiplier = damageMultiplier;
        _statusSpell = spell.statusEffect != EstadoDeCombate.Ninguno ? spell : null;
        _abreProteccion = spell.abreProteccionSegundos;
        _vfxProteccion = spell.vfxProteccionAbierta;
    }

    static Transform HitRoot(Collider c)
    {
        if (c == null) return null;
        var d = c.GetComponentInParent<Damageable>();
        if (d != null) return d.transform;
        return c.attachedRigidbody ? c.attachedRigidbody.transform : c.transform.root;
    }

    bool IsAlreadyHit(Collider c)
    {
        if (_alreadyHit.Count == 0) return false;
        Transform root = HitRoot(c);
        return root != null && _alreadyHit.Contains(root);
    }

    /// <summary>
    /// Tras dar a un enemigo: rebota al siguiente o sigue atravesando si le quedan. True = el
    /// proyectil sigue vivo.
    /// </summary>
    bool TryContinueAfterHit(Collider hit, Vector3 hitPoint)
    {
        Transform hitRoot = HitRoot(hit);
        if (hitRoot != null) _alreadyHit.Add(hitRoot);

        if (_bouncesLeft > 0)
        {
            Transform next = FindNextBounceTarget(hitPoint);
            if (next != null)
            {
                _bouncesLeft--;
                Vector3 aim = Targetable.CentroDelCuerpo(next);
                float speed = _cfg.initialSpeed;
                if (_rb != null && !_rb.isKinematic) speed = Mathf.Max(speed, _rb.linearVelocity.magnitude);
                Launch(aim - transform.position, speed, false);
                GuiarHacia(next, _gradosDeGuia);
                return true;
            }
        }

        if (_pierceLeft != 0)
        {
            if (_pierceLeft > 0) _pierceLeft--;
            return true;
        }
        return false;
    }

    Transform FindNextBounceTarget(Vector3 from)
    {
        int mask = BounceMask;
        int n = Physics.OverlapSphereNonAlloc(from, _bounceRange, s_bounceBuffer, mask, QueryTriggerInteraction.Collide);
        Transform best = null;
        float bestSqr = float.MaxValue;
        for (int i = 0; i < n; i++)
        {
            Transform root = HitRoot(s_bounceBuffer[i]);
            if (root == null || _alreadyHit.Contains(root)) continue;
            var d = root.GetComponentInChildren<Damageable>();
            if (d != null && !d.IsAlive) continue;
            float sqr = (root.position - from).sqrMagnitude;
            if (sqr < bestSqr) { bestSqr = sqr; best = root; }
        }
        return best;
    }

    public void Launch(Vector3 direction, float speed, bool useGravity)
    {
        Vector3 normalizedDirection = direction.sqrMagnitude > 0.0001f ? direction.normalized : transform.forward;
        if (normalizedDirection.sqrMagnitude <= 0.0001f)
            normalizedDirection = Vector3.forward;

        transform.rotation = Quaternion.LookRotation(normalizedDirection, Vector3.up);

        _cfg.initialSpeed = speed;
        _cfg.useGravity = useGravity;

        if (_rb != null)
        {
            // Nunca aplicar velocidades físicas a RB cinemático (evita warnings de Unity).
            if (!_rb.isKinematic)
            {
                _rb.useGravity = useGravity;
                _rb.angularVelocity = Vector3.zero;
                _rb.linearVelocity = normalizedDirection * Mathf.Max(0f, speed);
                _movementEnabled = true;
            }
            else
            {
                _rb.useGravity = false;
                _movementEnabled = true;
                transform.forward = normalizedDirection;
            }

            // Garantizar que el proyectil usa la posición actual como origen de rango
            _spawnPos = transform.position;
        }
        else
        {
            // Movimiento manual en Update usa _cfg.initialSpeed
            transform.forward = normalizedDirection;
            _spawnPos = transform.position;
            _movementEnabled = true;
        }
    }

    /// <summary>
    /// Corrige el rumbo en vuelo hacia el centro del cuerpo de 'objetivo', a 'gradosPorSegundo'
    /// como mucho: sigue a un objetivo que se mueve sin girar en seco. Llamar tras Launch; con
    /// objetivo null o 0 grados, vuela recto. Los rebotes guían al siguiente con el mismo giro.
    /// </summary>
    public void GuiarHacia(Transform objetivo, float gradosPorSegundo)
    {
        _gradosDeGuia = Mathf.Max(0f, gradosPorSegundo);
        _guia = _gradosDeGuia > 0f ? objetivo : null;
        _vidaDeLaGuia = null;
        if (_guia == null) return;
        _vidaDeLaGuia = _guia.GetComponentInParent<Damageable>();
        _centroLocalDeLaGuia = _guia.InverseTransformPoint(Targetable.CentroDelCuerpo(_guia));
    }

    void CorregirRumbo(float dt)
    {
        if (!_guia.gameObject.activeInHierarchy || (_vidaDeLaGuia != null && !_vidaDeLaGuia.IsAlive))
        {
            _guia = null;
            return;
        }

        Vector3 actual = _hasRb ? _rb.linearVelocity : transform.forward;
        float rapidez = actual.magnitude;
        if (rapidez < 0.0001f) return;
        Vector3 rumbo = actual / rapidez;

        Vector3 hacia = _guia.TransformPoint(_centroLocalDeLaGuia) - transform.position;
        // Si ya lo ha pasado de largo, deja de corregir: no da la vuelta para perseguirlo.
        if (Vector3.Dot(rumbo, hacia) <= 0f)
        {
            _guia = null;
            return;
        }

        Vector3 nuevo = Vector3.RotateTowards(rumbo, hacia.normalized, _gradosDeGuia * Mathf.Deg2Rad * dt, 0f);
        Quaternion giro = Quaternion.LookRotation(nuevo, Vector3.up);
        if (_hasRb)
        {
            _rb.linearVelocity = nuevo * rapidez;
            _rb.rotation = giro;
        }
        else
        {
            transform.rotation = giro;
        }
    }

    void RefreshHasRigidbody()
    {
        _hasRb = _rb != null && !_rb.isKinematic;
    }

    void Update()
    {
        if (_ended) return;

        if (_guia != null) CorregirRumbo(Time.deltaTime);

        // Movimiento manual si no hay Rigidbody
        if (!_hasRb && _movementEnabled && _cfg.initialSpeed > 0f)
            transform.position += transform.forward * (_cfg.initialSpeed * Time.deltaTime);

        // Fin por rango
        if (_cfg.maxRange > 0f)
        {
            float sqr = (transform.position - _spawnPos).sqrMagnitude;
            if (sqr >= _cfg.maxRange * _cfg.maxRange) End(false);
        }
    }
    
    // ==== Colisiones ===========================================================

    void OnTriggerEnter(Collider other)
    {
        if (Time.time < _spawnGraceEnd) return;
        Vector3 hitPoint = transform.position;
        
        // ClosestPoint solo funciona con Box, Sphere, Capsule y Mesh convexo
        if (other is BoxCollider || other is SphereCollider || other is CapsuleCollider || 
            (other is MeshCollider meshCol && meshCol.convex))
        {
            hitPoint = other.ClosestPoint(transform.position);
        }
        
        ResolveHit(other, hitPoint);
    }

    void OnCollisionEnter(Collision c)
    {
        if (Time.time < _spawnGraceEnd) return;
        ResolveHit(c.collider, c.GetContact(0).point);
    }

    void OnParticleCollision(GameObject other)
    {
        var col = other ? other.GetComponent<Collider>() : null;
        ResolveHit(col, transform.position);
    }

    // Capas integradas de Unity: 1 = TransparentFX, 2 = Ignore Raycast.
    const int CapaTransparentFX = 1;
    const int CapaIgnoreRaycast = 2;
    // Capa de los proyectiles del grupo; se resuelve una vez (no cambia en juego).
    static int _capaProyectil = int.MinValue;

    void ResolveHit(Collider other, Vector3 hitPoint)
    {
        if (_ended || other == null) return;

        int otherLayer = other.gameObject.layer;

        // Lo que nunca detiene un hechizo: las capas TransparentFX e Ignore Raycast, los demás
        // proyectiles aliados (capa Projectile) y el área de una arena de combate (el trigger de
        // BossArenaController delimita la zona; no es un muro).
        if (otherLayer == CapaTransparentFX || otherLayer == CapaIgnoreRaycast) return;
        if (_capaProyectil == int.MinValue) _capaProyectil = LayerMask.NameToLayer("Projectile");
        if (otherLayer == _capaProyectil) return;
        if (other.isTrigger && other.TryGetComponent(out BossArenaController _)) return;

        string layerName = LayerMask.LayerToName(otherLayer);

        // Escudo NPC activo: bloquear antes de cualquier lógica de daño.
        if (TryHandleNpcShieldBlock(other, hitPoint)) return;

        // Magia enemiga contra el jugador: solo si 'hitLayers' incluye expresamente la capa del
        // jugador (los hechizos del jugador y de sus aliados nunca la incluyen). El jugador no usa
        // Damageable, sino PlayerHealthSystem (con su defensa y su escudo). Ver INC-509.
        if (_cfg.hitLayers.value != 0 && ((1 << otherLayer) & _cfg.hitLayers.value) != 0)
        {
            var saludJugador = other.GetComponentInParent<PlayerHealthSystem>();
            if (saludJugador != null)
            {
                if (_instigator != null && saludJugador.gameObject == _instigator) return;
                if (IsAlreadyHit(other)) return;
                saludJugador.TakeDamage(_cfg.damage);
                SpawnImpactEffects(hitPoint);
                if (_cfg.destroyOnHit) End(true);
                return;
            }
        }

        // 🔍 DEBUG: Log de cada colisión (solo si no se ignora)
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[MagicProjectile] OnHit: {other.gameObject.name} (Layer: {layerName}, Tag: {other.tag})");
#endif

        // ✅ PRIORIDAD 1: Detectar colisión con proyectiles enemigos (layer "ProjectileEnemy" o "EnemyProjectile")
        if (layerName == "ProjectileEnemy" || layerName == "EnemyProjectile")
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[MagicProjectile] 💥 Colisión con proyectil enemigo detectada!");
#endif
            ProjectileCollisionHandler.HandleCollision(gameObject, other.gameObject, hitPoint);
            return;
        }

        // ✅ PRIORIDAD 2: Detectar colisión con layer Enemy o Boss directamente
        // Detectamos por layer (Enemy o Boss) y opcionalmente por tag "Enemy"
        bool isEnemy = layerName == "Enemy" || 
                       layerName == "Boss" ||
                       SafeCompareTag(other, "Enemy");
        
        if (isEnemy)
        {
            if (!TryMarkHit(other)) return;
            if (IsAlreadyHit(other)) return; // al atravesar o rebotar no se daña dos veces al mismo (INC-497)
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[MagicProjectile] 🎯 IMPACTO CONTRA ENEMIGO: {other.gameObject.name}!");
#endif
            ApplyDamageAndKnockback(other, hitPoint);
            SpawnImpactEffects(hitPoint);
            if (TryContinueAfterHit(other, hitPoint)) return;
            if (_cfg.destroyOnHit) End(true);
            return;
        }

        // Sellos y piezas sin vida con una protección que este hechizo abre (Amanecer, INC-724).
        if (_abreProteccion > 0f && other.GetComponentInParent<Damageable>() == null && AbrirProteccion(other))
        {
            SpawnImpactEffects(hitPoint);
            if (_cfg.destroyOnHit) End(true);
            return;
        }

        // ✅ PRIORIDAD 3: piezas del mundo que reaccionan a la magia (lo que arde, cristales,
        // molinetes…). Ver ReaccionesAMagia.
        if (ReaccionesAMagia.Notificar(other, new ImpactoDeMagia(_cfg.element, hitPoint, _instigator, false)))
        {
            SpawnImpactEffects(hitPoint);
            if (_cfg.destroyOnHit) End(true);
            return;
        }

        // ✅ PRIORIDAD 4: Intentar aplicar daño si el objeto tiene Damageable (independiente del layer)
        // Esto permite dañar enemigos/bosses aunque estén en layer Default
        var targetDamageable = other.GetComponent<Damageable>();
        if (targetDamageable == null)
            targetDamageable = other.GetComponentInParent<Damageable>();
        
        if (targetDamageable != null)
        {
            // Verificar que no sea aliado (el propio lanzador o sus aliados)
            if (_instigator != null && targetDamageable.gameObject == _instigator)
            {
                return; // No dañarse a sí mismo
            }
            if (IsAlreadyHit(other)) return; // INC-497

            // FIX M8 + INC-640: Si coincide con hitLayers, objetivo directo. Si no coincide
            // pero tiene Damageable, se permite siempre que no sea un aliado del grupo
            // (evita que dummies de prueba o enemigos en layer Default sean inmunes al daño).
            bool capaValida = _cfg.hitLayers.value == 0 || ((1 << other.gameObject.layer) & _cfg.hitLayers.value) != 0;
            if (!capaValida)
            {
                int playerLayer = LayerMask.NameToLayer("Player");
                if (playerLayer != -1 && other.gameObject.layer == playerLayer) return;
                if (ControlDelJugador.PersonajeDe(other.gameObject, out _)) return;
                if (other.GetComponentInParent<CuerpoDelGrupo>() != null) return;
            }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[MagicProjectile] 🎯 Impacto contra {other.gameObject.name} - Aplicando {_cfg.damage} de daño via Damageable");
#endif

            if (_cfg.aoeRadius > 0f)
            {
                // Para AOE, buscar todos los Damageable en el radio
                int aoeCount = Physics.OverlapSphereNonAlloc(hitPoint, _cfg.aoeRadius, _aoeHitBuffer); // ✅ OPTIMIZACIÓN FASE 2: NonAlloc
                _aoeTargets.Clear();
                for (int i = 0; i < aoeCount; i++)
                {
                    var c = _aoeHitBuffer[i];
                    if (c == null) continue;
                    bool aoeCapaValida = _cfg.hitLayers.value == 0 || ((1 << c.gameObject.layer) & _cfg.hitLayers.value) != 0;
                    if (!aoeCapaValida)
                    {
                        int playerLayer = LayerMask.NameToLayer("Player");
                        if (playerLayer != -1 && c.gameObject.layer == playerLayer) continue;
                        if (ControlDelJugador.PersonajeDe(c.gameObject, out _)) continue;
                        if (c.GetComponentInParent<CuerpoDelGrupo>() != null) continue;
                    }
                    var d = c.GetComponent<Damageable>() ?? c.GetComponentInParent<Damageable>();
                    if (d != null && (_instigator == null || d.gameObject != _instigator) && _aoeTargets.Add(d.transform))
                    {
                        ApplyDamageAndKnockback(c, hitPoint);
                    }
                }
            }
            else
            {
                ApplyDamageAndKnockback(other, hitPoint);
            }
            
            SpawnImpactEffects(hitPoint);
            if (TryContinueAfterHit(other, hitPoint)) return;
            if (_cfg.destroyOnHit) End(true);
            return;
        }

        // Paredes, rocas, árboles, casas: lo sólido que se interpone para el hechizo (INC-1167).
        // Antes lo atravesaba todo, así que esconderse detrás de algo no servía de nada (y los
        // proyectiles enemigos, EnemyProjectile, sí se paraban: no era justo). Lo que queda por
        // debajo del hechizo (el suelo que va rozando, un murete bajo) no lo para.
        if (EsObstaculo(other))
        {
            SpawnImpactEffects(hitPoint);
            End(true);
        }
    }

    static int s_mascaraDeObstaculos = -1;

    bool EsObstaculo(Collider other)
    {
        if (other.isTrigger || other is TerrainCollider) return false;
        if (s_mascaraDeObstaculos == -1) s_mascaraDeObstaculos = LayerMask.GetMask("Default", "Obstacle", "Floor", "Climb");
        if (((1 << other.gameObject.layer) & s_mascaraDeObstaculos) == 0) return false;
        if (_instigator != null && other.transform.IsChildOf(_instigator.transform)) return false;
        if (other.GetComponentInParent<CuerpoDelGrupo>() != null || ControlDelJugador.PersonajeDe(other.gameObject, out _)) return false;
        // Solo lo que se alza por encima del hechizo: el suelo bajo un remolino que avanza no cuenta
        // (ni una malla de suelo grande con cerros lejos: si está justo debajo, es suelo).
        if (other.bounds.max.y <= transform.position.y + 0.3f) return false;
        if (other.Raycast(new Ray(transform.position + Vector3.up * 0.2f, Vector3.down), out _, 0.9f)) return false;
        return true;
    }
    
    /// <summary>
    /// Spawn VFX y SFX de impacto
    /// </summary>
    void SpawnImpactEffects(Vector3 hitPoint)
    {
        // VFX de impacto (pooled — evita GC spikes en combate con muchos proyectiles)
        if (_cfg.impactVFX)
        {
            float lifetime = _cfg.vfxLifetime > 0f ? _cfg.vfxLifetime : 3f;
            VfxPoolService.Instance.Play(_cfg.impactVFX, hitPoint, Quaternion.identity, lifetime);
        }
        
        // SFX de impacto
        if (_cfg.impactEvent != null && _cfg.impactEvent.TieneCapas())
        {
            AudioService.Instance?.PlayEvent(_cfg.impactEvent, hitPoint);
        }
        else if (!string.IsNullOrEmpty(_cfg.impactSFXKey))
        {
            AudioService.Instance?.PlaySFX(_cfg.impactSFXKey, worldPosition: hitPoint);
        }
    }

    void ApplyDamageAndKnockback(Collider col, Vector3 hitPoint)
    {
        // La protección se abre antes del daño, para que el propio golpe ya entre (INC-724).
        if (_abreProteccion > 0f) AbrirProteccion(col);
        AplicarImpactoDirecto(col, hitPoint, _instigator, _cfg.damage, _cfg.knockbackForce, _statusSpell);
    }

    /// Abre la protección de lo alcanzado (en el collider, sus padres o junto a su Damageable).
    bool AbrirProteccion(Collider col)
    {
        var proteccion = ProteccionQueSeAbre.De(col);
        if (proteccion == null)
        {
            var receptor = EncontrarReceptor(col);
            if (receptor != null) proteccion = receptor.GetComponent<IProteccionQueSeAbre>();
        }
        if (proteccion == null) return false;
        proteccion.AbrirProteccion(_abreProteccion, _instigator, _vfxProteccion);
        return true;
    }

    /// <summary>Receptor del impacto, también para bolas devueltas y hitboxes en ramas distintas.</summary>
    public static Damageable EncontrarReceptor(Collider col)
    {
        if (col == null) return null;
        return col.GetComponent<Damageable>() ?? col.GetComponentInParent<Damageable>() ??
               col.GetComponentInChildren<Damageable>(true) ?? col.transform.root.GetComponentInChildren<Damageable>(true);
    }

    /// <summary>Camino compartido de daño, defensa, estados y empuje de los proyectiles del jugador.</summary>
    public static void AplicarImpactoDirecto(Collider col, Vector3 hitPoint, GameObject instigador, float dano, float empuje = 0f, MagicSpellSO estado = null)
    {
        // Si el objetivo está defendiendo con escudo NPC, no recibe daño ni knockback.
        if (col != null && TryGetDefendingNpcShield(col, out var defendingShield))
        {
            defendingShield.OnShieldHit();
            return;
        }

        // Daño simple
        if (col)
        {
            // Buscar Damageable en el propio collider, en sus padres (enemigos con colisionadores hijos)
            // o, como último recurso, en cualquier parte de la jerarquía raíz. Sin este último fallback,
            // algunos enemigos con hitboxes en una rama distinta a la del Damageable (ej. sub-objetos de
            // colisión que no son ancestros directos) recibían el impacto visual (VFX/SFX) pero no
            // perdían vida, porque GetComponentInParent no encontraba el componente.
            var d = EncontrarReceptor(col);

            if (d != null)
            {
                // Con el ataque de quien lo lanzó (FormulasDeCombate, INC-470).
                d.TakeDamage(FormulasDeCombate.DanoDe(instigador, dano), instigador);
                if (estado != null)
                    EstadosDeCombate.Aplicar(d, estado.statusEffect, estado.statusDuration,
                                             estado.statusStrength, hitPoint != Vector3.zero ? hitPoint : col.transform.position,
                                             estado.statusVFX);
            }
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            else
            {
                Debug.LogWarning($"[MagicProjectile] ⚠️ Impacto en '{col.gameObject.name}' pero no se encontró Damageable en su jerarquía - no se aplicó daño.");
            }
#endif
        }

        // Knockback simple (si hay RB dinámico)
        if (empuje > 0f && col)
        {
            var rb = col.attachedRigidbody ? col.attachedRigidbody : col.GetComponentInParent<Rigidbody>();
            if (rb != null && !rb.isKinematic)
            {
                Vector3 dir = (rb.worldCenterOfMass - (hitPoint != Vector3.zero ? hitPoint : col.transform.position)).normalized;
                dir.y = 0f; // empuje horizontal
                rb.AddForce(dir * empuje, ForceMode.Impulse);
            }
        }
    }

    // ==== Fin de vida ==========================================================

    void EndByTTL() => End(false);

    public void End(bool byImpact)
    {
        if (_ended) return;
        _ended = true;
        AmenazasAlJugador.Quitar(this);

        // Zona al impactar (INC-497): fuego en el suelo, etc.
        if (byImpact && _impactZone != null)
            MagicProjectileSpawner.SpawnZoneAt(_impactZone, transform.position, _instigator, _zoneLayers, _zoneDamageMultiplier);

        // Si muere sin impactar (TTL o rango), dispara VFX de despawn (pooled)
        if (!byImpact && _cfg.despawnVFX && VfxPoolService.Instance != null)
        {
            float lifetime = _cfg.vfxLifetime > 0f ? _cfg.vfxLifetime : 3f; // 3s por defecto
            VfxPoolService.Instance.Play(_cfg.despawnVFX, transform.position, Quaternion.identity, lifetime);
        }

        // Si usas pooling, reemplaza por Despawn
        Destroy(gameObject);
    }

    private bool TryHandleNpcShieldBlock(Collider other, Vector3 hitPoint)
    {
        if (!TryGetDefendingNpcShield(other, out var shieldController))
            return false;

        shieldController.OnShieldHit();
        SpawnImpactEffects(hitPoint);
        End(true);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[MagicProjectile] 🛡️ Bloqueado por escudo NPC: {shieldController.gameObject.name}");
#endif
        return true;
    }

    private static bool TryGetDefendingNpcShield(Collider other, out NPCShieldController shieldController)
    {
        shieldController = null;
        if (other == null) return false;

        if (TryGetDefendingNpcShieldFromTransform(other.transform, out shieldController))
            return true;

        if (other.attachedRigidbody != null &&
            TryGetDefendingNpcShieldFromTransform(other.attachedRigidbody.transform, out shieldController))
            return true;

        var damageable = other.GetComponent<Damageable>() ??
                         other.GetComponentInParent<Damageable>() ??
                         other.GetComponentInChildren<Damageable>(true);
        if (damageable != null && TryGetDefendingNpcShieldFromTransform(damageable.transform, out shieldController))
            return true;

        if (other.transform.root != null &&
            TryGetDefendingNpcShieldFromTransform(other.transform.root, out shieldController))
            return true;

        shieldController = null;
        return false;
    }

    private static bool TryGetDefendingNpcShieldFromTransform(Transform source, out NPCShieldController shieldController)
    {
        shieldController = null;
        if (source == null) return false;

        var shieldMarker = source.GetComponent<NPCShieldController.NPCShieldMarker>() ??
                           source.GetComponentInParent<NPCShieldController.NPCShieldMarker>() ??
                           source.GetComponentInChildren<NPCShieldController.NPCShieldMarker>(true);
        if (shieldMarker != null)
        {
            shieldController = shieldMarker.GetComponentInParent<NPCShieldController>() ??
                               shieldMarker.GetComponentInChildren<NPCShieldController>(true);
            if (shieldController != null && shieldController.IsDefending)
                return true;
        }

        shieldController = source.GetComponent<NPCShieldController>() ??
                           source.GetComponentInParent<NPCShieldController>() ??
                           source.GetComponentInChildren<NPCShieldController>(true);
        if (shieldController != null && shieldController.IsDefending)
            return true;

        shieldController = null;
        return false;
    }
    
    // ==== Helpers ==============================================================

    // Guard I16: devuelve false si este collider ya fue marcado como dañado en el frame actual
    private bool TryMarkHit(Collider col)
    {
        if (_lastDamagedCollider == col && _lastDamagedFrame == Time.frameCount)
            return false;
        _lastDamagedCollider = col;
        _lastDamagedFrame = Time.frameCount;
        return true;
    }

    /// <summary>
    /// CompareTag seguro que no lanza excepción si el tag no existe.
    /// </summary>
    private static bool SafeCompareTag(Component obj, string tag)
    {
        if (obj == null || string.IsNullOrEmpty(tag)) return false;
        try
        {
            return obj.CompareTag(tag);
        }
        catch
        {
            return false;
        }
    }
}
