using Sendero.Core.Feedback;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

/// <summary>
/// Sistema de salud específico para el jugador que se integra con GameBootProfile
/// </summary>
[RequireComponent(typeof(Animator))]
public class PlayerHealthSystem : MonoBehaviour
{
    [Header("Configuración de Daño")]
    [SerializeField] private float invulnerabilityDuration = 1f;
    [Tooltip("Si está activo, el jugador no puede morir: los golpes llegan y se ven, pero la vida no baja de 1 (para pruebas)")]
    [SerializeField] private bool godMode; // por defecto false

    [Header("Animaciones")]
    [Tooltip("Animaciones de daño (se alterna aleatoriamente entre ellas para variedad)")]
    [SerializeField] private string[] damageAnimationNames = new string[] { "TakeDamage", "TakeDamage_2" };
    [SerializeField] private string deathAnimationName = "Die02_NoWeapon";
    [SerializeField] private int upperBodyLayer = 1; // Layer para animaciones del torso superior
    [Tooltip("Segundos sin la pose de combate de los brazos tras un golpe, para que la animación de daño (de cuerpo entero) se vea completa.")]
    [SerializeField, Min(0f)] private float segundosSinPoseDeBrazos = 0.7f;
    [Tooltip("Velocidad de las animaciones de daño y de caída al morir. Se reproducen en tiempo real, " +
             "sin la cámara lenta del Game Over, para que la caída se vea entera. Menos de 1 = más lenta.")]
    [SerializeField, Range(0.2f, 1.5f)] private float ritmoDeLaCaida = 0.7f;
    [Tooltip("Tope, en segundos reales, de la animación de daño que precede a la de caída al morir.")]
    [SerializeField, Min(0.1f)] private float topeAnimacionDeDano = 1.5f;
    
    [Header("Efectos Visuales")]
    [SerializeField] private float damageFlashDuration = 0.2f;
    [SerializeField] private Color damageFlashColor = Color.red;
    [SerializeField] private GameObject damageVFX;
    [SerializeField] private GameObject healVFX;
    
    [Header("Invulnerabilidad Visual")]
    [SerializeField] private float invulnerabilityFlashRate = 0.1f;
    
    [Header("Camera Shake (opcional)")]
    [SerializeField] private bool enableCameraShake = true;
    [SerializeField] private float shakeIntensity = 0.5f;
    [SerializeField] private float shakeDuration = 0.3f;
    
    [Header("Knockback (opcional)")]
    [SerializeField] private bool enableKnockback = true;
    [SerializeField] private float knockbackForce = 5f;
    [SerializeField] private float knockbackDuration = 0.2f;
    [SerializeField] private AnimationCurve knockbackCurve = new AnimationCurve(new Keyframe(0, 1), new Keyframe(1, 0));
    
    [Header("Audio (claves del Audio Graph Profile)")]
    [SerializeField] private string damageSoundKey = "Player_Damage";
    [SerializeField] private string healSoundKey = "Player_Heal";
    [SerializeField] private string deathSoundKey = "Player_Death";

    [Header("Reacciones vocales")]
    [Tooltip("Personaje de las reacciones. Vacío desactiva las reacciones vocales.")]
    [SerializeField] private string reactionCharacter = "Will";
    [Tooltip("Desactivado de momento (petición de Raúl, 7 oct 2026): Will no se queja al recibir daño. Marcar para volver a oír la reacción 'hurt'.")]
    [SerializeField] private bool playDamageReaction = false;
    [Tooltip("Reacción al recibir daño. Vacío la desactiva.")]
    [SerializeField] private string damageReactionKind = "hurt";
    [Tooltip("Reacción al morir. Vacío la desactiva.")]
    [SerializeField] private string deathReactionKind = "death";
    [SerializeField, Min(0f)] private float damageReactionCooldown = 0.6f;
    private float _nextDamageReactionTime = float.NegativeInfinity;
    
    [Header("Eventos")]
    public UnityEvent<float> OnHealthChanged; // healthPercentage (0-1)
    public UnityEvent<float, float> OnDamageTaken; // (damageAmount, currentHealth)
    public UnityEvent<float, float> OnHealed; // (healAmount, currentHealth)
    public UnityEvent OnPlayerDeath;
    public UnityEvent OnPlayerRevived;
    
    // Property IDs para optimización de materiales (URP y Standard)
    private static readonly int BaseColorPropertyID = Shader.PropertyToID("_BaseColor"); // URP
    private static readonly int ColorPropertyID = Shader.PropertyToID("_Color");         // Standard
    
    // Componentes
    private Animator _animator;
    private Renderer[] _renderers;
    private WardrobeInventory _wardrobeInventory; // FIX 4 sep 2026, ver Awake()/RefreshRenderersForWardrobeChange
    private Material[] _originalMaterials;
    // FIX A10 (auditoría 2026-08-07): resuelto en Awake para god-frame en Cinematic (TakeDamage)
    // y para vaciar la pila de modos en Die()/ReviveInternal (ver comentarios más abajo).
    private PlayerActionManager _actionManager;

    // Cache para resolución de estados del Animator
    private readonly Dictionary<string, int> _stateHash = new Dictionary<string, int>();
    private readonly Dictionary<string, int> _stateLayer = new Dictionary<string, int>();

    // Estado local del sistema de salud
    private float _currentHp;
    private float _maxHp;
    private bool _isInvulnerable = false;
    private bool _isDead; // por defecto false
    private float _invulnerableUntil = -999f;
    // La próxima muerte va directa al Game Over aunque quede alguien del grupo en pie.
    private bool _sinRelevo;

    // Evitar doble inicialización
    private bool _initialized;

    // Corrutinas
    private Coroutine _invulnerabilityFlashCoroutine;
    private Coroutine _damageFlashCoroutine;
    private Coroutine _caidaCoroutine;

    // Renderers que ha apagado el parpadeo de invulnerabilidad. Al volver a mostrar solo se
    // encienden estos: los que tenga apagados otro sistema (el plano corto de un diálogo, el
    // cambio de personaje) se quedan como están. Ver INC-527.
    private readonly List<Renderer> _ocultosPorParpadeo = new List<Renderer>();

    // Muerte: animación de daño que se acaba de lanzar (para no repetirla) y si ya ha arrancado la
    // de caída. El Animator pasa a tiempo real durante la caída y se restaura al revivir.
    private string _animDeDanoLanzada;
    private int _frameAnimDeDano = -1;
    private bool _caidaIniciada;
    private bool _animatorEnModoCaida;
    private Game.Player.PlayerBattleModeController _modoDeBatalla;
    private AnimatorUpdateMode _modoAnimatorPrevio;
    private float _velocidadAnimatorPrevia = 1f;

    // Estado de regeneración
#pragma warning disable CS0414 // Usado para tracking de daño interno
    private float _lastDamageTime = -999f;
#pragma warning restore CS0414
    private float _lastNotifiedHealth;
    
    // Propiedades públicas usando GameBootProfile
    // Lista reutilizada para no reservar memoria en cada golpe.
    private readonly System.Collections.Generic.List<IFiltroDeDano> _filtrosDeDano = new();

    public bool IsAlive => _currentHp > 0 && !_isDead;
    public bool IsInvulnerable => _isInvulnerable || Time.time < _invulnerableUntil;
    public float CurrentHealth => _currentHp;
    public float MaxHealth => _maxHp;
    public float HealthPercentage => _maxHp > 0 ? _currentHp / _maxHp : 0f;
    public bool IsGodModeActive => godMode;
    
    // Eventos C#
    public event Action<float> OnHealthPercentageChanged;
    public event Action<float> OnDamageReceived;
    public event Action OnDied;
    
    void Awake()
    {
        _animator = GetComponent<Animator>();
        _actionManager = GetComponent<PlayerActionManager>() ?? GetComponentInParent<PlayerActionManager>();

        // Obtener renderers para efectos visuales
        _renderers = GetComponentsInChildren<Renderer>();
        CacheOriginalMaterials();

        // FIX 4 sep 2026: _renderers se cacheaba una sola vez aquí, en Awake(). Si el jugador
        // equipaba una prenda de WardrobeInventory (capa, gafas...) DESPUÉS de este momento, su
        // Renderer nunca entraba en el array — el cuerpo parpadeaba al recibir daño pero la prenda
        // se quedaba fija, quedando raro (reportado por Raúl). Nos suscribimos a
        // WardrobeInventory.OnWardrobeChanged para añadir al array cualquier Renderer nuevo que
        // aparezca al equipar (ver RefreshRenderersForWardrobeChange).
        if (_wardrobeInventory == null)
            PlayerService.TryGetComponent(out _wardrobeInventory, includeInactive: true, allowSceneLookup: true);
        if (_wardrobeInventory != null)
            _wardrobeInventory.OnWardrobeChanged += RefreshRenderersForWardrobeChange;
    }

    // Reemplaza Start/Coroutine por evento del boot service
    void OnEnable()
    {
        GameBootService.OnProfileReady += HandleProfileReady;
        ProfileReadyDiagnostics.RegisterSubscriber(nameof(PlayerHealthSystem));
        if (GameBootService.IsAvailable)
        {
            HandleProfileReady();
        }
    }

    void OnDisable()
    {
        GameBootService.OnProfileReady -= HandleProfileReady;
        if (_wardrobeInventory != null)
            _wardrobeInventory.OnWardrobeChanged -= RefreshRenderersForWardrobeChange;

        // FIX A10 (auditoría 2026-08-07): si el GameObject se desactiva a mitad del ciclo "apagado"
        // de InvulnerabilityFlashCoroutine (SetRenderersVisibility(false)), la corrutina muere en
        // seco sin llegar a su reactivación — el jugador queda invisible para siempre, incluso al
        // reactivarse, porque nada volvía a llamar a ResetDamageVisuals(). Se llama siempre al
        // desactivar (ya es seguro/no-op si no había nada que restaurar).
        ResetDamageVisuals();
        RestaurarAnimatorTrasCaida();
    }

    private void HandleProfileReady()
    {
        if (_initialized) return;

        // Inicializar desde GameBootProfile
        var bootProfile = GameBootService.Profile;
        var preset = Partida.Preset;
        
        if (preset != null)
        {
            _maxHp = preset.maxHP;
            _currentHp = preset.currentHP;
            _isDead = _currentHp <= 0;
            _lastNotifiedHealth = _currentHp;
            
            // Debug.Log($"[PlayerHealthSystem] Inicializado con vida: {_currentHp:0.1f}/{_maxHp:0.1f} ({HealthPercentage:P1}) - Estado: {(_isDead ? "MUERTO" : "VIVO")}");
        }
        else
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[PlayerHealthSystem] No se encontró preset válido, usando valores por defecto");
#endif
            _maxHp = 100f;
            _currentHp = 100f;
            _isDead = false;
            _lastNotifiedHealth = _currentHp;
        }
        
        // Notificar UI inicial después de la inicialización
        UpdateUI();

        _initialized = true;
        // No necesitamos seguir suscritos tras inicializar
        GameBootService.OnProfileReady -= HandleProfileReady;
    }
    
    // FIX Bajos (auditoría 2026-08-07): `renderer.material` (getter) ya auto-instancia una copia
    // única del material la primera vez que se accede, y esa copia se descarta inmediatamente al
    // envolverla en `new Material(...)` — una fuga por renderer cada vez que se llama a este
    // método. Se usa `sharedMaterial` como origen (no instancia nada) y se destruyen instancias
    // previas si el método se llegara a llamar más de una vez en la vida del componente.
    /// <summary>
    /// FIX 4 sep 2026: llamado desde WardrobeInventory.OnWardrobeChanged. En vez de recapturar y
    /// recachear TODOS los renderers (lo que destruiría y recrearía instancias de material para
    /// piezas que ya llevaban rato con su parpadeo funcionando con normalidad), solo AÑADE al
    /// array los Renderer nuevos que no estuvieran ya trackeados — típicamente los de la prenda
    /// recién equipada — y les crea su propia instancia de material igual que hace
    /// CacheOriginalMaterials() para el resto.
    /// </summary>
    private void RefreshRenderersForWardrobeChange()
    {
        var current = GetComponentsInChildren<Renderer>();
        var already = new HashSet<Renderer>(_renderers ?? System.Array.Empty<Renderer>());
        var newOnes = new List<Renderer>();
        foreach (var r in current)
        {
            if (r != null && !already.Contains(r))
                newOnes.Add(r);
        }
        if (newOnes.Count == 0) return;

        int oldLen = _renderers?.Length ?? 0;
        var mergedRenderers = new Renderer[oldLen + newOnes.Count];
        var mergedMaterials = new Material[oldLen + newOnes.Count];
        if (_renderers != null) System.Array.Copy(_renderers, mergedRenderers, oldLen);
        if (_originalMaterials != null) System.Array.Copy(_originalMaterials, mergedMaterials, oldLen);

        for (int i = 0; i < newOnes.Count; i++)
        {
            var r = newOnes[i];
            mergedRenderers[oldLen + i] = r;
            mergedMaterials[oldLen + i] = new Material(r.sharedMaterial);
            r.material = mergedMaterials[oldLen + i];
        }

        _renderers = mergedRenderers;
        _originalMaterials = mergedMaterials;
    }

    private void CacheOriginalMaterials()
    {
        if (_renderers == null) return;

        if (_originalMaterials != null)
        {
            for (int i = 0; i < _originalMaterials.Length; i++)
            {
                if (_originalMaterials[i] != null)
                    Destroy(_originalMaterials[i]);
            }
        }

        _originalMaterials = new Material[_renderers.Length];
        for (int i = 0; i < _renderers.Length; i++)
        {
            if (_renderers[i] != null)
            {
                // Crear una instancia del material para evitar modificar el material compartido
                _originalMaterials[i] = new Material(_renderers[i].sharedMaterial);
                _renderers[i].material = _originalMaterials[i];
            }
        }

    }
    
    /// <summary>
    /// Aplica daño al jugador
    /// </summary>
    public bool TakeDamage(float damageAmount, bool ignoreInvulnerability = false)
    {
        if (!IsAlive || damageAmount <= 0f) return false;
        // FIX A10 (auditoría 2026-08-07): god-frame durante cinemáticas. Sin esto, un AoE/proyectil
        // residual que impacta justo cuando arranca una cinemática (o un daño en curso que se
        // resuelve un frame después de que ActionMode.Cinematic ya esté en la pila) podía matar al
        // jugador y disparar el GameOver DENTRO de la cinemática — pantalla de muerte superpuesta a
        // una secuencia que se supone segura.
        if (_actionManager != null && _actionManager.Top == ActionMode.Cinematic) return false;
        if (IsInvulnerable && !ignoreInvulnerability) return false;

        // Reglas del jugador sobre el golpe (su defensa, ver CombateDelPersonaje; INC-470). Como en
        // Damageable, pero aquí un golpe nunca cura: si queda en 0 o menos, no hace nada.
        GetComponentsInParent(true, _filtrosDeDano);
        for (int i = 0; i < _filtrosDeDano.Count; i++)
            damageAmount = _filtrosDeDano[i].Filtrar(damageAmount, null);
        _filtrosDeDano.Clear();
        if (damageAmount <= 0f) return false;

        float oldHealth = _currentHp;
        _currentHp = Mathf.Max(godMode ? Mathf.Min(1f, oldHealth) : 0f, oldHealth - damageAmount);
        
        // Actualizar también el GameBootProfile si es necesario
        UpdateGameBootProfile();
        
        // Activar invulnerabilidad
        StartInvulnerability();
        
        // IMPORTANTE: Seleccionar y ejecutar animación de daño aleatoria INMEDIATAMENTE
        string selectedDamageAnim = GetRandomDamageAnimation();
        if (!string.IsNullOrEmpty(selectedDamageAnim))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[PlayerHealthSystem] 💥 Reproduciendo animación de daño: '{selectedDamageAnim}' ({damageAnimationNames?.Length ?? 0} variantes disponibles)");
#endif
            TriggerAnimation(selectedDamageAnim);
            _animDeDanoLanzada = selectedDamageAnim;
            _frameAnimDeDano = Time.frameCount;
        }
        
        // Efectos visuales y sonoros
        PlayDamageEffects();
        
        // Aplicar knockback DESPUÉS de la animación
        if (enableKnockback)
        {
            StartCoroutine(DelayedKnockback());
        }
        
        // Verificar muerte
        if (_currentHp <= 0 && !_isDead)
        {
            Die();
        }
        
        // Notificar eventos
        OnDamageTaken?.Invoke(damageAmount, _currentHp);
        OnDamageReceived?.Invoke(damageAmount);
        UpdateUI();
        
        return true;
    }
    
    private IEnumerator DelayedKnockback()
    {
        // Pequeño delay para que la animación empiece primero
        yield return new WaitForSeconds(0.1f);
        // Empujar en la dirección opuesta a donde mira el jugador.
        yield return ApplyKnockback(-transform.forward, knockbackForce);
    }
    
    /// <summary>
    /// Cura al jugador
    /// </summary>
    public bool Heal(float healAmount)
    {
        if (healAmount <= 0f) return false;
        if (_currentHp >= _maxHp) return false;
        
        float oldHealth = _currentHp;
        _currentHp = Mathf.Min(_maxHp, oldHealth + healAmount);
        float actualHeal = _currentHp - oldHealth;
        
        if (actualHeal <= 0f) return false;
        
        // Actualizar GameBootProfile
        UpdateGameBootProfile();
        
        // Verificar revivir
        if (_isDead && _currentHp > 0)
        {
            ReviveInternal();
        }
        
        // Efectos solo si el jugador está vivo
        if (_currentHp > 0)
        {
            PlayHealEffects();
        }
        
        // Notificar eventos
        OnHealed?.Invoke(actualHeal, _currentHp);
        UpdateUI();
        
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[PlayerHealth] Jugador curado {actualHeal}. Vida: {_currentHp}/{_maxHp} - Estado: {(_currentHp > 0 ? "VIVO" : "MUERTO")}");
#endif
        
        return true;
    }
    
    /// <summary>
    /// Mata instantáneamente al jugador
    /// </summary>
    public void Kill()
    {
        if (!IsAlive || godMode) return;
        
        _currentHp = 0f;
        UpdateGameBootProfile();
        
        if (!_isDead)
        {
            Die();
        }
        
        UpdateUI();
    }
    
    /// <summary>
    /// Revive al jugador con vida completa
    /// </summary>
    public void Revive(float healthPercentage = 1f)
    {
        healthPercentage = Mathf.Clamp01(healthPercentage);
        _currentHp = _maxHp * healthPercentage;
        
        UpdateGameBootProfile();
        
        if (_isDead && _currentHp > 0)
        {
            ReviveInternal();
        }
        
        UpdateUI();
    }
    
    /// <summary>
    /// Actualiza el GameBootProfile con los valores actuales de salud
    /// </summary>
    private void UpdateGameBootProfile()
    {
        // La vida del preset es la de Will. Con otro personaje al mando, este cuerpo lleva la suya,
        // que guarda SaludDelGrupo. Ver INC-717.
        if (ControlDelJugador.Activo != PartyControlManager.CharacterSlot.Will) return;
        var bootProfile = GameBootService.Profile;
        if (bootProfile != null)
        {
            var preset = Partida.Preset;
            if (preset != null)
            {
                preset.currentHP = _currentHp;
                preset.maxHP = _maxHp;
            }
        }
    }
    
    /// <summary>
    /// Establece la salud máxima y actualiza la actual proporcionalmente
    /// </summary>
    public void SetMaxHealth(float newMaxHp)
    {
        if (newMaxHp <= 0) return;
        
        float healthRatio = _maxHp > 0 ? _currentHp / _maxHp : 1f;
        _maxHp = newMaxHp;
        _currentHp = _maxHp * healthRatio;
        
        UpdateGameBootProfile();
        UpdateUI();
    }
    
    /// <summary>
    /// Establece la salud actual directamente
    /// </summary>
    public void SetCurrentHealth(float newCurrentHp)
    {
        _currentHp = Mathf.Clamp(newCurrentHp, 0f, _maxHp);
        
        bool wasDead = _isDead;
        bool shouldBeDead = _currentHp <= 0;
        
        if (!wasDead && shouldBeDead)
        {
            Die();
        }
        else if (wasDead && !shouldBeDead)
        {
            ReviveInternal();
        }
        
        UpdateGameBootProfile();
        UpdateUI();
    }
    
    private void Die()
    {
        if (_isDead) return;

        // Si queda otro personaje del grupo en pie, este cae y el mando pasa a él: no hay Game Over.
        if (!_sinRelevo && SaludDelGrupo.IntentarRelevo(this)) return;
        _sinRelevo = false;

        _isDead = true;

        // FIX A10 (auditoría 2026-08-07): vaciar la pila de modos al morir. Sin esto, morir con
        // Flying/Carrying/Cinematic/Stunned pushed (p. ej. un AoE que mata en pleno vuelo) dejaba
        // esos modos "vivos" de cara al respawn — el jugador reaparecía con el input parcialmente
        // bloqueado por un modo que ya no tiene sentido tras la muerte.
        _actionManager?.ResetToDefault();

        // Asegurar que la salud está a 0
        _currentHp = 0f;

        // Sincronizar profile y UI INMEDIATAMENTE para que el HUD muestre correctamente 0
        UpdateGameBootProfile();
        UpdateUI();

        // Notificar eventos lo antes posible (antes de intentar animaciones/sonidos que podrían lanzar)
        try
        {
            OnPlayerDeath?.Invoke();
            OnDied?.Invoke();
        }
        catch (Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            e
#endif
        )
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[PlayerHealth] Excepción al invocar eventos de muerte: {e}");
#endif
        }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log("[PlayerHealth] ¡El jugador ha muerto!");
#endif

        // Intentar ejecutar efectos (animación/sonido) de forma segura; si fallan, no impedimos la notificación de GameOver
        try
        {
            PlaySound(deathSoundKey);
            PlayVocalReaction(deathReactionKind);
            _caidaIniciada = false;
            if (_caidaCoroutine != null) StopCoroutine(_caidaCoroutine);
            if (isActiveAndEnabled)
                _caidaCoroutine = StartCoroutine(Co_Caida());
            else
            {
                TriggerAnimation(deathAnimationName);
                _caidaIniciada = true;
            }
        }
        catch (Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            e
#endif
        )
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[PlayerHealth] Error al reproducir animación/sonido de muerte: {e}");
#endif
        }

        try
        {
            // Pasamos la referencia a este PlayerHealthSystem para que GameOverManager pueda
            // enfocar la cámara en el jugador correcto y sincronizar la transición de pantalla
            // con el final real de la animación de caída (ver HasDeathAnimationFinished()).
            GameOverManager.NotifyGameOver(this);
        }
        catch (Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            e
#endif
        )
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[PlayerHealth] Error notificando GameOver: {e}");
#endif
        }
    }

    /// <summary>
    /// Indica si la animación de muerte (<see cref="deathAnimationName"/>) ha terminado de
    /// reproducirse, es decir, si el jugador ya ha llegado al suelo. La usa GameOverManager
    /// para disparar la transición de pantalla justo cuando termina la caída, en vez de tras
    /// una espera fija que podía cortar antes de tiempo o dejar un hueco muerto después.
    /// </summary>
    public bool HasDeathAnimationFinished()
    {
        if (_animator == null || string.IsNullOrEmpty(deathAnimationName)) return true;

        // Todavía en la animación de daño que precede a la caída (ver Co_Caida).
        if (!_caidaIniciada) return false;

        // Si nunca llegamos a resolver el estado (p. ej. TriggerAnimation falló al arrancar la
        // animación), no tenemos forma de saberlo: no bloqueamos la transición indefinidamente.
        if (!_stateHash.TryGetValue(deathAnimationName, out int hash) ||
            !_stateLayer.TryGetValue(deathAnimationName, out int layer))
            return true;

        var stateInfo = _animator.GetCurrentAnimatorStateInfo(layer);

        // Si el Animator ya no está en el estado de muerte (transicionó a otro, p. ej. un Idle de
        // "muerto en el suelo"), damos la caída por completada.
        if (stateInfo.shortNameHash != hash && stateInfo.fullPathHash != hash) return !_animator.IsInTransition(layer);

        return stateInfo.normalizedTime >= 1f && !_animator.IsInTransition(layer);
    }

    /// <summary>
    /// Al morir: la animación de daño y, cuando termina, la de caída. Las dos en tiempo real y a
    /// <see cref="ritmoDeLaCaida"/>, para que la cámara lenta del Game Over no las deje a medias.
    /// Si la muerte viene de un golpe, su animación de daño ya la lanzó TakeDamage en este frame.
    /// </summary>
    private IEnumerator Co_Caida()
    {
        PonerAnimatorEnModoCaida();

        string dano = _frameAnimDeDano == Time.frameCount ? _animDeDanoLanzada : null;
        if (string.IsNullOrEmpty(dano))
        {
            dano = GetRandomDamageAnimation();
            if (!string.IsNullOrEmpty(dano)) TriggerAnimation(dano);
        }

        if (_animator != null && !string.IsNullOrEmpty(dano) && EnsureResolved(dano))
        {
            int hash = _stateHash[dano];
            int layer = _stateLayer[dano];
            float limite = Time.unscaledTime + topeAnimacionDeDano;
            bool entro = false;

            while (Time.unscaledTime < limite && _animator != null)
            {
                yield return null;

                var actual = _animator.GetCurrentAnimatorStateInfo(layer);
                bool enDano = EsEstado(actual, hash);
                if (enDano)
                {
                    entro = true;
                    if (actual.normalizedTime >= 0.9f) break;
                    continue;
                }

                if (_animator.IsInTransition(layer) && EsEstado(_animator.GetNextAnimatorStateInfo(layer), hash))
                {
                    entro = true;
                    continue;
                }

                // Ya ha salido del estado de daño (o su transición de salida ha empezado).
                if (entro) break;
            }
        }

        TriggerAnimation(deathAnimationName);
        _caidaIniciada = true;
        _caidaCoroutine = null;
    }

    private static bool EsEstado(AnimatorStateInfo info, int hash)
        => info.shortNameHash == hash || info.fullPathHash == hash;

    private void PonerAnimatorEnModoCaida()
    {
        if (_animator == null) return;
        if (!_animatorEnModoCaida)
        {
            _modoAnimatorPrevio = _animator.updateMode;
            _velocidadAnimatorPrevia = _animator.speed;
            _animatorEnModoCaida = true;
        }
        _animator.updateMode = AnimatorUpdateMode.UnscaledTime;
        _animator.speed = ritmoDeLaCaida;
    }

    private void RestaurarAnimatorTrasCaida()
    {
        if (_caidaCoroutine != null)
        {
            StopCoroutine(_caidaCoroutine);
            _caidaCoroutine = null;
        }
        if (!_animatorEnModoCaida) return;
        _animatorEnModoCaida = false;
        if (_animator == null) return;
        _animator.updateMode = _modoAnimatorPrevio;
        _animator.speed = _velocidadAnimatorPrevia;
    }

    private void ReviveInternal()
    {
        if (!_isDead) return;

        _isDead = false;
        _caidaIniciada = false;
        RestaurarAnimatorTrasCaida();

        // FIX A10 (auditoría 2026-08-07): red de seguridad — vaciar la pila de nuevo por si algún
        // sistema empujó un modo entre la muerte y el revive (p. ej. una cinemática de Game Over).
        _actionManager?.ResetToDefault();

        // FIX A10 (auditoría 2026-08-07): invulnerabilidad temporal al revivir. Sin esto, el
        // jugador podía reaparecer exactamente sobre el peligro que lo mató (el anchor de
        // respawn no garantiza estar fuera del radio de un AoE/trampa) y morir de nuevo antes de
        // recuperar el control.
        StartInvulnerability();

        // Teletransportar al último anchor conocido si existe
        try
        {
            if (!string.IsNullOrEmpty(SpawnManager.CurrentAnchorId))
            {
                SpawnManager.TeleportToCurrent(true);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log("[PlayerHealth] Revivido y teletransportado al último punto de partida guardado");
#endif
            }
            else
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log("[PlayerHealth] Revivido pero no hay anchor guardado (CurrentAnchorId vacío)");
#endif
            }
        }
        catch (Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            ex
#endif
        )
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[PlayerHealth] Error al teletransportar en ReviveInternal: {ex.Message}");
#endif
        }

        // Actualizar profile/UI para asegurar que la HUD muestra el estado correcto
        UpdateGameBootProfile();
        UpdateUI();

        // Notificar eventos
        try
        {
            OnPlayerRevived?.Invoke();
        }
        catch (Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            ex
#endif
        )
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[PlayerHealth] Excepción al invocar OnPlayerRevived: {ex.Message}");
#endif
        }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log("[PlayerHealth] ¡El jugador ha revivido!");
#endif
    }
    
    /// <summary>
    /// Pone la vida del personaje que pasa a llevar el jugador, sin efectos de daño ni de curación.
    /// La usa SaludDelGrupo al cambiar de personaje (cada uno tiene su vida). Ver INC-717.
    /// </summary>
    public void CargarPersonaje(float vidaMaxima, float vidaActual)
    {
        _maxHp = Mathf.Max(1f, vidaMaxima);
        _currentHp = Mathf.Clamp(vidaActual, 0f, _maxHp);
        if (_isDead && _currentHp > 0f)
        {
            _isDead = false;
            _caidaIniciada = false;
            RestaurarAnimatorTrasCaida();
        }
        _lastNotifiedHealth = _currentHp;
        ResetDamageVisuals();
        UpdateGameBootProfile();
        UpdateUI();
    }

    /// <summary>Muere sin pasar el mando a otro personaje: Game Over. Ver INC-717.</summary>
    public void MorirSinRelevo()
    {
        if (_isDead || godMode) return;
        _currentHp = 0f;
        _sinRelevo = true;
        Die();
    }

    /// <summary>Amplía la protección temporal sin acortar una invulnerabilidad vigente.</summary>
    public void HacerInvulnerable(float segundos, bool parpadeo)
    {
        if (segundos <= 0f || !IsAlive) return;
        _invulnerableUntil = Mathf.Max(_invulnerableUntil, Time.time + segundos);
        if (parpadeo) StartInvulnerabilityFlash();
    }

    private void StartInvulnerability()
    {
        _invulnerableUntil = Time.time + invulnerabilityDuration;
        
        if (invulnerabilityDuration > 0f)
        {
            StartInvulnerabilityFlash();
        }
    }
    
    private void PlayDamageEffects()
    {
        StartDamageFlash();
        SpawnVFX(damageVFX);
        PlaySound(damageSoundKey);
        if (playDamageReaction && Time.unscaledTime >= _nextDamageReactionTime)
        {
            PlayVocalReaction(damageReactionKind);
            _nextDamageReactionTime = Time.unscaledTime + damageReactionCooldown;
        }
        
        if (enableCameraShake)
        {
            FeedbackService.CameraShake(shakeIntensity, shakeDuration);
        }
    }
    
    private void PlayVocalReaction(string kind)
    {
        if (AudioService.Instance == null || string.IsNullOrWhiteSpace(reactionCharacter)
            || string.IsNullOrWhiteSpace(kind)) return;
        AudioService.Instance.PlayReaction(reactionCharacter, kind);
    }

    private void PlayHealEffects()
    {
        SpawnVFX(healVFX);
        PlaySound(healSoundKey);
    }
    
    private void StartDamageFlash()
    {
        if (_damageFlashCoroutine != null)
            StopCoroutine(_damageFlashCoroutine);
        _damageFlashCoroutine = StartCoroutine(DamageFlashCoroutine());
    }
    
    private IEnumerator DamageFlashCoroutine()
    {
        SetRenderersColor(damageFlashColor);
        yield return new WaitForSeconds(damageFlashDuration);
        RestoreOriginalMaterials();
        _damageFlashCoroutine = null;
    }
    
    private void StartInvulnerabilityFlash()
    {
        if (_invulnerabilityFlashCoroutine != null)
            StopCoroutine(_invulnerabilityFlashCoroutine);
        _invulnerabilityFlashCoroutine = StartCoroutine(InvulnerabilityFlashCoroutine());
    }
    
    private IEnumerator InvulnerabilityFlashCoroutine()
    {
        while (Time.time < _invulnerableUntil)
        {
            SetRenderersVisibility(false);
            yield return new WaitForSeconds(invulnerabilityFlashRate);
            SetRenderersVisibility(true);
            yield return new WaitForSeconds(invulnerabilityFlashRate);
        }

        _invulnerabilityFlashCoroutine = null;
        SetRenderersVisibility(true);
    }

    /// <summary>
    /// Deshace lo que el destello y el parpadeo de daño hayan dejado a medias: vuelve a los
    /// materiales originales y enciende los renderers que apagó el parpadeo (solo esos).
    /// </summary>
    public void ResetDamageVisuals()
    {
        if (_damageFlashCoroutine != null)
        {
            StopCoroutine(_damageFlashCoroutine);
            _damageFlashCoroutine = null;
        }

        if (_invulnerabilityFlashCoroutine != null)
        {
            StopCoroutine(_invulnerabilityFlashCoroutine);
            _invulnerabilityFlashCoroutine = null;
        }

        SetRenderersVisibility(true);
        RestoreOriginalMaterials();
    }
    
    private void SetRenderersColor(Color color)
    {
        if (_renderers == null || _originalMaterials == null) return;
        
        for (int i = 0; i < _renderers.Length && i < _originalMaterials.Length; i++)
        {
            if (_renderers[i] != null && _originalMaterials[i] != null)
            {
                SetMaterialColor(_renderers[i].material, color);
            }
        }
    }
    
    /// <summary>
    /// Establece el color de un material, soportando tanto Standard (_Color) como URP (_BaseColor)
    /// </summary>
    private void SetMaterialColor(Material material, Color color)
    {
        if (material == null) return;
        
        // Intentar URP primero (_BaseColor)
        if (material.HasProperty(BaseColorPropertyID))
        {
            material.SetColor(BaseColorPropertyID, color);
        }
        // Fallback a Standard (_Color)
        else if (material.HasProperty(ColorPropertyID))
        {
            material.SetColor(ColorPropertyID, color);
        }
    }
    
    /// <summary>
    /// Obtiene el color de un material, soportando tanto Standard (_Color) como URP (_BaseColor)
    /// </summary>
    private Color GetMaterialColor(Material material)
    {
        if (material == null) return Color.white;
        
        // Intentar URP primero (_BaseColor)
        if (material.HasProperty(BaseColorPropertyID))
        {
            return material.GetColor(BaseColorPropertyID);
        }
        // Fallback a Standard (_Color)
        else if (material.HasProperty(ColorPropertyID))
        {
            return material.GetColor(ColorPropertyID);
        }
        
        return Color.white;
    }
    
    /// <summary>
    /// Parpadeo de invulnerabilidad. Apagar solo toca los renderers que estaban encendidos y los
    /// apunta; encender solo vuelve a encender esos. Así el parpadeo nunca enseña algo que otro
    /// sistema tenía oculto (INC-527: la cabeza de Will en el plano corto de un diálogo).
    /// </summary>
    private void SetRenderersVisibility(bool visible)
    {
        if (!visible)
        {
            if (_renderers == null) return;
            foreach (var rend in _renderers)
            {
                if (rend == null || !rend.enabled) continue;
                rend.enabled = false;
                _ocultosPorParpadeo.Add(rend);
            }
            return;
        }

        for (int i = 0; i < _ocultosPorParpadeo.Count; i++)
        {
            if (_ocultosPorParpadeo[i] != null)
                _ocultosPorParpadeo[i].enabled = true;
        }
        _ocultosPorParpadeo.Clear();
    }
    
    private void RestoreOriginalMaterials()
    {
        if (_renderers == null || _originalMaterials == null) return;

        for (int i = 0; i < _renderers.Length && i < _originalMaterials.Length; i++)
        {
            if (_renderers[i] != null && _originalMaterials[i] != null)
            {
                // Restaurar el color usando el método que soporta URP y Standard
                Color originalColor = GetMaterialColor(_originalMaterials[i]);
                SetMaterialColor(_renderers[i].material, originalColor);
            }
        }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log("[PlayerHealthSystem] Materiales restaurados al color original");
#endif
    }
    
    private void SpawnVFX(GameObject vfxPrefab)
    {
        if (vfxPrefab != null)
        {
            VfxPoolService.Instance.Play(vfxPrefab, transform.position, transform.rotation, 3f);
        }
    }
    
    private void PlaySound(string sfxKey)
    {
        if (!string.IsNullOrWhiteSpace(sfxKey))
        {
            AudioService.Instance?.PlaySFX(sfxKey, 1f, transform.position);
        }
    }
    
    /// <summary>
    /// Selecciona una animación de daño aleatoria del array configurado.
    /// Esto proporciona variedad visual y evita repetición.
    /// </summary>
    private string GetRandomDamageAnimation()
    {
        if (damageAnimationNames == null || damageAnimationNames.Length == 0)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[PlayerHealthSystem] ⚠️ No hay animaciones de daño configuradas en el array damageAnimationNames");
#endif
            return null;
        }
        
        // Seleccionar aleatoriamente
        int randomIndex = UnityEngine.Random.Range(0, damageAnimationNames.Length);
        return damageAnimationNames[randomIndex];
    }
    
    private void TriggerAnimation(string animationName)
    {
        if (_animator == null || string.IsNullOrEmpty(animationName))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[PlayerHealthSystem] No se puede reproducir animación - Animator: {(_animator != null ? "OK" : "NULL")}, AnimationName: '{animationName}'");
#endif
            return;
        }

        // Un estado de la capa de brazos necesita su peso; uno de cuerpo entero (capa base) necesita
        // quitar la pose de combate de los brazos, que lo taparía de cintura para arriba. Ver INC-1100
        if (EnsureResolved(animationName) && upperBodyLayer >= 0 && upperBodyLayer < _animator.layerCount)
        {
            if (_stateLayer[animationName] == upperBodyLayer) _animator.SetLayerWeight(upperBodyLayer, 1f);
            else
            {
                if (_modoDeBatalla == null) _modoDeBatalla = GetComponentInParent<Game.Player.PlayerBattleModeController>(true) ?? GetComponentInChildren<Game.Player.PlayerBattleModeController>(true);
                if (_modoDeBatalla != null) _modoDeBatalla.SoltarBrazos(segundosSinPoseDeBrazos);
                else _animator.SetLayerWeight(upperBodyLayer, 0f);
            }
        }

        // Intentar reproducir usando CrossFade en el estado resuelto (más seguro)
        if (CrossFadeResolved(animationName, 0.05f))
        {
            int layer = _stateLayer.ContainsKey(animationName) ? _stateLayer[animationName] : 0;
            return;
        }

        // Si CrossFade falló, intentamos resolver el estado y usar Play por hash (más seguro que Play(string))
        if (EnsureResolved(animationName))
        {
            int hash = _stateHash[animationName];
            int layer = _stateLayer[animationName];
            _animator.Play(hash, layer, 0f);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[PlayerHealthSystem] Reproduciendo animación (Play por hash): {animationName} en layer {layer}");
#endif
            return;
        }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.LogWarning($"[PlayerHealthSystem] No se encontró el estado '{animationName}' en Animator. Asegúrate del nombre EXACTO o usa la ruta completa (p. ej. 'Base Layer.NombreEstado').");
#endif
    }

    // ===== Helpers para resolución segura de estados en el Animator =====
    private bool CrossFadeResolved(string stateNameOrPath, float fade)
    {
        if (_animator == null) return false;
        if (!EnsureResolved(stateNameOrPath)) return false;

        int hash = _stateHash[stateNameOrPath];
        int layer = _stateLayer[stateNameOrPath];
        _animator.CrossFadeInFixedTime(hash, fade, layer, 0f);
        return true;
    }

    private bool EnsureResolved(string nameOrPath)
    {
        if (string.IsNullOrEmpty(nameOrPath) || _animator == null) return false;
        if (_stateHash.ContainsKey(nameOrPath)) return true;

        // Probar variantes comunes de nombre (por ejemplo sufijos usados en el animator como _NoWeapon)
        string[] suffixes = new string[] { "", "_NoWeapon", "-NoWeapon" };
        var candidateList = new List<string>();
        foreach (var s in suffixes)
        {
            candidateList.Add(nameOrPath + s);
            candidateList.Add($"Base Layer.{nameOrPath}{s}");
            candidateList.Add($"Base Layer.Locomotion.{nameOrPath}{s}");
        }
        string[] candidates = candidateList.ToArray();

        for (int layer = 0; layer < _animator.layerCount; layer++)
        {
            foreach (var cand in candidates)
            {
                int h = Animator.StringToHash(cand);
                if (_animator.HasState(layer, h))
                {
                    _stateHash[nameOrPath] = h;
                    _stateLayer[nameOrPath] = layer;
                    return true;
                }
            }
        }

        // intento directo por si ya viene con ruta completa
        int directHash = Animator.StringToHash(nameOrPath);
        for (int layer = 0; layer < _animator.layerCount; layer++)
        {
            if (_animator.HasState(layer, directHash))
            {
                _stateHash[nameOrPath] = directHash;
                _stateLayer[nameOrPath] = layer;
                return true;
            }
        }

        // Depuración: listar candidatos probados (solo si no se encontró)
        try
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[PlayerHealthSystem] EnsureResolved: no se encontró '{nameOrPath}'. Candidatos probados: {string.Join(", ", candidates)}");
#endif
        }
        catch (Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            ex
#endif
        )
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[PlayerHealthSystem] EnsureResolved: excepción al listar candidatos: {ex.Message}");
#endif
        }

        return false;
    }
    
    [ContextMenu("Dump Animator States")]
    public void DumpAnimatorStates()
    {
        if (_animator == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[PlayerHealthSystem] DumpAnimatorStates: Animator es null");
#endif
            return;
        }

        var rc = _animator.runtimeAnimatorController;
        if (rc == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[PlayerHealthSystem] DumpAnimatorStates: runtimeAnimatorController es null");
#endif
            return;
        }

#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[PlayerHealthSystem] Runtime clips ({rc.animationClips.Length}): {string.Join(", ", Array.ConvertAll(rc.animationClips, c => c.name))}");
#endif

        // Probar las mismas variantes que EnsureResolved para cada layer
        string[] suffixes = new string[] { "", "_NoWeapon", "-NoWeapon" };
        var candidateList = new List<string>();
        
        // Agregar todas las variantes de animaciones de daño
        if (damageAnimationNames != null && damageAnimationNames.Length > 0)
        {
            foreach (var damageAnim in damageAnimationNames)
            {
                foreach (var s in suffixes)
                {
                    candidateList.Add(damageAnim + s);
                    candidateList.Add($"Base Layer.{damageAnim}{s}");
                    candidateList.Add($"Base Layer.Locomotion.{damageAnim}{s}");
                }
            }
        }
        
        string[] candidates = candidateList.ToArray();

        for (int layer = 0; layer < _animator.layerCount; layer++)
        {
            var layerName = _animator.GetLayerName(layer);
            foreach (var cand in candidates)
            {
                int h = Animator.StringToHash(cand);
                bool has = _animator.HasState(layer, h);
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[PlayerHealthSystem] Layer {layer} ('{layerName}') - HasState('{cand}') = {has}");
#endif
            }
        }
    }
    
    private void UpdateUI()
    {
        float healthPercentage = HealthPercentage;
        OnHealthChanged?.Invoke(healthPercentage);
        OnHealthPercentageChanged?.Invoke(healthPercentage);
    }

    /// Aparta al jugador en una dirección, sin hacerle daño (p. ej. la onda del rugido de un jefe).
    public void Empujar(Vector3 direccion, float fuerza)
    {
        if (_isDead || fuerza <= 0f || direccion.sqrMagnitude < 0.0001f) return;
        StartCoroutine(ApplyKnockback(direccion.normalized, fuerza));
    }

    private IEnumerator ApplyKnockback(Vector3 knockbackDirection, float fuerza)
    {

        // Si el objeto tiene Rigidbody, aplicar una fuerza/impulso en vez de mover transform directamente.
        // Mover el transform de un objeto controlado por física puede producir valores NaN en la velocidad.
        var rb = GetComponent<Rigidbody>();
        if (rb != null)
        {
            // Normalizar y comprobar NaN por seguridad
            if (!float.IsNaN(knockbackDirection.x) && !float.IsNaN(knockbackDirection.y) && !float.IsNaN(knockbackDirection.z))
            {
                Vector3 impulse = knockbackDirection.normalized * fuerza;
                rb.AddForce(impulse, ForceMode.Impulse);
            }
            yield break;
        }

        float elapsed = 0f;

        while (elapsed < knockbackDuration)
        {
            float t = elapsed / knockbackDuration;
            float curveValue = knockbackCurve.Evaluate(t);

            // Aplicar fuerza de empuje (fallback para objetos sin Rigidbody)
            Vector3 delta = knockbackDirection * (fuerza * curveValue * Time.deltaTime);
            if (!float.IsNaN(delta.x) && !float.IsNaN(delta.y) && !float.IsNaN(delta.z))
            {
                transform.position += delta;
            }

            elapsed += Time.deltaTime;
            yield return null;
        }
    }
    
    // Métodos públicos para configuración
    public void SetGodMode(bool isEnabled)
    {
        godMode = isEnabled;
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[PlayerHealth] God Mode: {(isEnabled ? "ACTIVADO" : "DESACTIVADO")}");
#endif
    }
}
