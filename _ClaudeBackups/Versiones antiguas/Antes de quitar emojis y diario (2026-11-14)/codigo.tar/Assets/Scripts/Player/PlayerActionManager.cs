using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

/// Reglas declarativas que se aplican cuando un modo es el tope de la pila
[Serializable]
public sealed class ModeRule
{
    public ActionMode mode = ActionMode.Default;

    [Header("Bloqueos de habilidades (lógica)")]
    public PlayerAbility[] blockedAbilities;

    [Header("Desactivar componentes mientras este modo esté arriba")]
    public Behaviour[] disableComponents;

    [Header("Deshabilitar acciones del Input System")]
    public InputActionReference[] disableInputActions;

    [Header("Animación")]
    public bool forceUpperIdle = false;                 // Forzar clip idle de UpperBody
    [Range(0f, 1f)] public float upperBodyWeight = -1f; // -1 = no tocar, 0-1 = forzar peso
}

/// Manager central: prioridades, gates y efectos secundarios por modo
[DefaultExecutionOrder(-100)]
[RequireComponent(typeof(Animator))]
public class PlayerActionManager : MonoBehaviour, IActionValidator
{
    [Header("Animator")]
    [SerializeField] private int upperBodyLayer = 1;
    [SerializeField] private string upperIdleState = "UpperIdle";

    [Header("Reglas por modo (inspector)")]
    [Tooltip("Declara aquí todo lo que debe bloquearse/deshabilitarse por modo. Orden no importa.")]
    [SerializeField] private ModeRule[] rules;

#if UNITY_EDITOR
    [Header("Debug")]
    [SerializeField] private bool debugLogs = false;
#endif

    // --- Runtime: permisos globales aplicables desde presets u otros sistemas ---
    //private bool _allowPhysical = true; // ataques físicos
    private bool _allowSwim = false;     // nadar
    private bool _allowJump = false;     // saltar
    private bool _allowClimb = false;    // trepar
    private bool _allowMagic = false;   // lanzar magia
    private bool _allowFly = false;      // volar
    private bool _allowSprint = false;   // sprint
    private bool _allowShield = false;   // proteccion de magia enemiga (escudo)

    // API pública para que otros sistemas (p.ej. PlayerPresetService) apliquen permisos
    public void ApplyAbilities(PlayerAbilities abilities)
    {
        if (abilities == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[PlayerActionManager] ApplyAbilities called with null abilities!");
#endif
            return;
        }
        // _allowPhysical = abilities.physical;
        _allowSwim = abilities.swim;
        _allowJump = abilities.jump;
        _allowClimb = abilities.climb;
        _allowFly = abilities.fly;
        _allowMagic = abilities.magic;
        _allowSprint = abilities.sprint;
        _allowShield = abilities.shield;

        //if (debugLogs) Debug.Log($"[PlayerActionManager] Abilities applied: Swim={_allowSwim} Jump={_allowJump} Climb={_allowClimb} Fly={_allowFly} Magic={_allowMagic}");
        //else Debug.Log($"[PlayerActionManager] Abilities applied: Fly={_allowFly}");
    }

    // Opcional: getters públicos si otros sistemas necesitan consultarlos
    //public bool AllowPhysical => _allowPhysical;
    public bool AllowSwim => _allowSwim;
    public bool AllowJump => _allowJump;
    public bool AllowClimb => _allowClimb;
    public bool AllowMagic => _allowMagic;
    public bool AllowFly => _allowFly;
    public bool AllowSprint => _allowSprint;
    public bool AllowShield => _allowShield;

    public event Action<ActionMode> OnTopModeChanged;

    // --- Internals ---
    private readonly List<ActionMode> _stack = new() { ActionMode.Default };
    private readonly Dictionary<ActionMode, HashSet<PlayerAbility>> _blockedByMode = new();
    private readonly Dictionary<ActionMode, ModeRule> _ruleByMode = new();
    private Animator _anim;
    private Invector.vCharacterController.vThirdPersonMotor _motor;
    private PlayerDialogueAnimator _dialogueAnimator;
    private float _originalUpperWeight = 0f;
    private readonly object _lockOwner = new();
    private bool _hasMovementLock;
    
    // Cooldown para Interact - evita que el botón A se procese como salto justo después de interactuar
    private float _interactCooldownUntil = 0f;
    private const float INTERACT_COOLDOWN_DURATION = 0.3f;

    void Awake()
    {
        _anim = GetComponent<Animator>();
        _motor = GetComponent<Invector.vCharacterController.vThirdPersonMotor>();
        _dialogueAnimator = GetComponentInChildren<PlayerDialogueAnimator>(true);
        if (_anim == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[PlayerActionManager] No Animator on '{name}' — animation features disabled. (Is this component on a disabled GO that never ran Awake?)", gameObject);
#endif
        }

        // Guardar peso original del UpperBody
        if (_anim != null && upperBodyLayer > 0 && _anim.layerCount > upperBodyLayer)
            _originalUpperWeight = _anim.GetLayerWeight(upperBodyLayer);

        // Preconstruir diccionarios para O(1) en runtime
        if (rules != null)
        {
            foreach (var r in rules)
            {
                if (r == null) continue;
                _ruleByMode[r.mode] = r;

                var set = new HashSet<PlayerAbility>();
                if (r.blockedAbilities != null)
                    foreach (var a in r.blockedAbilities) set.Add(a);
                _blockedByMode[r.mode] = set;
            }
        }

        // Garantiza entrada Default
        if (!_blockedByMode.ContainsKey(ActionMode.Default))
            _blockedByMode[ActionMode.Default] = new HashSet<PlayerAbility>();

        // GARANTIZAR bloqueo total de input durante cinemática/diálogo
        if (!_blockedByMode.ContainsKey(ActionMode.Cinematic))
            _blockedByMode[ActionMode.Cinematic] = new HashSet<PlayerAbility>();
        _blockedByMode[ActionMode.Cinematic].Add(PlayerAbility.Interact);
        _blockedByMode[ActionMode.Cinematic].Add(PlayerAbility.Jump);
        _blockedByMode[ActionMode.Cinematic].Add(PlayerAbility.Sprint);
        _blockedByMode[ActionMode.Cinematic].Add(PlayerAbility.Move);
        _blockedByMode[ActionMode.Cinematic].Add(PlayerAbility.Attack);
        _blockedByMode[ActionMode.Cinematic].Add(PlayerAbility.Roll);
        _blockedByMode[ActionMode.Cinematic].Add(PlayerAbility.Magic);
        _blockedByMode[ActionMode.Cinematic].Add(PlayerAbility.Carry);
        _blockedByMode[ActionMode.Cinematic].Add(PlayerAbility.Aim);

        // GARANTIZAR bloqueos críticos para modo Carrying (independiente del Inspector)
        if (!_blockedByMode.ContainsKey(ActionMode.Carrying))
            _blockedByMode[ActionMode.Carrying] = new HashSet<PlayerAbility>();
        
        // Asegurar que Carrying SIEMPRE bloquee estas habilidades
        _blockedByMode[ActionMode.Carrying].Add(PlayerAbility.Magic);
        _blockedByMode[ActionMode.Carrying].Add(PlayerAbility.Attack);
        _blockedByMode[ActionMode.Carrying].Add(PlayerAbility.Roll);
        _blockedByMode[ActionMode.Carrying].Add(PlayerAbility.Jump);

        // GARANTIZAR bloqueos críticos para modo Stunned (independiente del Inspector)
        if (!_blockedByMode.ContainsKey(ActionMode.Stunned))
            _blockedByMode[ActionMode.Stunned] = new HashSet<PlayerAbility>();
        
        // Asegurar que Stunned SIEMPRE bloquee TODAS las habilidades (usado para limpiar inputs)
        _blockedByMode[ActionMode.Stunned].Add(PlayerAbility.Move);
        _blockedByMode[ActionMode.Stunned].Add(PlayerAbility.Jump);
        _blockedByMode[ActionMode.Stunned].Add(PlayerAbility.Sprint);
        _blockedByMode[ActionMode.Stunned].Add(PlayerAbility.Roll);
        _blockedByMode[ActionMode.Stunned].Add(PlayerAbility.Attack);
        _blockedByMode[ActionMode.Stunned].Add(PlayerAbility.Magic);
        _blockedByMode[ActionMode.Stunned].Add(PlayerAbility.Interact);
        _blockedByMode[ActionMode.Stunned].Add(PlayerAbility.Carry);

        // GARANTIZAR bloqueos críticos para modo Inventory (independiente del Inspector)
        if (!_blockedByMode.ContainsKey(ActionMode.Inventory))
            _blockedByMode[ActionMode.Inventory] = new HashSet<PlayerAbility>();

        _blockedByMode[ActionMode.Inventory].Add(PlayerAbility.Move);
        _blockedByMode[ActionMode.Inventory].Add(PlayerAbility.Jump);
        _blockedByMode[ActionMode.Inventory].Add(PlayerAbility.Sprint);
        _blockedByMode[ActionMode.Inventory].Add(PlayerAbility.Roll);
        _blockedByMode[ActionMode.Inventory].Add(PlayerAbility.Attack);
        _blockedByMode[ActionMode.Inventory].Add(PlayerAbility.Magic);
        _blockedByMode[ActionMode.Inventory].Add(PlayerAbility.Interact);
        _blockedByMode[ActionMode.Inventory].Add(PlayerAbility.Carry);
        _blockedByMode[ActionMode.Inventory].Add(PlayerAbility.Aim);

        // GARANTIZAR bloqueos críticos para modo Swimming (independiente del Inspector)
        if (!_blockedByMode.ContainsKey(ActionMode.Swimming))
            _blockedByMode[ActionMode.Swimming] = new HashSet<PlayerAbility>();
        
        // Asegurar que Swimming SIEMPRE bloquee estas habilidades
        _blockedByMode[ActionMode.Swimming].Add(PlayerAbility.Jump);
        _blockedByMode[ActionMode.Swimming].Add(PlayerAbility.Sprint);
        _blockedByMode[ActionMode.Swimming].Add(PlayerAbility.Roll);
        _blockedByMode[ActionMode.Swimming].Add(PlayerAbility.Attack);
        _blockedByMode[ActionMode.Swimming].Add(PlayerAbility.Magic);
        _blockedByMode[ActionMode.Swimming].Add(PlayerAbility.Carry);
        _blockedByMode[ActionMode.Swimming].Add(PlayerAbility.Interact);

        // GARANTIZAR bloqueos básicos para Flying (independiente del Inspector)
        if (!_blockedByMode.ContainsKey(ActionMode.Flying))
            _blockedByMode[ActionMode.Flying] = new HashSet<PlayerAbility>();

        _blockedByMode[ActionMode.Flying].Add(PlayerAbility.Jump);
        _blockedByMode[ActionMode.Flying].Add(PlayerAbility.Roll);

        // GARANTIZAR bloqueos básicos para Climbing (independiente del Inspector)
        if (!_blockedByMode.ContainsKey(ActionMode.Climbing))
            _blockedByMode[ActionMode.Climbing] = new HashSet<PlayerAbility>();

        _blockedByMode[ActionMode.Climbing].Add(PlayerAbility.Jump);
        _blockedByMode[ActionMode.Climbing].Add(PlayerAbility.Sprint);
        _blockedByMode[ActionMode.Climbing].Add(PlayerAbility.Roll);
        _blockedByMode[ActionMode.Climbing].Add(PlayerAbility.Attack);
        _blockedByMode[ActionMode.Climbing].Add(PlayerAbility.Magic);
        _blockedByMode[ActionMode.Climbing].Add(PlayerAbility.Carry);
        _blockedByMode[ActionMode.Climbing].Add(PlayerAbility.Interact);
        _blockedByMode[ActionMode.Climbing].Add(PlayerAbility.Fly);

        // GARANTIZAR bloqueos básicos para Boating (independiente del Inspector)
        if (!_blockedByMode.ContainsKey(ActionMode.Boating))
            _blockedByMode[ActionMode.Boating] = new HashSet<PlayerAbility>();

        // Movimiento e interacción NO se bloquean: el barco lee el stick y el jugador necesita
        // poder volver a interactuar para bajar.
        _blockedByMode[ActionMode.Boating].Add(PlayerAbility.Jump);
        _blockedByMode[ActionMode.Boating].Add(PlayerAbility.Sprint);
        _blockedByMode[ActionMode.Boating].Add(PlayerAbility.Roll);
        _blockedByMode[ActionMode.Boating].Add(PlayerAbility.Attack);
        _blockedByMode[ActionMode.Boating].Add(PlayerAbility.Magic);
        _blockedByMode[ActionMode.Boating].Add(PlayerAbility.Carry);
        _blockedByMode[ActionMode.Boating].Add(PlayerAbility.Climb);
        _blockedByMode[ActionMode.Boating].Add(PlayerAbility.Fly);

        // GARANTIZAR bloqueo de interacción durante combate
        if (!_blockedByMode.ContainsKey(ActionMode.Combat))
            _blockedByMode[ActionMode.Combat] = new HashSet<PlayerAbility>();
        _blockedByMode[ActionMode.Combat].Add(PlayerAbility.Interact);

        // GARANTIZAR bloqueos para minijuegos (sin bloquear movimiento)
        if (!_blockedByMode.ContainsKey(ActionMode.Minigame))
            _blockedByMode[ActionMode.Minigame] = new HashSet<PlayerAbility>();

        _blockedByMode[ActionMode.Minigame].Add(PlayerAbility.Jump);
        _blockedByMode[ActionMode.Minigame].Add(PlayerAbility.Roll);
        _blockedByMode[ActionMode.Minigame].Add(PlayerAbility.Attack);
        _blockedByMode[ActionMode.Minigame].Add(PlayerAbility.Magic);
        _blockedByMode[ActionMode.Minigame].Add(PlayerAbility.Interact);
        _blockedByMode[ActionMode.Minigame].Add(PlayerAbility.Carry);
        _blockedByMode[ActionMode.Minigame].Add(PlayerAbility.Aim);
        _blockedByMode[ActionMode.Minigame].Add(PlayerAbility.Fly);
        _blockedByMode[ActionMode.Minigame].Add(PlayerAbility.Climb);

        // GARANTIZAR bloqueos para UsingWorldPoint (sentarse, comer, dormir, etc.)
        if (!_blockedByMode.ContainsKey(ActionMode.UsingWorldPoint))
            _blockedByMode[ActionMode.UsingWorldPoint] = new HashSet<PlayerAbility>();

        _blockedByMode[ActionMode.UsingWorldPoint].Add(PlayerAbility.Move);
        _blockedByMode[ActionMode.UsingWorldPoint].Add(PlayerAbility.Jump);
        _blockedByMode[ActionMode.UsingWorldPoint].Add(PlayerAbility.Sprint);
        _blockedByMode[ActionMode.UsingWorldPoint].Add(PlayerAbility.Roll);
        _blockedByMode[ActionMode.UsingWorldPoint].Add(PlayerAbility.Attack);
        _blockedByMode[ActionMode.UsingWorldPoint].Add(PlayerAbility.Magic);
        _blockedByMode[ActionMode.UsingWorldPoint].Add(PlayerAbility.Interact);
        _blockedByMode[ActionMode.UsingWorldPoint].Add(PlayerAbility.Carry);
        _blockedByMode[ActionMode.UsingWorldPoint].Add(PlayerAbility.Fly);

#if UNITY_EDITOR
        if (debugLogs) Debug.Log($"[PlayerActionManager] Inicializado con {rules?.Length ?? 0} reglas");
#endif
    }

    public ActionMode Top => _stack[^1];

    public void PushMode(ActionMode mode)
    {
        // FIX C2 (auditoría 2026-08-07): antes, "if (Top == mode) return;" descartaba el segundo
        // Push del mismo modo cuando dos sistemas lo empujaban casi a la vez (p.ej. DialogueManager
        // y CinematicSequencerBase empujando Cinematic). El problema: el segundo sistema hace su
        // Pop igualmente, y ese Pop borraba la ÚNICA entrada que había en la pila — la del primer
        // sistema, que seguía activo. Resultado: input desbloqueado en mitad del diálogo, jugador
        // controlable en mitad de una cinemática. PopMode ya borra una sola instancia (la más
        // alta), así que permitir entradas repetidas en la pila la convierte en un refcount real:
        // cada Push añade una entrada, cada Pop quita una, y el modo solo desaparece de verdad
        // cuando el último Pop lo hace. Ya no hay early-return que descarte pushes "duplicados".
        _stack.Add(mode);
#if UNITY_EDITOR
        if (debugLogs) Debug.Log($"[PlayerActionManager] Push: {mode} (stack size: {_stack.Count})");
#endif
        ApplyTopMode();
    }

    public void PopMode(ActionMode mode)
    {
        ActionMode antes = Top;
        for (int i = _stack.Count - 1; i >= 0; --i)
        {
            if (_stack[i] == mode)
            {
                _stack.RemoveAt(i);
#if UNITY_EDITOR
                if (debugLogs) Debug.Log($"[PlayerActionManager] Pop: {mode} (stack size: {_stack.Count})");
#endif
                break;
            }
        }
        if (_stack.Count == 0) _stack.Add(ActionMode.Default);
        ApplyTopMode();

        // Vuelve el control tras un diálogo o una cinemática: el cuerpo, listo para andar (INC-901).
        if (antes == ActionMode.Cinematic && Top == ActionMode.Default && _dialogueAnimator != null)
            _dialogueAnimator.AlRecuperarElControl();
    }

    /// <summary>
    /// FIX A10 (auditoría 2026-08-07): vacía la pila de modos de golpe y vuelve a Default. Pensado
    /// para puntos de reseteo "duros" de la sesión del jugador (muerte, revivir) donde cualquier
    /// modo que quedara apilado (Flying/Carrying/Cinematic/Stunned...) ya no es válido — antes,
    /// morir con un modo pushed lo dejaba vivo de cara al respawn, porque nada hacía los Pop
    /// correspondientes.
    /// </summary>
    public void ResetToDefault()
    {
        _stack.Clear();
        _stack.Add(ActionMode.Default);
#if UNITY_EDITOR
        if (debugLogs) Debug.Log("[PlayerActionManager] ResetToDefault: pila vaciada a Default");
#endif
        ApplyTopMode();
    }

    // Bloqueos que ponen otros sistemas (una zona donde no se puede volar, una prueba…).
    // Cada fuente pone y quita los suyos; la habilidad sigue bloqueada mientras quede alguna.
    private readonly Dictionary<PlayerAbility, HashSet<UnityEngine.Object>> _bloqueosExternos =
        new Dictionary<PlayerAbility, HashSet<UnityEngine.Object>>();

    /// <summary>Bloquea una habilidad mientras <paramref name="fuente"/> no la libere.</summary>
    public void AnadirBloqueo(PlayerAbility habilidad, UnityEngine.Object fuente)
    {
        if (fuente == null) return;
        if (!_bloqueosExternos.TryGetValue(habilidad, out var fuentes))
            _bloqueosExternos[habilidad] = fuentes = new HashSet<UnityEngine.Object>();
        fuentes.Add(fuente);
    }

    /// <summary>Quita el bloqueo que puso <paramref name="fuente"/>.</summary>
    public void QuitarBloqueo(PlayerAbility habilidad, UnityEngine.Object fuente)
    {
        if (_bloqueosExternos.TryGetValue(habilidad, out var fuentes)) fuentes.Remove(fuente);
    }

    /// <summary>true si alguna fuente externa (viva) bloquea la habilidad.</summary>
    public bool EstaBloqueadaDesdeFuera(PlayerAbility habilidad)
    {
        if (!_bloqueosExternos.TryGetValue(habilidad, out var fuentes) || fuentes.Count == 0) return false;
        fuentes.RemoveWhere(f => f == null); // fuentes destruidas sin avisar
        return fuentes.Count > 0;
    }

    // Permisos que dan otros sistemas mientras dura algo (una zona de escalada, una prueba): la
    // habilidad se puede usar aunque el preset no la tenga. Los bloqueos externos siguen mandando.
    private readonly Dictionary<PlayerAbility, HashSet<UnityEngine.Object>> _permisosExternos =
        new Dictionary<PlayerAbility, HashSet<UnityEngine.Object>>();

    /// <summary>Permite una habilidad que el preset no tiene mientras <paramref name="fuente"/> no la retire.</summary>
    public void AnadirPermiso(PlayerAbility habilidad, UnityEngine.Object fuente)
    {
        if (fuente == null) return;
        if (!_permisosExternos.TryGetValue(habilidad, out var fuentes))
            _permisosExternos[habilidad] = fuentes = new HashSet<UnityEngine.Object>();
        fuentes.Add(fuente);
    }

    /// <summary>Quita el permiso que dio <paramref name="fuente"/>.</summary>
    public void QuitarPermiso(PlayerAbility habilidad, UnityEngine.Object fuente)
    {
        if (_permisosExternos.TryGetValue(habilidad, out var fuentes)) fuentes.Remove(fuente);
    }

    /// <summary>true si alguna fuente externa (viva) permite la habilidad aunque el preset no la tenga.</summary>
    public bool EstaPermitidaDesdeFuera(PlayerAbility habilidad)
    {
        if (!_permisosExternos.TryGetValue(habilidad, out var fuentes) || fuentes.Count == 0) return false;
        fuentes.RemoveWhere(f => f == null);
        return fuentes.Count > 0;
    }

    public bool CanUse(PlayerAbility ability)
    {
        // Comprueba permisos globales aplicados desde preset u otros sistemas
        switch (ability)
        {
            case PlayerAbility.Jump:
                if (!_allowJump && !EstaPermitidaDesdeFuera(ability))
                {
#if UNITY_EDITOR
                    if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Jump deshabilitado por preset");
#endif
                    return false;
                }
                break;
            case PlayerAbility.Fly:
                if (!_allowFly && !EstaPermitidaDesdeFuera(ability))
                {
#if UNITY_EDITOR
                    if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Fly deshabilitado por preset");
#endif
                    return false;
                }
                break;
            case PlayerAbility.Climb:
                if (!_allowClimb && !EstaPermitidaDesdeFuera(ability))
                {
#if UNITY_EDITOR
                    if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Climb deshabilitado por preset");
#endif
                    return false;
                }
                break;
            case PlayerAbility.Magic:
                if (!_allowMagic && !EstaPermitidaDesdeFuera(ability))
                {
#if UNITY_EDITOR
                    if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Magic deshabilitado por preset");
#endif
                    return false;
                }
                break;
            case PlayerAbility.Sprint:
                if (!_allowSprint && !EstaPermitidaDesdeFuera(ability))
                {
#if UNITY_EDITOR
                    if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Sprint deshabilitado por preset");
#endif
                    return false;
                }
                break;
            //case PlayerAbility.Attack:
            //    if (!_allowPhysical)
            //    {
            //        if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Attack deshabilitado por preset");
            //        return false;
            //    }
            //    break;
            // Otros mapeos pueden añadirse si se utiliza swim/climb en otras partes
        }

        // Bloqueos externos (zonas, pruebas…): ver AnadirBloqueo.
        if (EstaBloqueadaDesdeFuera(ability))
        {
#if UNITY_EDITOR
            if (debugLogs) Debug.Log($"[PlayerActionManager] ❌ {ability} bloqueado desde fuera");
#endif
            return false;
        }

        // Recorre de arriba a abajo (prioridad)
        for (int i = _stack.Count - 1; i >= 0; --i)
        {
            var m = _stack[i];
            if (_blockedByMode.TryGetValue(m, out var set) && set.Contains(ability))
            {
#if UNITY_EDITOR
                if (debugLogs) Debug.Log($"[PlayerActionManager] ❌ {ability} bloqueado por modo {m}");
#endif
                return false;
            }
        }
        return true;
    }

    // --- Core: aplicar efectos secundarios del modo superior ---
    private void ApplyTopMode()
    {
        // Primero, re-habilitar todo (seguridad) y luego aplicar deshabilitaciones del top.
        ReenableAll();

        var top = Top;

        // Special-case: when flying, ensure base locomotion animator doesn't transition to falling.
        // Some animator controllers check IsGrounded/InputMagnitude to play fall states — force safe values while Flying.
        if (top == ActionMode.Flying && _anim != null)
        {
            try
            {
                _anim.SetBool(Invector.vCharacterController.vAnimatorParameters.IsGrounded, true);
                _anim.SetFloat(Invector.vCharacterController.vAnimatorParameters.InputMagnitude, 0f);
#if UNITY_EDITOR
                if (debugLogs) Debug.Log("[PlayerActionManager] Flight mode active - forcing IsGrounded=true and InputMagnitude=0 on animator to avoid fall animations.");
#endif
            }
            catch { }
        }

        // Resetear visuales de daño y detener movimiento al entrar en modo Cinematic
        if (top == ActionMode.Cinematic)
        {
            var healthSystem = GetComponent<PlayerHealthSystem>();
            if (healthSystem != null)
            {
                healthSystem.ResetDamageVisuals();
#if UNITY_EDITOR
                if (debugLogs) Debug.Log("[PlayerActionManager] Visuales de daño reseteados (modo Cinematic)");
#endif
            }

            // Zeroa los parámetros de movimiento del Animator inmediatamente y asegura estado en el suelo.
            // ControlLocomotionType() queda bloqueado por lockMovement=true y nunca llama a
            // SetAnimatorMoveSpeed(), por lo que InputMagnitude quedaría con el valor del
            // frame anterior y la animación de caminar seguiría reproduciéndose.
            // Si el jugador entra a cinemática en el aire, IsGrounded quedaría en false congelado (INC-843).
            if (_anim != null)
            {
                try
                {
                    _anim.SetFloat(Invector.vCharacterController.vAnimatorParameters.InputMagnitude, 0f);
                    _anim.SetFloat(Invector.vCharacterController.vAnimatorParameters.InputHorizontal, 0f);
                    _anim.SetFloat(Invector.vCharacterController.vAnimatorParameters.InputVertical, 0f);
                    _anim.SetBool(Invector.vCharacterController.vAnimatorParameters.IsGrounded, true);
                    _anim.SetFloat(Invector.vCharacterController.vAnimatorParameters.GroundDistance, 0f);

                    var state = _anim.GetCurrentAnimatorStateInfo(0);
                    if (state.IsName("Falling") || state.IsName("Jump") || state.IsName("JumpMove") || state.IsName("Airborne"))
                    {
                        if (_dialogueAnimator != null) _dialogueAnimator.ReturnToLocomotion(0f);
                        else if (_anim.HasState(0, Animator.StringToHash("Free Locomotion")))
                            _anim.CrossFadeInFixedTime(Animator.StringToHash("Free Locomotion"), 0.1f, 0, 0f);
                    }
#if UNITY_EDITOR
                    if (debugLogs) Debug.Log("[PlayerActionManager] InputMagnitude/H/V reseteados a 0 e IsGrounded=true (modo Cinematic)");
#endif
                }
                catch { }
            }

            if (_motor != null)
            {
                _motor.ForzarEnElSuelo();
            }
        }

        if (_ruleByMode.TryGetValue(top, out var rule))
        {
            // Desactivar componentes
            if (rule.disableComponents != null)
                foreach (var c in rule.disableComponents) 
                    if (c) 
                    {
                        c.enabled = false;
#if UNITY_EDITOR
                        if (debugLogs) Debug.Log($"[PlayerActionManager] Deshabilitando componente: {c.GetType().Name}");
#endif
                    }

            // Deshabilitar acciones Input System
            if (rule.disableInputActions != null)
                foreach (var a in rule.disableInputActions)
                    if (a && a.action != null && a.action.enabled) 
                    {
                        a.action.Disable();
#if UNITY_EDITOR
                        if (debugLogs) Debug.Log($"[PlayerActionManager] Deshabilitando input: {a.action.name}");
#endif
                    }

            // Control de peso de UpperBody
            if (_anim != null && rule.upperBodyWeight >= 0f && upperBodyLayer > 0 && _anim.layerCount > upperBodyLayer)
            {
                _anim.SetLayerWeight(upperBodyLayer, rule.upperBodyWeight);
#if UNITY_EDITOR
                if (debugLogs) Debug.Log($"[PlayerActionManager] UpperBody weight: {rule.upperBodyWeight}");
#endif
            }

            // Anim: UpperIdle limpio
            if (_anim != null && rule.forceUpperIdle && upperBodyLayer > 0 && !string.IsNullOrEmpty(upperIdleState))
                _anim.CrossFade(upperIdleState, 0.1f, upperBodyLayer);
        }
        else
        {
            // Modo Default: restaurar peso original
            if (_anim != null && top == ActionMode.Default && upperBodyLayer > 0 && _anim.layerCount > upperBodyLayer)
                _anim.SetLayerWeight(upperBodyLayer, _originalUpperWeight);
        }

        OnTopModeChanged?.Invoke(top);
#if UNITY_EDITOR
        if (debugLogs) Debug.Log($"[PlayerActionManager] ✅ Modo activo: {top}");
#endif

        UpdatePlayerLock(top);
    }

    private void ReenableAll()
    {
        // Rehabilita TODO lo que cualquier regla pudiera haber tocado.
        // Esto se ejecuta solo cuando cambia el modo → coste despreciable.
        if (rules == null) return;

        foreach (var r in rules)
        {
            if (r == null) continue;

            if (r.disableComponents != null)
                foreach (var c in r.disableComponents) if (c) c.enabled = true;

            if (r.disableInputActions != null)
                foreach (var a in r.disableInputActions)
                    if (a && a.action != null && !a.action.enabled) a.action.Enable();
        }
    }

    // Por si el GameObject se desactiva en mitad de un modo
    void OnDisable()
    {
        ReenableAll();
        _stack.Clear();
        _stack.Add(ActionMode.Default);
        ReleasePlayerLockIfHeld();
    }

    // API pública para consultar estado
    public bool IsInMode(ActionMode mode) => _stack.Contains(mode);
    public int StackDepth => _stack.Count;

    // IActionValidator: permisos que consulta el controlador de personaje de Plugins.
    public bool CanJump()
    {
        // Si hay menús abiertos (Shop, Equipment, etc.), NO permitir saltar
        if (MenuManager.HasOpenMenus)
        {
#if UNITY_EDITOR
            if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Jump bloqueado - hay menús abiertos");
#endif
            return false;
        }
        
        return CanUse(PlayerAbility.Jump);
    }
    
    public bool CanSprint()
    {
        // Si hay menús abiertos, NO permitir sprint
        if (MenuManager.HasOpenMenus)
        {
#if UNITY_EDITOR
            if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Sprint bloqueado - hay menús abiertos");
#endif
            return false;
        }
        
        return CanUse(PlayerAbility.Sprint);
    }
    
    public bool CanAttack()
    {
        // Si hay menús abiertos, NO permitir atacar
        if (MenuManager.HasOpenMenus)
        {
#if UNITY_EDITOR
            if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Attack bloqueado - hay menús abiertos");
#endif
            return false;
        }
        
        return CanUse(PlayerAbility.Attack);
    }
    
    public bool CanCastMagic()
    {
        // Si hay menús abiertos, NO permitir magia
        if (MenuManager.HasOpenMenus)
        {
#if UNITY_EDITOR
            if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Magic bloqueado - hay menús abiertos");
#endif
            return false;
        }

        return CanUse(PlayerAbility.Magic);
    }

    public bool CanInteract()
    {
        // IMPORTANTE: Cooldown después de interactuar para evitar que el botón A se procese como salto
        if (Time.unscaledTime < _interactCooldownUntil)
        {
#if UNITY_EDITOR
            if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Interact en cooldown");
#endif
            return false;
        }
        
        // Si hay menús abiertos, el botón A se usa para submit en UI, no para interactuar
        if (MenuManager.HasOpenMenus)
        {
#if UNITY_EDITOR
            if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Interact bloqueado - hay menús abiertos");
#endif
            return false;
        }
        
        return CanUse(PlayerAbility.Interact);
    }
    
    /// <summary>
    /// Llamar este método después de que el player interactúe con algo
    /// para establecer un cooldown que evite procesamiento múltiple del botón A
    /// </summary>
    public void SetInteractCooldown()
    {
        _interactCooldownUntil = Time.unscaledTime + INTERACT_COOLDOWN_DURATION;
        
        // IMPORTANTE: También ignorar el botón de salto en GamepadInputReader
        // para evitar que el botón A se procese como salto después de interactuar
        Core.GamepadInputReader.IgnoreJumpButton(INTERACT_COOLDOWN_DURATION);
        
#if UNITY_EDITOR
        if (debugLogs) Debug.Log($"[PlayerActionManager] Interact cooldown activado por {INTERACT_COOLDOWN_DURATION}s (Jump también ignorado)");
#endif
    }
    
    public bool CanSwim() => _allowSwim;
    
    public bool CanFly()
    {
        // Si hay menús abiertos, NO permitir volar
        if (MenuManager.HasOpenMenus)
        {
#if UNITY_EDITOR
            if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Fly bloqueado - hay menús abiertos");
#endif
            return false;
        }
        
        return CanUse(PlayerAbility.Fly);
    }
    
    public bool CanClimb()
    {
        // Si hay menús abiertos, NO permitir trepar
        if (MenuManager.HasOpenMenus)
        {
#if UNITY_EDITOR
            if (debugLogs) Debug.Log("[PlayerActionManager] ❌ Climb bloqueado - hay menús abiertos");
#endif
            return false;
        }
        
        return CanUse(PlayerAbility.Climb);
    }

    void UpdatePlayerLock(ActionMode top)
    {
        bool shouldLock = ShouldLockMovement(top);

        if (shouldLock)
        {
            if (_hasMovementLock) return;
            var lockService = PlayerLockService.Instance;
            if (lockService == null) return; // Juego cerrando: no crear una instancia nueva a destiempo
            lockService.Acquire(_lockOwner);
            _hasMovementLock = true;
        }
        else
        {
            ReleasePlayerLockIfHeld();
        }
    }

    void ReleasePlayerLockIfHeld()
    {
        if (!_hasMovementLock) return;
        if (PlayerLockService.HasInstance)
            PlayerLockService.Instance.Release(_lockOwner);
        _hasMovementLock = false;
    }

    bool ShouldLockMovement(ActionMode mode)
    {
        // UsingWorldPoint bloquea el motor directamente en PlayerAmbientActivityHandler
        // para que el mapa de input GamePlay no se deshabilite y la cámara siga disponible
        if (mode == ActionMode.UsingWorldPoint) return false;

        if (_blockedByMode.TryGetValue(mode, out var blocked) && blocked.Contains(PlayerAbility.Move))
            return true;

        return mode == ActionMode.Cinematic;
    }
}
