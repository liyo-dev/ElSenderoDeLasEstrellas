using System;
using System.Collections.Generic;
using UnityEngine;

public class WardrobeInventory : MonoBehaviour
{
    [SerializeField] private ModularAutoBuilder builder;
    [SerializeField] private bool unlockAllByDefault = true;
    [SerializeField] private WardrobeItemSO[] initialUnlocked;

    readonly Dictionary<PartCategory, List<WardrobeEntry>> _entries = new();
    readonly HashSet<string> _persistedIds = new(StringComparer.OrdinalIgnoreCase);

    PlayerPresetSO _currentPreset;

    public event Action OnWardrobeChanged;

    void Awake()
    {
        InitializeCategories();
    }

    void OnEnable()
    {
        GameBootService.OnProfileReady += HandleProfileReady;
        ProfileReadyDiagnostics.RegisterSubscriber(nameof(WardrobeInventory));
        if (GameBootService.IsAvailable)
            HandleProfileReady();
    }

    void OnDisable()
    {
        GameBootService.OnProfileReady -= HandleProfileReady;
    }

    void HandleProfileReady()
    {
        var preset = Partida.Preset;
        if (preset != null)
            ApplyFromPreset(preset);
    }

    void InitializeCategories()
    {
        foreach (PartCategory cat in Enum.GetValues(typeof(PartCategory)))
        {
            if (!_entries.ContainsKey(cat))
                _entries[cat] = new List<WardrobeEntry>();
        }
    }

    void ClearAll()
    {
        foreach (var list in _entries.Values)
            list.Clear();
        _persistedIds.Clear();
    }

    public void ApplyFromPreset(PlayerPresetSO preset)
    {
        if (preset == null) return;

        EnsureBuilderReference();
        InitializeCategories();

        _currentPreset = preset;
        ClearAll();

        if (unlockAllByDefault)
            AutoUnlockAll();

        if (initialUnlocked != null)
        {
            for (int i = 0; i < initialUnlocked.Length; i++)
            {
                var item = initialUnlocked[i];
                if (item)
                    Unlock(item, persistToPreset: false);
            }
        }

        if (preset.unlockedWardrobeIds != null)
        {
            foreach (var id in preset.unlockedWardrobeIds)
            {
                if (string.IsNullOrEmpty(id)) continue;
                var item = WardrobeItemSO.Find(id);
                if (item == null)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.LogWarning($"[WardrobeInventory] Wardrobe item '{id}' no encontrado al aplicar preset.");
#endif
                    continue;
                }

                _persistedIds.Add(id);
                AddEntry(CreateEntry(item), persistable: true);
            }
        }

        EnsureCurrentSelectionEntries();
        NotifyChanged();
    }

    // La ropa que se tiene es del grupo (GrupoDelJugador); la que se lleva puesta, del cuerpo del
    // jugador: el builder se busca a través de PlayerService. Ver INC-484.
    void EnsureBuilderReference()
    {
        if (builder != null) return;
        PlayerService.TryGetComponent(out builder, includeInactive: true, allowSceneLookup: true);
    }

    void AutoUnlockAll()
    {
        EnsureBuilderReference();
        if (builder == null) return;

        foreach (PartCategory cat in Enum.GetValues(typeof(PartCategory)))
        {
            var options = builder.GetOptions(cat);
            if (options == null) continue;
            foreach (var option in options)
            {
                if (string.IsNullOrEmpty(option)) continue;
                AddEntry(new WardrobeEntry
                {
                    category = cat,
                    partName = option,
                    displayName = option,
                    wardrobeId = null
                }, persistable: false);
            }
        }
    }

    void EnsureCurrentSelectionEntries()
    {
        EnsureBuilderReference();
        if (builder == null) return;

        var selection = builder.GetSelection();
        if (selection == null) return;

        foreach (var kvp in selection)
        {
            if (string.IsNullOrEmpty(kvp.Value)) continue;
            AddEntry(new WardrobeEntry
            {
                category = kvp.Key,
                partName = kvp.Value,
                displayName = kvp.Value,
                wardrobeId = null
            }, persistable: false);
        }
    }

    WardrobeEntry CreateEntry(WardrobeItemSO item)
    {
        return new WardrobeEntry
        {
            category = item.Category,
            partName = item.PartName,
            displayName = item.GetLocalizedDisplayName(),
            description = item.GetLocalizedDescription(),
            icon = item.Icon,
            wardrobeId = item.WardrobeId
        };
    }

    bool AddEntry(WardrobeEntry entry, bool persistable)
    {
        if (string.IsNullOrEmpty(entry.partName))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[WardrobeInventory.AddEntry] partName está vacío");
#endif
            return false;
        }
        
        if (!_entries.TryGetValue(entry.category, out var list))
        {
            list = new List<WardrobeEntry>();
            _entries[entry.category] = list;
            // Debug.Log($"[WardrobeInventory.AddEntry] Creada nueva lista para categoría {entry.category}");
        }

        int existingIndex = list.FindIndex(e => string.Equals(e.partName, entry.partName, StringComparison.OrdinalIgnoreCase));
        if (existingIndex >= 0)
        {
            // Debug.Log($"[WardrobeInventory.AddEntry] Ya existe entrada para '{entry.partName}' en {entry.category}");
            if (persistable)
            {
                var existing = list[existingIndex];
                if (string.IsNullOrEmpty(existing.wardrobeId) && !string.IsNullOrEmpty(entry.wardrobeId))
                {
                    existing.wardrobeId = entry.wardrobeId;
                    existing.displayName = entry.displayName;
                    existing.description = entry.description;
                    existing.icon = entry.icon;
                    list[existingIndex] = existing;
                    // Debug.Log($"[WardrobeInventory.AddEntry] ✅ Actualizada entrada existente con wardrobeId '{entry.wardrobeId}'");
                    return true;
                }
            }
            return false;
        }

        int insertIndex = list.FindIndex(e => string.Compare(e.displayName, entry.displayName, StringComparison.OrdinalIgnoreCase) > 0);
        if (insertIndex >= 0)
            list.Insert(insertIndex, entry);
        else
            list.Add(entry);

        // Debug.Log($"[WardrobeInventory.AddEntry] ✅ Añadida nueva entrada '{entry.partName}' ({entry.displayName}) a {entry.category}. Total items en categoría: {list.Count}");

        if (persistable && !string.IsNullOrEmpty(entry.wardrobeId))
            _persistedIds.Add(entry.wardrobeId);

        return true;
    }

    public bool Unlock(WardrobeItemSO item, bool persistToPreset = true)
    {
        if (!item)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[WardrobeInventory] WardrobeItemSO no asignado.");
#endif
            return false;
        }

        // Debug.Log($"[WardrobeInventory] Unlock: {item.WardrobeId} (Category: {item.Category}, PartName: {item.PartName}, persistToPreset: {persistToPreset})");

        var entry = CreateEntry(item);
        bool added = AddEntry(entry, persistable: true);
        
        if (!added)
        {
            // Debug.LogWarning($"[WardrobeInventory] El item '{item.WardrobeId}' no pudo ser añadido (probablemente ya existe)");
            return false;
        }

        // Debug.Log($"[WardrobeInventory] ✅ Item '{item.WardrobeId}' añadido correctamente a la categoría {item.Category}");

        if (persistToPreset && !string.IsNullOrEmpty(entry.wardrobeId))
        {
            _persistedIds.Add(entry.wardrobeId);
            SyncPresetUnlockedIds();
            // Debug.Log($"[WardrobeInventory] Item '{item.WardrobeId}' persistido al preset");
        }

        // Debug.Log($"[WardrobeInventory] Notificando cambios (OnWardrobeChanged)");
        NotifyChanged();
        return true;
    }

    public IReadOnlyList<WardrobeEntry> GetUnlockedOptions(PartCategory category)
    {
        return _entries.TryGetValue(category, out var list) ? list : Array.Empty<WardrobeEntry>();
    }

    /// <summary>
    /// La ropa que se tiene es del grupo, pero cada cuerpo solo puede llevar lo suyo: de lo desbloqueado en
    /// esa categoría, lo que ese personaje puede ponerse (<see cref="WardrobeItemSO.PuedeLlevarla"/>) y su
    /// cuerpo tiene (<see cref="ModularAutoBuilder.GetOptions"/>), más lo que lleva puesto ahora.
    /// </summary>
    public List<WardrobeEntry> GetOptionsFor(PartCategory category, ModularAutoBuilder cuerpo, PartyControlManager.CharacterSlot personaje)
    {
        var resultado = new List<WardrobeEntry>();
        var piezas = cuerpo != null ? cuerpo.GetOptions(category) : null;
        if (piezas == null) return resultado;
        bool Tiene(string pieza)
        {
            for (int i = 0; i < piezas.Count; i++)
                if (string.Equals(piezas[i], pieza, StringComparison.OrdinalIgnoreCase)) return true;
            return false;
        }
        foreach (var entry in GetUnlockedOptions(category))
        {
            if (!Tiene(entry.partName)) continue;
            var item = WardrobeItemSO.FindPart(category, entry.partName);
            if (item != null && !item.PuedeLlevarla(personaje)) continue;
            resultado.Add(entry);
        }
        var puesta = cuerpo.GetSelection();
        if (puesta != null && puesta.TryGetValue(category, out var actual) && !string.IsNullOrEmpty(actual)
            && !resultado.Exists(e => string.Equals(e.partName, actual, StringComparison.OrdinalIgnoreCase)))
        {
            var item = WardrobeItemSO.FindPart(category, actual);
            resultado.Add(item != null ? CreateEntry(item) : new WardrobeEntry { category = category, partName = actual, displayName = actual });
        }
        return resultado;
    }

    public bool HasOptions(PartCategory category)
    {
        return _entries.TryGetValue(category, out var list) && list.Count > 0;
    }

    public bool TryGetEntry(PartCategory category, string partName, out WardrobeEntry entry)
    {
        entry = default;
        if (!_entries.TryGetValue(category, out var list)) return false;
        for (int i = 0; i < list.Count; i++)
        {
            if (string.Equals(list[i].partName, partName, StringComparison.OrdinalIgnoreCase))
            {
                entry = list[i];
                return true;
            }
        }
        return false;
    }

    void SyncPresetUnlockedIds()
    {
        if (_currentPreset == null && GameBootService.IsAvailable)
            _currentPreset = Partida.Preset;
        if (_currentPreset == null) return;

        if (_currentPreset.unlockedWardrobeIds == null)
            _currentPreset.unlockedWardrobeIds = new List<string>();

        _currentPreset.unlockedWardrobeIds.Clear();
        _currentPreset.unlockedWardrobeIds.AddRange(_persistedIds);
    }

    /// <summary>
    /// Obtiene una lista de todos los IDs de wardrobe desbloqueados y persistidos.
    /// Se usa para sincronizar con el preset durante el guardado.
    /// </summary>
    public List<string> GetUnlockedIds()
    {
        return new List<string>(_persistedIds);
    }

    void NotifyChanged()
    {
        OnWardrobeChanged?.Invoke();
    }

    public struct WardrobeEntry
    {
        public PartCategory category;
        public string partName;
        public string displayName;
        public string description;
        public Sprite icon;
        public string wardrobeId;
    }
}
