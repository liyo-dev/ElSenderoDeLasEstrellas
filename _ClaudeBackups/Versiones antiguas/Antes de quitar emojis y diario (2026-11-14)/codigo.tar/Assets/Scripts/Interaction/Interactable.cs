using System.Collections.Generic;
using Game.NPC;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using DG.Tweening;
using Core.InputGlyphs;

[DisallowMultipleComponent]
public class Interactable : MonoBehaviour
{
    // Cooldown global breve para evitar re-disparar interacción justo al cerrar prompts/opciones
    static float s_globalCooldownUntil = 0f;
    [Header("Modo")]
    [SerializeField] private InteractableMode mode = InteractableMode.OpenDialogue;

    [Header("Hint (icono botón)")]
    [SerializeField] private GameObject hint;
    [SerializeField] private bool hideHintAtStart = true;
    [SerializeField] private float hintAnimDuration = 0.25f;
    [Tooltip("Tamaño del icono respecto a la escala que tiene el hint en el prefab (1 = tal cual, 0.5 = la mitad).")]
    [SerializeField, Range(0.1f, 2f)] private float hintScale = 0.5f;
    [Tooltip("Set de sprites (uno por familia de mando/teclado) para el icono de interactuar. " +
             "Referencia DIRECTA (sin Resources.Load) — arrastrar el asset compartido " +
             "InteractionHintIconSet. Si se deja vacío, el icono se queda con el sprite que ya " +
             "tenga puesto a mano en el prefab (comportamiento anterior, sin romper nada).")]
    [SerializeField] private InteractionHintIconSet iconSet;
    [Tooltip("Sin icono asignado, copia el de otro interactuable de la escena (el primero con icono y juego de " +
             "sprites) y lo pone sobre este objeto. Así los objetos montados por código también lo enseñan.")]
    [SerializeField] private bool iconoPorDefectoSiFalta = true;

    [Header("Uso")]
    [SerializeField] private bool singleUse = false;
    [SerializeField] private bool initiallyEnabled = true;

    [Header("Persistencia single-use")]
    [SerializeField] private string persistentIdOverride;
    [SerializeField] private bool includeSceneInPersistentId = true;

    [Header("Abrir diálogo")]
    [SerializeField] private string dialogueCharacterId;
    [SerializeField] private DialogueAsset dialogue;
    [SerializeField] private DialogueAsset yesOption;
    [SerializeField] private DialogueAsset noOption;
    [SerializeField] private DialogueAsset confirmFollowUp;
    [SerializeField] private DialogueAsset cancelFollowUp;

    [Header("Opciones (UnityEvent)")]
    public UnityEvent OnConfirm;

    [Header("Eventos opcionales")]
    public UnityEvent<GameObject> OnInteract = new UnityEvent<GameObject>();
    public UnityEvent OnStarted;
    public UnityEvent OnFinished;
    public UnityEvent OnConsumed;

    bool used, enabledForUse;
    NPCBehaviourManagerV2 _npcManager;
    NPCPartyMember _partyMember;
    Personaje _personaje;
    CuerpoDelGrupo _cuerpoDelGrupo;
    Game.NPC.CompanionFollowPrompt _followPrompt;
    NPCWorldPoint _worldPoint;
    bool _hintVisible;
    Image _hintIcon;

    public bool IsHintVisible => _hintVisible;
    Tweener _hintTween;
    Vector3 _hintOriginalScale;

    [Header("Línea de visión")]
    [Tooltip("Altura sobre la base de este objeto usada como SightPoint cuando no hay 'hint' " +
             "asignado (ver SightPoint). Sin efecto si hint sí está asignado.")]
    [SerializeField] private float defaultSightHeight = 1.4f;

    // FIX (2026-08-12): InteractionDetector.FindNearest() comprobaba línea de visión contra
    // transform.position (la base/los pies del NPC). Cualquier mueble de altura media entre el
    // player y el NPC (mostrador de tienda, mesa...) queda justo a esa altura y se detectaba
    // como obstrucción real aunque el jugador viera al NPC perfectamente por encima — el hint
    // nunca llegaba a mostrarse en ningún vendedor con mostrador delante. En vez de re-etiquetar
    // el layer de cada mueble de cada tienda (frágil y con efectos secundarios en renderizado/
    // física), se expone aquí el punto que SÍ debe comprobarse: por defecto la posición del
    // propio hint, que ya está a la altura de la cabeza/por encima del NPC por diseño (es un
    // icono flotante). Si el jugador puede ver ese punto, un mostrador bajo deja de bloquear.
    //
    // FIX (2026-08-12b): la asunción de arriba ("el hint ya está a la altura de la cabeza") no
    // se cumple para todos los prefabs de NPC — p.ej. Patricia tiene el Canvas del hint colgando
    // directamente de la raíz del prefab con offset local (0,0,0), así que hint.transform.position
    // queda prácticamente a la misma altura que transform.position (por eso el mostrador de su
    // tienda seguía bloqueando el hint incluso después del fix anterior). En vez de depender de
    // que cada prefab tenga el Canvas bien posicionado, se garantiza aquí una altura mínima
    // (defaultSightHeight) sobre la base del NPC: si el hint ya está más alto que eso (el caso
    // "bien configurado"), se usa su posición tal cual; si no, se eleva hasta el mínimo.
    public Vector3 SightPoint
    {
        get
        {
            // La conversación apunta a la cara, no al icono que puede estar sobre un toldo.
            if (EsPersonaje) return transform.position + Vector3.up * defaultSightHeight;
            Vector3 point = hint != null ? hint.transform.position : transform.position + Vector3.up * defaultSightHeight;
            float minY = transform.position.y + defaultSightHeight;
            if (point.y < minY)
                point.y = minY;
            return point;
        }
    }

    void Awake()
    {
        EsPersonaje = GetComponent<NPCSimpleAnimator>() != null;
        enabledForUse = initiallyEnabled;
        if (hint)
        {
            _hintOriginalScale = hint.transform.localScale * hintScale;
            _hintIcon = hint.GetComponentInChildren<Image>(true);
            if (s_muestraDeIcono == null && iconSet != null && hint.transform.parent != null) s_muestraDeIcono = this;
            if (hideHintAtStart)
            {
                hint.transform.localScale = Vector3.zero;
                hint.SetActive(false);
            }
            else
            {
                hint.transform.localScale = _hintOriginalScale;
            }
        }
        _npcManager = GetComponent<NPCBehaviourManagerV2>();
        _partyMember = GetComponent<NPCPartyMember>() ?? GetComponentInParent<NPCPartyMember>();
        _worldPoint = GetComponent<NPCWorldPoint>();

        if (EsPersonajeDelGrupo())
        {
            enabledForUse = false;
            if (hint)
            {
                hint.transform.localScale = Vector3.zero;
                hint.SetActive(false);
            }
        }
    }

    public bool EsPersonajeDelGrupo()
    {
        if (_personaje == null)
            _personaje = GetComponent<Personaje>() ?? GetComponentInParent<Personaje>();
        if (_personaje != null)
        {
            if (ControlDelJugador.PersonajeDe(gameObject, out var slot))
                return ControlDelJugador.EnElGrupo(slot);
            return true;
        }

        if (_cuerpoDelGrupo == null)
            _cuerpoDelGrupo = GetComponent<CuerpoDelGrupo>() ?? GetComponentInParent<CuerpoDelGrupo>();
        if (_cuerpoDelGrupo != null)
            return true;

        if (_partyMember == null)
            _partyMember = GetComponent<NPCPartyMember>() ?? GetComponentInParent<NPCPartyMember>();
        if (_partyMember != null && _partyMember.IsInParty)
            return true;

        if (ControlDelJugador.PersonajeDe(gameObject, out var slotDirecto))
            return ControlDelJugador.EnElGrupo(slotDirecto);

        return false;
    }

    public bool EsPersonaje { get; private set; }

    // Hay una orden del modo Libre que dar a este personaje del grupo (ver CompanionFollowPrompt).
    bool HayOrdenDelGrupo()
    {
        if (_followPrompt == null)
            _followPrompt = GetComponent<Game.NPC.CompanionFollowPrompt>() ?? GetComponentInParent<Game.NPC.CompanionFollowPrompt>();
        return _followPrompt != null && _followPrompt.isActiveAndEnabled && _followPrompt.CanShowFollowPrompt();
    }

    void OnEnable()
    {
        GameBootService.OnProfileReady += RestoreSingleUseStateFromPreset;
        // Re-aplicar estado single-use también cuando el preset se re-aplique en runtime (tras cargar save)
        PlayerPresetService.OnPresetApplied += HandlePresetApplied;

        if (GameBootService.IsAvailable)
            RestoreSingleUseStateFromPreset();

        // Icono según mando/teclado (sprites baked en iconSet, sin Resources.Load).
        InputGlyphService.FamilyChanged += HandleInputFamilyChanged;
        RefreshHintIcon();
    }

    void OnDisable()
    {
        StopPromptVoice();
        GameBootService.OnProfileReady -= RestoreSingleUseStateFromPreset;
        PlayerPresetService.OnPresetApplied -= HandlePresetApplied;
        InputGlyphService.FamilyChanged -= HandleInputFamilyChanged;

        // Si el jugador murió o la escena se descargó mientras un diálogo estaba activo,
        // limpiar las fases que este Interactable pudo haber empujado sin hacer Pop.
        if (GameState.Is(GamePhase.Dialogue)) GameState.Pop(GamePhase.Dialogue);
        if (GameState.Is(GamePhase.SavePrompt)) GameState.Pop(GamePhase.SavePrompt);

        // Si el que se va era el del hint encendido, que no se quede la plaza cogida para siempre
        // (ver SetHintVisible): el siguiente no podría encender el suyo sin apagar a un fantasma.
        if (_hintEncendido == this) _hintEncendido = null;
        if (hint != null && _hintVisible) { _hintVisible = false; hint.SetActive(false); }
    }

    void HandlePresetApplied()
    {
        // Cuando el PlayerPresetService re-aplica el preset (por ejemplo tras Load),
        // refrescar el estado single-use desde el preset activo.
        RestoreSingleUseStateFromPreset();
    }

    void HandleInputFamilyChanged(InputGlyphDeviceFamily _) => RefreshHintIcon();

    /// Pone sobre este objeto una copia del icono de la muestra, a la misma escala en el mundo y
    /// por encima de lo que se dibuja. Ver INC-1092.
    bool CrearIconoPorDefecto()
    {
        if (!iconoPorDefectoSiFalta || EsPersonaje) return false;
        var muestra = s_muestraDeIcono;
        if (muestra == null || muestra.hint == null || muestra.hint.transform.parent == null) return false;

        float arriba = transform.position.y + defaultSightHeight;
        var renderers = GetComponentsInChildren<Renderer>(false);
        if (renderers.Length > 0)
        {
            float max = float.MinValue;
            for (int i = 0; i < renderers.Length; i++)
                if (!(renderers[i] is ParticleSystemRenderer)) max = Mathf.Max(max, renderers[i].bounds.max.y);
            if (max > float.MinValue) arriba = max + 0.45f;
        }

        hint = Instantiate(muestra.hint, transform, false);
        hint.name = muestra.hint.name;
        hint.transform.position = new Vector3(transform.position.x, arriba, transform.position.z);
        hint.transform.rotation = muestra.hint.transform.rotation;
        Vector3 enElMundo = Vector3.Scale(muestra._hintOriginalScale, muestra.hint.transform.parent.lossyScale);
        Vector3 propia = transform.lossyScale;
        _hintOriginalScale = new Vector3(enElMundo.x / Mathf.Max(0.0001f, Mathf.Abs(propia.x)),
                                         enElMundo.y / Mathf.Max(0.0001f, Mathf.Abs(propia.y)),
                                         enElMundo.z / Mathf.Max(0.0001f, Mathf.Abs(propia.z)));
        hint.transform.localScale = Vector3.zero;
        hint.SetActive(false);
        if (iconSet == null) iconSet = muestra.iconSet;
        _hintIcon = hint.GetComponentInChildren<Image>(true);
        RefreshHintIcon();
        return true;
    }

    /// <summary>
    /// Actualiza el sprite del icono de interactuar según la familia de mando/teclado activa,
    /// usando el set de sprites baked en <see cref="iconSet"/> (referencia directa, sin
    /// Resources.Load). Si no hay iconSet asignado, o le falta el sprite de la familia actual,
    /// no toca nada — se queda con el sprite que ya tuviera el prefab a mano.
    /// </summary>
    void RefreshHintIcon()
    {
        if (iconSet == null || _hintIcon == null) return;

        var sprite = iconSet.GetSprite(InputGlyphService.CurrentFamily);
        if (sprite == null) return;

        _hintIcon.sprite = sprite;
        _hintIcon.preserveAspect = true;
    }

    /// El único interactuable con el hint encendido ahora mismo. Ver SetHintVisible.
    private static Interactable _hintEncendido;

#if UNITY_EDITOR
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
    private static void ResetHintEstatico() { _hintEncendido = null; s_muestraDeIcono = null; }
#endif

    /// Interactuable cuyo icono se copia en los que no tienen uno (ver iconoPorDefectoSiFalta).
    private static Interactable s_muestraDeIcono;

    public void SetHintVisible(bool visible, GameObject interactor = null)
    {
        if (hint == null && (!visible || !CrearIconoPorDefecto())) return;
        
        // Los personajes del grupo solo muestran el icono cuando hay una orden del modo Libre
        // («Sígueme» / «Deja de seguir»); su uso no depende de enabledForUse ni de single-use.
        bool delGrupo = EsPersonajeDelGrupo();
        if (delGrupo && !HayOrdenDelGrupo())
        {
            if (_hintVisible)
            {
                _hintVisible = false;
                _hintTween?.Kill();
                hint.SetActive(false);
                if (_hintEncendido == this) _hintEncendido = null;
            }
            return;
        }

        // Solo mostrar hint si puede interactuar
        bool canShow = visible && (delGrupo || (!used && enabledForUse)) && CanInteract(interactor);
        
        // Si el estado no cambia, no hacer nada
        if (canShow == _hintVisible) return;
        
        _hintVisible = canShow;

        // ── Solo puede haber UN hint en pantalla (INC-381) ──────────────────────────────────
        //
        // «El icono de interactuar sale dos veces.» Con dos interactuables cerca (un pozo y un
        // buzón, dos NPCs pegados) cada uno encendía el suyo, porque cada Interactable maneja su
        // propio `hint` y nadie llevaba la cuenta de los demás. Barrer los de alrededor desde
        // InteractionDetector no bastaba: solo veía los que caían dentro de su esfera y solo
        // cuando él era quien lo encendía.
        //
        // Aquí no hay forma de escaparse: el que se enciende apaga al anterior, lo encienda quien
        // lo encienda y esté donde esté.
        if (canShow)
        {
            if (_hintEncendido != null && _hintEncendido != this)
                _hintEncendido.SetHintVisible(false);
            _hintEncendido = this;
        }
        else if (_hintEncendido == this)
        {
            _hintEncendido = null;
        }

        // Matar cualquier tween anterior
        _hintTween?.Kill();
        
        if (canShow)
        {
            // Mostrar con animación
            hint.SetActive(true);
            hint.transform.localScale = Vector3.zero;
            _hintTween = hint.transform.DOScale(_hintOriginalScale, hintAnimDuration)
                .SetEase(Ease.OutCubic)
                .SetUpdate(true); // Usar tiempo no escalado por si está en pausa
        }
        else
        {
            // Ocultar con animación
            _hintTween = hint.transform.DOScale(Vector3.zero, hintAnimDuration * 0.7f)
                .SetEase(Ease.InCubic)
                .SetUpdate(true)
                .OnComplete(() =>
                {
                    if (hint != null)
                        hint.SetActive(false);
                });
        }
    }

    public bool CanInteract(GameObject interactor)
    {
        if (_partyMember == null)
            _partyMember = GetComponent<NPCPartyMember>() ?? GetComponentInParent<NPCPartyMember>();

        var dm = DialogueManager.Instance;
        if (dm != null && dm.IsOpen)
            return false;
        if (!GameState.CanInteractGlobally)
            return false;
        if (Time.unscaledTime < s_globalCooldownUntil)
            return false;

        // Los personajes del grupo (Will, Liam, Estela) no son interactuables entre sí: solo
        // reciben las órdenes del modo Libre de CompanionFollowPrompt. Ver INC-754 e INC-1200.
        if (EsPersonajeDelGrupo())
            return HayOrdenDelGrupo() && !IsInteractionBlockedByCurrentState(interactor);

        if (!enabledForUse)
            return false;
        if (singleUse && used)
            return false;

        // Un NPC en cinemática (una secuencia lo retiene, o guía al jugador a un sitio) no se
        // puede interrumpir: ni botón A ni acción. Ver INC-462.
        if (_npcManager != null && _npcManager.Context != null && _npcManager.Context.IsInCinematic)
            return false;

        // Bloqueo central: durante combate/diálogo/cinemática no permitir nuevas interacciones
        if (IsInteractionBlockedByCurrentState(interactor))
            return false;
        
        // Bloquear interacción si el NPC está ejecutando una narrativa
        var narrativeExecutor = GetComponent<Game.NPC.Modules.NPCInteractiveNarrativeExecutor>();
        if (narrativeExecutor != null && narrativeExecutor.IsExecuting)
            return false;

        // No mostrar el hint si el NPCWorldPoint ya está ocupado por OTRO ocupante. Si el ocupante
        // es el propio interactor (p.ej. el jugador ya está tumbado/sentado aquí), SÍ dejamos pasar:
        // así el mismo botón A que se usó para tumbarse sirve para despertarse/levantarse (ver
        // StartWorldPointActivity). FIX (15 ago 2026): antes esto bloqueaba siempre que estaba
        // ocupado, así que "A" no hacía nada mientras el jugador dormía — la única forma de
        // levantarse era el botón de cancelar (B/Circle), que no coincide con el icono "A" que
        // se sigue mostrando en pantalla.
        if (_worldPoint != null && _worldPoint.IsOccupied && !_worldPoint.IsOccupiedBy(interactor != null ? interactor.transform : null))
            return false;

        // Comprobar proximidad al punto de interacción exacto (evita activar desde lejos)
        if (_worldPoint != null && interactor != null)
        {
            float dist = Vector3.Distance(interactor.transform.position, _worldPoint.InteractionPosition);
            if (dist > _worldPoint.requiredProximity)
                return false;
        }

        return true;
    }

    public void Interact(GameObject interactor)
    {
        // Verificar si este NPC requiere Will como personaje activo
        var willOnly = GetComponent<WillOnlyInteractable>();
        if (willOnly != null && !willOnly.IsWillActive())
        {
            willOnly.ShowFeedback();
            return;
        }

        if (!CanInteract(interactor)) return;

        // IMPORTANTE: Establecer cooldown en PlayerActionManager para evitar que el botón A
        // se procese como salto inmediatamente después de interactuar
        PlayerActionManager actionManager = null;
        if (interactor != null)
        {
            actionManager = interactor.GetComponent<PlayerActionManager>() ??
                            interactor.GetComponentInParent<PlayerActionManager>();
        }
        if (actionManager == null)
        {
            PlayerService.TryGetComponent(out actionManager, includeInactive: true, allowSceneLookup: true);
        }
        if (actionManager != null)
        {
            actionManager.SetInteractCooldown();
        }

        OnInteract?.Invoke(interactor);

        // Con un personaje o miembro del grupo, la interacción es la orden de CompanionFollowPrompt
        // (ya atendida en OnInteract): sin diálogo ni narrativa. El Will de la IA no es miembro
        // del grupo, pero sí personaje.
        if (EsPersonajeDelGrupo() || (_partyMember != null && _partyMember.IsInParty))
            return;

        // El Brain reserva las charlas esperadas por el grafo antes del diálogo o servicio local.
        if (_npcManager != null)
        {
            if (mode == InteractableMode.HandOffToTarget)
            {
                _npcManager.HandleInteraction(interactor);
                return;
            }
            if (_npcManager.TryHandleNarrativeInteraction()) return;

            // La frase que el grafo asigna ahora al NPC sustituye a su diálogo por defecto; lo que
            // va después del diálogo (p. ej. abrir su tienda con OnFinished) sigue igual.
            if (_npcManager.TryGetStandingLine(out var frase))
            {
                if (mode == InteractableMode.OpenDialogue)
                {
                    StartDialogue(frase);
                    NarrativeStandingLines.MarkSaid(_npcManager.PersistenceId, frase);
                }
                else NarrativeStandingLines.TryPlay(_npcManager.PersistenceId, transform);
                return;
            }
        }
        
        // ✅ PRIORIDAD: Si hay un NPCInteractiveNarrativeExecutor con narrativas condicionales,
        // delegar a él en lugar de ejecutar el diálogo por defecto
        var narrativeExecutor = GetComponent<Game.NPC.Modules.NPCInteractiveNarrativeExecutor>();
        if (narrativeExecutor != null)
        {
            var config = narrativeExecutor.GetConfiguration();
            if (config != null && config.HasAvailableNarrative())
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Interactable:{name}] 🎭 Delegando a NPCInteractiveNarrativeExecutor (tiene narrativas condicionales disponibles)");
#endif
                bool success = narrativeExecutor.TryExecuteNarrative();
                if (success)
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.Log($"[Interactable:{name}] ✅ Narrativa condicional ejecutada exitosamente");
#endif
                    return; // ✅ Salir - no ejecutar el diálogo por defecto
                }
                else
                {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                    Debug.LogWarning($"[Interactable:{name}] ⚠️ TryExecuteNarrative() falló, usando diálogo por defecto");
#endif
                }
            }
            else
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Interactable:{name}] ℹ️ NPCInteractiveNarrativeExecutor existe pero no hay narrativas disponibles, usando diálogo por defecto");
#endif
            }
        }
        
        // Si no hay NPCInteractiveNarrativeExecutor o no tiene narrativas disponibles,
        // ejecutar el comportamiento por defecto del Interactable
        switch (mode)
        {
            case InteractableMode.OpenDialogue:
                StartDialogue(dialogue);
                break;
            case InteractableMode.OpenDialogueWithOptions:
                StartDialogueWithOptions();
                break;
            case InteractableMode.UseWorldPoint:
                StartWorldPointActivity(interactor);
                break;
            case InteractableMode.ConfirmationPopup:
                StartConfirmationPopup();
                break;
            case InteractableMode.Custom:
                // El evento OnInteract (que se ha disparado antes) es todo el comportamiento: no
                // hay diálogo ni popup que abrir.
                break;
        }
    }

    public void InteractWithPlayer()
    {
        TryInteractWithPlayer();
    }

    public bool TryInteractWithPlayer()
    {
        if (!PlayerService.TryGetPlayer(out var playerGo, allowSceneLookup: true) || playerGo == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[Interactable] Could not locate Player for interaction via PlayerService.");
#endif
            return false;
        }

        Interact(playerGo);
        return true;
    }

    private bool IsInteractionBlockedByCurrentState(GameObject interactor)
    {
        // Regla global: si existe combate activo en el mundo, no se permite interactuar.
        if (ActiveCombatRegistry.Count > 0)
        {
            ActiveCombatRegistry.CleanupDestroyedNPCs();
            if (ActiveCombatRegistry.Count > 0)
                return true;
        }

        PlayerActionManager actionManager = null;
        if (interactor != null)
        {
            actionManager = interactor.GetComponent<PlayerActionManager>() ??
                            interactor.GetComponentInParent<PlayerActionManager>();
        }
        if (actionManager == null)
        {
            PlayerService.TryGetComponent(out actionManager, includeInactive: true, allowSceneLookup: true);
        }
        if (actionManager != null && !actionManager.CanInteract())
            return true;

        Game.Player.PlayerBattleModeController battleController = null;
        if (interactor != null)
        {
            battleController = interactor.GetComponent<Game.Player.PlayerBattleModeController>() ??
                               interactor.GetComponentInParent<Game.Player.PlayerBattleModeController>();
        }
        if (battleController == null)
        {
            PlayerService.TryGetComponent(out battleController, includeInactive: true, allowSceneLookup: true);
        }
        if (battleController != null && battleController.IsInBattleMode)
            return true;

        return false;
    }

    void StartDialogue(DialogueAsset asset)
    {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
        Debug.Log($"[Interactable:{name}] 📖 StartDialogue - dialogue={asset?.name}");
#endif
        
        // ✅ REPRODUCIR ANIMACIÓN DE INTERACCIÓN (si no es batalla)
        var npcAnimator = GetComponent<NPCSimpleAnimator>();
        if (npcAnimator != null && _npcManager != null)
        {
            // Solo reproducir animación si NO está en combate
            if (_npcManager.Context == null || !_npcManager.Context.IsInCombat)
            {
                StartCoroutine(PlayInteractionAnimation(npcAnimator));
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Interactable:{name}] 🎭 Reproduciendo animación de interacción");
#endif
            }
        }
        
        var dm = DialogueManager.Instance;
        if (asset && dm != null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Interactable:{name}] ✅ Iniciando diálogo: {asset.name}");
#endif
            OnStarted?.Invoke();
            GameState.Push(GamePhase.Dialogue);

            // ✅ FIX: bloquear Wander/Idle mientras dura el diálogo por defecto.
            // Sin esto, un NPC con enableWander sigue caminando durante todo el diálogo
            // porque este flujo (a diferencia de NPCInteractiveNarrativeExecutor) nunca
            // pasaba por el Brain ni tocaba Context.IsInteracting.
            SetNpcInteracting(true);

            // ✅ NPCSimpleAnimator maneja la rotación del NPC (suscrito a eventos de DialogueManager)
            dm.StartDialogue(asset, transform, () =>
            {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Interactable:{name}] 🔚 Diálogo terminado");
#endif
                SetNpcInteracting(false);
                OnFinished?.Invoke();
                if (GameState.Is(GamePhase.Dialogue)) GameState.Pop(GamePhase.Dialogue);
                AfterUse();
            });
        }
        else
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[Interactable] No DialogueAsset o DialogueManager en {name}.");
#endif
            AfterUse();
        }
    }
    
    /// <summary>
    /// Reproduce la animación de interacción en el NPC
    /// </summary>
    private System.Collections.IEnumerator PlayInteractionAnimation(NPCSimpleAnimator npcAnimator)
    {
        // Reproducir animación de interacción
        npcAnimator.PlayOneShot("Talk01", 0, onComplete: null);
        
        // Esperar un frame
        yield return null;
    }

    void StartDialogueWithOptions()
    {
        // ✅ REPRODUCIR ANIMACIÓN DE INTERACCIÓN (si no es batalla)
        var npcAnimator = GetComponent<NPCSimpleAnimator>();
        if (npcAnimator != null && _npcManager != null)
        {
            // Solo reproducir animación si NO está en combate
            if (_npcManager.Context == null || !_npcManager.Context.IsInCombat)
            {
                StartCoroutine(PlayInteractionAnimation(npcAnimator));
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
                Debug.Log($"[Interactable:{name}] 🎭 Reproduciendo animación de interacción (con opciones)");
#endif
            }
        }
        
        var dm = DialogueManager.Instance;
        if (dm == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning("[Interactable] DialogueManager no disponible.");
#endif
            return;
        }

        // Resolver textos desde DialogueAssets (localizados por el propio manager o por LocalizationManager en SavePoint, según tu flujo)
        string prompt = ResolveDialogueText(dialogue, string.Empty);
        string yes = ResolveDialogueText(yesOption, "Sí");
        string no = ResolveDialogueText(noOption, "No");

        OnStarted?.Invoke();
        // Ocultar el hint del interactable mientras aparecen las opciones
        SetHintVisible(false);
        // Bloquear otros menús mientras se muestran las opciones
        GameState.Push(GamePhase.SavePrompt);

        // ✅ FIX: mismo motivo que StartDialogue() - evitar que el NPC siga vagando
        // mientras se muestra el diálogo con opciones. Se libera en HandleChoiceResult().
        SetNpcInteracting(true);

        // NPCSimpleAnimator maneja la rotación del NPC (suscrito a eventos de DialogueManager)

        try
        {
            dm.ShowWithChoices(prompt, yes, no,
                onYes: () => {
                    HandleChoiceResult(confirmFollowUp, invokeConfirm: true);
                },
                onNo:  () => {
                    HandleChoiceResult(cancelFollowUp, invokeConfirm: false);
                }
            );
            PlayPromptVoice();
        }
        catch (System.Exception
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            ex
#endif
        )
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogError($"[Interactable] ShowWithChoices failed: {ex.Message}\n{ex.StackTrace}");
#endif
            if (GameState.Is(GamePhase.SavePrompt)) GameState.Pop(GamePhase.SavePrompt);
            SetNpcInteracting(false);
        }
    }

    /// <summary>
    /// FIX INC-048: variante de StartDialogueWithOptions() que usa el popup de confirmación
    /// unificado (ConfirmationPopupUI) en vez del cuadro de diálogo con opciones. Reutiliza los
    /// mismos campos serializados (dialogue = mensaje, confirmFollowUp/cancelFollowUp = diálogo
    /// opcional posterior, OnConfirm = evento al confirmar) para no duplicar configuración en el
    /// Inspector ni romper los Interactables existentes en modo OpenDialogueWithOptions.
    /// </summary>
    void StartConfirmationPopup()
    {
        var npcAnimator = GetComponent<NPCSimpleAnimator>();
        if (npcAnimator != null && _npcManager != null)
        {
            if (_npcManager.Context == null || !_npcManager.Context.IsInCombat)
                StartCoroutine(PlayInteractionAnimation(npcAnimator));
        }

        var popup = ConfirmationPopupUI.Instance;
        if (popup == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[Interactable:{name}] ConfirmationPopupUI.Instance es null (¿Start.unity no está cargada?). Usando diálogo con opciones como fallback.");
#endif
            StartDialogueWithOptions();
            return;
        }

        string prompt = ResolveDialogueText(dialogue, string.Empty);

        OnStarted?.Invoke();
        SetHintVisible(false);
        GameState.Push(GamePhase.SavePrompt);

        // ✅ FIX: mismo motivo que StartDialogue() - ver comentario allí.
        SetNpcInteracting(true);

        popup.Show(prompt,
            onConfirm: () => HandleChoiceResult(confirmFollowUp, invokeConfirm: true),
            onCancel:  () => HandleChoiceResult(cancelFollowUp, invokeConfirm: false),
            quien: ResolveSpeakerName(dialogue));
        PlayPromptVoice();
    }

    private AudioClip _promptVoice;

    private void StopPromptVoice()
    {
        var audio = AudioService.Instance;
        if (audio != null && audio.IsVoicePlaying(_promptVoice)) audio.StopVoice();
        _promptVoice = null;
    }

    private void PlayPromptVoice()
    {
        if (dialogue == null || dialogue.lines == null || dialogue.lines.Length == 0) return;
        var line = dialogue.lines[0];
        string key = !string.IsNullOrEmpty(line.textId) ? line.textId : (LooksLikeKey(line.text) ? line.text : null);
        if (VoiceLines.TryPlay(key) > 0f) VoiceLines.TryGet(key, out _promptVoice);
    }

    string ResolveDialogueText(DialogueAsset asset, string fallback)
    {
        if (asset == null || asset.lines == null || asset.lines.Length == 0) return fallback;
        var line = asset.lines[0];
        string textId = line.textId;
        string text = line.text;
        if (!string.IsNullOrEmpty(textId) && LocalizationManager.Instance != null)
        {
            return LocalizationManager.Instance.Get(textId, string.IsNullOrEmpty(text) ? fallback : text);
        }
        // Si text parece una clave (MAYÚS_CON_GUIONES), intentar localizarla
        if (!string.IsNullOrEmpty(text) && LocalizationManager.Instance != null && LooksLikeKey(text))
        {
            return LocalizationManager.Instance.Get(text, text);
        }
        return string.IsNullOrEmpty(text) ? fallback : text;
    }

    /// Nombre de quien dice la primera línea, tal como se ve en la caja de diálogo.
    string ResolveSpeakerName(DialogueAsset asset)
    {
        if (asset == null || asset.lines == null || asset.lines.Length == 0) return null;
        string id = asset.lines[0].speakerNameId;
        if (string.IsNullOrEmpty(id)) return null;
        return LocalizationManager.Instance != null ? LocalizationManager.Instance.Get(id, id) : id;
    }

    bool LooksLikeKey(string value)
    {
        if (string.IsNullOrEmpty(value)) return false;
        var trimmed = value.Trim();
        if (trimmed.Length == 0) return false;
        bool hasUnderscore = trimmed.Contains('_');
        bool isUpper = trimmed.ToUpperInvariant() == trimmed;
        return hasUnderscore && isUpper;
    }

    void HandleChoiceResult(DialogueAsset followUp, bool invokeConfirm)
    {
        StopPromptVoice();
        if (invokeConfirm)
            OnConfirm?.Invoke();

        if (GameState.Is(GamePhase.SavePrompt))
            GameState.Pop(GamePhase.SavePrompt);

        // Armar un pequeño cooldown tras cerrar el prompt para evitar reabrir al instante
        s_globalCooldownUntil = Time.unscaledTime + 0.25f;

        var dm = DialogueManager.Instance;
        if (followUp != null && dm != null)
        {
            // Sigue habiendo diálogo (follow-up): mantener IsInteracting hasta que también termine.
            dm.StartDialogue(followUp, transform, () =>
            {
                SetNpcInteracting(false);
                OnFinished?.Invoke();
                AfterUse();
            });
        }
        else
        {
            if (dm != null)
                dm.FinalizeChoiceNoFollowUp();
            SetNpcInteracting(false);
            OnFinished?.Invoke();
            AfterUse();
        }
    }

    /// <summary>
    /// Bloquea/libera el movimiento ambiental (Wander/Idle) del NPC mientras dura un diálogo
    /// que no pasa por NPCBrain (StartDialogue, StartDialogueWithOptions, StartConfirmationPopup).
    /// Sin esto, un NPC con enableWander sigue caminando durante el diálogo.
    /// </summary>
    void SetNpcInteracting(bool interacting)
    {
        if (_npcManager?.Context != null)
            _npcManager.Context.IsInteracting = interacting;
    }

    void StartWorldPointActivity(GameObject interactor)
    {
        if (_worldPoint == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[Interactable:{name}] UseWorldPoint configurado pero no hay NPCWorldPoint en este objeto.");
#endif
            return;
        }

        var handler = interactor != null
            ? interactor.GetComponent<PlayerAmbientActivityHandler>()
              ?? interactor.GetComponentInParent<PlayerAmbientActivityHandler>()
            : null;

        if (handler == null)
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.LogWarning($"[Interactable:{name}] No se encontró PlayerAmbientActivityHandler en el interactor.");
#endif
            return;
        }

        // FIX (15 ago 2026): si el propio interactor ya está ocupando este punto (durmiendo/sentado
        // aquí), pulsar Interactuar otra vez debe despertarlo/levantarlo, no intentar TryOccupy() de
        // nuevo — eso siempre devuelve false porque ya está ocupado, y antes de este fix el botón A
        // simplemente no hacía nada mientras el jugador dormía (ver CanInteract más arriba).
        if (_worldPoint.IsOccupiedBy(interactor.transform))
        {
            handler.StopActivity();
            return;
        }

        if (!_worldPoint.TryOccupy(interactor.transform))
        {
#if UNITY_EDITOR || UNITY_INCLUDE_INSTRUMENTATION
            Debug.Log($"[Interactable:{name}] NPCWorldPoint ya ocupado — no se puede iniciar actividad.");
#endif
            return;
        }

        handler.StartActivity(_worldPoint);
    }

    void AfterUse()
    {
        if (singleUse && !used)
        {
            used = true;
            MarkConsumedInPreset();
            OnConsumed?.Invoke();
        }
        SetHintVisible(false);
    }

    /// Se puede usar ahora (EnableInteraction).
    public bool HabilitadoParaUsar => enabledForUse;

    public void EnableInteraction(bool enable)
    {
        enabledForUse = enable;
        if (!enable) SetHintVisible(false);
    }

    public string DialogueCharacterId => dialogueCharacterId;
    public void SetDialogue(DialogueAsset asset) => dialogue = asset;
    public void SetMode(InteractableMode newMode) => mode = newMode;

    internal void RegisterNPCManager(NPCBehaviourManagerV2 manager)
    {
        _npcManager = manager;
    }

    internal void UnregisterNPCManager(NPCBehaviourManagerV2 manager)
    {
        if (_npcManager == manager)
            _npcManager = null;
    }

    string GetPersistentId()
    {
        // Si hay un override explícito, usarlo directamente
        if (!string.IsNullOrEmpty(persistentIdOverride))
            return persistentIdOverride;

        // Construir ID único basado en escena + nombre + posición
        var sceneName = includeSceneInPersistentId && gameObject.scene.IsValid()
            ? gameObject.scene.name
            : string.Empty;

        // Incluir posición para garantizar unicidad entre objetos con el mismo nombre
        var posKey = IdDePersistencia.ClaveDePosicion(transform.position);

        if (string.IsNullOrEmpty(sceneName))
            return $"{gameObject.name}_{posKey}";
        else
            return $"{sceneName}:{gameObject.name}_{posKey}";
    }

    void MarkConsumedInPreset()
    {
        if (!GameBootService.IsAvailable || !singleUse)
            return;

        var preset = Partida.Preset;
        if (preset == null)
            return;

        var id = GetPersistentId();
        if (string.IsNullOrEmpty(id))
            return;

        preset.consumedInteractableIds ??= new List<string>();
        if (!preset.consumedInteractableIds.Contains(id))
            preset.consumedInteractableIds.Add(id);
    }

    void RestoreSingleUseStateFromPreset()
    {
        if (!singleUse || used)
            return;

        var preset = Partida.Preset;
        if (preset == null || preset.consumedInteractableIds == null)
            return;

        var id = GetPersistentId();
        if (string.IsNullOrEmpty(id))
            return;

        if (preset.consumedInteractableIds.Contains(id))
        {
            used = true;
            SetHintVisible(false);
        }
    }
}
